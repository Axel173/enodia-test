#!/bin/sh



































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}


ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}





HOTPLUG_HOOK=/etc/hotplug.d/block/99-enodia-usb
ETC_LEFTOVERS="/etc/init.d/enodia-early /etc/rc.d/S20enodia-early /etc/enodia-persist"
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }


if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }
command -v pkg_install_alive >/dev/null 2>&1 || pkg_install_alive() { return 1; }
command -v uninstall_alive >/dev/null 2>&1 || uninstall_alive() {
    _ual=$(cat /tmp/enodia-uninstall.pid 2>/dev/null | tr -cd '0-9'); pid_runs "$_ual" 'uninstall\.sh (deactivate|purge)'; }
SELF=/tmp/enodia-uninstall.sh              # копия для purge (см. выше)
UN_PID=/tmp/enodia-uninstall.pid           # «идёт снятие» для установщика кода (daemon-lib.sh::uninstall_alive)









REPORT=/data/usr/enodia-uninstall.log
STATE="$ENODIA_STATE/.uninstall.state"       # RUNNING|OK|FAIL — панель опрашивает, пока жива






if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v store_ready >/dev/null 2>&1 || store_ready() { return 1; }
command -v store_root >/dev/null 2>&1 || store_root() { printf ''; }

log() { printf '[%s] %s\n' "$(date '+%H:%M:%S')" "$*" >> "$REPORT"; echo "$*"; }


set_state() { [ -d "$ENODIA_DIR" ] && { echo "$1" > "$STATE.new" 2>/dev/null && mv -f "$STATE.new" "$STATE" 2>/dev/null; }; return 0; }




run() { [ -f "$ENODIA_DIR/$1" ] || return 0; _s="$1"; shift; sh "$ENODIA_DIR/$_s" "$@" >> "$REPORT" 2>&1; return 0; }








CHAINS_MANGLE="VPN_EXCLUDE VPN_FORCE VPN_PORTS VPN_KEEP VPN_DEV ENODIA_ZAPRET"
CHAINS_FILTER="ENODIA_BLK ENODIA_GEOBLK VPNSRV_IN VPNSRV_FWD VPNSRV_WAN"


CHAIN_PARENTS="INPUT FORWARD input_wan_rule"



SET_PREFIXES="enodia_ iplist_ grp_ geo_ zapret_ blocklist_ xiaomi_"









DAEMON_DIRS="$ENODIA_DIR $ENODIA_BIN"
[ "${BIN_DIR:-$ENODIA_BIN}" != "$ENODIA_BIN" ] && DAEMON_DIRS="$DAEMON_DIRS $BIN_DIR"
DAEMONS="amneziawg-go xray hysteria byedpi hev nfqws https-dns-proxy dot-proxy"




DAEMONS_PURGE="panel-tls"

IFACES="awg0 awg2 awg3 awg4 awgs0 xtun xtun2 xtun3 xtun4"
TABLES="1000 1002 1003 1004"












GUEST_RULE_SHOW="^200:.*from 192.168.33.0/24 lookup 200"
GUEST_RULE_DEL="from 192.168.33.0/24 table 200 pref 200"
GUEST_BYPASS_SHOW="^90:.*from 192.168.33.0/24 lookup main"
GUEST_BYPASS_DEL="from 192.168.33.0/24 lookup main pref 90"



GUEST_DNS_SHOW="^100:.*from 192.168.33.0/24 to 192.168.33.1 dport 53 lookup main"
GUEST_DNS_DEL="from 192.168.33.0/24 to 192.168.33.1 dport 53 table main pref 100"

























RAM_GLOBS="/tmp/enodia-* /tmp/.enodia-*
/tmp/xray.log* /tmp/xray-access.log /tmp/xray-s*.log /tmp/xray-test.*.log"






RAM_GLOBS_LEGACY="/tmp/.awg-* /tmp/awg-uninstall.sh* /tmp/panel-token /tmp/hev*.yaml
/tmp/doh.log /tmp/notify.log /tmp/support.log /tmp/iplist-update.log /tmp/switch-vpn-setup.log
/tmp/notify-event.log /tmp/transport-awg-setup.log /tmp/panel-tls.log /tmp/xiaomi-bypass.log
/tmp/subs-update.log /tmp/byedpi.log /tmp/byedpi-fetch.log /tmp/byedpi-test-run.log
/tmp/hysteria.log /tmp/zapret-nfqws.log /tmp/hev.log /tmp/hev-s*.log
/tmp/.bin-manifest.* /tmp/.carrier-up.stamp /tmp/.cpu-stat /tmp/.curl-cafile /tmp/.dns-merge.*
/tmp/.doh-* /tmp/.grp-apply.* /tmp/.grp-pairs /tmp/.ip6t-wait /tmp/.ipt-wait /tmp/.lists-reg.*
/tmp/.set-snap* /tmp/.slots.lock /tmp/.support-* /tmp/.totp-* /tmp/.vpnsrv-* /tmp/.zapret-*
/tmp/.05-dhcp-static.conf.stage /tmp/awg0.seen /tmp/awgs0.conf /tmp/byedpi* /tmp/devwatch-stop.*
/tmp/doh.pid /tmp/geo /tmp/geo*.pid /tmp/gh-update.* /tmp/hev.pid /tmp/hev-s*.pid
/tmp/hysteria* /tmp/iplist.txt /tmp/iplist-restore.pid /tmp/lists /tmp/lists-*.pid
/tmp/notify-event.* /tmp/panel-pass.pid /tmp/panel-reboot.pid /tmp/panel-tls.*
/tmp/ping-active-dead /tmp/proto-install.* /tmp/subs-update* /tmp/support-tunnel.pid
/tmp/traffic-acct.lock /tmp/uhttpd-web.pid /tmp/uninstall.pid /tmp/xray.pid /tmp/xray-s*.pid
/tmp/xray-test.*.json /tmp/xray-test.*.out /tmp/xray-test.*.pid /tmp/zapret-*"   # legacy-name: имена до 29.08, до 02.09 и до 03.09.2026








HOSTS_TAG="# awg-seed"











CRON_PANEL="web-ui.sh"







cron_ours() { grep -F -e "$ENODIA_BOOT/boot.sh" -e "$ENODIA_DIR/" "$@"; }
DNSMASQ_KEEP="05-dhcp-static.conf"




DNSMASQ_CONF=/etc/dnsmasq.conf
DNSMASQ_DIR=/etc/dnsmasq.d





DNSMASQ_LINE="conf-dir=$DNSMASQ_DIR,*.conf"


DNSMASQ_MARK="добавлено Enodia"



DNSMASQ_MARK_OLD="добавлено awg-setup-be7000"


CRON_SAVE="$ENODIA_STATE/.cron-saved"






FW_ZONE=awg







step_rules() {
    log "Снимаю правила…"
    run support.sh down                                   # удалённый доступ («режим поддержки»)
    for _id in 2 3 4; do
        run transport.sh slot-down "$_id"
        run slots.sh unwire "$_id"
    done
    run vpn-server.sh down                                # awgs0 + VPNSRV_* + правила пиров
    run zapret.sh src-clear                               # NFQUEUE устройств «целиком в десинк» (по источнику)
    run zapret.sh down                                    # nfqws + NFQUEUE + dnsmasq-сниппет
    _t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_t" ] && run transport.sh down "$_t"           # несущая: default/FORWARD/MASQ/DNS
    run mark-core.sh unwire                               # маркировка, гарды, ip rule
    for _c in $CHAINS_MANGLE; do
        while iptables -t mangle -D PREROUTING -j "$_c" 2>/dev/null; do :; done
        while iptables -t mangle -D OUTPUT -j "$_c" 2>/dev/null; do :; done
        iptables -t mangle -F "$_c" 2>/dev/null; iptables -t mangle -X "$_c" 2>/dev/null
    done
    for _c in $CHAINS_FILTER; do
        for _par in $CHAIN_PARENTS; do
            while iptables -D "$_par" -j "$_c" 2>/dev/null; do :; done
        done
        iptables -F "$_c" 2>/dev/null; iptables -X "$_c" 2>/dev/null
    done
    for _tb in $TABLES; do ip route flush table "$_tb" 2>/dev/null; done


    ct_flush
    log "Правила сняты (цепочки, марки, ip rule, таблицы $TABLES, conntrack сброшен)."
}

















sweep_chain() {      # $1=таблица $2=цепочка $3=ERE «наше» $4=count|del ; копит в $_n



    for _sc in $(iptables -t "$1" -S "$2" 2>/dev/null | grep '^-A' | grep -nE "$3" | cut -d: -f1 | sort -nr); do
        _n=$((_n+1))
        [ "$4" = del ] && iptables -t "$1" -D "$2" "$_sc" 2>/dev/null
    done
    return 0
}







rule_drop() {
    _rm="$1"; _rp="$2"; shift 2
    _ri=0
    while [ "$_ri" -lt 20 ] && ip rule show 2>/dev/null | grep -q "$_rp"; do
        _ri=$((_ri+1)); _n=$((_n+1))
        [ "$_rm" = del ] || break        # в режиме подсчёта хватает одного факта
        ip rule del "$@" 2>/dev/null || break
    done
    return 0
}

sweep_run() {        # $1 = count|del ; $2 = keep → цепочки ПАНЕЛИ не наши (deactivate, см. CRON_PANEL)
    _n=0
    _sp=$(echo $SET_PREFIXES | sed 's/  */|/g')
    _if=$(echo $IFACES | sed 's/  */|/g')



    _jump="AWG|VPN_|VPNSRV"
    [ "$2" = keep ] || _jump="$_jump|PANEL_WAN"
    _our="match-set ($_sp)|-[io] ($_if)|-j ($_jump)"


    for _pr in "mangle PREROUTING" "mangle OUTPUT" "mangle POSTROUTING" "nat PREROUTING" \
               "nat POSTROUTING" "filter INPUT" "filter FORWARD" "filter OUTPUT"; do
        sweep_chain "${_pr% *}" "${_pr#* }" "$_our" "$1"
    done


    for _tb in mangle nat filter; do
        for _ch in $(iptables -t "$_tb" -S 2>/dev/null | awk '/^-N/{print $2}'); do
            if [ "$2" = keep ]; then case "$_ch" in PANEL_WAN*) continue ;; esac; fi
            case "$_ch" in
                AWG*|VPN_*|VPNSRV_*|PANEL_WAN*)
                    _n=$((_n+1))
                    if [ "$1" = del ]; then
                        iptables -t "$_tb" -F "$_ch" 2>/dev/null
                        iptables -t "$_tb" -X "$_ch" 2>/dev/null
                    fi ;;
            esac
        done
    done




    for _tb in $TABLES; do
        _i=0
        while [ "$_i" -lt 20 ] && ip rule show 2>/dev/null | grep -qE "lookup $_tb( |\$)"; do
            _i=$((_i+1)); _n=$((_n+1))
            [ "$1" = del ] || break                      # в режиме подсчёта хватает одного факта
            ip rule del table "$_tb" 2>/dev/null || break
        done
    done




    rule_drop "$1" "$GUEST_RULE_SHOW"   $GUEST_RULE_DEL
    rule_drop "$1" "$GUEST_BYPASS_SHOW" $GUEST_BYPASS_DEL
    rule_drop "$1" "$GUEST_DNS_SHOW"    $GUEST_DNS_DEL
    echo "$_n"
}

step_sweep() {       # $1 = keep → цепочки панели оставляем (deactivate)
    _sw=$(sweep_run del "$1")
    ct_flush      # сняли правила — вердикт в conntrack протух (грабля №1)
    log "Доборка по факту: снято артефактов $_sw (правила, цепочки, ip rule — независимо от того, кто их ставил)."
}








step_hosts() {
    grep -qF "$HOSTS_TAG" /etc/hosts 2>/dev/null || return 0
    grep -vF "$HOSTS_TAG" /etc/hosts > /etc/hosts.enodiatmp 2>/dev/null
    [ -f /etc/hosts.enodiatmp ] && mv -f /etc/hosts.enodiatmp /etc/hosts
    rm -f /etc/hosts.enodiatmp 2>/dev/null
    log "/etc/hosts: строки сида server-host сняты."
}




step_ram() {         # $1 = full → вместе с логами и снимками (только purge)
    [ "$1" = full ] || return 0


    if [ -f "$ENODIA_DIR/clean.sh" ]; then
        for _rl in $(sh "$ENODIA_DIR/clean.sh" ramlogs-list 2>/dev/null); do rm -f "$_rl" 2>/dev/null; done
    fi
    _rn=0
    for _rg in $RAM_GLOBS $RAM_GLOBS_LEGACY; do
        for _rf in $_rg; do
            [ -e "$_rf" ] || continue
            [ "$_rf" = "$SELF" ] && continue     # мы ИЗ него сейчас и читаемся (busybox дочитывает по ходу)
            rm -rf "$_rf" 2>/dev/null; _rn=$((_rn+1))
        done
    done
    log "RAM: удалено объектов в /tmp $_rn (локи, штампы, снимки наборов, логи)."
}











daemons_pids() {      # $1 = дополнительные демоны (только purge, см. DAEMONS_PURGE)
    for _pp in /proc/[0-9]*; do
        [ -r "$_pp/cmdline" ] || continue
        _cl="$(tr '\0' ' ' < "$_pp/cmdline" 2>/dev/null) "
        _dh=0
        for _dp in $DAEMON_DIRS; do
            for _db in $DAEMONS $1; do
                case "$_cl" in *"$_dp/$_db "*) _dh=1 ;; esac
            done
        done
        [ "$_dh" = 1 ] && echo "${_pp#/proc/}"
    done
    return 0
}













step_jobs() {
    _n=0
    for _pp in /proc/[0-9]*; do
        _jp=${_pp#/proc/}
        [ "$_jp" = "$$" ] && continue
        [ "$_jp" = "$PPID" ] && continue
        [ -r "$_pp/cmdline" ] || continue
        case "$(tr '\0' ' ' < "$_pp/cmdline" 2>/dev/null)" in
            *"$ENODIA_DIR/"*.sh*) kill "$_jp" 2>/dev/null; _n=$((_n+1)) ;;
        esac
    done
    [ "$_n" = 0 ] || sleep 1        # шанс завершиться штатно и отпустить локи
    log "Фоновых заданий остановлено: $_n."
}



step_daemons() {      # $1 = дополнительные демоны (только purge, см. DAEMONS_PURGE)
    log "Гашу демоны…"
    _extra="$1"
    _n=0
    for _pid in $(daemons_pids "$_extra"); do kill "$_pid" 2>/dev/null; _n=$((_n+1)); done




    [ "$_n" = 0 ] || sleep 1
    _i=0
    while [ "$_i" -lt 10 ]; do
        _left=$(daemons_pids "$_extra")
        [ -n "$_left" ] || break
        for _pid in $_left; do kill -9 "$_pid" 2>/dev/null; done
        _i=$((_i+1))
    done
    for _if in $IFACES; do ip link del "$_if" 2>/dev/null; done
    rm -rf /var/run/amneziawg /var/run/wireguard 2>/dev/null   # stale UAPI-сокеты
    log "Демонов остановлено: $_n; интерфейсы сняты."
}




step_cron() {        # $1 = keep → строку панели оставляем, снятое помним (deactivate)
    _ct=/etc/crontabs/root
    _kept=""
    [ -f "$_ct" ] || return 0
    _was=$(cron_ours -c "$_ct" 2>/dev/null); [ -n "$_was" ] || _was=0






    cron_ours -v "$_ct" > "$_ct.new" 2>/dev/null
    if [ "$1" = keep ]; then



        _was=$(cron_ours "$_ct" 2>/dev/null | grep -vcF "$CRON_PANEL")
        case "$_was" in ''|*[!0-9]*) _was=0 ;; esac


        cron_ours "$_ct" 2>/dev/null | grep -vF "$CRON_PANEL" > "$CRON_SAVE.new" 2>/dev/null
        if [ -s "$CRON_SAVE.new" ]; then mv "$CRON_SAVE.new" "$CRON_SAVE"; else rm -f "$CRON_SAVE.new"; fi


        if [ "$_was" != 0 ] && [ ! -s "$CRON_SAVE" ]; then
            log "ВНИМАНИЕ: расписание снято, но запомнить его не вышло ($CRON_SAVE) — после «включить» проверьте cron."
        fi
        cron_ours "$_ct" 2>/dev/null | grep -F "$CRON_PANEL" >> "$_ct.new" 2>/dev/null
        _kept=" (строка панели оставлена — ею панель поднимается после ребута)"
    fi
    [ -f "$_ct.new" ] && mv "$_ct.new" "$_ct"
    /etc/init.d/cron restart >/dev/null 2>&1 || /etc/init.d/crond restart >/dev/null 2>&1
    log "Cron: снято строк $_was$_kept."
}







cmd_cron_restore() {


    if [ -f "$ENODIA_STATE/server/.on-deact" ]; then mv -f "$ENODIA_STATE/server/.on-deact" "$ENODIA_STATE/server/.on" 2>/dev/null; fi
    [ -s "$CRON_SAVE" ] || { echo "расписание не снималось — возвращать нечего"; return 0; }
    _ct=/etc/crontabs/root
    mkdir -p /etc/crontabs 2>/dev/null
    [ -f "$_ct" ] || : > "$_ct"
    _n=0

    while IFS= read -r _l || [ -n "$_l" ]; do
        [ -n "$_l" ] || continue












        _sc=""
        set -f
        for _w in $_l; do
            case "$_w" in
                */boot.sh) continue ;;
                *.sh) _sc="${_w##*/}"; break ;;
            esac
        done
        set +f
        [ -n "$_sc" ] || _sc="$_l"
        grep -qF "$_sc" "$_ct" 2>/dev/null && continue
        printf '%s\n' "$_l" >> "$_ct"
        _n=$((_n+1))
    done < "$CRON_SAVE"
    if [ "$_n" != 0 ]; then
        /etc/init.d/cron restart >/dev/null 2>&1 || /etc/init.d/crond restart >/dev/null 2>&1
    fi
    rm -f "$CRON_SAVE"
    echo "Расписание возвращено: строк $_n (сторож, самовосстановление, обновление списков)."
    return 0
}




dnsdir_empty() {
    for _dx in "$DNSMASQ_DIR"/* "$DNSMASQ_DIR"/.[!.]*; do
        [ -e "$_dx" ] && return 1
    done
    return 0
}



dnsconf_ours() {
    grep -qxF "$DNSMASQ_LINE" "$DNSMASQ_CONF" 2>/dev/null && return 0
    grep -qF -e "$DNSMASQ_MARK" -e "$DNSMASQ_MARK_OLD" "$DNSMASQ_CONF" 2>/dev/null
}















dnsmasq_ours() {     # пути НАШИХ сниппетов обоих каталогов, по одному на строку
    for _dd in /etc/dnsmasq.d /tmp/dnsmasq.d; do
        for _df in "$_dd"/[0-9][0-9]-*.conf "$_dd"/enodia-*.conf "$_dd"/awg-*.conf; do   # legacy-name: awg-* — сниппеты прежних установок
            if [ -f "$_df" ]; then echo "$_df"; fi
        done
    done
}
step_dnsmasq() {     # $1 = keep → сниппет закрепления адресов оставляем (deactivate, см. DNSMASQ_KEEP)

    _dso=$(dnsmasq_ours)
    while IFS= read -r _f; do
        [ -n "$_f" ] || continue
        if [ "$1" = keep ] && [ "${_f##*/}" = "$DNSMASQ_KEEP" ]; then continue; fi
        rm -f "$_f" 2>/dev/null
    done <<EOF
$_dso
EOF




    rm -rf /tmp/.enodia-dns-merge.* 2>/dev/null










    if [ "$1" != keep ] && dnsdir_empty && dnsconf_ours; then





        _dnstmp="${DNSMASQ_CONF%/*}/.dnsmasq.conf.uninst.$$"
        _dn0=$(wc -l < "$DNSMASQ_CONF" 2>/dev/null)
        grep -vxF "$DNSMASQ_LINE" "$DNSMASQ_CONF" | grep -vF -e "$DNSMASQ_MARK" -e "$DNSMASQ_MARK_OLD" > "$_dnstmp" 2>/dev/null
        _dn1=$(wc -l < "$_dnstmp" 2>/dev/null)
        case "$_dn0" in ''|*[!0-9]*) _dn0=0 ;; esac
        case "$_dn1" in ''|*[!0-9]*) _dn1=0 ;; esac
        if [ -s "$_dnstmp" ] && [ "$_dn1" -lt "$_dn0" ]; then
            mv "$_dnstmp" "$DNSMASQ_CONF" 2>/dev/null
            log "dnsmasq: убрал нашу строку $DNSMASQ_LINE (каталог пуст) — конфиг демона стоковый."
        fi
        rm -f "$_dnstmp" 2>/dev/null
        rmdir "$DNSMASQ_DIR" 2>/dev/null
    fi
    /etc/init.d/dnsmasq restart >/dev/null 2>&1
    log "dnsmasq: наши сниппеты удалены, служба перезапущена (резолверы провайдера вернулись)."
}














step_fwzone() {
    FW_RELOAD=0
    command -v uci >/dev/null 2>&1 || { log "firewall: uci не найден — зону не трогаю."; return 0; }
    _fwn=0


    _fwi=$(uci show firewall 2>/dev/null \
        | grep -E "^firewall\.@forwarding\[[0-9]+\]\.(src|dest)='$FW_ZONE'\$" \
        | sed 's/^firewall\.@forwarding\[//' | sed 's/\].*$//' | sort -nr | uniq)
    for _fi in $_fwi; do
        uci delete "firewall.@forwarding[$_fi]" 2>/dev/null && _fwn=$((_fwn+1))
    done
    if uci get "firewall.$FW_ZONE" >/dev/null 2>&1; then
        uci delete "firewall.$FW_ZONE" 2>/dev/null && _fwn=$((_fwn+1))
    fi
    if [ "$_fwn" = 0 ]; then
        log "firewall: нашей зоны '$FW_ZONE' нет — конфиг не трогаю."
        return 0
    fi



    if uci commit firewall 2>/dev/null; then
        FW_RELOAD=1
        log "firewall: снята зона '$FW_ZONE' и её forwarding (секций: $_fwn)."
    else
        log "firewall: зону '$FW_ZONE' снять не вышло — uci не записал конфиг (флеш занят?). Убрать вручную: uci delete firewall.$FW_ZONE && uci commit firewall."
    fi
}

















fwzone_reload() {
    if [ "$FW_RELOAD" = 1 ]; then
        /etc/init.d/firewall reload >/dev/null 2>&1
    fi
    _fwx=0
    for _tb in filter nat mangle; do
        for _ch in $(iptables -t "$_tb" -S 2>/dev/null | awk '/^-N/{print $2}'); do
            case "$_ch" in
                zone_"$FW_ZONE"|zone_"$FW_ZONE"_*|*_"$FW_ZONE"_rule)
                    iptables -t "$_tb" -X "$_ch" 2>/dev/null && _fwx=$((_fwx+1)) ;;
            esac
        done
    done
    if [ "$FW_RELOAD" = 1 ]; then
        log "firewall: перезагружен, цепочек зоны '$FW_ZONE' убрано: $_fwx."
    elif [ "$_fwx" != 0 ]; then
        log "firewall: убрано осиротевших цепочек зоны '$FW_ZONE': $_fwx."
    fi
}

fwzone_ours() {
    command -v uci >/dev/null 2>&1 || return 1
    uci get "firewall.$FW_ZONE" >/dev/null 2>&1 && return 0
    uci show firewall 2>/dev/null | grep -qE "^firewall\.@forwarding\[[0-9]+\]\.(src|dest)='$FW_ZONE'\$"
}



step_panel() {
    log "Снимаю панель…"
    run web-ui.sh wan-off
    run web-ui.sh tls-off
    run web-ui.sh stop




    if [ -f /tmp/enodia-stub.pid ]; then
        start-stop-daemon -K -p /tmp/enodia-stub.pid -x /usr/sbin/uhttpd >/dev/null 2>&1
        rm -f /tmp/enodia-stub.pid 2>/dev/null
        log "Заглушка накопителя остановлена."
    fi
    log "Панель остановлена."
}




step_hotplug() {
    _hn=0
    for _hf in "$HOTPLUG_HOOK" $ETC_LEFTOVERS; do


        { [ -e "$_hf" ] || [ -L "$_hf" ]; } || continue
        rm -f "$_hf" 2>/dev/null
        if [ -e "$_hf" ] || [ -L "$_hf" ]; then log "ВНИМАНИЕ: $_hf удалить не вышло."; else _hn=$((_hn+1)); fi
    done
    [ "$_hn" = 0 ] && return 0
    log "Следы в /etc сняты: $_hn (hotplug-хук, ранний старт, проба персистентности)."
    return 0
}


step_sets() {
    _n=0
    for _s in $(ipset list -n 2>/dev/null); do
        for _pref in $SET_PREFIXES; do
            case "$_s" in "$_pref"*) ipset destroy "$_s" 2>/dev/null && _n=$((_n+1)); break ;; esac
        done
    done
    log "ipset: удалено сетов $_n."
}












step_store() {
    store_ready || { log "Внешний накопитель: не подключён — на нём ничего не трогаю."; return 0; }
    _sr=$(store_root)
    _ssub=
    case "$_sr" in */"$STORE_SUB") _ssub="$STORE_SUB" ;; esac
    if [ -z "$_ssub" ] && [ -n "$STORE_SUB_OLD" ]; then
        case "$_sr" in */"$STORE_SUB_OLD") _ssub="$STORE_SUB_OLD" ;; esac
    fi
    [ -n "$_ssub" ] || { log "Внешний накопитель: неожиданный путь ($_sr) — не трогаю."; return 0; }
    _mp=${_sr%/$_ssub}
    rm -rf "$_sr" 2>/dev/null
    if [ -d "$_sr" ]; then log "Внешний накопитель: $_sr удалить не вышло — удалите его вручную."
    else log "Внешний накопитель: хранилище $_sr удалено, остальное на флешке не тронуто."; fi






    case "$_mp" in
        "$STORE_MNT"|"$STORE_MNT_OLD") umount "$_mp" 2>/dev/null ;;
    esac
    return 0
}









step_verify() {      # $1 = дополнительные демоны (как у step_daemons) ; $2 = keep → см. CRON_PANEL
    _left=""



    for _c in $CHAINS_MANGLE; do
        iptables -t mangle -n -L "$_c" >/dev/null 2>&1
        case $? in 0) _left="$_left mangle/$_c" ;; 1) ;; *) _left="$_left mangle/$_c(?)" ;; esac
    done
    for _c in $CHAINS_FILTER; do
        iptables -n -L "$_c" >/dev/null 2>&1
        case $? in 0) _left="$_left filter/$_c" ;; 1) ;; *) _left="$_left filter/$_c(?)" ;; esac
    done


    ip rule show 2>/dev/null | grep -q 'lookup 100[0-4]' && _left="$_left ip-rule"


    ip rule show 2>/dev/null | grep -q "$GUEST_RULE_SHOW" && _left="$_left ip-rule/guest"
    ip rule show 2>/dev/null | grep -q "$GUEST_BYPASS_SHOW" && _left="$_left ip-rule/guest-bypass"
    ip rule show 2>/dev/null | grep -q "$GUEST_DNS_SHOW" && _left="$_left ip-rule/guest-dns"
    for _if in $IFACES; do ip link show "$_if" >/dev/null 2>&1 && _left="$_left iface/$_if"; done



    _dl=$(daemons_pids "$1")
    [ -n "$_dl" ] && _left="$_left демоны($(echo "$_dl" | tr '\n' ',' | sed 's/,$//'))"


    if [ "$2" = keep ]; then _cn=$(cron_ours /etc/crontabs/root 2>/dev/null | grep -vcF "$CRON_PANEL")
    else _cn=$(cron_ours -c /etc/crontabs/root 2>/dev/null); fi
    case "$_cn" in ''|*[!0-9]*) _cn=0 ;; esac
    [ "$_cn" = 0 ] || _left="$_left cron($_cn)"


    _dso=$(dnsmasq_ours)
    while IFS= read -r _f; do
        [ -n "$_f" ] || continue
        if [ "$2" = keep ] && [ "${_f##*/}" = "$DNSMASQ_KEEP" ]; then continue; fi
        _left="$_left dnsmasq/$_f"
    done <<EOF
$_dso
EOF


    for _s in $(ipset list -n 2>/dev/null); do
        for _pref in $SET_PREFIXES; do
            case "$_s" in "$_pref"*) _left="$_left ipset/$_s"; break ;; esac
        done
    done



    _sw=$(sweep_run count "$2")
    case "$_sw" in ''|0) ;; *) _left="$_left правила($_sw)" ;; esac


    grep -qF "$HOSTS_TAG" /etc/hosts 2>/dev/null && _left="$_left /etc/hosts"









    if [ "$2" != keep ] && dnsdir_empty && dnsconf_ours; then
        log "Мелочь: наша строка в $DNSMASQ_CONF осталась (перезапись не прошла). Ничего не ломает; убрать вручную: grep -v '$DNSMASQ_LINE'."
    fi




    if [ "$2" != keep ] && fwzone_ours; then
        log "Мелочь: зона '$FW_ZONE' в /etc/config/firewall осталась (uci не отдал запись). Трафика не трогает; убрать вручную: uci delete firewall.$FW_ZONE && uci commit firewall."
    fi
    if [ -n "$_left" ]; then
        log "НЕ СНЯТО:$_left"
        return 1
    fi
    log "Проверка: правил, марок, демонов, cron-строк и сниппетов dnsmasq не осталось."
    return 0
}







un_busy() {
    if pkg_install_alive; then echo "идёт установка кода"; return 0; fi
    if [ -f "$ENODIA_DIR/gh-update.sh" ] && sh "$ENODIA_DIR/gh-update.sh" upd-busy >/dev/null 2>&1; then
        echo "идёт обновление или откат кода"; return 0
    fi
    return 1
}




un_gate() {   # $1 — имя снятия для отчёта
    echo $$ > "$UN_PID" 2>/dev/null
    _ubw=$(un_busy) || return 0
    rm -f "$UN_PID" 2>/dev/null
    : > "$REPORT"
    set_state FAIL
    log "ОТМЕНЕНО ($1): $_ubw — снятие посреди неё оставило бы половину системы. Ничего не тронуто; дождитесь конца и повторите."
    return 1
}

cmd_deactivate() {
    un_gate "деактивация" || return 4
    : > "$REPORT"
    set_state RUNNING





    mkdir -p "$ENODIA_STATE" 2>/dev/null
    date +%s > "$ENODIA_STATE/.vpn-off" 2>/dev/null





    _srv_on=0; if [ -f "$ENODIA_STATE/server/.on" ] || [ -f "$ENODIA_STATE/server/.on-deact" ]; then _srv_on=1; fi
    log "=== ДЕАКТИВАЦИЯ: снимаю обвязку VPN, файлы и настройки ОСТАВЛЯЮ ==="
    step_jobs           # ПЕРВЫМ: фоновая задача, убитая позже, успела бы переиграть снятое
    step_rules



    step_sweep keep     # то, что владелец не снял (его может не быть — ранние версии)
    step_daemons
    step_sets
    step_cron keep
    step_dnsmasq keep
    step_hosts          # ДО вердикта: он про hosts спрашивает




    if [ "$_srv_on" = 1 ] && [ -d "$ENODIA_STATE/server" ]; then : > "$ENODIA_STATE/server/.on-deact"; fi



    if ! step_verify "" keep; then
        set_state FAIL
        log "ДЕАКТИВАЦИЯ НЕ ЗАВЕРШЕНА: часть обвязки пережила снятие (перечень — в строке выше)."
        log "Интернет может идти всё ещё через VPN или не идти вовсе. Повторите деактивацию;"
        log "не помогло — перезагрузите роутер (правила живут в RAM и на буте их ставит cron, который снят)."
        return 1
    fi
    set_state OK
    log "Готово. VPN снят, интернет идёт напрямую через провайдера."
    log "Файлы и настройки на месте ($ENODIA_DIR), панель работает (и переживёт ребут) — вернуть всё"
    log "можно оттуда же: «включить» вернёт правила, настройки подсистем и расписание."
    return 0
}

cmd_purge() {

    un_gate "полное удаление" || return 4


    if [ "$0" != "$SELF" ]; then
        cp "$0" "$SELF" 2>/dev/null && chmod +x "$SELF" 2>/dev/null




        [ -s "$SELF" ] || { log "не смог скопировать себя в $SELF — полное удаление отменено"; return 1; }
        exec sh "$SELF" purge
    fi
    : > "$REPORT"
    set_state RUNNING
    log "=== ПОЛНОЕ УДАЛЕНИЕ: обвязка + панель + файлы ==="
    step_jobs           # ПЕРВЫМ: иначе доживающая задача пересоздаёт сеты и сниппеты ПОСЛЕ нас
    step_rules
    step_sweep          # то, что владелец не снял (его может не быть — ранние версии)
    step_daemons "$DAEMONS_PURGE"
    step_sets
    step_cron
    step_dnsmasq
    step_fwzone         # ДО вердикта: он про uci-след спрашивает (и только purge — см. шаг 4b)
    step_hosts          # ДО вердикта: RAM-след ниже идёт последним, а вердикт про hosts спрашивает


    _vr=0
    step_verify "$DAEMONS_PURGE" || { _vr=1; set_state FAIL; }
    fwzone_reload       # ПОСЛЕ вердикта: reload смывает iptables и сделал бы его слепым
    step_panel
    step_hotplug





    step_jobs
    step_store



    step_ram full



    for _od in "$ENODIA_STATE" "$ENODIA_BIN" "$ENODIA_BOOT" "$ENODIA_DIR"; do
        rm -rf "$_od" 2>/dev/null
        if [ -d "$_od" ]; then
            log "ВНИМАНИЕ: $_od удалить не вышло (занят?). Повторите: rm -rf $_od"
            return 1
        fi
    done












    _bpar=${ENODIA_BOOT%/*}
    for _par in "$_bpar/enodia" "$_bpar/enodia-state" "$_bpar/enodia-bin" "$_bpar" "${ENODIA_DIR%/*}"; do
        case "$_par" in
            ''|/|/data|/data/usr|/*/) ;;              # страховка от обрезки до корня системных путей
            *) [ -d "$_par" ] && rmdir "$_par" 2>/dev/null && log "Пустой каталог $_par убран." ;;
        esac
    done
    log "Каталоги $ENODIA_DIR, $ENODIA_STATE, $ENODIA_BIN и $ENODIA_BOOT удалены. Роутер вернулся к стоковому состоянию."
    log "Отчёт: $REPORT (панели уже нет — читать по SSH)."



    [ "$_vr" = 0 ] || { log "НО: часть обвязки пережила снятие (см. «НЕ СНЯТО» выше) — ПЕРЕЗАГРУЗИТЕ роутер."; return 1; }
    return 0
}







zapret_live() {
    if [ -f "$ENODIA_DIR/zapret.sh" ]; then
        sh "$ENODIA_DIR/zapret.sh" wired >/dev/null 2>&1
        _zrc=$?
        [ "$_zrc" = 0 ] && return 0
        [ "$_zrc" = 1 ] && return 1
    fi
    [ -f "$ENODIA_STATE/.zapret-on" ] && return 0
    iptables -t mangle -S PREROUTING 2>/dev/null | grep -q ENODIA_ZAPRET
}




cmd_ours() {
    echo "cron:"
    _oc=$(cron_ours /etc/crontabs/root 2>/dev/null)
    if [ -n "$_oc" ]; then printf '%s\n' "$_oc"; else echo "  (пусто — после ребута ничего не поднимется)"; fi
    echo "dnsmasq:"
    _od=$(dnsmasq_ours)
    [ -n "$_od" ] || echo "  (наших сниппетов нет — на установке «только панель» это норма)"
    while IFS= read -r _f; do
        [ -n "$_f" ] || continue
        ls -la "$_f" 2>/dev/null
    done <<EOF
$_od
EOF
    return 0
}


cmd_plan() {
    _t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    _slots=0
    [ -s "$ENODIA_STATE/.slots" ] && _slots=$(grep -c . "$ENODIA_STATE/.slots" 2>/dev/null)
    case "$_slots" in ''|*[!0-9]*) _slots=0 ;; esac
    _cron=0
    [ -f /etc/crontabs/root ] && _cron=$(cron_ours -c /etc/crontabs/root 2>/dev/null)
    case "$_cron" in ''|*[!0-9]*) _cron=0 ;; esac


    _size=$(du -xsk "$ENODIA_DIR" 2>/dev/null | awk '{printf "%.0f", $1*1024}')
    case "$_size" in ''|*[!0-9]*) _size=0 ;; esac
    _sets=0
    for _s in $(ipset list -n 2>/dev/null); do
        for _pref in $SET_PREFIXES; do
            case "$_s" in "$_pref"*) _sets=$((_sets+1)); break ;; esac
        done
    done




    _fl=$(du -xsk "${ENODIA_BOOT%/*}" 2>/dev/null | awk '{printf "%.0f", $1*1024}')
    case "$_fl" in ''|*[!0-9]*) _fl=$_size ;; esac
    printf '{"engine":true,"dir":"%s","size_b":%s,"flash_b":%s,"transport":"%s","slots":%s,"cron":%s,"sets":%s' \
        "$ENODIA_DIR" "$_size" "$_fl" "$_t" "$_slots" "$_cron" "$_sets"
    printf ',"server":%s'    "$([ -f "$ENODIA_STATE/server/.on" ] && echo true || echo false)"
    printf ',"zapret":%s'    "$(zapret_live && echo true || echo false)"




    _stb=0
    if store_ready; then
        _stb=$(du -xsk "$(store_root)" 2>/dev/null | awk '{printf "%.0f", $1*1024}')
        case "$_stb" in ''|*[!0-9]*) _stb=0 ;; esac
    fi
    printf ',"store":%s,"store_b":%s' "$(store_ready && echo true || echo false)" "$_stb"



    _swp=$(sweep_run count); case "$_swp" in ''|*[!0-9]*) _swp=0 ;; esac
    printf ',"rules":%s' "$_swp"
    printf ',"hosts_seed":%s' "$(grep -qF "$HOSTS_TAG" /etc/hosts 2>/dev/null && echo true || echo false)"




    printf ',"fwzone":%s' "$(fwzone_ours && echo true || echo false)"
    printf ',"panel_tls":%s' "$([ -f "$ENODIA_STATE/.panel-tls" ] && echo true || echo false)"
    printf ',"twofa":%s'     "$([ -f "$ENODIA_STATE/.totp" ] && echo true || echo false)"




    _st=$(cat "$STATE" 2>/dev/null | tr -d ' \r\n'); [ -n "$_st" ] || _st=IDLE
    printf ',"state":"%s"' "$_st"





    _run=false
    if [ "$_st" = RUNNING ] && uninstall_alive; then _run=true; fi
    printf ',"running":%s' "$_run"


    _um=""
    if [ "$_run" = true ]; then _um=$(cat /tmp/enodia-uninstall.mode 2>/dev/null | tr -d ' \r\n'); fi
    case "$_um" in deactivate|purge) : ;; *) _um="" ;; esac
    printf ',"mode":"%s"' "$_um"
    printf '}\n'
}

case "$1" in
    plan)         cmd_plan ;;
    ours)         cmd_ours ;;
    deactivate)   cmd_deactivate ;;
    purge)        cmd_purge ;;
    cron-restore) cmd_cron_restore ;;
    state)        cat "$STATE" 2>/dev/null || echo IDLE ;;
    busy)         un_busy ;;
    *) echo "usage: $0 plan | ours | deactivate | purge | cron-restore | state | busy"
       echo "  ours         — наши cron-строки и сниппеты dnsmasq (для диагностики; только чтение)"
       echo "  deactivate   — снять VPN (правила/демоны/cron/dnsmasq), файлы и панель ОСТАВИТЬ"
       echo "  purge        — то же + панель + снос каталогов кода/настроек/бинарей (роутер станет стоковым)"
       echo "  cron-restore — вернуть расписание, снятое деактивацией (зовёт vpn-toggle.sh on)"
       echo "  busy         — снимать сейчас нельзя? (идёт установка/обновление кода: печатает причину, код 0)"
       exit 2 ;;
esac
