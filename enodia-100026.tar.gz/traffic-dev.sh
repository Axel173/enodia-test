#!/bin/sh










































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
TD_RUN=${TD_RUN:-/tmp/enodia-traffic-dev}
TD_BOOT_F=${TD_BOOT_F:-/proc/sys/kernel/random/boot_id}
TD_HIST="$ENODIA_STATE/.traffic-dev"
TD_CKPT="$ENODIA_STATE/.traffic-dev-day"
TD_HOSTS="$ENODIA_STATE/.traffic-dev-hosts"
TD_KEEP=400            # days of history — as .traffic-daily keeps: every window of the screen has its days
TD_DAY_MAX=16          # devices a closed day keeps by name; the rest — one «other» line
TD_SAVE=14400          # seconds of uptime between checkpoints of the day
TD_BOOT_WIN=7200       # without a boot id: «the counters are this boot's» while uptime is under this
TD_CAP=1250000000      # bytes per second of one pair (10 Gbit/s): a delta over it is a counter glitch, not traffic
TD_CARRY=86400         # seconds of uptime a pair missing from trafficd's answer keeps its last counters in `last`






TD_LINE_OK='NF == 4 && $1 <= today && $1 ~ /^[0-9][0-9][0-9][0-9]-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/ && ($2 ~ /^[0-9a-f][0-9a-f](:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])$/ || $2 == "other") && $3 ~ /^[0-9]+$/ && length($3) <= 15 && $4 ~ /^[0-9]+$/ && length($4) <= 15'
TAB=$(printf '\t')


if [ -f "$ENODIA_DIR/lease-lib.sh" ]; then . "$ENODIA_DIR/lease-lib.sh"; fi
if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v mac_norm >/dev/null 2>&1 || mac_norm() { printf '%s' "$1" | tr 'A-Z' 'a-z' | tr -d ' \t\r\n'; }
command -v mac_ok   >/dev/null 2>&1 || mac_ok()   { printf '%s' "$1" | grep -qE '^[0-9a-f]{2}(:[0-9a-f]{2}){5}$'; }
command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }
command -v clock_trusted >/dev/null 2>&1 || clock_trusted() { return 1; }


td_cleanup() { rm -f "$TD_RUN/"*".$$" "$TD_CKPT.$$" "$TD_HIST.$$" "$TD_HOSTS.$$" 2>/dev/null; }
trap td_cleanup EXIT
trap 'exit 1' INT TERM HUP PIPE



td_clean() { tr -d '\000-\010\013-\037"\\'; }
td_lt() { awk 'BEGIN { exit !(ARGV[1] < ARGV[2]) }' "$1" "$2"; }   # string order of two dates (ISO sorts as text)
td_boot() {
	_tbi=""; read -r _tbi < "$TD_BOOT_F" 2>/dev/null
	case "$_tbi" in *[!0-9a-f-]*) _tbi="" ;; esac
	echo "$_tbi"
}









td_snap() {
	ubus -t 5 call trafficd hw 2>/dev/null | tr -d '\000-\010\013-\037\\' | awk -v T="$TAB" '
		BEGIN { OFMT = "%.0f"; CONVFMT = "%.0f" }
		/^[ \t]*\{[ \t]*$/ { ip = ""; pk = "" }
		# the device is named by the "hw" of its object, never by the "hw" inside an address entry (round 2: if trafficd keeps
		# the current holder of the address there, the bytes of the next entry would go to another MAC)
		/^[ \t]*"[0-9A-Fa-f:]+": *\{/ { inl = 0 }
		/^[ \t]*"ip_list":/ { inl = 1 }
		/^[ \t]*\][ \t,]*$/ { inl = 0 }   # the list closed: a device object keyed otherwise than by a MAC still names itself (r.3)
		/^[ \t]*"hw":/ { if (inl) next; v = $0; sub(/^[ \t]*"hw": *"/, "", v); sub(/".*/, "", v); mac = tolower(v) }
		/^[ \t]*"hostname":/ { v = $0; sub(/^[ \t]*"hostname": *"/, "", v); sub(/".*/, "", v); if (v == "*") v = ""; gsub(/\t/, " ", v); hn[mac] = v }
		/^[ \t]*"ifname":/ { v = $0; sub(/^[ \t]*"ifname": *"/, "", v); sub(/".*/, "", v); ifn[mac] = v }
		/^[ \t]*"assoc":/ { v = $0; gsub(/[^0-9]/, "", v); as[mac] = v + 0 }
		/^[ \t]*"ip":/ { v = $0; sub(/^[ \t]*"ip": *"/, "", v); sub(/".*/, "", v); ip = v; pk = mac T ip
			if (!(pk in seen)) { seen[pk] = 1; pm[++n] = mac; pi[n] = ip } }
		/^[ \t]*"rx_bytes":/ { v = $0; gsub(/[^0-9]/, "", v); if (length(v) > 15) v = 0; if (pk != "") rx[pk] += v }
		/^[ \t]*"tx_bytes":/ { v = $0; gsub(/[^0-9]/, "", v); if (length(v) > 15) v = 0; if (pk != "") tx[pk] += v }
		END { for (i = 1; i <= n; i++) {
			m = pm[i]; a = pi[i]; k = m T a
			if (m !~ /^[0-9a-f][0-9a-f](:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])(:[0-9a-f][0-9a-f])$/) continue
			if (a !~ /^[0-9A-Fa-f:.]+$/) a = "-"
			f = ifn[m]; if (f !~ /^[A-Za-z0-9._-]+$/) f = "-"
			printf "%s%s%s%s%.0f%s%.0f%s%d%s%s%s%s\n", m, T, a, T, rx[k] + 0, T, tx[k] + 0, T, as[m], T, f, T, hn[m] } }'
}








td_deltas() {
	awk -F'\t' -v L="$1" -v md="$3" -v el="$4" -v cps="$TD_CAP" '
		BEGIN { OFMT = "%.0f"; CONVFMT = "%.0f"; T = "\t"; c = cps * el }
		FILENAME == L { if ($1 != "#") { k = $1 T $2; lr[k] = $3 + 0; lt[k] = $4 + 0; lk[k] = 1 }; next }
		md == "seed" { next }
		{ k = $1 T $2; r = $3 + 0; t = $4 + 0
		  if (md == "live") { dr = ((k in lk) && r >= lr[k]) ? r - lr[k] : 0; dt = ((k in lk) && t >= lt[k]) ? t - lt[k] : 0 }
		  else if (md == "boot" || !(k in lk)) { dr = r; dt = t }
		  else { dr = (r >= lr[k]) ? r - lr[k] : r; dt = (t >= lt[k]) ? t - lt[k] : t }
		  if (dr > c) dr = 0
		  if (dt > c) dt = 0
		  if (!($1 in seen)) { seen[$1] = 1; o[++n] = $1 }
		  R[$1] += dr; X[$1] += dt }
		END { for (i = 1; i <= n; i++) if (R[o[i]] + X[o[i]] > 0) printf "%s %.0f %.0f\n", o[i], R[o[i]], X[o[i]] }' "$1" "$2"
}




td_close() {
	_cd=$(head -n 1 "$1" 2>/dev/null | cut -d' ' -f1)
	case "$_cd" in [0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]) ;; *) return 0 ;; esac
	_cdt=$(date +%F)
	_cl=$(awk -v today="$_cdt" "$TD_LINE_OK { d = \$1 } END { print d }" "$TD_HIST" 2>/dev/null)   # the last VALID closed day (a once-a-day pass)
	if [ -n "$_cl" ] && ! td_lt "$_cl" "$_cd"; then return 0; fi


	awk 'NR > 1 && NF == 3 && ($2 + $3) > 0 { printf "%017.0f %s %.0f %.0f\n", $2 + $3, $1, $2, $3 }' "$1" | sort -r |
		awk -v d="$_cd" -v n="$TD_DAY_MAX" 'BEGIN { OFMT = "%.0f"; CONVFMT = "%.0f" }
			NR <= n && $2 != "other" { printf "%s %s %.0f %.0f\n", d, $2, $3, $4; next }
			{ r += $3; t += $4 }
			END { if (r + t > 0) printf "%s other %.0f %.0f\n", d, r, t }' >> "$TD_HIST"


	: >> "$TD_HOSTS" 2>/dev/null
	if [ -f "$TD_RUN/hosts" ] && awk -F'\t' -v H="$TD_HOSTS" -v R="$TD_RUN/hosts" -v T="$TAB" '
			FILENAME == H { if (NF >= 2 && !($1 in h)) { h[$1] = $2; o[++n] = $1 }; next }
			FILENAME == R { if (NF >= 2 && $2 != "") r[$1] = $2; next }
			FNR > 1 { m = $1; sub(/ .*/, "", m)
				# membership BEFORE the comparison: reading h[m] would create the element, and a new device would never be listed
				if (!(m in r)) next
				if (!(m in h)) { o[++n] = m; h[m] = r[m]; ch = 1 } else if (h[m] != r[m]) { h[m] = r[m]; ch = 1 } }
			END { if (!ch) exit 1; for (i = 1; i <= n; i++) print o[i] T h[o[i]] }' "$TD_HOSTS" "$TD_RUN/hosts" "$1" > "$TD_HOSTS.$$"
	then mv "$TD_HOSTS.$$" "$TD_HOSTS"; fi
	rm -f "$TD_HOSTS.$$" 2>/dev/null
	_cf=$(awk -v today="$_cdt" "$TD_LINE_OK { print \$1; exit }" "$TD_HIST" 2>/dev/null)   # the first VALID line: a garbage one must not stall the trim
	_ck=$(date -d "@$(( $2 - TD_KEEP * 86400 ))" +%F 2>/dev/null)
	_ct=$(date -d "@$(( $2 - (TD_KEEP + 31) * 86400 ))" +%F 2>/dev/null)
	if [ -n "$_cf" ] && [ -n "$_ct" ] && td_lt "$_cf" "$_ct"; then
		awk -v k="$_ck" -v today="$_cdt" "$TD_LINE_OK"' && $1 >= k' "$TD_HIST" > "$TD_HIST.$$" && mv "$TD_HIST.$$" "$TD_HIST"
		awk -F'\t' -v Hh="$TD_HIST" 'FILENAME == Hh { k = $0; sub(/^[^ ]* /, "", k); sub(/ .*/, "", k); m[k] = 1; next } ($1 in m)' \
			"$TD_HIST" "$TD_HOSTS" > "$TD_HOSTS.$$" && mv "$TD_HOSTS.$$" "$TD_HOSTS"
	fi
	return 0
}

cmd_tick() {
	clock_trusted || return 0
	mkdir -p "$TD_RUN" 2>/dev/null || return 0


	for _tf in "$TD_RUN"/*.* "$TD_CKPT".* "$TD_HIST".* "$TD_HOSTS".*; do   # …and a killed tick's own on the flash (r.3)
		_tp=${_tf##*.}; case "$_tp" in ''|*[!0-9]*) continue ;; esac
		[ -d "/proc/$_tp" ] || rm -f "$_tf"
	done
	_tn=$(date +%s); _tt=$(date +%F); _tu=$(uptime_s); _tb=$(td_boot)
	_ts="$TD_RUN/snap.$$"
	td_snap > "$_ts"
	[ -s "$_ts" ] || return 0              # trafficd silent: no sample — `last` stays, the next answer covers the gap
	_tdf="$TD_RUN/day"
	if [ ! -s "$_tdf" ] && [ -s "$TD_CKPT" ]; then cp "$TD_CKPT" "$_tdf" 2>/dev/null; fi
	_tlf="$TD_RUN/last"
	if [ -s "$_tlf" ]; then
		_tm=delta
		_tlu=$(head -n 1 "$_tlf" | cut -f2); case "$_tlu" in ''|*[!0-9]*) _tlu=$_tu ;; esac
		_tel=$(( _tu - _tlu ))
	else
		_tm=seed; _tlf=/dev/null; _tel=$_tu
		if [ -s "$TD_CKPT" ]; then
			_tcb=$(head -n 1 "$TD_CKPT" | cut -d' ' -f2)
			if [ -n "$_tb" ]; then
				if [ "$_tcb" != "$_tb" ]; then _tm=boot; fi
			elif [ "$_tu" -lt "$TD_BOOT_WIN" ]; then _tm=boot; fi
		fi
	fi
	[ "$_tel" -ge 60 ] 2>/dev/null || _tel=60




	_tdd=$(head -n 1 "$_tdf" 2>/dev/null | cut -d' ' -f1); _tday=$_tt
	if [ -n "$_tdd" ] && [ "$_tdd" != "$_tt" ]; then
		if td_lt "$_tdd" "$_tt"; then td_close "$_tdf" "$_tn"; rm -f "$_tdf"
		elif [ "$_tdd" = "$(date -d "@$(( _tn + 86400 ))" +%F 2>/dev/null)" ]; then _tday=$_tdd
		else rm -f "$_tdf"; fi
	fi
	td_deltas "$_tlf" "$_ts" "$_tm" "$_tel" > "$TD_RUN/dlt.$$"






	awk -F'\t' -v S="$_ts" -v up="$_tu" -v keep="$TD_CARRY" -v T="$TAB" '
		BEGIN { print "#" T up }
		FILENAME == S { s[$1 T $2] = 1; print $1 T $2 T $3 T $4 T up; next }
		$1 != "#" && NF >= 5 && !(($1 T $2) in s) && $5 + keep >= up { print $1 T $2 T $3 T $4 T $5 }' \
		"$_ts" "$_tlf" > "$TD_RUN/last.$$" && mv "$TD_RUN/last.$$" "$TD_RUN/last"
	{
		printf '%s %s\n' "$_tday" "${_tb:--}"
		{ if [ -s "$_tdf" ]; then awk 'NR > 1 && NF == 3' "$_tdf"; fi; cat "$TD_RUN/dlt.$$"; } |
			awk 'BEGIN { OFMT = "%.0f"; CONVFMT = "%.0f" }
				$1 ~ /^[0-9a-f:]+$/ || $1 == "other" { if (!($1 in s)) { s[$1] = 1; o[++n] = $1 }; r[$1] += $2; t[$1] += $3 }
				END { for (i = 1; i <= n; i++) printf "%s %.0f %.0f\n", o[i], r[o[i]], t[o[i]] }'
	} > "$TD_RUN/day.$$" && mv "$TD_RUN/day.$$" "$_tdf"
	: >> "$TD_RUN/hosts"
	awk -F'\t' -v H="$TD_RUN/hosts" -v T="$TAB" '
		FILENAME == H { if (NF >= 2 && !($1 in h)) { h[$1] = $2; o[++n] = $1 }; next }
		$7 != "" { if (!($1 in h)) o[++n] = $1; h[$1] = $7 }
		END { for (i = 1; i <= n; i++) print o[i] T h[o[i]] }' "$TD_RUN/hosts" "$_ts" > "$TD_RUN/hosts.$$" && mv "$TD_RUN/hosts.$$" "$TD_RUN/hosts"


	_tsv=$(cat "$TD_RUN/saved" 2>/dev/null); case "$_tsv" in ''|*[!0-9]*) _tsv="" ;; esac
	if [ -z "$_tsv" ] || [ ! -s "$TD_CKPT" ] || [ "$_tu" -lt "$_tsv" ] || [ $(( _tu - _tsv )) -ge "$TD_SAVE" ]; then
		cp "$_tdf" "$TD_CKPT.$$" 2>/dev/null && mv "$TD_CKPT.$$" "$TD_CKPT" && echo "$_tu" > "$TD_RUN/saved"
	fi
	return 0
}





td_read() {   # list <today|week|month|year> | mac <mac>
	mkdir -p "$TD_RUN" 2>/dev/null
	_rn=$(date +%s); _rt=$(date +%F)
	_rw=$(date -d "@$(( _rn - 6 * 86400 ))" +%F 2>/dev/null)
	_rm=$(date -d "@$(( _rn - 29 * 86400 ))" +%F 2>/dev/null)
	_ry=$(date -d "@$(( _rn - 364 * 86400 ))" +%F 2>/dev/null)
	if [ -z "$_ry" ]; then echo '{"ok":false,"msg":"date -d"}'; return 1; fi
	_rs="$TD_RUN/rsnap.$$"
	td_snap > "$_rs"
	_rsrc=false; [ -s "$_rs" ] && _rsrc=true
	_rtr=false; clock_trusted && _rtr=true
	_rd="$TD_RUN/day"; [ -s "$_rd" ] || _rd="$TD_CKPT"
	_rel=60
	if [ -s "$TD_RUN/last" ]; then
		_rlu=$(head -n 1 "$TD_RUN/last" | cut -f2); case "$_rlu" in ''|*[!0-9]*) _rlu=0 ;; esac
		_rel=$(( $(uptime_s) - _rlu )); [ "$_rel" -ge 60 ] 2>/dev/null || _rel=60
	fi
	{
		if [ -s "$TD_HIST" ]; then
			awk -v today="$_rt" "$TD_LINE_OK"' { print "F\t" $1; exit }' "$TD_HIST"
			awk -v y="$_ry" -v today="$_rt" "$TD_LINE_OK"' && $1 >= y { print "H\t" $1 "\t" $2 "\t" $3 "\t" $4 }' "$TD_HIST"
		fi
		if [ -s "$_rd" ]; then awk 'NR == 1 { d = $1; if (d !~ /^[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]$/) exit; next }
			NF == 3 && $2 ~ /^[0-9]+$/ && $3 ~ /^[0-9]+$/ { print "D\t" d "\t" $1 "\t" $2 "\t" $3 }' "$_rd"; fi
		if [ -s "$TD_RUN/last" ] && [ "$_rsrc" = true ]; then
			td_deltas "$TD_RUN/last" "$_rs" live "$_rel" | awk '{ print "U\t" $1 "\t" $2 "\t" $3 }'
		fi




		if [ "$1" = list ] && command -v ip_owner_now >/dev/null 2>&1; then   # one device (json-mac) has no door field
			for _ri in $(awk -F'\t' '$2 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ { print $2 }' "$_rs" | sort -u); do
				_ro=$(ip_owner_now "$_ri" 2>/dev/null) && printf 'O\t%s\t%s\n' "$_ri" "$_ro"
			done
		fi
		awk -F'\t' '{ print "S\t" $1 "\t" $2 "\t" $5 "\t" $6 "\t" $7 }' "$_rs"
		if [ -f "$ENODIA_DIR/dev-names.sh" ]; then
			sh "$ENODIA_DIR/dev-names.sh" list 2>/dev/null | awk -F'\t' 'NF >= 2 { print "A\t" $1 "\t" $2 }'
		fi
		td_clean < "${LEASE_FILE:-/tmp/dhcp.leases}" 2>/dev/null | awk '$4 != "*" && $4 != "" { print "L\t" tolower($2) "\t" $4 }'
		cat "$TD_HOSTS" "$TD_RUN/hosts" 2>/dev/null | td_clean | awk -F'\t' 'NF >= 2 && $2 != "" { print "R\t" $1 "\t" $2 }'
	} | awk -F'\t' -v md="$1" -v q="$2" -v today="$_rt" -v fw="$_rw" -v fm="$_rm" -v fy="$_ry" -v src="$_rsrc" -v tr="$_rtr" '
		BEGIN { OFMT = "%.0f"; CONVFMT = "%.0f"; w = (q == "today") ? 0 : (q == "week") ? 1 : (q == "month") ? 2 : 3 }
		$1 == "F" { since = $2; next }
		$1 == "O" { own[$2] = $3; next }
		$1 == "S" { if ($6 != "") sh[$2] = $6
			if (!($2 in sif) && $5 != "-") sif[$2] = $5
			if (!($2 in sip) && ($3 in own) && own[$3] == $2) sip[$2] = $3
			next }
		$1 == "A" { al[$2] = $3; next }
		$1 == "L" { lh[$2] = $3; next }
		$1 == "R" { rh[$2] = $3; next }
		$1 == "H" { if ($2 > hl) hl = $2; dt = $2; m = $3; r = $4 + 0; t = $5 + 0 }
		$1 == "D" { if (hl != "" && $2 <= hl) next; if (since == "") since = $2; dt = $2; m = $3; r = $4 + 0; t = $5 + 0 }
		$1 == "U" { dt = today; m = $2; r = $3 + 0; t = $4 + 0; if (since == "") since = today }
		$1 == "H" || $1 == "D" || $1 == "U" {
			if (m !~ /^[0-9a-f:]+$/ && m != "other") next
			if (!(m in seen)) { seen[m] = 1; o[++n] = m }
			if (dt == today) { r0[m] += r; t0[m] += t }
			if (dt >= fw) { r1[m] += r; t1[m] += t }
			if (dt >= fm) { r2[m] += r; t2[m] += t }
			if (dt >= fy) { r3[m] += r; t3[m] += t } }
		END {
			if (md == "mac") {
				for (i = 1; i <= n; i++) { k = o[i]; a0 += r0[k]; b0 += t0[k]; a1 += r1[k]; b1 += t1[k]; a2 += r2[k]; b2 += t2[k]; a3 += r3[k]; b3 += t3[k] }
				printf "{\"ok\":true,\"mac\":\"%s\",\"src\":%s,\"trusted\":%s,\"since\":\"%s\",\"w\":{", q, src, tr, since
				printf "\"today\":[%.0f,%.0f,%.0f,%.0f],\"week\":[%.0f,%.0f,%.0f,%.0f],", r0[q], t0[q], a0, b0, r1[q], t1[q], a1, b1
				printf "\"month\":[%.0f,%.0f,%.0f,%.0f],\"year\":[%.0f,%.0f,%.0f,%.0f]}}\n", r2[q], t2[q], a2, b2, r3[q], t3[q], a3, b3
				exit
			}
			for (i = 1; i <= n; i++) {
				k = o[i]
				r = (w == 0) ? r0[k] : (w == 1) ? r1[k] : (w == 2) ? r2[k] : r3[k]
				t = (w == 0) ? t0[k] : (w == 1) ? t1[k] : (w == 2) ? t2[k] : t3[k]
				if (k == "other") { orx = r; otx = t; continue }
				if (r + t <= 0) continue
				h = (k in lh) ? lh[k] : ((k in sh) ? sh[k] : rh[k])
				printf "%017.0f\t{\"mac\":\"%s\",\"rx\":%.0f,\"tx\":%.0f,\"ip\":\"%s\",\"ifn\":\"%s\",\"host\":\"%s\",\"alias\":\"%s\"}\n", r + t, k, r, t, sip[k], sif[k], h, al[k]
			}
			printf "-\t%s\t%.0f\t%.0f\n", since, orx, otx
		}' > "$TD_RUN/rout.$$"
	if [ "$1" = mac ]; then cat "$TD_RUN/rout.$$"; return 0; fi

	sort -r "$TD_RUN/rout.$$" | awk -F'\t' -v per="$2" -v from="$(case "$2" in today) echo "$_rt" ;; week) echo "$_rw" ;; month) echo "$_rm" ;; *) echo "$_ry" ;; esac)" \
		-v src="$_rsrc" -v tr="$_rtr" '
		BEGIN { printf "{\"ok\":true,\"per\":\"%s\",\"from\":\"%s\",\"src\":%s,\"trusted\":%s,\"devs\":[", per, from, src, tr }
		$1 == "-" { since = $2; orx = $3; otx = $4; next }
		{ printf "%s%s", (n++ ? "," : ""), $2 }
		END { printf "],\"since\":\"%s\",\"other_rx\":%s,\"other_tx\":%s}\n", since, (orx == "" ? 0 : orx), (otx == "" ? 0 : otx) }'
}

case "$1" in
	snap) td_snap ;;
	tick) cmd_tick ;;
	json)
		case "$2" in today|week|month|year) td_read list "$2" ;; *) echo '{"ok":false,"msg":"period"}'; exit 1 ;; esac ;;
	json-mac)
		_jm=$(mac_norm "$2")
		mac_ok "$_jm" || { echo '{"ok":false,"msg":"mac"}'; exit 1; }
		td_read mac "$_jm" ;;
	*) echo "usage: traffic-dev.sh snap | tick | json <today|week|month|year> | json-mac <mac>" >&2; exit 1 ;;
esac
