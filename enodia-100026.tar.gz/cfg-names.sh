#!/bin/sh























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
STORE="$ENODIA_STATE/.cfg-names"
LOCK=/tmp/enodia-cfg-names.lock


NAME_MAX=240
KEY_RE='^(awg|xray|hy2)/[A-Za-z0-9_.-]+$'
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; else
    echo "[cfg-names] нет $ENODIA_DIR/label-lib.sh — обновите установку" >&2; exit 1
fi

key_ok() { printf '%s' "$1" | grep -qE "$KEY_RE"; }
cmd_list() { lbl_list "$STORE" "$KEY_RE"; }
cmd_get() { key_ok "$1/$2" || return 1; cmd_list | awk -F"$LBL_TAB" -v k="$1/$2" '$1==k { print $2; exit }'; }


put() {   # $1 = вид/файл, $2 = имя (пусто = снять)
    lbl_lock_take "$LOCK" 'cfg-names' || { echo "[cfg-names] имена сейчас правит другая операция — повторите"; return 1; }
    lbl_write "$STORE" "$1" "$2" "$KEY_RE"; _pr=$?
    lbl_lock_drop "$LOCK"
    [ "$_pr" = 0 ] || { echo "[cfg-names] не удалось записать имя (место на разделе?)"; return 1; }
    return 0
}
san_checked() {   # $1 = файл, $2 = имя → очищенное имя в $SN; 1 — отказ (сказано словами)
    SN=$(lbl_san "$2")


    if [ -z "$SN" ] && [ -n "$(printf '%s' "$2" | tr -d ' \t\r\n')" ]; then
        echo "[cfg-names] в имени нет ни одного допустимого знака — кавычки и обратная косая не сохраняются"; return 1
    fi
    [ "$SN" = "$1" ] && SN=""
    if [ "$(printf '%s' "$SN" | wc -c)" -gt "$NAME_MAX" ]; then
        echo "[cfg-names] имя слишком длинное — сократите"; return 1
    fi
    return 0
}

cmd_set() {
    key_ok "$1/$2" || { echo "[cfg-names] не тот вид или имя файла: $1/$2"; return 1; }
    san_checked "$2" "$3" || return 1
    put "$1/$2" "$SN" || return 1

    if [ -n "$SN" ]; then echo "[cfg-names] имя «$SN»"; else echo "[cfg-names] своё имя снято"; fi
}



cmd_mv() {
    key_ok "$1/$2" && key_ok "$1/$3" || { echo "[cfg-names] не тот вид или имя файла: $1/$2 → $1/$3"; return 1; }
    lbl_lock_take "$LOCK" 'cfg-names' || { echo "[cfg-names] имена сейчас правит другая операция — повторите"; return 1; }
    if [ "$#" -ge 4 ]; then _mvn="$4"; else _mvn=$(cmd_list | awk -F"$LBL_TAB" -v k="$1/$2" '$1==k { print $2; exit }'); fi


    if san_checked "$3" "$_mvn"; then
        lbl_write "$STORE" "$1/$2" "" "$KEY_RE" && lbl_write "$STORE" "$1/$3" "$SN" "$KEY_RE"; _mr=$?
    else
        lbl_write "$STORE" "$1/$2" "" "$KEY_RE"; lbl_lock_drop "$LOCK"; return 1
    fi
    lbl_lock_drop "$LOCK"
    [ "$_mr" = 0 ] || { echo "[cfg-names] не удалось записать имя"; return 1; }
    return 0
}

cmd_json() {
    cmd_list | awk -F"$LBL_TAB" '{ printf "%s\"%s\":\"%s\"", (c++ ? "," : ""), $1, $2 }'
}




cmd_import() {
    _ik=$( for _if in "$2"/configs/*.conf; do [ -f "$_if" ] && { _ib=${_if##*/}; echo "awg/${_ib%.conf}"; }; done
           for _if in "$2"/xray-configs/*.json; do [ -f "$_if" ] && { _ib=${_if##*/}; echo "xray/${_ib%.json}"; }; done
           for _if in "$2"/hy2-configs/*.yaml; do [ -f "$_if" ] && { _ib=${_if##*/}; echo "hy2/${_ib%.yaml}"; }; done )
    lbl_lock_take "$LOCK" 'cfg-names' || { echo "[cfg-names] имена сейчас правит другая операция — повторите"; return 1; }


    lbl_import "$STORE" "$1" "$_ik" "$KEY_RE"; _imr=$?
    lbl_lock_drop "$LOCK"
    [ "$_imr" = 0 ] || { echo "[cfg-names] не удалось записать имена (место на разделе?)"; return 1; }
    return 0
}

cmd_merge() {
    [ -f "$1" ] || { echo "[cfg-names] нет файла $1"; return 1; }
    lbl_lock_take "$LOCK" 'cfg-names' || { echo "[cfg-names] имена сейчас правит другая операция — повторите"; return 1; }
    lbl_merge "$STORE" "$1" "$KEY_RE"; _mgr=$?
    lbl_lock_drop "$LOCK"
    [ "$_mgr" = 0 ] || { echo "[cfg-names] не удалось записать имена (место на разделе?)"; return 1; }
    return 0
}

case "$1" in
    set)  cmd_set "$2" "$3" "$4" ;;
    merge) cmd_merge "$2" ;;
    import) cmd_import "$2" "$3" ;;
    del)  key_ok "$2/$3" || exit 1; put "$2/$3" "" ;;
    mv)   shift; cmd_mv "$@" ;;
    get)  cmd_get "$2" "$3" ;;
    list) cmd_list; exit 0 ;;
    json) cmd_json; exit 0 ;;
    *) echo "usage: $0 set <вид> <файл> <имя> | del <вид> <файл> | mv <вид> <старый> <новый> [имя] | get <вид> <файл> | list | json | merge <файл> | import <файл> <корень архива>"; exit 2 ;;
esac
