#!/bin/sh
















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
API=https://api.cloudflareclient.com/v0a2158
UA="okhttp/3.12.1"; CV="a-6.10-2158"                  # what the Android app sends; the API refuses other clients
WARP_PUB='bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo='   # one server key for everyone — a config with it IS WARP (road/panel badge)
NAME=WARP                                              # the first config and its exit; the next ones — WARP-2 … WARP-9 (next_name)
PORTS="891 500 1701 4500 854 878 894 908 2408"          # the measured one first, WARP's standard one last (cut here)
TRACE=https://1.1.1.1/cdn-cgi/trace                     # answers `warp=on` + `colo=XXX` only through WARP
TRY_SECS=8                                             # per port: a live WARP answers in ~1 s; worst case ≤ 9 × ~11 s
ST=/tmp/enodia-warp.json; PIDF=/tmp/enodia-warp.pid
STARTF=/tmp/enodia-warp.start                          # the pid of the front verb that is launching a job right now (busy)
STARTL=/tmp/enodia-warp-start.lock                     # «is a job alive?» and «the start is mine» are ONE step under it (take_start)
REGL=/tmp/enodia-warp-reg.lock                         # one writer of the record at a time (reg_lock)
HOLDF=/tmp/enodia-warp.hold                            # the config whose exits an own-key pick keeps DOWN right now (cmd_holds)
DEVF=/tmp/enodia-warp-dev.conf                         # RAM, 600: the other device's config until the panel takes it (once)
DEV_TTL=${ENODIA_WARP_DEV_TTL:-600}                    # …and no longer than this: nobody came for it — it is removed
case "$DEV_TTL" in ''|*[!0-9]*) DEV_TTL=600 ;; esac





REG="$ENODIA_STATE/.warp-reg"
OP=get
if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
command -v curl_ca_opt >/dev/null 2>&1 || curl_ca_opt() { return 0; }
if [ -f "$ENODIA_DIR/json-lib.sh" ]; then . "$ENODIA_DIR/json-lib.sh"; fi   # jtxt: a byte cut that keeps UTF-8 whole
command -v jtxt >/dev/null 2>&1 || jtxt() { tr -d '"\000-\037\\'; }
if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v clock_sane >/dev/null 2>&1 || clock_sane() { _csn=${1:-$(date +%s 2>/dev/null)}; case "$_csn" in ''|*[!0-9]*) return 1 ;; esac; [ "$_csn" -gt 1700000000 ] 2>/dev/null && [ "$_csn" -lt 4102444800 ] 2>/dev/null; }
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi   # pid_runs: alive AND ours
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -d "/proc/$1" ]; }
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi     # lbl_lock_take/_drop: a lock directory, stale by /proc
command -v lbl_lock_take >/dev/null 2>&1 || { lbl_lock_take() { mkdir "$1" 2>/dev/null; }; lbl_lock_drop() { rm -rf "$1" 2>/dev/null; }; }
command -v lbl_commit >/dev/null 2>&1 || lbl_commit() { if [ -z "$2" ]; then rm -f "$1"; return $?; fi; if printf '%s\n' "$2" > "$1.$$" 2>/dev/null && [ "$(cat "$1.$$" 2>/dev/null)" = "$2" ]; then mv "$1.$$" "$1" && return 0; fi; rm -f "$1.$$"; return 1; }
TAB=$(printf '\t')
NL='
'




gen_i1() { printf '<b 0xce0000000108><r 8><b 0x000044d0><r 1232>'; }





JOB=$(printf '%s' "${ENODIA_WARP_JOB:-}" | tr -cd 'a-f0-9' | cut -c1-32)
put() {
    _wpj=$1; [ -z "$JOB" ] || _wpj="${1%\}},\"job\":\"$JOB\"}"
    _wpt=$(mktemp "$ST.XXXXXX" 2>/dev/null) || return 1; printf '%s\n' "$_wpj" > "$_wpt" && mv "$_wpt" "$ST"   # mktemp: O_EXCL, no planted name
}


wconf() {
    printf '[Interface]\nPrivateKey = %s\nAddress = %s/32%s\nMTU = 1280\n' "$_wpriv" "$_wv4" "${_wv6:+, $_wv6/128}"
    printf 'S1 = 0\nS2 = 0\nJc = 4\nJmin = 40\nJmax = 70\nH1 = 1\nH2 = 2\nH3 = 3\nH4 = 4\nI1 = %s\n' "${_wi1:-$(gen_i1)}"
    printf '\n[Peer]\nPublicKey = %s\nAllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = %s:%s\nPersistentKeepalive = 25\n' "$WARP_PUB" "$_wep" "$1"
}

dconf() { wconf "$1" | awk '{ print } /^MTU = 1280$/ { print "DNS = 1.1.1.1, 1.0.0.1" }'; }


conf_as() {
    awk -v pk="$2" -v ad="$3" -v pt="$4" -v i1="$5" '
        { sub(/\r$/, "") }
        /^[ \t]*PrivateKey[ \t]*=/ { if (pk != "") { print "PrivateKey = " pk; next } }
        /^[ \t]*Address[ \t]*=/    { if (ad != "") { print "Address = " ad; next } }
        /^[ \t]*Endpoint[ \t]*=/   { if (pt != "") { v = $0; sub(/:[0-9]+[ \t]*$/, "", v); print v ":" pt; next } }
        /^[ \t]*I1[ \t]*=/         { seen = 1; if (i1 != "") { print "I1 = " i1; next } }
        /^[ \t]*\[Peer\]/          { if (i1 != "" && !seen) { print "I1 = " i1; seen = 1 } }
        { print }' "$1"
}
xconf() { conf_as "$_wsrc" "$_wpriv" "$_wv4/32${_wv6:+, $_wv6/128}" "$1" "$_wi1"; }
oconf() { conf_as "$_wsrc" "" "" "$1" ""; }   # …and the config AS IT IS but for the port: its own key, address and masking
say() { put "{\"state\":\"running\",\"op\":\"$OP\",\"name\":\"$_wnm\",\"msg\":\"$1\"}"; }




_wgid=""; _wgtok=""
give_back() { reg_del "$_wgid" "$_wgtok"; _wgid=""; _wgtok=""; }
owned() { _wgid=""; _wgtok=""; }




_wsoon=""
fail() { give_back; put "{\"state\":\"error\",\"op\":\"$OP\",\"name\":\"$_wnm\",\"msg\":\"$1\"${_wsoon:+,\"soon\":true}}"; exit 1; }
now_s() { if clock_sane; then date +%s 2>/dev/null; else echo 0; fi; }


cfg_val() { sed -n "s/^[[:space:]]*$2[[:space:]]*=[[:space:]]*//p" "$1" 2>/dev/null | head -n 1 | tr -d '\r'; }
cfg_pub() { _wcp=$(cfg_val "$1" PrivateKey | tr -d ' \t'); [ -n "$_wcp" ] && printf '%s' "$_wcp" | "$ENODIA_BIN/awg" pubkey 2>/dev/null | tr -d ' \r\n'; }
cfg_port() { cfg_val "$1" Endpoint | sed -n 's/.*:\([0-9][0-9]*\)[[:space:]]*$/\1/p'; }
cfg_ep() { cfg_val "$1" Endpoint | sed 's/:[0-9]*[[:space:]]*$//' | tr -d '[] \t'; }

is_warp() { cmd_list | awk -F"$TAB" -v n="$1" '($1 "") == (n "") { f = 1 } END { exit !f }'; }



exits_of() { sh "$ENODIA_DIR/slots.sh" list-enabled 2>/dev/null | awk -F"$TAB" -v c="$1" '$2 == "awg" && ($3 "") == (c "") { print $1 }'; }




reup_exits() {
    _wrf=""
    for _wx in $(exits_of "$1"); do
        _wxo=$(sh "$ENODIA_DIR/slots.sh" set "$_wx" config "$1" 2>&1) && ! printf '%s' "$_wxo" | grep -q 'не поднялась' || _wrf="$_wrf${_wrf:+, }№$_wx"
    done
}

reup_note() { [ -z "$_wrf" ] || printf '; выход %s не поднялся — откройте его в «Дополнительных выходах»' "$_wrf"; }


reg_line() { [ -n "$1" ] && [ -f "$REG" ] && awk -F"$TAB" -v k="$1" '($1 "") == (k "") { print; exit }' "$REG" 2>/dev/null; }



reg_lock() { _wrl=0; lbl_lock_take "$REGL" 'warp\.sh' && _wrl=1; return 0; }
reg_unlock() { [ "$_wrl" = 1 ] && lbl_lock_drop "$REGL"; _wrl=0; return 0; }






reg_commit() { ( umask 077; lbl_commit "$REG" "$1" ); }

reg_others() {
    _wrx=""
    [ -f "$REG" ] || return 0
    _wrx=$(awk -F"$TAB" -v k="$1" '($1 "") != (k "")' "$REG" 2>/dev/null) || return 1
    return 0
}
reg_put() {   # pub own id token at port cut colo i1 pat
    [ -n "$1" ] || return 1
    reg_lock
    _wrr=1
    if reg_others "$1"; then
        reg_commit "${_wrx:+$_wrx$NL}$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' "$1" "${2:-0}" "${3:--}" "${4:--}" "${5:-0}" "${6:--}" "${7:--}" "${8:--}" "${9:--}" "${10:-0}")"; _wrr=$?
    fi
    reg_unlock
    return "$_wrr"
}
reg_drop() {
    [ -n "$1" ] && [ -f "$REG" ] || return 0
    reg_lock
    reg_others "$1" && reg_commit "$_wrx"
    reg_unlock
    return 0
}


warp_keys() {
    [ -x "$ENODIA_BIN/awg" ] || return 1
    for _wpn in $(cmd_list | cut -f1); do
        _wk=$(cfg_pub "$ENODIA_STATE/configs/$_wpn.conf"); [ -n "$_wk" ] || return 1
        printf '%s\n' "$_wk"
    done
    return 0
}







cmd_prune() {   # $1 = give — the registrations of the OWN records dropped here go back to Cloudflare (give_bg)
    [ -s "$REG" ] || return 0
    reg_lock
    _wpgv=""
    if _wkeep=$(warp_keys); then
        _wprn=""
        while IFS= read -r _wprl || [ -n "$_wprl" ]; do
            case "$NL$_wkeep$NL" in
                *"$NL${_wprl%%"$TAB"*}$NL"*) _wprn="${_wprn:+$_wprn$NL}$_wprl" ;;
                *) _wpgv="${_wpgv:+$_wpgv$NL}$_wprl" ;;
            esac
        done < "$REG"
        reg_commit "$_wprn" || _wpgv=""   # not rewritten — the lines (and their tokens) are still in the record: nothing goes back
    fi
    reg_unlock
    if [ "$1" = give ] && [ -n "$_wpgv" ]; then give_bg "$_wpgv"; fi
    return 0
}









give_bg() {   # $1 = the dropped lines of the record
    _wgl=$(printf '%s\n' "$1" | awk -F"$TAB" '$2 == "1" && $3 != "" && $3 != "-" && $4 != "" && $4 != "-" { print $3 "\t" $4 }')
    [ -n "$_wgl" ] || return 0
    _wgf=$(umask 077; mktemp /tmp/enodia-warp-give.XXXXXX 2>/dev/null) || return 0
    printf '%s\n' "$_wgl" > "$_wgf" || { rm -f "$_wgf"; return 0; }
    if [ -x /sbin/start-stop-daemon ]; then
        start-stop-daemon -S -b -m -p "$_wgf.pid" -x /bin/sh -- "$ENODIA_DIR/warp.sh" run-give "$_wgf" >/dev/null 2>&1
    else ( sh "$ENODIA_DIR/warp.sh" run-give "$_wgf" </dev/null >/dev/null 2>&1 & ); fi
    return 0
}
cmd_run_give() {   # $1 = the file of `id⇥token` pairs — ours by its name, and nothing else
    case "$1" in /tmp/enodia-warp-give.*) ;; *) return 1 ;; esac
    [ -f "$1" ] || return 0
    _wgvf=$1
    trap 'rm -f "$_wgvf" "$_wgvf.pid"' EXIT
    trap 'exit 1' INT TERM HUP PIPE
    while IFS="$TAB" read -r _wgi _wgt || [ -n "$_wgi" ]; do reg_del "$_wgi" "$_wgt"; done < "$_wgvf"
    return 0
}





IMPORT_MAX=64
cmd_import() {
    if [ -f "$1" ]; then
        reg_lock

        _wim=0; _wia=""
        while IFS="$TAB" read -r _wr1 _wr2 _wr3 _wr4 _wr5 _wr6 _wr7 _wr8 _wr9 _wr10 _wrrest || [ -n "$_wr1" ]; do
            [ "$_wim" -lt "$IMPORT_MAX" ] || break
            printf '%s' "$_wr1" | grep -Eq '^[A-Za-z0-9+/]{43}=$' || continue
            case "$_wr2" in 0|1) ;; *) continue ;; esac
            printf '%s\n%s\n' "$_wr3" "$_wr4" | grep -Evq '^(-|[A-Za-z0-9_-]{1,64})$' && continue
            printf '%s\n%s\n' "$_wr5" "$_wr10" | grep -Evq '^(0|[1-9][0-9]{0,11})$' && continue
            case "$_wr6" in -) ;; ''|0*|*[!0-9]*) continue ;; esac
            case "$_wr7" in -) ;; ''|*[!0-9,]*) continue ;; esac
            case "$_wr8" in -|[A-Z][A-Z][A-Z]) ;; *) continue ;; esac
            case "$_wr9" in -|gen|custom) ;; *) continue ;; esac
            _wim=$((_wim+1))
            _wia="${_wia:+$_wia$NL}$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' "$_wr1" "$_wr2" "$_wr3" "$_wr4" "$_wr5" "$_wr6" "$_wr7" "$_wr8" "$_wr9" "$_wr10")"
        done < "$1"

        if [ -n "$_wia" ] && _wia=$(printf '%s\n' "$_wia" | awk -F"$TAB" '{ a[$1] = $0; if (!($1 in o)) { o[$1] = 1; q[++n] = $1 } }
                END { for (i = 1; i <= n; i++) print a[q[i]] }') && [ -n "$_wia" ]; then
            _wiak=$(printf '%s\n' "$_wia" | cut -f1); _wio=""
            if [ -f "$REG" ]; then
                while IFS= read -r _wil || [ -n "$_wil" ]; do
                    [ -n "$_wil" ] || continue
                    case "$NL$_wiak$NL" in *"$NL${_wil%%"$TAB"*}$NL"*) ;; *) _wio="${_wio:+$_wio$NL}$_wil" ;; esac
                done < "$REG"
            fi
            reg_commit "${_wio:+$_wio$NL}$_wia"
        fi
        reg_unlock
    fi
    cmd_prune
}



reg_new() {
    say "создаю ключ на роутере"
    _wpriv=$("$ENODIA_BIN/awg" genkey 2>/dev/null); _wpub=$(printf '%s' "$_wpriv" | "$ENODIA_BIN/awg" pubkey 2>/dev/null)
    [ -n "$_wpriv" ] && [ -n "$_wpub" ] || fail "не удалось создать ключ (awg genkey)"
    say "регистрируюсь у Cloudflare"
    _wtos=$(date -u '+%Y-%m-%dT%H:%M:%S.000Z')
    printf '{"key":"%s","install_id":"","fcm_token":"","tos":"%s","model":"PC","serial_number":"","locale":"en_US"}' "$_wpub" "$_wtos" > "$W/req"
    _wca=$(curl_ca_opt "$API/reg")

    _wc=$(curl -s $_wca -o "$W/reg" -w '%{http_code}' --connect-timeout 10 --max-time 20 -X POST \
        -H "User-Agent: $UA" -H "CF-Client-Version: $CV" -H 'Content-Type: application/json' --data-binary @"$W/req" "$API/reg" 2>/dev/null)
    case "$_wc" in
        200) ;;
        000|'') fail "Cloudflare не ответил — попробуйте позже" ;;
        *) fail "Cloudflare отклонил регистрацию (HTTP $_wc): он сменил порядок — нужна новая версия панели" ;;
    esac
    _wsk=$(jsonfilter -i "$W/reg" -e '@.config.peers[0].public_key' 2>/dev/null)
    _wv4=$(jsonfilter -i "$W/reg" -e '@.config.interface.addresses.v4' 2>/dev/null)
    _wv6=$(jsonfilter -i "$W/reg" -e '@.config.interface.addresses.v6' 2>/dev/null)
    _wep=$(jsonfilter -i "$W/reg" -e '@.config.peers[0].endpoint.v4' 2>/dev/null | sed 's/:[0-9]*$//')


    _wrid=$(jsonfilter -i "$W/reg" -e '@.id' 2>/dev/null); _wtok=$(jsonfilter -i "$W/reg" -e '@.token' 2>/dev/null)
    printf '%s' "$_wrid" | grep -Eq '^[A-Za-z0-9_-]{1,64}$' || _wrid=""
    printf '%s' "$_wtok" | grep -Eq '^[A-Za-z0-9_-]{1,64}$' || _wtok=""
    _wgid=$_wrid; _wgtok=$_wtok          # nobody's yet: `fail` gives it back (the three refusals right below included)
    [ "$_wsk" = "$WARP_PUB" ] || fail "Cloudflare прислал незнакомый ключ сервера — нужна новая версия панели"
    printf '%s' "$_wv4" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || fail "Cloudflare не прислал адрес — нужна новая версия панели"
    printf '%s' "$_wep" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || fail "Cloudflare не прислал адрес сервера — нужна новая версия панели"
}





reg_del() {
    [ -n "$1" ] && [ -n "$2" ] && [ "$1" != - ] && [ "$2" != - ] || return 0
    _wdh=$(umask 077; mktemp /tmp/enodia-warp-del.XXXXXX 2>/dev/null) || return 0
    printf 'header = "Authorization: Bearer %s"\n' "$2" > "$_wdh"
    _wca=$(curl_ca_opt "$API/reg/$1")

    curl -s $_wca -K "$_wdh" -o /dev/null --connect-timeout 8 --max-time 15 -X DELETE \
        -H "User-Agent: $UA" -H "CF-Client-Version: $CV" "$API/reg/$1" >/dev/null 2>&1
    rm -f "$_wdh"
    return 0
}



pick() {
    _wport=""; _wcolo=""; _wcut=""
    _wpl=$1; [ -n "$2" ] || for _wp in $PORTS; do [ "$_wp" = "$1" ] || _wpl="$_wpl $_wp"; done
    _wn=0; _wall=0
    for _wp in $_wpl; do _wall=$((_wall+1)); done
    for _wp in $_wpl; do
        _wn=$((_wn+1))
        if [ -n "$2" ]; then say "спрашиваю WARP с этой маскировкой (порт $_wp)"; else say "ищу порт, который провайдер не режет: $_wp ($_wn из $_wall)"; fi
        $MK "$_wp" > "$W/conf" || fail "не удалось записать конфиг"
        _wtr=$(sh "$ENODIA_DIR/transport-awg.sh" try "$W/conf" "$TRACE" "$TRY_SECS" 2>/dev/null); _wrc=$?
        case "$_wrc" in
            0) if printf '%s\n' "$_wtr" | grep -qx 'warp=on'; then
                   _wport=$_wp; _wcolo=$(printf '%s\n' "$_wtr" | sed -n 's/^colo=\([A-Z][A-Z][A-Z]\)$/\1/p' | head -n 1); break
               fi ;;
            4) _wsoon=1; fail "не поднялся пробный интерфейс AmneziaWG — проверьте его в «Компонентах»" ;;
            5) _wsoon=1; fail "сейчас идёт другая проба конфига — повторите через минуту" ;;
        esac
        _wcut="$_wcut${_wcut:+,}$_wp"
    done
}










name_held() {   # $1 = a config name → 0 when somebody names it
    { [ -f "$ENODIA_DIR/slots.sh" ] && sh "$ENODIA_DIR/slots.sh" configs awg 2>/dev/null
      head -n 1 "$ENODIA_STATE/.active" 2>/dev/null; echo
      head -n 1 "$ENODIA_STATE/.failover-home" 2>/dev/null; echo
    } | tr -d '\r' | grep -Fxi "$1" >/dev/null
}
next_name() {
    for _wnn in "" 2 3 4 5 6 7 8 9; do
        _wcand="$NAME${_wnn:+-$_wnn}"
        ls -1 "$ENODIA_STATE/configs" 2>/dev/null | grep -Fxi "$_wcand.conf" >/dev/null && continue
        name_held "$_wcand" && continue
        printf '%s' "$_wcand"; return 0
    done
    return 1
}


target() {
    _wnm=""
    printf '%s' "$1" | grep -qE '^[A-Za-z0-9_.-]+$' || { _wtm="недопустимое имя конфига"; return 1; }
    _wnm=$1
    [ -f "$ENODIA_STATE/configs/$1.conf" ] || { _wtm="нет конфига «$1»"; return 1; }
    is_warp "$1" || { _wtm="конфиг «$1» — не WARP"; return 1; }





    if [ "$(cat "$ENODIA_STATE/.active" 2>/dev/null | tr -d ' \r\n')" = "$1" ]; then
        _wtm="«$1» выбран сервером AmneziaWG для основного канала — сперва выберите там другой"; return 1
    fi
    _wsrc="$ENODIA_STATE/configs/$1.conf"; _wcur=$(cfg_port "$_wsrc"); _wopub=$(cfg_pub "$_wsrc"); _wold=$(reg_line "$_wopub")
    [ -n "$_wcur" ] || { _wtm="в конфиге «$1» нет порта сервера"; return 1; }
    return 0
}


still_there() { [ -f "$_wsrc" ] || fail "конфиг «$_wnm» удалён, пока шла работа — ничего не записано"; }
conf_write() {
    still_there
    ( umask 077; cp "$W/new" "$_wsrc.$$" ) && mv "$_wsrc.$$" "$_wsrc" || { rm -f "$_wsrc.$$"; fail "не удалось записать конфиг (место на разделе?)"; }
}



conf_new() {
    _wcnt=$(conf_as "$@") && [ -n "$_wcnt" ] && ( umask 077; lbl_commit "$W/new" "$_wcnt" ) || fail "не удалось записать конфиг"
}



conf_save() {
    conf_write
    reg_put "$@"
    say "перезапускаю выход"
    reup_exits "$_wnm"
}


work_dir() {
    W=/tmp/enodia-warp.work.$$
    rm -rf /tmp/enodia-warp.work.* /tmp/enodia-warp-mask.* /tmp/enodia-warp-del.* "$HOLDF" 2>/dev/null
    ( umask 077; mkdir "$W" ) || fail "нет места для работы"
    trap 'rm -rf "$W" "$PIDF"' EXIT
    trap 'exit 1' INT TERM HUP PIPE
}






job_alive() { _wjp=$(cat "$1" 2>/dev/null | tr -cd '0-9'); [ -n "$_wjp" ] && pid_runs "$_wjp" 'warp\.sh'; }
busy() { job_alive "$PIDF" || job_alive "$STARTF"; }





take_start() {
    lbl_lock_take "$STARTL" 'warp\.sh' || return 1
    if busy; then lbl_lock_drop "$STARTL"; return 1; fi
    rm -f "$STARTF" "$PIDF"

    ( set -C; echo $$ > "$STARTF" ) 2>/dev/null || { lbl_lock_drop "$STARTL"; return 1; }
    lbl_lock_drop "$STARTL"
    trap 'rm -f "$STARTF"' EXIT
    trap 'exit 1' INT TERM HUP PIPE
    return 0
}
BUSY_MSG="[warp] другая работа с WARP уже идёт — дождитесь её"


start() {
    say "начинаю"
    if [ -x /sbin/start-stop-daemon ]; then
        start-stop-daemon -S -b -m -p "$PIDF" -x /bin/sh -- "$ENODIA_DIR/warp.sh" "$@" >/dev/null 2>&1
    else ( sh "$ENODIA_DIR/warp.sh" "$@" >/dev/null 2>&1 & echo $! > "$PIDF" ); fi

    _wsw=0
    while ! job_alive "$PIDF" && [ "$_wsw" -lt 20 ]; do
        if command -v usleep >/dev/null 2>&1; then usleep 100000; else sleep 1; _wsw=$((_wsw+9)); fi
        _wsw=$((_wsw+1))
    done
}
need_awg() { [ -x "$ENODIA_BIN/awg" ] || { echo "[warp] нет AmneziaWG — поставьте его в «Компонентах»"; return 1; }; }





get_room() {   # $1 = rider (optional)
    _wgr=$(sh "$ENODIA_DIR/slots.sh" free 2>/dev/null | tail -n 1)
    case "$_wgr" in '[slots] '*) _wtm=${_wgr#\[slots\] }; return 1 ;; esac
    if [ -n "$1" ] && [ -f "$ENODIA_DIR/road.sh" ]; then
        _wgr=$(sh "$ENODIA_DIR/road.sh" serves awg "$1" 2>/dev/null | tr -cd '2-7' | cut -c1)
        [ -z "$_wgr" ] || { _wtm="«$1» сам служит дорогой (выход №$_wgr) — дорога бывает только в один шаг"; return 1; }
    fi
    return 0
}
cmd_get() {
    if [ -n "$1" ]; then printf '%s' "$1" | grep -qE '^[A-Za-z0-9_.-]+$' && [ -f "$ENODIA_STATE/configs/$1.conf" ] \
        || { echo "[warp] нет конфига «$1»"; return 1; }; fi
    _wnm=$(next_name) || { echo "[warp] имена WARP … WARP-9 заняты — удалите ненужный конфиг"; return 1; }
    need_awg || return 1
    get_room "$1" || { echo "[warp] $_wtm"; return 1; }
    take_start || { echo "$BUSY_MSG"; return 1; }
    start run "$1"
    echo "[warp] получаю WARP — обычно до 30 секунд"
}
cmd_run() {   # $1 = rider (optional)
    _wnm=$(next_name) || fail "имена WARP … WARP-9 заняты — удалите ненужный конфиг"
    get_room "$1" || fail "$_wtm"
    work_dir
    reg_new
    MK=wconf; pick ""
    [ -n "$_wport" ] || fail "Cloudflare выдал WARP, но провайдер режет его на всех портах ($(echo $PORTS | sed 's/ /, /g')) — конфиг не сохранён"
    say "сохраняю конфиг (порт $_wport)"
    mkdir -p "$ENODIA_STATE/configs" || fail "нет каталога конфигов"
    _wtmp="$ENODIA_STATE/configs/$_wnm.conf.$$"
    ( umask 077; cp "$W/conf" "$_wtmp" ) || { rm -f "$_wtmp"; fail "не удалось записать конфиг (место на разделе?)"; }




    _wtk=0; _wtn=0
    while [ "$_wtn" -lt 10 ]; do
        _wtn=$((_wtn+1))
        ( set -C; umask 077; : > "$ENODIA_STATE/configs/$_wnm.conf" ) 2>/dev/null && { _wtk=1; break; }
        [ -e "$ENODIA_STATE/configs/$_wnm.conf" ] || break
        _wnm=$(next_name) || { _wtk=2; break; }
    done
    case "$_wtk" in
        1) ;;
        2) rm -f "$_wtmp"; fail "имена WARP … WARP-9 заняты — удалите ненужный конфиг" ;;
        *) rm -f "$_wtmp"; fail "не удалось записать конфиг (место на разделе?)" ;;
    esac
    mv "$_wtmp" "$ENODIA_STATE/configs/$_wnm.conf" || { rm -f "$_wtmp" "$ENODIA_STATE/configs/$_wnm.conf"; fail "не удалось записать конфиг (место на разделе?)"; }
    owned
    reg_put "$_wpub" 1 "$_wrid" "$_wtok" "$(now_s)" "$_wport" "$_wcut" "$_wcolo" gen "$(now_s)"
    say "создаю выход"
    _wso=$(sh "$ENODIA_DIR/slots.sh" add "$_wnm" awg "$_wnm" main 2>&1)
    _wid=$(printf '%s\n' "$_wso" | sed -n 's/.*выход №\([2-7]\) .*создан.*/\1/p' | tail -n 1)


    [ -n "$_wid" ] || fail "конфиг «$_wnm» сохранён, а выход не создался: $(printf '%s' "$_wso" | tail -n 1 | sed 's/^\[slots\] //' | tr -d '"\\' | jtxt 600)"
    if [ -n "$1" ]; then
        say "прокладываю дорогу для $1"
        _wro=$(sh "$ENODIA_DIR/road.sh" set awg "$1" "$_wid" 2>&1) \
            || fail "WARP получен (выход №$_wid), а дорога не встала: $(printf '%s' "$_wro" | tail -n 1 | sed 's/^\[road\] //' | tr -d '"\\' | jtxt 600)"
    fi
    put "{\"state\":\"done\",\"op\":\"get\",\"name\":\"$_wnm\",\"exit\":\"$_wid\",\"rider\":\"$1\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"WARP получен: выход №$_wid${1:+, $1 едет через него}\"}"
    exit 0
}



cmd_repick() { target "$1" || { echo "[warp] $_wtm"; return 1; }; need_awg || return 1
    take_start || { echo "$BUSY_MSG"; return 1; }
    OP=repick
    if [ "$2" = own ]; then start run-repick-own "$1"; else start run-repick "$1"; fi
    echo "[warp] подбираю порт — до двух минут"; }




















own_back() {
    [ "$_wodn" = 1 ] || return 0
    _wodn=0; rm -f "$HOLDF"; _wrf=""
    [ ! -f "$ENODIA_STATE/.vpn-off" ] || return 0      # the VPN was switched off meanwhile: nothing is raised, as it should be
    for _wx in $(exits_of "$_wnm"); do
        sh "$ENODIA_DIR/transport.sh" slot-up "$_wx" >/dev/null 2>&1 || _wrf="$_wrf${_wrf:+, }№$_wx"
    done
}
cmd_run_repick_own() {
    OP=repick; target "$1" || fail "$_wtm"
    work_dir
    _wodn=1
    trap 'own_back; rm -rf "$W" "$PIDF"' EXIT
    say "снимаю выход на время подбора — он всё равно не везёт"
    ( umask 077; set -C; printf '%s\n' "$_wnm" > "$HOLDF" ) 2>/dev/null   # noclobber: the name lives in the shared /tmp
    for _wx in $(exits_of "$_wnm"); do sh "$ENODIA_DIR/transport.sh" slot-down "$_wx" >/dev/null 2>&1; done
    MK=oconf; pick "$_wcur"

    [ -n "$_wport" ] || { own_back; fail "провайдер режет WARP на всех портах ($(echo "$_wcut" | sed 's/,/, /g')) — конфиг не изменён$(reup_note)"; }
    _wo=$(printf '%s' "$_wold" | cut -f2); _wi=$(printf '%s' "$_wold" | cut -f9)
    set -- "$_wopub" "${_wo:-0}" "$(printf '%s' "$_wold" | cut -f3)" "$(printf '%s' "$_wold" | cut -f4)" "$(printf '%s' "$_wold" | cut -f5)" \
        "$_wport" "$_wcut" "$_wcolo" "${_wi:--}" "$(now_s)"
    if [ "$_wport" = "$_wcur" ]; then
        still_there
        reg_put "$@"
        own_back
        put "{\"state\":\"done\",\"op\":\"repick\",\"name\":\"$_wnm\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"порт $_wport по-прежнему проходит — конфиг «$_wnm» не менялся$(reup_note)\"}"; exit 0
    fi
    conf_new "$_wsrc" "" "" "$_wport" ""
    conf_write
    reg_put "$@"
    say "перезапускаю выход"



    for _wx in $(exits_of "$_wnm"); do
        _wxi=$(sh "$ENODIA_DIR/transport.sh" slot-iface "$_wx" 2>/dev/null | head -n 1 | tr -d ' \t\r')
        [ -n "$_wxi" ] && [ -e "/sys/class/net/$_wxi" ] && sh "$ENODIA_DIR/transport.sh" slot-down "$_wx" >/dev/null 2>&1
    done
    own_back         # by the new text; a refusal above (the config deleted, no room for it) brings them back by the old one — the trap
    put "{\"state\":\"done\",\"op\":\"repick\",\"name\":\"$_wnm\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"«$_wnm»: порт $_wcur провайдер режет — теперь $_wport$(reup_note)\"}"
    exit 0
}


cmd_holds() {
    [ -n "$1" ] && [ -f "$HOLDF" ] || return 1
    [ "$(head -n 1 "$HOLDF" 2>/dev/null | tr -d '\r\n')" = "$1" ] || return 1
    job_alive "$PIDF"
}


cmd_running() {
    busy || return 1
    _wrn=$(sed -n 's/.*"name":"\([^"]*\)".*/\1/p' "$ST" 2>/dev/null | head -n 1)
    [ -n "$_wrn" ] || return 1
    printf '%s\n' "$_wrn"
}
cmd_run_repick() {
    OP=repick; target "$1" || fail "$_wtm"
    work_dir
    reg_new; _wi1=""
    MK=xconf; pick "$_wcur"
    give_back
    [ -n "$_wport" ] || fail "провайдер режет WARP на всех портах ($(echo "$_wcut" | sed 's/,/, /g')) — конфиг не изменён"
    _wo=$(printf '%s' "$_wold" | cut -f2); _wi=$(printf '%s' "$_wold" | cut -f9)

    set -- "$_wopub" "${_wo:-0}" "$(printf '%s' "$_wold" | cut -f3)" "$(printf '%s' "$_wold" | cut -f4)" "$(printf '%s' "$_wold" | cut -f5)" \
        "$_wport" "$_wcut" "$_wcolo" "${_wi:--}" "$(now_s)"
    if [ "$_wport" = "$_wcur" ]; then


        still_there
        reg_put "$@"
        put "{\"state\":\"done\",\"op\":\"repick\",\"name\":\"$_wnm\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"порт $_wport по-прежнему проходит — конфиг «$_wnm» не менялся\"}"; exit 0
    fi
    conf_new "$_wsrc" "" "" "$_wport" ""
    conf_save "$@"
    put "{\"state\":\"done\",\"op\":\"repick\",\"name\":\"$_wnm\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"«$_wnm»: порт $_wcur провайдер режет — теперь $_wport$(reup_note)\"}"
    exit 0
}






cmd_reget() { target "$1" || { echo "[warp] $_wtm"; return 1; }; need_awg || return 1
    take_start || { echo "$BUSY_MSG"; return 1; }
    OP=reget; start run-reget "$1"; echo "[warp] получаю WARP заново — обычно до 30 секунд"; }
cmd_run_reget() {
    OP=reget; target "$1" || fail "$_wtm"
    work_dir
    _wkind=gen; _wkeep=""
    if [ "$(printf '%s' "$_wold" | cut -f9)" != gen ]; then
        _wkeep=$(cfg_val "$_wsrc" I1 | mask_norm)


        if [ "$_wkeep" != "$(gen_i1)" ] && printf '%s' "$_wkeep" | grep -Eq "$MASK_RE"; then _wkind=custom; else _wkeep=""; fi
    fi
    reg_new; _wi1=$_wkeep
    MK=wconf; pick "$_wcur"
    [ -n "$_wport" ] || fail "Cloudflare выдал WARP, но провайдер режет его на всех портах ($(echo "$_wcut" | sed 's/,/, /g')) — конфиг «$_wnm» не изменён"
    say "сохраняю конфиг (порт $_wport)"
    cp "$W/conf" "$W/new" || fail "не удалось записать конфиг"



    conf_write
    owned
    reg_put "$_wpub" 1 "$_wrid" "$_wtok" "$(now_s)" "$_wport" "$_wcut" "$_wcolo" "$_wkind" "$(now_s)"
    say "перезапускаю выход"
    reup_exits "$_wnm"



    if [ "$_wopub" != "$_wpub" ]; then
        if _wks=$(warp_keys) && ! printf '%s\n' "$_wks" | grep -Fxq "$_wopub"; then
            reg_drop "$_wopub"
            reg_del "$(printf '%s' "$_wold" | cut -f3)" "$(printf '%s' "$_wold" | cut -f4)"
        fi
    fi
    put "{\"state\":\"done\",\"op\":\"reget\",\"name\":\"$_wnm\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"«$_wnm» получен заново: ключ новый, порт $_wport$(reup_note)\"}"
    exit 0
}





MASK_RE='^(<(b 0x[0-9a-fA-F]+|r [0-9]+|rc [0-9]+|rd [0-9]+|c|t)>)+$'



mask_norm() { tr -d '\r\n' | sed 's/>[[:space:]]*</></g; s/^[[:space:]]*//; s/[[:space:]]*$//'; }
cmd_mask() { target "$1" || { echo "[warp] $_wtm"; return 1; }; need_awg || return 1
    _wmt=""
    if [ "$2" != gen ]; then
        [ -f "$2" ] || { echo "[warp] нет текста маскировки"; return 1; }
        _wmt=$(mask_norm < "$2")
        [ "${#_wmt}" -le 8000 ] && printf '%s' "$_wmt" | grep -Eq "$MASK_RE" \
            || { echo "[warp] маскировка — только теги <b 0x…>, <r N>, <rc N>, <rd N>, <c>, <t> подряд, до 8000 знаков"; return 1; }
    fi
    take_start || { echo "$BUSY_MSG"; return 1; }
    if [ "$2" != gen ]; then


        _wmf=$(mktemp /tmp/enodia-warp-mask.XXXXXX 2>/dev/null) || { echo "[warp] нет места для работы"; return 1; }
        printf '%s' "$_wmt" > "$_wmf"; set -- "$1" "$_wmf"
    fi
    OP=mask; start run-mask "$1" "$2"; echo "[warp] проверяю маскировку — до 20 секунд"; }
cmd_run_mask() {
    OP=mask
    _wkind=gen; _wi1=$(gen_i1)
    if [ "$2" != gen ]; then
        _wkind=custom; _wi1=$(mask_norm < "$2" 2>/dev/null)
        case "$2" in /tmp/enodia-warp-mask.*) rm -f "$2" ;; esac   # cmd_mask's private copy — and nothing else
    fi
    target "$1" || fail "$_wtm"
    printf '%s' "$_wi1" | grep -Eq "$MASK_RE" || fail "маскировка — только теги <b 0x…>, <r N>, <rc N>, <rd N>, <c>, <t> подряд"
    work_dir
    reg_new
    MK=xconf; pick "$_wcur" only
    give_back
    [ -n "$_wport" ] || fail "с этой маскировкой WARP не ответил (порт $_wcur) — конфиг «$_wnm» не изменён"
    conf_new "$_wsrc" "" "" "" "$_wi1"
    _wo=$(printf '%s' "$_wold" | cut -f2)
    conf_save "$_wopub" "${_wo:-0}" "$(printf '%s' "$_wold" | cut -f3)" "$(printf '%s' "$_wold" | cut -f4)" "$(printf '%s' "$_wold" | cut -f5)" \
        "$_wport" "$(printf '%s' "$_wold" | cut -f7)" "$_wcolo" "$_wkind" "$(printf '%s' "$_wold" | cut -f10)"
    put "{\"state\":\"done\",\"op\":\"mask\",\"name\":\"$_wnm\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"«$_wnm»: маскировка $([ "$_wkind" = gen ] && echo 'собрана роутером' || echo 'ваша') — WARP с ней отвечает$(reup_note)\"}"
    exit 0
}






cmd_device() { need_awg || return 1
    take_start || { echo "$BUSY_MSG"; return 1; }
    _wnm=""; OP=device; rm -f "$DEVF"; start run-device; echo "[warp] получаю WARP для устройства — обычно до 30 секунд"; }
cmd_run_device() {
    OP=device; _wnm=""
    work_dir
    reg_new; _wi1=""
    MK=dconf; pick ""
    [ -n "$_wport" ] || fail "Cloudflare выдал WARP, но провайдер режет его на всех портах ($(echo $PORTS | sed 's/ /, /g')) — конфиг не собран"
    rm -f "$DEVF"
    _wdn=$(umask 077; mktemp "$DEVF.XXXXXX" 2>/dev/null) && cp "$W/conf" "$_wdn" && mv "$_wdn" "$DEVF" || { rm -f "$_wdn"; fail "не удалось собрать конфиг"; }
    owned
    _wds=$(md5sum < "$DEVF" 2>/dev/null)
    ( sleep "$DEV_TTL"; [ -f "$DEVF" ] && [ "$(md5sum < "$DEVF" 2>/dev/null)" = "$_wds" ] && rm -f "$DEVF" ) </dev/null >/dev/null 2>&1 &
    put "{\"state\":\"done\",\"op\":\"device\",\"name\":\"\",\"port\":\"$_wport\",\"colo\":\"$_wcolo\",\"msg\":\"WARP для устройства получен: порт $_wport\"}"
    exit 0
}




cmd_device_take() {
    [ -f "$DEVF" ] || { echo '{"ok":false,"msg":"конфиг уже забран или не получен — получите новый"}'; return 0; }
    _wdt=$(base64 < "$DEVF" 2>/dev/null | tr -d '\n'); _wde=$(cfg_ep "$DEVF"); rm -f "$DEVF"
    [ -n "$_wdt" ] || { echo '{"ok":false,"msg":"не удалось прочитать конфиг"}'; return 0; }
    printf '%s' "$_wde" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || _wde=""
    printf '{"ok":true,"conf_b64":"%s","ep":"%s"}\n' "$_wdt" "$_wde"
}






cmd_status() {
    _wss=$(cat "$ST" 2>/dev/null)
    case "$_wss" in
        '{"state":"running",'*)
            if ! busy; then
                _wss=$(cat "$ST" 2>/dev/null)
                case "$_wss" in '{"state":"running",'*)
                    _wss=$(printf '%s\n' "$_wss" | sed 's/^{"state":"running",/{"state":"error",/; s/"msg":"[^"]*"/"msg":"работа прервалась — запустите её снова","soon":true/') ;;
                esac
            fi ;;
    esac
    case "$_wss" in '{'*'}') ;; *) _wss='{"state":"none"}' ;; esac
    if [ -f "$DEVF" ]; then _wdv=true; else _wdv=false; fi
    printf '%s\n' "$_wss" | sed "s/^{/{\"dev\":$_wdv,/"
}



cmd_list() {
    set -- "$ENODIA_STATE"/configs/*.conf
    [ -f "$1" ] || return 0
    awk -v k="$WARP_PUB" '
        FNR == 1 { if (nm != "" && w) print nm "\t" i; nm = FILENAME; sub(/^.*\//, "", nm); sub(/\.conf$/, "", nm); w = 0; i = 0 }
        { sub(/\r$/, "") }
        /^[ \t]*PublicKey[ \t]*=/ { v = $0; sub(/^[^=]*=[ \t]*/, "", v); sub(/[ \t]+$/, "", v); if (v == k) w = 1 }
        /^[ \t]*I1[ \t]*=/ { v = $0; sub(/^[^=]*=[ \t]*/, "", v); if (v ~ /[^ \t]/) i = 1 }
        END { if (nm != "" && w) print nm "\t" i }' "$@" 2>/dev/null | grep -E "^[A-Za-z0-9._-]+$(printf '\t')[01]\$"
}



cmd_info() {
    printf '{"now":%s,"items":[' "$(now_s)"
    _wfirst=1
    cmd_list | while IFS="$TAB" read -r _wn _wm; do
        [ -n "$_wn" ] || continue
        _wf="$ENODIA_STATE/configs/$_wn.conf"; _wr=$(reg_line "$(cfg_pub "$_wf")")
        _wown=0; _wat=0; _wct=""; _wcl=""; _wik=""; _wpat=0
        if [ -n "$_wr" ]; then
            [ "$(printf '%s' "$_wr" | cut -f2)" = 1 ] && _wown=1

            _wat=$(printf '%s' "$_wr" | cut -f5 | tr -cd '0-9' | sed 's/^0*//'); _wpat=$(printf '%s' "$_wr" | cut -f10 | tr -cd '0-9' | sed 's/^0*//')
            _wct=$(printf '%s' "$_wr" | cut -f7 | tr -cd '0-9,'); _wcl=$(printf '%s' "$_wr" | cut -f8 | tr -cd 'A-Z')
            _wik=$(printf '%s' "$_wr" | cut -f9 | tr -cd 'a-z')
        fi

        [ "$_wm" = 1 ] || _wik=none
        case "$_wik" in gen|custom|none) ;; *) _wik=other ;; esac
        [ "$_wfirst" = 1 ] || printf ','
        _wfirst=0
        printf '{"name":"%s","own":%s,"at":%s,"pat":%s,"ep":"%s","port":"%s","cut":"%s","colo":"%s","i1":"%s"}' \
            "$_wn" "$([ "$_wown" = 1 ] && echo true || echo false)" "${_wat:-0}" "${_wpat:-0}" \
            "$(cfg_ep "$_wf" | tr -cd 'A-Za-z0-9.:-')" "$(cfg_port "$_wf" | tr -cd '0-9')" "$_wct" "$_wcl" "$_wik"
    done
    printf ']}\n'
}


cmd_colo() {
    case "$1" in [2-7]) ;; *) echo '{"colo":"","why":"битый номер выхода"}'; return 0 ;; esac
    _wif=$(sh "$ENODIA_DIR/transport.sh" slot-iface "$1" 2>/dev/null | tr -cd 'a-z0-9')
    [ -n "$_wif" ] && [ -d "/sys/class/net/$_wif" ] || { echo '{"colo":"","why":"выход не поднят"}'; return 0; }
    _wca=$(curl_ca_opt "$TRACE" --interface "$_wif")

    _wtr=$(curl -s $_wca --interface "$_wif" --connect-timeout 5 --max-time "$TRY_SECS" "$TRACE" 2>/dev/null)
    _wcl=$(printf '%s\n' "$_wtr" | sed -n 's/^colo=\([A-Z][A-Z][A-Z]\)$/\1/p' | head -n 1)
    [ -n "$_wcl" ] || { echo '{"colo":"","why":"Cloudflare не ответил через выход"}'; return 0; }
    printf '{"colo":"%s","warp":%s}\n' "$_wcl" "$(printf '%s\n' "$_wtr" | grep -qx 'warp=on' && echo true || echo false)"
}

case "$1" in
    get)         cmd_get "$2" ;;
    repick)      cmd_repick "$2" "$3" ;;
    running)     cmd_running ;;
    holds)       cmd_holds "$2" ;;
    reget)       cmd_reget "$2" ;;
    mask)        cmd_mask "$2" "$3" ;;
    device)      cmd_device ;;
    device-take) cmd_device_take ;;
    status)      cmd_status ;;
    info)        cmd_info ;;
    prune)       cmd_prune "$2" ;;
    run-give)    cmd_run_give "$2" ;;
    import)      cmd_import "$2" ;;
    run)         cmd_run "$2" ;;
    run-repick)  cmd_run_repick "$2" ;;
    run-repick-own) cmd_run_repick_own "$2" ;;
    run-reget)   cmd_run_reget "$2" ;;
    run-mask)    cmd_run_mask "$2" "$3" ;;
    run-device)  cmd_run_device ;;
    i1)          gen_i1; echo ;;
    list)        cmd_list ;;
    colo)        cmd_colo "$2" ;;
    *)           echo "usage: $0 get [<конфиг>] | repick|reget <конфиг> | mask <конфиг> gen|<файл> | device | device-take | status | info | prune | import <файл> | i1 | list | colo <id>"; exit 2 ;;
esac
