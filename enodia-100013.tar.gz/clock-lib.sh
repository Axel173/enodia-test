#!/bin/sh















































uptime_s() {
	_cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null)
	case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac
	echo "$_cl_u"
}









age_since() {
	case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
	[ "$1" -gt 0 ] || { echo 999999; return; }
	_cl_age=$(( $(date +%s) - $1 ))   # clock-raw: здесь и живёт сама поправка, ниже по тексту







	if [ "$_cl_age" -lt 0 ]; then _cl_age=0; fi                     # часы шагнули назад
	if [ "$_cl_age" -gt "$(uptime_s)" ]; then _cl_age=0; fi         # отметка «старше загрузки» = скачок
	echo "$_cl_age"
}







up_age() {
	case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
	_cl_ua=$(( $(uptime_s) - $1 ))
	if [ "$_cl_ua" -lt 0 ]; then _cl_ua=999999; fi
	echo "$_cl_ua"
}










CLOCK_EPOCH_MIN=1700000000
CLOCK_EPOCH_MAX=4102444800
clock_sane() {
	_cse=${1:-$(date +%s 2>/dev/null)}
	case "$_cse" in ''|*[!0-9]*) return 1 ;; esac
	[ "$_cse" -gt "$CLOCK_EPOCH_MIN" ] 2>/dev/null && [ "$_cse" -lt "$CLOCK_EPOCH_MAX" ] 2>/dev/null
}









http_date_epoch() {
	_hde_s=$(printf '%s' "$1" | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*GMT.*$//; s/[[:space:]]*$//')
	[ -n "$_hde_s" ] || return 1
	_hde_e=$(date -u -D '%a, %d %b %Y %H:%M:%S' -d "$_hde_s" +%s 2>/dev/null)

	case "$_hde_e" in ''|*[!0-9]*) return 1 ;; esac
	printf '%s' "$_hde_e"
}



http_date_iso() {
	_hdi_e=$(http_date_epoch "$1") || return 1
	date -u -d "@$_hdi_e" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null
}













CARRIER_UP_STAMP=/tmp/.enodia-carrier-up.stamp



carrier_up_mark() {
	date +%s > "$CARRIER_UP_STAMP" 2>/dev/null
	return 0
}




















































CLOCK_SYNC_MARK=/tmp/enodia-clock.synced
CLOCK_SYNC_TRIES_F=/tmp/enodia-clock.tries    # «неудач за загрузку» + аптайм последней (см. clock_boot_sync)



CLOCK_HTTP_URLS="${CLOCK_HTTP_URLS:-http://1.1.1.1/ http://94.140.14.14/ http://208.67.222.222/ https://8.8.8.8/}"
CLOCK_HTTP_TMO=${CLOCK_HTTP_TMO:-3}          # с на источник (коннект — 2); четыре источника = потолок 12 с
CLOCK_AGREE=${CLOCK_AGREE:-10}              # на сколько секунд вправе разойтись два источника
CLOCK_STEP_MIN=${CLOCK_STEP_MIN:-30}        # вперёд двигаем от такого отставания
CLOCK_BACK_MIN=${CLOCK_BACK_MIN:-300}       # назад — от такого убегания
CLOCK_SYNC_TRIES=${CLOCK_SYNC_TRIES:-10}    # неудач за загрузку, после которых clock_boot_sync замолкает
CLOCK_RETRY_GAP=${CLOCK_RETRY_GAP:-300}     # с аптайма между неудачными попытками (12 с curl не на каждый тик)
CLOCK_STEP=0
CLOCK_MSG=
CLOCK_LOCK=/tmp/enodia-clock.lock           # heal и тик сторожа могут сверять ОДНОВРЕМЕННО — писатель часов один




command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }

clock_synced() { [ -f "$CLOCK_SYNC_MARK" ]; }




CLOCK_STOCK_NTP=/tmp/ntp.status
clock_trusted() {
	clock_sane || return 1
	clock_synced && return 0
	case "$(cut -d, -f1 "$CLOCK_STOCK_NTP" 2>/dev/null)" in ok) return 0 ;; esac
	return 1
}




clock_http_date() {
	_cd_h=$(curl -sI -k --connect-timeout 2 --max-time "$CLOCK_HTTP_TMO" --interface "$1" "$2" 2>/dev/null | awk 'tolower($1)=="date:"{sub(/^[Dd][Aa][Tt][Ee]: */,""); print; exit}')
	[ -n "$_cd_h" ] || return 1
	_cd_e=$(http_date_epoch "$_cd_h") || return 1
	clock_sane "$_cd_e" || return 1
	printf '%s' "$_cd_e"
}





clock_rebase_stamps() {
	_rb_n=0
	for _rb_f in /tmp/enodia-*.stamp /tmp/.enodia-*.stamp; do
		[ -f "$_rb_f" ] || continue
		_rb_v=$(cat "$_rb_f" 2>/dev/null | tr -d ' \r\n')
		case "$_rb_v" in ''|*[!0-9]*) continue ;; esac
		echo $(( _rb_v + $1 )) > "$_rb_f" 2>/dev/null && _rb_n=$((_rb_n + 1))
	done
	return 0
}

clock_http_sync() {
	CLOCK_STEP=0; CLOCK_MSG=
	[ -n "$1" ] || { CLOCK_MSG="часы: нет WAN-интерфейса для бинда — сверку пропускаю (без бинда проба ушла бы в туннель)"; return 2; }
	_cs_d1=; _cs_u1=; _cs_d=; _cs_u=; _cs_ans=0
	for _cs_u in $CLOCK_HTTP_URLS; do
		_cs_web=$(clock_http_date "$1" "$_cs_u") || continue
		_cs_ans=$((_cs_ans + 1))
		_cs_now=$(date +%s)
		_cs_d=$(( _cs_web - _cs_now ))   # clock-raw: две точки одних и тех же секунд, разность = сама поправка


		if [ -z "$_cs_d1" ]; then _cs_d1=$_cs_d; _cs_u1=$_cs_u; _cs_d=; continue; fi
		_cs_diff=$(( _cs_d - _cs_d1 )); [ "$_cs_diff" -lt 0 ] && _cs_diff=$(( -_cs_diff ))
		if [ "$_cs_diff" -le "$CLOCK_AGREE" ]; then break; fi

		_cs_d1=$_cs_d; _cs_u1=$_cs_u; _cs_d=
	done
	if [ -z "$_cs_d" ]; then
		CLOCK_MSG="часы: двух согласных HTTP-источников даты не нашлось (ответили: $_cs_ans) — сверку повторю позже"
		return 1
	fi
	_cs_dir=
	if [ "$_cs_d" -gt "$CLOCK_STEP_MIN" ]; then _cs_dir=вперёд
	elif [ "$_cs_d" -lt "-$CLOCK_BACK_MIN" ]; then _cs_dir=назад
	fi
	if [ -z "$_cs_dir" ]; then
		echo "step=0 src=$_cs_u1+$_cs_u d=$_cs_d" > "$CLOCK_SYNC_MARK" 2>/dev/null
		CLOCK_MSG="часы: верны (расхождение с $_cs_u ${_cs_d} с) — отметка поставлена, больше не сверяю"
		return 3
	fi
	_cs_now=$(date +%s); _cs_web=$(( _cs_now + _cs_d ))
	date -u -s "@$_cs_web" >/dev/null 2>&1 || { CLOCK_MSG="часы: источники дают сдвиг ${_cs_d} с, а date -s не сработал — оставляю как есть"; return 1; }
	CLOCK_STEP=$_cs_d
	clock_rebase_stamps "$_cs_d"
	echo "step=$_cs_d src=$_cs_u1+$_cs_u was=$_cs_now" > "$CLOCK_SYNC_MARK" 2>/dev/null
	if [ "$_cs_dir" = вперёд ]; then
		CLOCK_MSG="часы: отставали на ${_cs_d} с (RTC нет, сток ставит время по mtime файла) — сдвинуты вперёд по HTTP-дате $_cs_u1 и $_cs_u; без этого сервер AWG молча отбрасывает рукопожатие как повтор"
	else
		CLOCK_MSG="часы: убегали на $(( -_cs_d )) с — возвращены назад по HTTP-дате $_cs_u1 и $_cs_u ДО несущей; иначе сервер AWG запомнил бы отметку из будущего и отбрасывал нас после правки стоковым ntp"
	fi
	clock_step_event
	return 0
}









clock_boot_sync() {
	if clock_synced; then return 1; fi
	command -v wan_iface >/dev/null 2>&1 || return 1
	_cb_n=0; _cb_last=0
	if [ -f "$CLOCK_SYNC_TRIES_F" ]; then read -r _cb_n _cb_last < "$CLOCK_SYNC_TRIES_F" || :; fi
	case "$_cb_n" in ''|*[!0-9]*) _cb_n=0 ;; esac
	case "$_cb_last" in ''|*[!0-9]*) _cb_last=0 ;; esac
	[ "$_cb_n" -lt "$CLOCK_SYNC_TRIES" ] || return 1
	_cb_up=$(uptime_s)
	[ "$_cb_n" = 0 ] || [ $(( _cb_up - _cb_last )) -ge "$CLOCK_RETRY_GAP" ] || return 1
	_cb_if=$(wan_iface)
	[ -n "$_cb_if" ] || return 1



	_cb_lp=$(cat "$CLOCK_LOCK" 2>/dev/null | tr -cd '0-9')
	if [ -n "$_cb_lp" ] && [ -d "/proc/$_cb_lp" ]; then return 1; fi
	[ -n "$_cb_lp" ] && rm -f "$CLOCK_LOCK" 2>/dev/null
	( set -C; echo "$$" > "$CLOCK_LOCK" ) 2>/dev/null || return 1
	clock_http_sync "$_cb_if"; _cb_rc=$?
	rm -f "$CLOCK_LOCK" 2>/dev/null
	case "$_cb_rc" in
		0) return 0 ;;
		3) return 1 ;;
		*) echo "$((_cb_n + 1)) $_cb_up" > "$CLOCK_SYNC_TRIES_F" 2>/dev/null; return 1 ;;
	esac
}




clock_step_event() {
	_ce_s=${CLOCK_STEP:-0}; _ce_dir=вперёд
	[ "$_ce_s" != 0 ] || return 0
	if [ "$_ce_s" -lt 0 ]; then _ce_s=$(( -_ce_s )); _ce_dir=назад; fi
	[ -n "$ENODIA_DIR" ] && [ -f "$ENODIA_DIR/events.sh" ] || return 0


	if [ "$_ce_s" -ge 86400 ]; then _ce_h="$((_ce_s / 86400)) дн"
	elif [ "$_ce_s" -ge 3600 ]; then _ce_h="$((_ce_s / 3600)) ч"
	elif [ "$_ce_s" -ge 60 ]; then _ce_h="$((_ce_s / 60)) мин"
	else _ce_h="$_ce_s с"; fi
	sh "$ENODIA_DIR/events.sh" add clock-step 0 "Часы сдвинуты $_ce_dir на $_ce_h" \
"После перезагрузки часы роутера расходились с реальным временем (RTC нет). Без поправки VPN-сервер отбрасывал бы рукопожатие как повтор, и роутер ушёл бы на резервный сервер. Время взято из HTTP-даты двух независимых узлов, мимо туннеля." >/dev/null 2>&1 || true
	return 0
}
