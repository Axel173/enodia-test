#!/bin/sh

















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }






if [ -f "$ENODIA_DIR/lists-lib.sh" ]; then
	. "$ENODIA_DIR/lists-lib.sh"
else
	echo "geo: нет $ENODIA_DIR/lists-lib.sh — обновите установку (панель → «Обновление» или переустановка с компьютера)" >&2
	exit 1
fi



if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }

GEO="$ENODIA_STATE/geo"       # ПЕРСИСТ на флеше: реестр действий/провайдеров + снимки агрегатов
REG="$GEO/actions.tsv"
PROV="$GEO/providers.tsv"     # выбор провайдера на тип: type<TAB>pid (дормант — оставлен на возможный возврат)
SHAS="$GEO/.shas"             # SHA-пиновка фетча: repo_id<TAB>sha<TAB>upstream_iso (иммутабельный jsDelivr — убирает 12ч-эдж-лаг)
RAM="/tmp/enodia-geo"         # ОЗУ: кэш фетча + рабочие файлы + состояние обновления
CACHE="$RAM/cache"
GEO_LOCK="$RAM/.build.lock"   # сериализация сборки (apply/update/provider-set) — ls_lock_take
GEO_DIRTY="$RAM/.build.dirty" # «пока собирали, попросили ещё раз»; содержимое = запрошенный refetch (0|1)
SET_VPN=geo_vpn
SET_OUT=geo_out
SET_BLK=geo_block



SET_DSY=geo_zapret
SNAP_VPN="$GEO/.snap-vpn"                 # флеш-снимки CIDR-агрегатов
SNAP_OUT="$GEO/.snap-out"
SNAP_BLK="$GEO/.snap-blk"
SNAP_DSY="$GEO/.snap-dsy"
DNSCONF=/tmp/dnsmasq.d/11-geo.conf        # ЖИВОЙ conf: ipset=/дом/geo_vpn|geo_out (маршрут доменов)
DNSBLK=/tmp/dnsmasq.d/12-geo-block.conf   # ЖИВОЙ conf: address=/дом/0.0.0.0 (блок доменов; отдельно от adblock/ipblock)
SNAP_DNS="$GEO/.snap-dns"                 # флеш-снимки доменных conf (офлайн-ребут переживает)
SNAP_DNSBLK="$GEO/.snap-dnsblk"
V2CAT_SNAP="$GEO/.cat-v2fly"              # флеш-снимок ПЕРЕЧИСЛЕНИЯ категорий v2fly (свежий, с апстрима)
V2CAT_BAKED="$ENODIA_DIR/geo-v2fly-catalog.txt"  # baked-фолбэк в комплекте скриптов (панель не пуста до первого update/офлайн)
V2CAT_URL='https://data.jsdelivr.com/v1/packages/gh/v2fly/domain-list-community@master?structure=flat'  # листинг data/<категория>






RFIP_SNAP="$GEO/.cat-rfip"; RFIP_BAKED="$ENODIA_DIR/geo-rfip-catalog.txt"
RFGS_SNAP="$GEO/.cat-rfgs"; RFGS_BAKED="$ENODIA_DIR/geo-rfgs-catalog.txt"




RESOLVER_VER=2
RVER="$GEO/.rver"                         # последняя применённая версия резолвера (флеш)

mkdir -p "$GEO" "$CACHE" 2>/dev/null
[ -f "$REG" ] || : > "$REG"







jsd_ref() {   # jsd_ref <repo_id> <ветка-фолбэк> → "@<sha>" (если известен) или "@<ветка>"
	_s=$(grep "^$1$TAB" "$SHAS" 2>/dev/null | head -1 | cut -f2)
	case "$_s" in [0-9a-f][0-9a-f]*) printf '@%s' "$_s" ;; *) printf '@%s' "$2" ;; esac
}
set_source_urls() {   # (пере)собрать пиновку в globals — на старте (из прежнего $SHAS) и после resolve_upstream
	RF="https://cdn.jsdelivr.net/gh/runetfreedom/russia-blocked-geoip$(jsd_ref rfip release)/text"       # CIDR РКН (geoip, per-category)
	RF_GEOSITE="https://cdn.jsdelivr.net/gh/runetfreedom/russia-blocked-geosite$(jsd_ref rfgs release)"   # домены РКН (geosite, плоские domain:/full:)
	V2FLY="https://cdn.jsdelivr.net/gh/v2fly/domain-list-community$(jsd_ref v2fly master)/data"           # домены v2fly (include-рекурсия)
}
set_source_urls
IPDENY='https://www.ipdeny.com/ipblocks/data/aggregated'                                  # CIDR стран (весь пул IP страны; дормант — из панели выведено)





provider_lines() {
	cat <<EOF
service|v2fly|v2fly community (глобальный)|https://api.github.com/repos/v2fly/domain-list-community/commits/master
service|rf-geosite|runetfreedom (RU-блокировки)|https://api.github.com/repos/runetfreedom/russia-blocked-geosite/commits/release
country|ipdeny|ipdeny.com|
blocked|rf-geoip|runetfreedom (РКН)|https://api.github.com/repos/runetfreedom/russia-blocked-geoip/commits/release
EOF
}
provider_default() { provider_lines | awk -F'|' -v t="$1" '$1==t{print $2; exit}'; }
provider_get() {   # provider_get <type> → выбранный pid (валидный) или дефолт
	_p=$(grep "^$1$TAB" "$PROV" 2>/dev/null | head -1 | cut -f2)
	if [ -n "$_p" ] && provider_lines | grep -q "^$1|$_p|"; then printf '%s' "$_p"; return; fi
	provider_default "$1"
}
provider_set() {   # provider_set <type> <pid> → валидация + персист
	provider_lines | grep -q "^$1|$2|" || { echo "неизвестный провайдер: $1/$2"; return 1; }
	grep -v "^$1$TAB" "$PROV" 2>/dev/null > "$PROV.new"
	printf '%s\t%s\n' "$1" "$2" >> "$PROV.new"
	mv "$PROV.new" "$PROV"
}
prov_fresh_url() { provider_lines | awk -F'|' -v t="$1" -v p="$2" '$1==t&&$2==p{print $4; exit}'; }



















country_codes() {
	cat <<'EOF'
ad ae af ag ai al am ao aq ar as at au aw ax az ba bb bd be bf bg bh bi bj bl bm bn bo bq br bs bt bv bw by bz ca cc cd cf cg ch ci ck cl cm cn co cr cu cv cw cx cy cz de dj dk dm do dz ec ee eg eh er es et fi fj fk fm fo fr ga gb gd ge gf gg gh gi gl gm gn gp gq gr gs gt gu gw gy hk hm hn hr ht hu id ie il im in io iq ir is it je jm jo jp ke kg kh ki km kn kp kr kw ky kz la lb lc li lk lr ls lt lu lv ly ma mc md me mf mg mh mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nc ne nf ng ni nl no np nr nu nz om pa pe pf pg ph pk pl pm pn pr ps pt pw py qa re ro rs ru rw sa sb sc sd se sg sh si sj sk sl sm sn so sr ss st sv sx sy sz tc td tf tg th tj tk tl tm tn to tr tt tv tw tz ua ug um us uy uz va vc ve vg vi vn vu wf ws ye yt za zm zw
EOF
}
country_lines() {
	for _cc in $(country_codes); do
		[ -n "$_cc" ] || continue
		printf 'country|%s|%s|cidr|%s/%s-aggregated.zone||IP-пул страны (ipdeny)\n' \
			"$_cc" "$_cc" "$IPDENY" "$_cc"
	done
}






_blk_rfip() {
	_src="$RFIP_SNAP"; [ -s "$_src" ] || _src="$RFIP_BAKED"; [ -s "$_src" ] || return 0
	tr -d '\r' < "$_src" | while IFS= read -r _n; do
		[ -n "$_n" ] || continue
		printf 'blocked|rfip-%s|%s|cidr|%s/%s.txt|—|runetfreedom geoip: %s\n' "$_n" "$_n" "$RF" "$_n" "$_n"
	done
}
_blk_rfgs() {
	_src="$RFGS_SNAP"; [ -s "$_src" ] || _src="$RFGS_BAKED"; [ -s "$_src" ] || return 0
	tr -d '\r' < "$_src" | while IFS= read -r _n; do
		[ -n "$_n" ] || continue
		printf 'blocked|rfgs-%s|%s|domain|%s/%s.txt|—|runetfreedom geosite: %s\n' "$_n" "$_n" "$RF_GEOSITE" "$_n" "$_n"
	done
}
blocked_lines() { _blk_rfip; _blk_rfgs; }







svc_lines() { _svc_v2fly; }

_svc_rf() {
	for _n in youtube google discord; do
		printf 'service|rf-%s|%s|domain|%s/%s.txt|—|geosite runetfreedom: %s\n' \
			"$_n" "$_n" "$RF_GEOSITE" "$_n" "$_n"
	done
}




_svc_v2fly() {
	_src="$V2CAT_SNAP"; [ -s "$_src" ] || _src="$V2CAT_BAKED"
	[ -s "$_src" ] || return 0
	tr -d '\r' < "$_src" | while IFS= read -r _n; do
		[ -n "$_n" ] || continue
		printf 'service|v2fly-%s|%s|domain|v2fly:%s|—|geosite v2fly: %s\n' "$_n" "$_n" "$_n" "$_n"
	done
}











catalog_lines() {
	svc_lines            # v2fly geosite (сервисы/категории, домены)
	blocked_lines        # runetfreedom «заблок-в-РФ»: geoip (CIDR) + geosite (домены)
	country_lines        # страны-CIDR (ipdeny): весь пул IP страны — вкладка «Страны»
}






cat_type() {
	case "$1" in
		rfip-*|rfgs-*|ru-blocked|re-filter|ru-blocked-community) echo blocked ;;
		v2fly-*|rf-*) echo service ;;
		??) echo country ;;
		*) echo '' ;;
	esac
}

cat_kind() {
	case "$1" in
		v2fly-*|rf-*|rfgs-*) echo domain ;;
		rfip-*|ru-blocked|re-filter|ru-blocked-community|??) echo cidr ;;
		*) echo '' ;;
	esac
}



cat_label() {
	case "$1" in
		v2fly-*) echo "${1#v2fly-}" ;;
		rfip-*)  echo "${1#rfip-}" ;;
		rfgs-*)  echo "${1#rfgs-}" ;;
		rf-*)    echo "${1#rf-}" ;;
		*)       echo "$1" ;;
	esac
}
cat_url() {
	case "$1" in
		v2fly-*) echo "v2fly:${1#v2fly-}" ;;
		rfip-*)  echo "$RF/${1#rfip-}.txt" ;;
		rfgs-*)  echo "$RF_GEOSITE/${1#rfgs-}.txt" ;;
		rf-*)    echo "$RF_GEOSITE/${1#rf-}.txt" ;;
		ru-blocked)           echo "$RF/ru-blocked.txt" ;;
		re-filter)            echo "$RF/re-filter.txt" ;;
		ru-blocked-community) echo "$RF/ru-blocked-community.txt" ;;
		??)      echo "$IPDENY/$1-aggregated.zone" ;;
		*) echo '' ;;
	esac
}
jesc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }


reg_get()    { grep "^$1$TAB" "$REG" 2>/dev/null | head -1; }
reg_action() { reg_get "$1" | cut -f2; }
reg_write()  { cat > "$REG.new" && mv "$REG.new" "$REG"; }   # атомарно (обрыв не бьёт файл)

reg_set() {
	_k="$1"; _a="$2"

	_old=$(reg_get "$_k"); _c=$(printf '%s' "$_old" | cut -f3); _t=$(printf '%s' "$_old" | cut -f4)
	case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
	case "$_t" in ''|*[!0-9]*) _t=0 ;; esac


	_s=$(printf '%s' "$_old" | cut -f5)
	case "$_s" in [2-7]) ;; *) _s=0 ;; esac
	[ "$_a" = vpn ] || _s=0
	grep -v "^$_k$TAB" "$REG" 2>/dev/null > "$REG.tmp"
	[ "$_a" = off ] || printf '%s\t%s\t%s\t%s\t%s\n' "$_k" "$_a" "$_c" "$_t" "$_s" >> "$REG.tmp"
	mv "$REG.tmp" "$REG"
}
reg_set_meta() {  # reg_set_meta <key> <cnt> <ts>
	awk -F"$TAB" -v OFS="$TAB" -v k="$1" -v c="$2" -v t="$3" '$1==k{$3=c;$4=t} {print}' "$REG" > "$REG.new" 2>/dev/null && mv "$REG.new" "$REG"
}


migrate_reg() {
	[ -s "$REG" ] || return 0
	awk -F"$TAB" 'NF>0 && NF!=5{c=1} END{exit c?0:1}' "$REG" || return 0
	awk -F"$TAB" -v OFS="$TAB" 'NF==4{print $1,$2,$3,$4,"0"; next} NF>0{print}' "$REG" > "$REG.mig" \
		&& mv "$REG.mig" "$REG"
}
migrate_reg







SET_HASHSIZE=4096
SET_MAXELEM=1000000

if [ -f "$ENODIA_DIR/set-lib.sh" ]; then . "$ENODIA_DIR/set-lib.sh"; fi


if ! command -v set_sync >/dev/null 2>&1; then
	set_ensure() { ipset list -n 2>/dev/null | grep -qx "$1" || ipset create "$1" hash:net hashsize 4096 maxelem 1000000 2>/dev/null; }
	set_fill() {
		_s="$1"; _f="$2"
		set_ensure "$_s"
		ipset destroy "${_s}_new" 2>/dev/null
		ipset create "${_s}_new" hash:net hashsize 4096 maxelem 1000000 2>/dev/null || return 1
		if [ -s "$_f" ]; then
			awk -v s="${_s}_new" '/^[0-9]/{print "add " s " " $1}' "$_f" | ipset restore -exist 2>/dev/null
		fi
		ipset swap "${_s}_new" "$_s" 2>/dev/null
		ipset destroy "${_s}_new" 2>/dev/null
	}
	set_sync() { set_fill "$1" "$2"; }
fi


snap_flash() {
	_dst="$1"; _src="$2"
	_ln=$(grep -c '' "$_src" 2>/dev/null); case "$_ln" in ''|*[!0-9]*) _ln=0 ;; esac
	if [ "$_ln" -gt "$MAX_FLASH_CIDR" ]; then
		echo "снимок гео на флеш пропущен: $_ln строк > лимита $MAX_FLASH_CIDR (маршрут в RAM работает, офлайн-ребут не переживёт)"








		if [ -f "$ENODIA_DIR/events.sh" ]; then
			sh "$ENODIA_DIR/events.sh" add geo-snap-skip 86400 \
				"Гео-категория не переживёт перезагрузку" \
				"Категория слишком велика для снимка на флеш ($_ln строк при лимите $MAX_FLASH_CIDR). Сейчас она работает, но после перезагрузки роутера начнёт действовать не сразу — сперва её нужно будет заново скачать (несколько минут). Уменьшить ожидание можно, отключив самые крупные категории." >/dev/null 2>&1
		fi
		rm -f "$_dst" 2>/dev/null; return 0
	fi
	cp "$_src" "$_dst" 2>/dev/null
}




dns_reload() { sh "$ENODIA_DIR/dns-merge.sh" reload 2>/dev/null \
	|| /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null; }



ustate() { { echo "$1" > "$RAM/.update.state.new" && mv -f "$RAM/.update.state.new" "$RAM/.update.state"; } 2>/dev/null; }


uprogress() {
	if [ -n "$1" ] && [ -n "$2" ]; then printf '%s\t%s\n' "$1" "$2" > "$RAM/.update.progress" 2>/dev/null
	else rm -f "$RAM/.update.progress" 2>/dev/null; fi
	return 0
}





norm_geosite() {  # stdin (geosite-текст) → stdout (домен на строку)
	tr 'A-Z' 'a-z' | tr -d '\r' | awk '
		/^[[:space:]]*#/ {next}
		/^[[:space:]]*$/ {next}
		/^include:/ {next}
		/^regexp:/ {next}
		/^keyword:/ {next}
		{
			d=$1
			sub(/^full:/,"",d); sub(/^domain:/,"",d)
			# Метка ≤63 ({0,61} между граничными знаками) — тот же гард, что в lists-lib.sh:
			# geosite приезжает чужим файлом, а одна строка с длинной меткой роняет ВЕСЬ конфиг
			# dnsmasq (замер — в шапке dns-lib.sh::dom_ok).
			if (d ~ /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/) print d
		}'
}

























v2_name_ok() { case "$1" in ''|*[!a-z0-9._!-]*) return 1 ;; esac; return 0; }





v2_raw_dir() {
	_vrk=$(printf '%s' "$V2FLY" | md5sum 2>/dev/null | cut -c1-8 | tr -cd 'a-f0-9')
	[ -n "$_vrk" ] || _vrk=nopin



	for _vro in "$RAM"/.v2raw.*; do
		[ -d "$_vro" ] || continue
		[ "$_vro" = "$RAM/.v2raw.$_vrk" ] && continue
		rm -rf "$_vro" 2>/dev/null
	done
	printf '%s/.v2raw.%s' "$RAM" "$_vrk"
}



v2_fetch_level() {
	_vd="$1"; _vargs=""; _vn=0; _vgot="$RAM/.v2got.$$"; : > "$_vgot"
	while IFS= read -r _v || [ -n "$_v" ]; do
		[ -n "$_v" ] || continue
		[ -s "$_vd/$_v" ] && continue
		_vargs="$_vargs -o $_vd/$_v $V2FLY/$_v"
		echo "$_v" >> "$_vgot"
		_vn=$((_vn + 1))
		if [ "$_vn" -ge 24 ]; then
			curl -sfL --max-time 120 $_vargs >/dev/null 2>&1
			_vargs=""; _vn=0
		fi
	done < "$2"
	[ "$_vn" -gt 0 ] && curl -sfL --max-time 120 $_vargs >/dev/null 2>&1









	while IFS= read -r _v || [ -n "$_v" ]; do
		[ -n "$_v" ] || continue
		[ -s "$_vd/$_v" ] || continue
		[ "$(tail -c 1 "$_vd/$_v" 2>/dev/null | wc -l | tr -cd '0-9')" = 1 ] && continue
		rm -f "$_vd/$_v" 2>/dev/null
	done < "$_vgot"
	rm -f "$_vgot" 2>/dev/null
	return 0
}

fetch_v2fly() {  # fetch_v2fly <имя> <outfile>
	_seen="$RAM/.v2seen.$$"; _queue="$RAM/.v2q.$$"; : > "$_seen"; : > "$2"
	_vdir=$(v2_raw_dir); mkdir -p "$_vdir" 2>/dev/null
	printf '%s\t\n' "$1" > "$_queue"; _it=0
	while [ -s "$_queue" ]; do


		mv "$_queue" "$_queue.lvl" 2>/dev/null; : > "$_queue"; : > "$_queue.names"
		while IFS= read -r _ln || [ -n "$_ln" ]; do
			_nm=${_ln%%"$TAB"*}
			v2_name_ok "$_nm" || continue
			grep -qxF "$_nm" "$_queue.names" 2>/dev/null || echo "$_nm" >> "$_queue.names"
		done < "$_queue.lvl"
		[ -s "$_queue.names" ] && v2_fetch_level "$_vdir" "$_queue.names"
		while IFS= read -r _ln || [ -n "$_ln" ]; do
			_it=$((_it + 1)); [ "$_it" -gt 800 ] && break
			_nm=${_ln%%"$TAB"*}; _req=${_ln#*"$TAB"}
			v2_name_ok "$_nm" || continue
			grep -qxF "$_nm|$_req" "$_seen" 2>/dev/null && continue
			echo "$_nm|$_req" >> "$_seen"
			_tf="$_vdir/$_nm"
			[ -s "$_tf" ] || fetch_url "$V2FLY/$_nm" "$_tf" || { rm -f "$_tf"; continue; }
			tr 'A-Z' 'a-z' < "$_tf" | tr -d '\r' | awk -v req="$_req" '
				/^[[:space:]]*#/ {next} /^[[:space:]]*$/ {next}
				/^include:/ {
					name=$1; sub(/^include:/,"",name)
					ia=""; if (NF>=2 && $2 ~ /^@/) { ia=$2; sub(/^@/,"",ia) }
					nr=req; if (req=="") nr=ia          # фильтр родителя пуст → берём фильтр include; иначе наследуем родителя
					print "Q\t" name "\t" nr; next
				}
				/^regexp:/ {next} /^keyword:/ {next}
				{
					d=$1; sub(/^full:/,"",d); sub(/^domain:/,"",d)
					# {0,61} = метка ≤63: одна длинная метка из ЧУЖОГО geosite роняет весь конфиг
					# dnsmasq (замер — в шапке dns-lib.sh::dom_ok). Второй проход того же гарда:
					# сюда домены приезжают мимо norm_geosite.
					if (d !~ /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/) next
					pass=(req=="")
					if (req!="") { for(i=2;i<=NF;i++) if($i=="@" req) pass=1 }
					if (pass) print "D\t" d
				}' > "$RAM/.v2p.$$"
			grep "^D$TAB" "$RAM/.v2p.$$" 2>/dev/null | cut -f2 >> "$2"
			grep "^Q$TAB" "$RAM/.v2p.$$" 2>/dev/null | cut -f2,3 >> "$_queue"
			rm -f "$RAM/.v2p.$$"
		done < "$_queue.lvl"
		[ "$_it" -gt 800 ] && break


		uprogress "$(wc -l < "$_seen" 2>/dev/null | tr -cd '0-9')" "$(wc -l < "$_queue" 2>/dev/null | tr -cd '0-9')"
	done
	uprogress "" ""
	rm -f "$_seen" "$_queue" "$_queue.lvl" "$_queue.names"
}





v2fly_enumerate() {
	_tmp="$RAM/.v2list.$$"
	fetch_url "$V2CAT_URL" "$_tmp" || { rm -f "$_tmp" 2>/dev/null; return 0; }
	grep -oE '"/data/[^"/]+"' "$_tmp" 2>/dev/null | sed 's|"/data/||; s|"$||' \
		| grep -E '^[a-z0-9._!-]+$' | sort -u > "$_tmp.n"
	[ -s "$_tmp.n" ] && mv "$_tmp.n" "$V2CAT_SNAP"
	rm -f "$_tmp" "$_tmp.n" 2>/dev/null
}





ensure_cache() {
	_k="$1"; _refetch="$2"; _cf="$CACHE/$_k"
	if [ "$_refetch" = 1 ] || [ ! -s "$_cf" ]; then
		_u=$(cat_url "$_k"); [ -n "$_u" ] || { printf '%s' "$_cf"; return 0; }
		_kind=$(cat_kind "$_k")
		if [ "$_kind" = domain ]; then
			_raw="$RAM/.raw.$_k"
			case "$_u" in
				v2fly:*) fetch_v2fly "${_u#v2fly:}" "$_raw" ;;       # уже norm_geosite'нуто внутри
				*)       fetch_url "$_u" "$_raw.dl" && norm_geosite < "$_raw.dl" > "$_raw"; rm -f "$_raw.dl" 2>/dev/null ;;
			esac
			[ -s "$_raw" ] && sort -u "$_raw" > "$_cf"
			rm -f "$_raw" 2>/dev/null
		else
			_raw="$RAM/.raw.$_k"
			if fetch_url "$_u" "$_raw"; then
				norm_cidr < "$_raw" | sort -u > "$_cf"


				norm_cidr6 < "$_raw" | strip_bogon6 | sort -u > "$_cf@6"
			fi
			rm -f "$_raw" 2>/dev/null
		fi
	fi
	printf '%s' "$_cf"
}




wire_rules() {
	iptables -t mangle -C PREROUTING -m set --match-set "$SET_VPN" dst -j MARK --set-mark 0x1 2>/dev/null \
		|| iptables -t mangle -C PREROUTING -m set --match-set "$SET_VPN" dst -j ACCEPT 2>/dev/null \
		|| sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1 || true
	sh "$ENODIA_DIR/apply-bypass.sh" set-dst-ensure "$SET_OUT" >/dev/null 2>&1 || true
}





geo_block_wire() {
	set_ensure "$SET_BLK"
	ensure_allow_set
	_wif=$(wan_iface)
	if iptables -nL ENODIA_GEOBLK >/dev/null 2>&1; then iptables -F ENODIA_GEOBLK 2>/dev/null
	else iptables -N ENODIA_GEOBLK 2>/dev/null; fi
	iptables -A ENODIA_GEOBLK -m set --match-set blocklist_allow src -j RETURN 2>/dev/null
	iptables -A ENODIA_GEOBLK -m set --match-set blocklist_allow dst -j RETURN 2>/dev/null
	[ -n "$_wif" ] && iptables -A ENODIA_GEOBLK -i "$_wif" -m set --match-set "$SET_BLK" src -j DROP 2>/dev/null
	iptables -A ENODIA_GEOBLK -m set --match-set "$SET_BLK" dst -j DROP 2>/dev/null
	iptables -C INPUT   -j ENODIA_GEOBLK 2>/dev/null || iptables -I INPUT   -j ENODIA_GEOBLK 2>/dev/null
	iptables -C FORWARD -j ENODIA_GEOBLK 2>/dev/null || iptables -I FORWARD -j ENODIA_GEOBLK 2>/dev/null
}
geo_block_teardown() {
	iptables -D INPUT   -j ENODIA_GEOBLK 2>/dev/null
	iptables -D FORWARD -j ENODIA_GEOBLK 2>/dev/null
	iptables -F ENODIA_GEOBLK 2>/dev/null
	iptables -X ENODIA_GEOBLK 2>/dev/null




	iptables -nL ENODIA_BLK >/dev/null 2>&1 || cat_enabled ipblock 2>/dev/null || ipset destroy blocklist_allow 2>/dev/null
	return 0
}






adblock_resync() {
	cat_enabled adblock 2>/dev/null && [ -s "$(allow_path adblock)" ] || return 0
	[ -f "$ENODIA_DIR/lists-update.sh" ] && LISTS_NO_RELOAD=1 sh "$ENODIA_DIR/lists-update.sh" reapply adblock >/dev/null 2>&1
	return 0
}






build_dns() {  # build_dns <домены-vpn> <домены-out> <домены-blk> [домены-десинк]
	mkdir -p /tmp/dnsmasq.d 2>/dev/null
	: > "$DNSCONF.new"
	[ -s "$1" ] && sed "s|.*|ipset=/&/$SET_VPN|" "$1" >> "$DNSCONF.new"
	[ -s "$2" ] && sed "s|.*|ipset=/&/$SET_OUT|" "$2" >> "$DNSCONF.new"

	[ -n "$4" ] && [ -s "$4" ] && sed "s|.*|ipset=/&/$SET_DSY|" "$4" >> "$DNSCONF.new"


	for _bn in 2 3 4 5 6 7; do
		[ -s "$RAM/.dom-vpn-s$_bn" ] && sed "s|.*|ipset=/&/geo_vpn_s$_bn|" "$RAM/.dom-vpn-s$_bn" >> "$DNSCONF.new"
	done
	mv "$DNSCONF.new" "$DNSCONF"
	: > "$DNSBLK.new"
	if [ -s "$3" ]; then
		{ sed 's|.*|address=/&/0.0.0.0|' "$3"; sed 's|.*|address=/&/::|' "$3"; } >> "$DNSBLK.new"
	fi
	mv "$DNSBLK.new" "$DNSBLK"
	snap_flash "$SNAP_DNS" "$DNSCONF"; snap_flash "$SNAP_DNSBLK" "$DNSBLK"
}
dns_dom_count() {  # число доменов-маршрутов в живом conf
	_n=$(grep -c '^ipset=/' "$DNSCONF" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac; printf '%s' "$_n"
}
dns_blk_count() {  # число доменов-блоков (A-строк; их вдвое меньше всех)
	_n=$(grep -c '/0\.0\.0\.0$' "$DNSBLK" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac; printf '%s' "$_n"
}





snap_q() {
	_sq=$(snap_flash "$1" "$2")
	[ -n "$_sq" ] && GEO_SNAPW="$GEO_SNAPW; $_sq"
	return 0
}









WANT_DIR="$GEO/want"                    # one file per consumer: a key per line
WSNAP="$GEO/.wsnap.$RESOLVER_VER"       # gz snapshots of wanted keys; keyed by the resolver version (new logic = stale data)
WSNAP_MAX=1048576                       # bytes of one gz snapshot; a bigger key lives in RAM only (a journal line, as snap_flash)
want_keys() { cat "$WANT_DIR"/* 2>/dev/null | tr -d '\r' | grep . | sort -u; }


cat_known() {
	case "$1" in
		v2fly-*) _ckf="$V2CAT_SNAP"; [ -s "$_ckf" ] || _ckf="$V2CAT_BAKED"; tr -d '\r' < "$_ckf" 2>/dev/null | grep -qxF -- "${1#v2fly-}" ;;
		rfip-*)  _ckf="$RFIP_SNAP"; [ -s "$_ckf" ] || _ckf="$RFIP_BAKED"; tr -d '\r' < "$_ckf" 2>/dev/null | grep -qxF -- "${1#rfip-}" ;;
		rfgs-*)  _ckf="$RFGS_SNAP"; [ -s "$_ckf" ] || _ckf="$RFGS_BAKED"; tr -d '\r' < "$_ckf" 2>/dev/null | grep -qxF -- "${1#rfgs-}" ;;
		??)      country_codes | tr ' ' '\n' | grep -qxF -- "$1" ;;
		*)       [ -n "$(cat_url "$1")" ] && [ -n "$(cat_kind "$1")" ] ;;
	esac
}
want_forms() {   # <key> → «<file name in CACHE> <kind>» per consumer form
	case "$(cat_kind "$1")" in
		domain) echo "$1 domain" ;;
		cidr)   echo "$1@4 cidr"; echo "$1@6 cidr6" ;;
	esac
}


_wanted_pass() {
	_wk=$(want_keys)
	for _wo in "$GEO"/.wsnap.*; do [ -d "$_wo" ] && [ "$_wo" != "$WSNAP" ] && rm -rf "$_wo"; done
	for _ws in "$WSNAP"/*.gz; do
		[ -f "$_ws" ] || continue
		_wn=${_ws##*/}; _wn=${_wn%.gz}; _wn=${_wn%@[46]}
		printf '%s\n' "$_wk" | grep -qxF "$_wn" || rm -f "$_ws"
	done
	[ -n "$_wk" ] || return 0
	mkdir -p "$WSNAP" 2>/dev/null
	for _wn in $_wk; do
		_wr=$1; _wkd=$(cat_kind "$_wn")

		[ "$_wkd" = cidr ] && [ ! -f "$CACHE/$_wn@6" ] && _wr=1
		_wc=$(ensure_cache "$_wn" "$_wr")
		if [ "$_wkd" = cidr ]; then


			if [ -f "$_wc" ]; then
				strip_bogon < "$_wc" 2>/dev/null | sort -u > "$_wc@4.$$" && mv -f "$_wc@4.$$" "$_wc@4"
				rm -f "$_wc@4.$$" 2>/dev/null
			fi
			[ -f "$_wc@4" ] || continue
			[ -f "$_wc@6" ] || : > "$_wc@6"
		else
			[ -s "$_wc" ] || continue
		fi
		for _wf in $(want_forms "$_wn" | awk '{ print $1 }'); do

			gzip -c "$CACHE/$_wf" > "$RAM/.wsnap.$$" 2>/dev/null || { rm -f "$RAM/.wsnap.$$"; continue; }
			if [ "$(wc -c < "$RAM/.wsnap.$$" | tr -d ' ')" -gt "$WSNAP_MAX" ]; then
				rm -f "$RAM/.wsnap.$$" "$WSNAP/$_wf.gz"
				if [ -f "$ENODIA_DIR/events.sh" ]; then
					sh "$ENODIA_DIR/events.sh" add geo-want-snap-skip 86400 \
						"Категория расписания не переживёт перезагрузку" \
						"Категория «$_wn» слишком велика для снимка на флеш. Сейчас она работает, но после перезагрузки роутера начнёт закрываться не сразу — сперва её нужно будет заново скачать (несколько минут)." >/dev/null 2>&1
				fi
				continue
			fi
			if [ -f "$WSNAP/$_wf.gz" ] && gunzip -c "$WSNAP/$_wf.gz" 2>/dev/null | cmp -s - "$CACHE/$_wf"; then
				rm -f "$RAM/.wsnap.$$"
			else
				mv -f "$RAM/.wsnap.$$" "$WSNAP/$_wf.gz"
			fi
		done
	done
	return 0
}




_build_pass() {
	_refetch="$1"
	GEO_SNAPW=""



	_rv=$(cat "$RVER" 2>/dev/null | tr -d ' \r\n')
	[ "$_rv" = "$RESOLVER_VER" ] || _refetch=1
	echo "$RESOLVER_VER" > "$RVER" 2>/dev/null
	ustate RUNNING

	_vpn="$RAM/.agg-vpn"; _out="$RAM/.agg-out"; _blk="$RAM/.agg-blk"; _dsy="$RAM/.agg-dsy"
	_dv="$RAM/.dom-vpn"; _do="$RAM/.dom-out"; _db="$RAM/.dom-blk"; _dd="$RAM/.dom-dsy"
	: > "$_vpn"; : > "$_out"; : > "$_blk"; : > "$_dsy"; : > "$_dv"; : > "$_do"; : > "$_db"; : > "$_dd"




	for _sn in 2 3 4 5 6 7; do : > "$RAM/.agg-vpn-s$_sn"; : > "$RAM/.dom-vpn-s$_sn"; done
	_any_slot=0
	_en_slots=" "
	[ -f "$ENODIA_DIR/slots.sh" ] && _en_slots=" $(sh "$ENODIA_DIR/slots.sh" list-enabled 2>/dev/null | cut -f1 | tr '\n' ' ') "
	if [ -s "$REG" ]; then
		while IFS="$TAB" read -r _k _a _c _t _s; do
			[ -n "$_k" ] || continue
			[ -n "$(cat_url "$_k")" ] || continue        # ключа нет НИ У ОДНОГО провайдера (реально устарел) — игнор
			case "$_s" in [2-7]) ;; *) _s=0 ;; esac
			[ "$_s" != 0 ] && case "$_en_slots" in *" $_s "*) ;; *) _s=0 ;; esac
			if [ "$(cat_kind "$_k")" = domain ]; then
				case "$_a" in
					vpn)    if [ "$_s" != 0 ]; then _dst="$RAM/.dom-vpn-s$_s"; _any_slot=1; else _dst="$_dv"; fi ;;
					bypass) _dst="$_do" ;; block) _dst="$_db" ;; desync) _dst="$_dd" ;; *) continue ;;
				esac
			else
				case "$_a" in
					vpn)    if [ "$_s" != 0 ]; then _dst="$RAM/.agg-vpn-s$_s"; _any_slot=1; else _dst="$_vpn"; fi ;;
					bypass) _dst="$_out" ;; block) _dst="$_blk" ;; desync) _dst="$_dsy" ;; *) continue ;;
				esac
			fi
			_cf=$(ensure_cache "$_k" "$_refetch")
			_n=0
			if [ -s "$_cf" ]; then
				cat "$_cf" >> "$_dst"
				_n=$(grep -c '' "$_cf" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
			fi
			reg_set_meta "$_k" "$_n" "$(date +%s)"
		done < "$REG"
	fi


	sort -u "$_vpn" > "$_vpn.s" 2>/dev/null && mv "$_vpn.s" "$_vpn"
	sort -u "$_out" > "$_out.s" 2>/dev/null && mv "$_out.s" "$_out"
	strip_bogon < "$_blk" 2>/dev/null | sort -u > "$_blk.s" 2>/dev/null; mv "$_blk.s" "$_blk"


	strip_bogon < "$_dsy" 2>/dev/null | sort -u > "$_dsy.s" 2>/dev/null; mv "$_dsy.s" "$_dsy"




	_gfail=""
	set_sync "$SET_VPN" "$_vpn" "$_dv" || _gfail="$_gfail $SET_VPN"
	set_sync "$SET_OUT" "$_out" "$_do" || _gfail="$_gfail $SET_OUT"
	set_sync "$SET_BLK" "$_blk"        || _gfail="$_gfail $SET_BLK"
	set_sync "$SET_DSY" "$_dsy" "$_dd" || _gfail="$_gfail $SET_DSY"
	snap_q "$SNAP_VPN" "$_vpn"; snap_q "$SNAP_OUT" "$_out"; snap_q "$SNAP_BLK" "$_blk"
	snap_q "$SNAP_DSY" "$_dsy"



	for _sn in 2 3 4 5 6 7; do
		_sf="$RAM/.agg-vpn-s$_sn"; _df="$RAM/.dom-vpn-s$_sn"
		sort -u "$_sf" > "$_sf.s" 2>/dev/null && mv "$_sf.s" "$_sf"
		sort -u "$_df" > "$_df.s" 2>/dev/null && mv "$_df.s" "$_df"
		if [ -s "$_sf" ] || [ -s "$_df" ] || ipset list -n 2>/dev/null | grep -qx "geo_vpn_s$_sn"; then
			set_sync "geo_vpn_s$_sn" "$_sf" "$_df" || _gfail="$_gfail geo_vpn_s$_sn"
		fi
		snap_q "$GEO/.snap-vpn-s$_sn" "$_sf"
	done

	sort -u "$_dv" > "$_dv.s" 2>/dev/null && mv "$_dv.s" "$_dv"
	sort -u "$_do" > "$_do.s" 2>/dev/null && mv "$_do.s" "$_do"
	sort -u "$_db" > "$_db.s" 2>/dev/null && mv "$_db.s" "$_db"
	sort -u "$_dd" > "$_dd.s" 2>/dev/null && mv "$_dd.s" "$_dd"
	build_dns "$_dv" "$_do" "$_db" "$_dd"
	adblock_resync


	overlap_scan "$_vpn" "$SET_OUT" "$_dv" "$_do" > "$GEO/.overlap.new" 2>/dev/null \
		&& mv "$GEO/.overlap.new" "$GEO/.overlap" || rm -f "$GEO/.overlap.new" 2>/dev/null
	wire_rules


	[ -f "$ENODIA_DIR/zapret.sh" ] && sh "$ENODIA_DIR/zapret.sh" rewire >/dev/null 2>&1


	if [ "$_any_slot" = 1 ] && [ -f "$ENODIA_DIR/transport.sh" ]; then
		sh "$ENODIA_DIR/transport.sh" slots-up >/dev/null 2>&1
	fi

	_bn=$(grep -c '' "$_blk" 2>/dev/null); case "$_bn" in ''|*[!0-9]*) _bn=0 ;; esac
	if [ "$_bn" -gt 0 ]; then geo_block_wire; else geo_block_teardown; fi
	dns_reload

	ct_flush

	if [ "$_refetch" = 1 ]; then _wanted_pass 1 >/dev/null 2>&1; fi
	rm -f "$_vpn" "$_out" "$_blk" "$_dsy" "$_dv" "$_do" "$_db" "$_dd" 2>/dev/null
	for _sn in 2 3 4 5 6 7; do rm -f "$RAM/.agg-vpn-s$_sn" "$RAM/.dom-vpn-s$_sn" 2>/dev/null; done


	printf 'гео применено: CIDR в VPN %s / мимо %s / блок %s / десинк %s; домены маршрут %s / блок %s%s%s\n' \
		"$(ipset_count "$SET_VPN")" "$(ipset_count "$SET_OUT")" "$(ipset_count "$SET_BLK")" "$(ipset_count "$SET_DSY")" "$(dns_dom_count)" "$(dns_blk_count)" \
		"${_gfail:+; НЕ удалось залить наборы:$_gfail (маршрут для них остался прежним)}" "$GEO_SNAPW"
	[ -z "$_gfail" ]
}








do_build() {
	_want="$1"
	if ! ls_lock_take "$GEO_LOCK" "$GEO_DIRTY" "$_want"; then
		echo 'гео: сборка уже идёт — учту свежий выбор в ней'
		return 0
	fi
	trap 'ls_lock_drop "$GEO_LOCK"' EXIT
	trap 'exit 1' INT TERM HUP PIPE
	_sum=''; _rc=0
	while :; do
		rm -f "$GEO_DIRTY" 2>/dev/null   # сброс ДО чтения реестра: пойманный dirty ⇒ реестр прочитан ПОСЛЕ мутации
		_sum=$(_build_pass "$_want"); _rc=$?
		[ -f "$GEO_DIRTY" ] || break
		_want=$(cat "$GEO_DIRTY" 2>/dev/null | tr -d ' \r\n'); [ "$_want" = 1 ] || _want=0
	done
	ustate DONE
	trap - EXIT INT TERM HUP PIPE
	ls_lock_drop "$GEO_LOCK"
	[ -z "$_sum" ] || echo "$_sum"
	return $_rc   # провал заливки набора не должен читаться как «применено» (сводка это же и говорит)
}



do_reapply() {
	_any=0
	[ -s "$SNAP_VPN" ] && { set_fill "$SET_VPN" "$SNAP_VPN"; _any=1; }
	[ -s "$SNAP_OUT" ] && { set_fill "$SET_OUT" "$SNAP_OUT"; _any=1; }
	[ -s "$SNAP_BLK" ] && { set_fill "$SET_BLK" "$SNAP_BLK"; _any=1; }
	[ -s "$SNAP_DSY" ] && { set_fill "$SET_DSY" "$SNAP_DSY"; _any=1; }
	mkdir -p /tmp/dnsmasq.d 2>/dev/null
	[ -s "$SNAP_DNS" ]    && { cp "$SNAP_DNS" "$DNSCONF" 2>/dev/null; _any=1; }
	[ -s "$SNAP_DNSBLK" ] && { cp "$SNAP_DNSBLK" "$DNSBLK" 2>/dev/null; _any=1; adblock_resync; }


	for _sn in 2 3 4 5 6 7; do
		[ -s "$GEO/.snap-vpn-s$_sn" ] && { set_fill "geo_vpn_s$_sn" "$GEO/.snap-vpn-s$_sn"; _any=1; }
	done
	[ "$_any" = 1 ] || return 0

	set_ensure "$SET_VPN"; set_ensure "$SET_OUT"


	grep -q "/$SET_DSY\$" "$DNSCONF" 2>/dev/null && set_ensure "$SET_DSY"


	for _sn in 2 3 4 5 6 7; do
		grep -q "/geo_vpn_s$_sn\$" "$DNSCONF" 2>/dev/null && set_ensure "geo_vpn_s$_sn"
	done
	wire_rules
	if [ -s "$SNAP_BLK" ]; then geo_block_wire; else geo_block_teardown; fi
	dns_reload
	ct_flush
	return 0
}

geo_enabled() { [ -s "$REG" ]; }   # есть хоть один выбранный элемент → гео активно





resolve_upstream() {
	: > "$SHAS.new"
	for _row in \
		"v2fly|https://api.github.com/repos/v2fly/domain-list-community/commits/master" \
		"rfip|https://api.github.com/repos/runetfreedom/russia-blocked-geoip/commits/release" \
		"rfgs|https://api.github.com/repos/runetfreedom/russia-blocked-geosite/commits/release"; do
		_rid=${_row%%|*}; _api=${_row#*|}; _sha=''; _iso=''
		_tmp="$RAM/.sha.$$"
		if fetch_url "$_api" "$_tmp"; then


			_sha=$(grep -o '"sha": *"[^"]*"' "$_tmp" 2>/dev/null | head -1 | cut -d'"' -f4)
			_iso=$(grep -o '"date": *"[^"]*"' "$_tmp" 2>/dev/null | head -1 | cut -d'"' -f4)
		fi
		rm -f "$_tmp" 2>/dev/null
		case "$_sha" in
			[0-9a-f][0-9a-f]*) printf '%s\t%s\t%s\n' "$_rid" "$_sha" "$_iso" >> "$SHAS.new" ;;
			*) grep "^$_rid$TAB" "$SHAS" 2>/dev/null >> "$SHAS.new" ;;   # провал API — держим прежний sha/дату
		esac
	done





	_ipd=$(ipdeny_iso 2>/dev/null)
	if [ -n "$_ipd" ]; then printf 'ipdeny\t-\t%s\n' "$_ipd" >> "$SHAS.new"
	else grep "^ipdeny$TAB" "$SHAS" 2>/dev/null >> "$SHAS.new"; fi
	[ -s "$SHAS.new" ] && mv "$SHAS.new" "$SHAS" || rm -f "$SHAS.new" 2>/dev/null
}






ipdeny_iso() {
	command -v http_date_iso >/dev/null 2>&1 || return 1
	_lm=$(curl -sI --max-time 20 "$IPDENY/ru-aggregated.zone" 2>/dev/null \
	      | grep -i '^last-modified:' | head -1 | sed 's/^[Ll]ast-[Mm]odified:[ ]*//')
	[ -n "$_lm" ] || return 1
	http_date_iso "$_lm"
}
upstream_iso() { grep "^$1$TAB" "$SHAS" 2>/dev/null | head -1 | cut -f3; }   # дата апстрима репо (для панели)
















OVERLAP_PROBES=200
overlap_scan() {   # $1=CIDR-агрегат «в VPN»  $2=набор «мимо»  $3/$4=домены vpn/out
	_ot=0; _oc=0; _od=0
	_on=$(grep -c '' "$1" 2>/dev/null); case "$_on" in ''|*[!0-9]*) _on=0 ;; esac
	if [ "$_on" -gt 0 ]; then
		_ostep=$(( (_on + OVERLAP_PROBES - 1) / OVERLAP_PROBES )); [ "$_ostep" -gt 0 ] || _ostep=1
		for _oa in $(awk -v s="$_ostep" 'NR%s==0{print $1}' "$1" 2>/dev/null); do
			_oa=${_oa%%/*}
			case "$_oa" in ''|*[!0-9.]*) continue ;; esac
			_ot=$((_ot+1))
			ipset test "$2" "$_oa" >/dev/null 2>&1 && _oc=$((_oc+1))
		done
	fi

	if [ -s "$3" ] && [ -s "$4" ]; then
		_od=$(sort "$3" "$4" 2>/dev/null | uniq -d | grep -c '' 2>/dev/null)
		case "$_od" in ''|*[!0-9]*) _od=0 ;; esac
	fi
	printf '%s\t%s\t%s\t%s\t%s\n' "$_on" "$_ot" "$_oc" "$_od" "$(date +%s)"
}




upd_state() {
	_us=$(cat "$RAM/.update.state" 2>/dev/null | tr -d ' \r\n')



	if [ "$_us" = RUNNING ] && { [ ! -d "$GEO_LOCK" ] || _lock_stale "$GEO_LOCK"; }; then
		_us=$(cat "$RAM/.update.state" 2>/dev/null | tr -d ' \r\n'); [ "$_us" = RUNNING ] && _us=ABORTED
	fi
	printf '%s' "${_us:-IDLE}"
}


emit_head() {
	st=$(upd_state)







	_zi=false
	if [ -x "$(bin_path nfqws)" ]; then
		_zi=true
		if [ -f "$ENODIA_DIR/zapret.sh" ]; then
			sh "$ENODIA_DIR/zapret.sh" nfq-ok >/dev/null 2>&1 || [ "$?" = 2 ] || _zi=false
		fi
	fi













	_pdone=0; _pq=0
	if [ -f "$RAM/.update.progress" ]; then
		_pdone=$(cut -f1 "$RAM/.update.progress" 2>/dev/null | tr -cd '0-9')
		_pq=$(cut -f2 "$RAM/.update.progress" 2>/dev/null | tr -cd '0-9')
		[ -n "$_pdone" ] || _pdone=0; [ -n "$_pq" ] || _pq=0
	fi






	_zon=false; [ -f "$ENODIA_STATE/.zapret-on" ] && _zon=true
	printf '{"update_state":"%s","upd_done":%s,"upd_queue":%s,"now":%s,"set_vpn":%s,"set_out":%s,"set_blk":%s,"set_dsy":%s,"zapret":%s,"zapret_on":%s,"dns_route":%s,"dns_block":%s,' \
		"$st" "$_pdone" "$_pq" "$(date +%s)" "$(ipset_count "$SET_VPN")" "$(ipset_count "$SET_OUT")" "$(ipset_count "$SET_BLK")" "$(ipset_count "$SET_DSY")" "$_zi" "$_zon" "$(dns_dom_count)" "$(dns_blk_count)"
}





emit_overlap() {
	_ovl=$(cat "$GEO/.overlap" 2>/dev/null | head -1)
	_ov_t=$(printf '%s' "$_ovl" | cut -f1); _ov_p=$(printf '%s' "$_ovl" | cut -f2)
	_ov_h=$(printf '%s' "$_ovl" | cut -f3); _ov_d=$(printf '%s' "$_ovl" | cut -f4)
	for _v in _ov_t _ov_p _ov_h _ov_d; do
		eval "_vv=\$$_v"; case "$_vv" in ''|*[!0-9]*) eval "$_v=0" ;; esac
	done
	printf ',"overlap":{"total":%s,"probed":%s,"hits":%s,"domains":%s}' "$_ov_t" "$_ov_p" "$_ov_h" "$_ov_d"
}
emit_json() {
	emit_head
	_ramtot=$(awk '/^MemTotal:/{print $2*1024; exit}' /proc/meminfo 2>/dev/null)
	case "$_ramtot" in ''|*[!0-9]*) _ramtot=0 ;; esac
	printf '"ram":{"per_dom_b":498,"per_cidr_b":43,"total_b":%s},"items":[' "$_ramtot"






	_cf="$RAM/.emit-cat.$$"
	catalog_lines | tr '|' '\t' > "$_cf" 2>/dev/null
	awk -F'\t' -v RG="$REG" '
		FILENAME==RG { act[$1]=$2; cnt[$1]=$3; ts[$1]=$4; slt[$1]=$5; next }
		{
			if($2=="") next
			a=act[$2]; if(a=="") a="off"
			c=cnt[$2]; if(c !~ /^[0-9]+$/) c=0
			t=ts[$2];  if(t !~ /^[0-9]+$/) t=0
			s=slt[$2]; if(s !~ /^[2-7]$/) s=0
			if(f) printf(","); f=1
			printf("{\"type\":\"%s\",\"key\":\"%s\",\"label\":\"%s\",\"kind\":\"%s\",\"approx\":\"%s\",\"desc\":\"%s\",\"action\":\"%s\",\"count\":%s,\"ts\":%s,\"slot\":%s}",$1,$2,$3,$4,$6,$7,a,c,t,s)
		}
	' "$REG" "$_cf"
	rm -f "$_cf" 2>/dev/null
	printf ']'

	printf ',"upstreams":{"v2fly":"%s","rfip":"%s","rfgs":"%s","ipdeny":"%s"}' \
		"$(jesc "$(upstream_iso v2fly)")" "$(jesc "$(upstream_iso rfip)")" "$(jesc "$(upstream_iso rfgs)")" \
		"$(jesc "$(upstream_iso ipdeny)")"
	emit_overlap
	printf '}\n'
}









emit_active() {
	printf '{"update_state":"%s","now":%s,"items":[' "$(upd_state)" "$(date +%s)"
	_af=0
	if [ -f "$REG" ]; then




		awk -F"$TAB" -v OFS="$TAB" '{ for(i=1;i<=5;i++) if($i=="") $i="-"; print }' "$REG" 2>/dev/null | \
		while IFS="$TAB" read -r _ak _aa _ac _at _as _arest; do
			case "$_aa" in vpn|bypass|block|desync) ;; *) continue ;; esac

			case "$_ak" in ''|*[!A-Za-z0-9._!-]*) continue ;; esac
			_aty=$(cat_type "$_ak"); [ -n "$_aty" ] || continue
			case "$_ac" in ''|*[!0-9]*) _ac=0 ;; esac
			case "$_at" in ''|*[!0-9]*) _at=0 ;; esac
			case "$_as" in [2-7]) ;; *) _as=0 ;; esac
			[ "$_af" = 1 ] && printf ','
			_af=1
			printf '{"type":"%s","key":"%s","label":"%s","kind":"%s","action":"%s","count":%s,"ts":%s,"slot":%s}' \
				"$_aty" "$_ak" "$(cat_label "$_ak")" "$(cat_kind "$_ak")" "$_aa" "$_ac" "$_at" "$_as"
		done
	fi
	printf ']'
	emit_overlap
	printf '}\n'
}

case "$1" in
	list) emit_json ;;
	active) emit_active ;;
	set)   # set <key> <vpn|bypass|block|desync|off> — записать выбор действия (мгновенно), сборку зовёт update/apply
		[ -n "$(cat_url "$2")" ] || { echo "неизвестный ключ гео"; exit 1; }
		case "$3" in vpn|bypass|block|desync|off) ;; *) echo "действие: vpn|bypass|block|desync|off"; exit 1 ;; esac
		reg_set "$2" "$3"
		echo "гео «$2»: $(case "$3" in vpn) echo 'в VPN' ;; bypass) echo 'мимо VPN' ;; block) echo 'заблокировано' ;; desync) echo 'в десинк' ;; *) echo 'выкл' ;; esac)"
		;;
	desync-list)   # что выбрано «в десинк» — key|label|доменов/адресов. Читает карточка Zapret:

		_cf="$RAM/.dsy-cat.$$"
		catalog_lines | tr '|' '\t' > "$_cf" 2>/dev/null
		awk -F'\t' -v RG="$REG" '
			FILENAME==RG { if($2=="desync"){ act[$1]=1; cnt[$1]=$3 } next }
			{ if($2=="" || !act[$2]) next
			  c=cnt[$2]; if(c !~ /^[0-9]+$/) c=0
			  printf("%s|%s|%s\n",$2,$3,c) }
		' "$REG" "$_cf" 2>/dev/null
		rm -f "$_cf" 2>/dev/null
		;;
	slot)  # slot <key> <0|2..7> — привязать категорию к доп-выходу (0 = основной; только action=vpn).

		[ -n "$(cat_url "$2")" ] || { echo "неизвестный ключ гео"; exit 1; }
		case "$3" in 0|[2-7]) ;; *) echo "слот: 0|2..7"; exit 1 ;; esac
		_ln=$(reg_get "$2"); [ -n "$_ln" ] || { echo "категория выключена — сначала выберите действие"; exit 1; }
		if [ "$3" != 0 ] && [ "$(printf '%s' "$_ln" | cut -f2)" != vpn ]; then
			echo "доп-выход только для действия «в VPN»"; exit 1
		fi
		awk -F"$TAB" -v OFS="$TAB" -v k="$2" -v s="$3" '$1==k{$5=s} {print}' "$REG" > "$REG.new" && mv "$REG.new" "$REG"
		echo "выход: $([ "$3" = 0 ] && echo 'Основной' || echo "слот №$3")"
		;;


	want)
		case "$2" in ''|*[!a-z0-9-]*) echo "потребитель: [a-z0-9-]"; exit 1 ;; esac
		_wc="$2"; shift 2
		for _wn in "$@"; do
			case "$_wn" in */*|.*|*[!a-z0-9._!-]*) echo "неверный ключ гео: $_wn"; exit 1 ;; esac   # a key becomes a file name
			[ -n "$(cat_url "$_wn")" ] && [ -n "$(cat_kind "$_wn")" ] || { echo "неизвестный ключ гео: $_wn"; exit 1; }
		done
		mkdir -p "$WANT_DIR" 2>/dev/null
		if [ "$#" = 0 ]; then rm -f "$WANT_DIR/$_wc"; exit 0; fi
		printf '%s\n' "$@" | sort -u > "$WANT_DIR/.$_wc.$$" && mv -f "$WANT_DIR/.$_wc.$$" "$WANT_DIR/$_wc" ;;




	ready)
		shift
		for _wn in "$@"; do
			case "$_wn" in */*|.*|*[!a-z0-9._!-]*) continue ;; esac
			[ -n "$(cat_url "$_wn")" ] || continue
			_wrd=0
			for _wf in $(want_forms "$_wn" | awk '{ print $1 }'); do
				_wc="$CACHE/$_wf"
				if [ ! -f "$_wc" ] && [ -f "$WSNAP/$_wf.gz" ]; then
					gunzip -c "$WSNAP/$_wf.gz" > "$_wc.$$" 2>/dev/null && mv -f "$_wc.$$" "$_wc"
					rm -f "$_wc.$$" 2>/dev/null
				fi
				case "$_wf" in
					*@4) if [ -f "$_wc" ]; then _wrd=1; printf '%s\tcidr\t%s\n' "$_wn" "$_wc"; fi ;;
					*@6) if [ "$_wrd" = 1 ] && [ -s "$_wc" ]; then printf '%s\tcidr6\t%s\n' "$_wn" "$_wc"; fi ;;
					*)   if [ -s "$_wc" ]; then printf '%s\tdomain\t%s\n' "$_wn" "$_wc"; fi ;;
				esac
			done
		done
		exit 0 ;;


	about)
		shift
		for _wn in "$@"; do
			case "$_wn" in */*|.*|*[!a-z0-9._!-]*) continue ;; esac
			cat_known "$_wn" || continue
			printf '%s\t%s\t%s\t%s\n' "$_wn" "$(cat_kind "$_wn")" "$(cat_type "$_wn")" "$(cat_label "$_wn")"
		done
		exit 0 ;;


	wanted)
		_wi=0
		until ls_lock_take "$GEO_LOCK" "$RAM/.wanted.wait" 1; do
			_wi=$((_wi + 1)); [ "$_wi" -le 720 ] || exit 1   # an hour: an update of everything is the longest holder
			sleep 5
		done
		rm -f "$RAM/.wanted.wait" 2>/dev/null
		trap 'ls_lock_drop "$GEO_LOCK"' EXIT
		trap 'exit 1' INT TERM HUP PIPE
		_wanted_pass 0
		trap - EXIT INT TERM HUP PIPE; ls_lock_drop "$GEO_LOCK"
		exit 0 ;;
	apply)   do_build 0 ;;     # собрать из кэша (быстро; после смены действия)
	update)  resolve_upstream; set_source_urls; v2fly_enumerate; do_build 1 ;;   # SHA+даты → пиновка URL → перечислить v2fly (rf=baked) → перекачать (пиновано) + собрать
	reapply) do_reapply ;;     # офлайн из снимка (boot)







	wire)
		[ -s "$SNAP_BLK" ] || exit 0
		_gwd=$(cat "$GEO_DIRTY" 2>/dev/null | tr -d ' \r\n'); [ "$_gwd" = 1 ] || _gwd=0
		ls_lock_take "$GEO_LOCK" "$GEO_DIRTY" "$_gwd" || exit 0
		trap 'ls_lock_drop "$GEO_LOCK"' EXIT
		trap 'exit 1' INT TERM HUP PIPE
		geo_block_wire
		trap - EXIT INT TERM HUP PIPE; ls_lock_drop "$GEO_LOCK"
		exit 0 ;;



	wired)
		[ -s "$SNAP_BLK" ] || exit 0
		command -v ipt_jump_state >/dev/null 2>&1 || exit 2
		ipt_jump_state INPUT ENODIA_GEOBLK; _gwi=$?
		ipt_jump_state FORWARD ENODIA_GEOBLK; _gwf=$?
		[ "$_gwi" = 2 ] || [ "$_gwf" = 2 ] && exit 2
		[ "$_gwi" = 0 ] && [ "$_gwf" = 0 ] && exit 0
		exit 3 ;;
	enabled) geo_enabled && echo 1 || echo 0 ;;
	provider)     provider_get "$2" ;;         # provider <type> → выбранный pid (дормант)
	provider-set)                              # provider-set <type> <pid> → дормант (панель без дропдауна)
		provider_set "$2" "$3" || exit 1
		do_build 0 >/dev/null 2>&1
		echo "провайдер [$2] → $3"
		;;
	freshness) resolve_upstream; echo ok ;;    # обновить $SHAS (sha+даты; панель зовёт async при открытии)
	*)
		echo "geo.sh — гео-категории (страны/сервисы/заблок-в-РФ → в VPN / мимо VPN / блок)"
		echo "  list | active | set <key> <vpn|bypass|block|desync|off> | slot <key> <0|2..7> | apply | update | reapply | enabled"
		echo "  desync-list | want <consumer> [<key>…] | ready <key>… | about <key>… | wanted"
		echo "  provider <type> | provider-set <type> <pid> | freshness"
		exit 1
		;;
esac
