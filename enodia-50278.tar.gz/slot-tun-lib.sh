#!/bin/sh





































if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }

: "${ENODIA_STATE:=/data/usr/app/enodia-state}"

SLOT_SOCKS_BASE=10830

slot_socks_port() { echo $(( SLOT_SOCKS_BASE + $1 )); }   # id 2 -> 10832 ...
slot_tun()        { echo "xtun$1"; }
slot_table()      { echo "100$1"; }
slot_hev_pid()    { echo "/tmp/enodia-hev-s$1.pid"; }
slot_hev_log()    { echo "/tmp/enodia-hev-s$1.log"; }
slot_hev_yaml()   { echo "$ENODIA_STATE/hev-s$1.yaml"; }



slot_write_hev_yaml() {   # $1 = id
    _id="$1"
    cat > "$(slot_hev_yaml "$_id")" <<YAML
tunnel:
  name: xtun$_id
  mtu: 8500
  ipv4: 198.18.$_id.1
socks5:
  port: $(slot_socks_port "$_id")
  address: 127.0.0.1
  udp: 'udp'
misc:
  log-file: $(slot_hev_log "$_id")
  log-level: warn
YAML
}






slot_wait_socks() {   # $1 = порт ; $2 = пидфайл демона слота ; $3 = имя бинаря ; $4 = срок на флеше (деф. 8)





    case "$2" in
        /*) daemon_wait_port "$2" "$3" "${4:-8}" "$SOCKS_ADDR" "$1"; return $? ;;
    esac
    _p="$1"; _t="${2:-8}"; _i=0


    while [ "$_i" -lt "$_t" ]; do
        netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$_p " && return 0
        sleep 1; _i=$((_i+1))
    done
    netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$_p "
}





slot_free_socks() {   # $1 = id ; $2 = пидфайл СВОЕГО socks-провайдера
    _port=$(slot_socks_port "$1"); _own=$(cat "$2" 2>/dev/null | tr -d ' \r\n')
    _holder=$(netstat -ltnp 2>/dev/null | grep "$SOCKS_ADDR:$_port " | awk '{print $NF}' | cut -d/ -f1 | head -n1)
    case "$_holder" in ''|*[!0-9]*) return 0 ;; esac
    [ "$_holder" = "$_own" ] && return 0
    log "слот №$1: socks $_port держит чужой pid $_holder — освобождаю"
    kill "$_holder" 2>/dev/null
    _i=0; while [ $_i -lt 5 ]; do netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$_port " || break; sleep 1; _i=$((_i+1)); done
}






slot_socks_is_ours() {   # $1 = port ; $2 = свой пидфайл
    _own=$(cat "$2" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_own" ] || return 1
    _holder=$(netstat -ltnp 2>/dev/null | grep "$SOCKS_ADDR:$1 " | awk '{print $NF}' | cut -d/ -f1 | head -n1)
    case "$_holder" in ''|*[!0-9]*) return 0 ;; esac
    [ "$_holder" = "$_own" ]
}



slot_hev_up() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id")
    [ -x "$HEV" ] || { log "слот №$_id: НЕТ бинаря hev ($HEV)"; return 1; }
    slot_write_hev_yaml "$_id"
    if ! proc_alive "$(slot_hev_pid "$_id")"; then
        log "слот №$_id: запускаю hev (tun2socks -> $_tun)…"
        start-stop-daemon -S -b -m -p "$(slot_hev_pid "$_id")" -x "$HEV" -- "$(slot_hev_yaml "$_id")"
    fi
    daemon_wait_dev "$(slot_hev_pid "$_id")" hev 6 "$_tun" || {
        log "слот №$_id: tun $_tun не создан ($DAEMON_WAIT_WHY). Лог hev:"; tail -n 15 "$(slot_hev_log "$_id")" 2>/dev/null; return 1; }
    return 0
}




slot_hev_down() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id")
    _hdp=$(cat "$(slot_hev_pid "$_id")" 2>/dev/null | tr -d ' \r\n')
    start-stop-daemon -K -p "$(slot_hev_pid "$_id")" 2>/dev/null


    command -v daemon_wait_gone >/dev/null 2>&1 && daemon_wait_gone "$_hdp" 5
    _i=0
    while ip link show "$_tun" >/dev/null 2>&1 && [ "$_i" -lt 6 ]; do
        ip link del "$_tun" 2>/dev/null
        ip link show "$_tun" >/dev/null 2>&1 || break
        sleep 1; _i=$((_i+1))
    done
    rm -f "$(slot_hev_pid "$_id")" 2>/dev/null
}



slot_apply_routing() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id"); _tab=$(slot_table "$_id")
    ip link set "$_tun" up 2>/dev/null
    ipt_top FORWARD -o "$_tun" -j ACCEPT
    ipt_top FORWARD -i "$_tun" -j ACCEPT
    ip route replace default dev "$_tun" table "$_tab"
}
slot_remove_routing() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id"); _tab=$(slot_table "$_id")
    ip route flush table "$_tab" 2>/dev/null || true
    iptables -D FORWARD -o "$_tun" -j ACCEPT 2>/dev/null
    iptables -D FORWARD -i "$_tun" -j ACCEPT 2>/dev/null
}
























HEV_WERR_MIN=5          # строк `socks5 tunnel write` на 2 минуты (окно — от вызова до вызова, тик сторожа = 2 мин)
HEV_WERR_WINDOWS=2      # окон подряд: одиночная пачка (обрыв на сервере, пересоздание TUN) лечения не стоит
HEV_RESTART_GAP=1800    # с: перезапуск — не чаще; не помог — повтор каждые 4 минуты лишь рвал бы соединения дома
HEV_SWLOCK=${SWITCH_LOCK:-/tmp/enodia-switching.lock}
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}





hev_tun_ok() { [ -n "$(probe_ext_ip "--interface $1" 8)" ]; }





hev_write_flood() {
    _hwl=$1; _hws="/tmp/enodia-hev-werr.$2"
    _hwz=$(wc -c < "$_hwl" 2>/dev/null | tr -d ' '); case "$_hwz" in ''|*[!0-9]*) _hwz=0 ;; esac
    _hwst=$(cat "$_hws" 2>/dev/null)
    _hwo=$(printf '%s' "$_hwst" | cut -d' ' -f1); _hwt=$(printf '%s' "$_hwst" | cut -d' ' -f2); _hwk=$(printf '%s' "$_hwst" | cut -d' ' -f3)
    case "$_hwo$_hwt$_hwk" in ''|*[!0-9]*) echo "$_hwz $(date +%s) 0" > "$_hws"; return 1 ;; esac   # первый вызов или битая запись
    _hwa=$(age_since "$_hwt")
    [ "$_hwa" -lt 60 ] && return 1
    [ "$_hwz" -lt "$_hwo" ] && _hwo=0                                   # лог начат заново (перезапуск — hev_log_trim)
    _hwn=$(tail -c +$((_hwo + 1)) "$_hwl" 2>/dev/null | grep -c 'socks5 tunnel write' || true)
    case "$_hwn" in ''|*[!0-9]*) _hwn=0 ;; esac
    if [ $(( _hwn * 120 / _hwa )) -ge "$HEV_WERR_MIN" ]; then _hwk=$((_hwk + 1)); else _hwk=0; fi
    echo "$_hwz $(date +%s) $_hwk" > "$_hws"
    [ "$_hwk" -ge "$HEV_WERR_WINDOWS" ] || return 1
    echo "$_hwn строк «socks5 tunnel write» за ${_hwa} с, $_hwk-е окно подряд"
}


hev_restart_recent() {
    _hrc=$(cat "/tmp/enodia-hev-restart.$1" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_hrc" ] && [ "$(age_since "$_hrc")" -lt "$HEV_RESTART_GAP" ]
}





hev_dead_mark()  { date +%s > "/tmp/enodia-hev-dead.$1"; }
hev_dead_clear() { rm -f "/tmp/enodia-hev-dead.$1" 2>/dev/null; return 0; }
hev_path_dead()  {
    _hdd=$(cat "/tmp/enodia-hev-dead.$1" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_hdd" ] && [ "$(age_since "$_hdd")" -lt "$HEV_RESTART_GAP" ]
}



hev_stuck() {
    if ! hev_tun_ok "$1"; then
        sleep 2
        if ! hev_tun_ok "$1"; then
            echo "сервер отвечает через socks, а путь клиентов через $1 — нет (дважды)"
            hev_restart_recent "$3" && return 2
            return 0
        fi
    fi
    _hsf=$(hev_write_flood "$2" "$3") || return 1
    if hev_restart_recent "$3"; then
        log "health: hev ($1) сыплет ошибками записи в туннель ($_hsf), но его перезапускали меньше $((HEV_RESTART_GAP / 60)) мин назад — не трогаю" >&2
        return 1
    fi
    echo "путь клиентов через $1 жив, но hev сыплет ошибками записи в туннель ($_hsf)"
}


hev_lock_take() { ( set -C; echo $$ > "$HEV_SWLOCK" ) 2>/dev/null; }
hev_lock_drop() { rm -f "$HEV_SWLOCK" 2>/dev/null; return 0; }


hev_log_trim() { tail -n 20 "$1" > "$1.trim" 2>/dev/null && mv -f "$1.trim" "$1" 2>/dev/null; rm -f "$1.trim" 2>/dev/null; return 0; }


hev_restart_note() {
    date +%s > "/tmp/enodia-hev-restart.$1"
    rm -f "/tmp/enodia-hev-werr.$1" 2>/dev/null
    _hrn=$ENODIA_DIR/notify-event.sh
    [ -f "$_hrn" ] || return 0

    if ! command -v nf_lang >/dev/null 2>&1 && [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi

    if command -v nf_lang >/dev/null 2>&1 && [ "$(nf_lang)" = en ]; then
        case "$1" in main) _hrw="the main carrier" ;; *) _hrw="extra exit #${1#s}" ;; esac
        case "$3" in ok) _hrr="After the restart the clients' path works." ;; *) _hrr="Even after the restart the clients' path does not work." ;; esac
        sh "$_hrn" "hev-restart-$1" 3600 "BE7000: hev of $_hrw restarted" \
"The hev layer (TUN -> protocol proxy) of $_hrw got stuck: $2. The server kept answering, so the router restarted only hev — established connections were cut at that moment.
$_hrr" >/dev/null 2>&1
        return 0
    fi
    case "$1" in main) _hrw="основной несущей" ;; *) _hrw="доп-выхода №${1#s}" ;; esac
    case "$3" in ok) _hrr="После перезапуска путь клиентов работает." ;; *) _hrr="И после перезапуска путь клиентов не работает." ;; esac
    sh "$_hrn" "hev-restart-$1" 3600 "BE7000: hev $_hrw перезапущен" \
"Прослойка hev (TUN → прокси протокола) $_hrw залипла: $2. Сервер при этом отвечал, поэтому роутер перезапустил только hev — установленные соединения в это время оборвались.
$_hrr" >/dev/null 2>&1
    return 0
}





hev_path_check() {   # $1 = функция маршрута плагина
    [ "${HEV_CHECK:-}" = 1 ] || return 0      # не тик сторожа (перебор, прогрев, дамп) — путь клиентов не судим
    _hpw=$(hev_stuck "$TUN" "$HEV_LOG" main); _hpr=$?
    case "$_hpr" in
        1) hev_dead_clear main; return 0 ;;
        2) log "health: $_hpw — hev перезапускали меньше $((HEV_RESTART_GAP / 60)) мин назад, а путь снова мёртв: не трогаю, решает лестница сторожа (перебор серверов не нужен)"
           hev_dead_mark main
           return 1 ;;
    esac
    hev_lock_take || { log "health: $_hpw — но идёт смена транспорта (лок): hev не трогаю"; return 0; }
    log "health: $_hpw — hev залип → перезапускаю hev на месте"
    _hpp=$(cat "$HEV_PID" 2>/dev/null | tr -d ' \r\n')
    start-stop-daemon -K -p "$HEV_PID" >/dev/null 2>&1      # -K пишет в stdout — health читают и CGI
    command -v daemon_wait_gone >/dev/null 2>&1 && daemon_wait_gone "$_hpp" 5
    hev_log_trim "$HEV_LOG"
    ip link del "$TUN" 2>/dev/null; rm -f "$HEV_PID" 2>/dev/null
    _hpo=fail
    if start_daemons && "$1"; then
        ct_flush
        hev_tun_ok "$TUN" && _hpo=ok
    fi
    hev_lock_drop
    hev_restart_note main "$_hpw" "$_hpo"
    if [ "$_hpo" = ok ]; then hev_dead_clear main; log "health: hev перезапущен — путь клиентов через $TUN ожил"; return 0; fi
    hev_dead_mark main
    log "health: и после перезапуска hev путь клиентов через $TUN мёртв — решает лестница сторожа (перебор серверов не нужен)"
    return 1
}







slot_hev_path_check() {   # $1 = id
    _shid="$1"; _shtun=$(slot_tun "$_shid")
    _shw=$(hev_stuck "$_shtun" "$(slot_hev_log "$_shid")" "s$_shid"); _shr=$?
    case "$_shr" in
        1) return 0 ;;
        2) log "слот №$_shid health: $_shw — hev выхода перезапускали меньше $((HEV_RESTART_GAP / 60)) мин назад, а путь снова мёртв: не трогаю"
           return 5 ;;
    esac
    hev_lock_take || { log "слот №$_shid health: $_shw — но идёт смена транспорта (лок): hev выхода не трогаю"; return 0; }
    log "слот №$_shid health: $_shw — hev залип → перезапускаю hev выхода на месте"
    slot_hev_down "$_shid"
    hev_log_trim "$(slot_hev_log "$_shid")"
    _sho=fail
    if slot_hev_up "$_shid"; then
        slot_apply_routing "$_shid"
        ct_flush
        hev_tun_ok "$_shtun" && _sho=ok
    fi
    hev_lock_drop
    hev_restart_note "s$_shid" "$_shw" "$_sho"
    if [ "$_sho" = ok ]; then log "слот №$_shid health: hev перезапущен — путь клиентов через $_shtun ожил"; return 0; fi
    log "слот №$_shid health: и после перезапуска hev путь клиентов через $_shtun мёртв"
    return 5
}
