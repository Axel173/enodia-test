#!/bin/sh




















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
DOCROOT="$ENODIA_DIR/web"


TOTP_LIB=1
if [ -f "$ENODIA_DIR/totp.sh" ]; then . "$ENODIA_DIR/totp.sh"; fi

if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi



if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v clock_sane >/dev/null 2>&1 || clock_sane() { _csn=${1:-$(date +%s 2>/dev/null)}; case "$_csn" in ''|*[!0-9]*) return 1 ;; esac; [ "$_csn" -gt 1700000000 ] 2>/dev/null && [ "$_csn" -lt 4102444800 ] 2>/dev/null; }



command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }





LAN_IF=br-lan   # lan-lit: фолбэк на payload БЕЗ router-lib.sh — прежняя строка байт-в-байт
command -v lan_if >/dev/null 2>&1 && LAN_IF=$(lan_if)
LISTEN=$(ip -4 addr show "$LAN_IF" 2>/dev/null | awk '/inet /{print $2; exit}' | cut -d/ -f1)
[ -n "$LISTEN" ] || LISTEN=192.168.31.1
PORT=8088
PIDFILE=/tmp/enodia-uhttpd-web.pid
UHTTPD=/usr/sbin/uhttpd






if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }
TLS_BIN=$(bin_path panel-tls)
TLS_FLAG="$ENODIA_STATE/.panel-tls"      # есть файл = HTTPS включён; содержимое = порт (персист на /data)
TLS_CERT="$ENODIA_STATE/panel-cert.pem"
TLS_KEY="$ENODIA_STATE/panel-key.pem"
TLS_PID=/tmp/enodia-panel-tls.pid
TLS_LOG=/tmp/enodia-panel-tls.log
TLS_PORT_DEF=8443                   # 443 занят стоковым nginx — его не трогаем


WAN_FLAG="$ENODIA_STATE/.panel-wan"      # есть файл = порт открыт наружу (персист на /data)
WAN_CHAIN=PANEL_WAN                 # СВОЯ цепочка (как ENODIA_GEOBLK/VPN_PORTS) — снимается целиком
WAN_DNAT=PANEL_WAN_DNAT             # она же в nat: заводит пакет с WAN на LAN-сокет panel-tls
WAN_HOOK=input_wan_rule             # штатный пустой хук fw3 внутри zone_wan_input
WAN_CONN_MAX=12                     # одновременных соединений с ОДНОГО адреса (у panel-tls всего 32

WAN_RATE=30/min                     # новых соединений с адреса: браузер держит keep-alive, ему хватает
WAN_BURST=60                        # запас на первый заход (панель тянет статику+CGI параллельно)
WAN_IP_FILE="$ENODIA_STATE/.panel-wan-ip"  # последний известный внешний адрес (персист) — см. wan_ip_watch



if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi

if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v daemon_port_listens >/dev/null 2>&1 || daemon_port_listens() { netstat -ltn 2>/dev/null | grep -q "$1:$2 "; }
command -v daemon_wait_gone >/dev/null 2>&1 || daemon_wait_gone() { return 0; }   # старая библиотека — не ждём, как раньше


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v ct_flush_dport >/dev/null 2>&1 || ct_flush_dport() { [ -n "$1" ] && conntrack -D -p tcp --dport "$1" >/dev/null 2>&1; return 0; }


if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }


if [ -f "$ENODIA_DIR/json-lib.sh" ]; then . "$ENODIA_DIR/json-lib.sh"; fi
command -v jesc >/dev/null 2>&1 || {
	jesc() { tr -d '\033\r' | tr '\n\t' '  ' | cut -c1-"$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
}

is_running() {
	[ -f "$PIDFILE" ] || return 1
	pid=$(cat "$PIDFILE" 2>/dev/null)
	[ -n "$pid" ] && [ -d "/proc/$pid" ]
}

tls_enabled() { [ -f "$TLS_FLAG" ]; }




port_norm() {   # $1 — строка; печатает порт без ведущих нулей, код 1 — не порт
	case "$1" in ''|*[!0-9]*) return 1 ;; esac
	_pn=$(printf '%s' "$1" | sed 's/^0*//')
	case "$_pn" in ''|??????*) return 1 ;; esac
	[ "$_pn" -le 65535 ] || return 1
	echo "$_pn"
}
tls_port()    { _tp=$(port_norm "$(cat "$TLS_FLAG" 2>/dev/null)") || _tp=$TLS_PORT_DEF; echo "$_tp"; }

tls_running() {
	[ -f "$TLS_PID" ] || return 1
	pid=$(cat "$TLS_PID" 2>/dev/null)
	[ -n "$pid" ] && [ -d "/proc/$pid" ]
}






tls_port_foreign() {   # $1 — порт; код 0 = его слушает кто-то, кроме нашего терминатора
	tls_running && [ "$1" = "$(tls_port)" ] && return 1
	for _pa in "$LISTEN" 0.0.0.0 "::"; do
		daemon_port_listens "$_pa" "$1" || continue
		tls_orphan_on "$1" && return 1     # слушает НАШ осиротевший терминатор — его снимет tls_stop (разбор у tls_orphans)
		return 0
	done
	return 1
}





tls_orphans() {   # pid терминаторов panel-tls на нашем адресе, кроме записанного в пидфайле
	_tpo=$(cat "$TLS_PID" 2>/dev/null)
	for _tpf in $(grep -l "[p]anel-tls" /proc/[0-9]*/cmdline 2>/dev/null); do   # argv0: ищем САМУ программу (argv[0] — путь panel-tls); busybox grep видит его до первого NUL (C115)
		_tpp=${_tpf#/proc/}; _tpp=${_tpp%/cmdline}
		[ "$_tpp" = "$_tpo" ] && continue
		tr '\000' ' ' < "$_tpf" 2>/dev/null | grep -q -- "-l $LISTEN:" && echo "$_tpp"
	done
}
tls_orphan_on() {   # $1 — порт: его держит наш сирота?
	for _to in $(tls_orphans); do tr '\000' ' ' 2>/dev/null < "/proc/$_to/cmdline" | grep -q -- "-l $LISTEN:$1 " && return 0; done
	return 1
}
tls_pid_ours() { [ -n "$1" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -q "panel-tls"; }





tls_ensure_cert() {
	[ -s "$TLS_CERT" ] && [ -s "$TLS_KEY" ] && return 0

	clock_sane || {
		echo "часы не синхронизированы — сертификат не выписан (повтор после ntp)"; return 1; }
	command -v openssl >/dev/null 2>&1 || { echo "нет openssl — сертификат не выписать"; return 1; }
	cn=$(cat /proc/sys/kernel/hostname 2>/dev/null)
	[ -n "$cn" ] || cn="$LISTEN"
	openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
		-keyout "$TLS_KEY.tmp" -out "$TLS_CERT.tmp" -subj "/CN=$cn" >/dev/null 2>&1 || {
		rm -f "$TLS_KEY.tmp" "$TLS_CERT.tmp"; echo "не удалось выписать сертификат"; return 1; }
	mv "$TLS_KEY.tmp" "$TLS_KEY"; mv "$TLS_CERT.tmp" "$TLS_CERT"
	chmod 600 "$TLS_KEY"; chmod 644 "$TLS_CERT"
	echo "сертификат выписан (CN=$cn, самоподписанный)"
}

tls_start() {
	tls_enabled || return 0
	tls_running && return 0
	[ -x "$TLS_BIN" ] || { echo "нет $TLS_BIN — HTTPS пропущен"; return 1; }
	is_running || { echo "панель не поднята — HTTPS пропущен"; return 1; }
	tls_ensure_cert || return 1
	[ -f "$TLS_PID" ] && : > "$TLS_PID"

	start-stop-daemon -S -b -m -p "$TLS_PID" -x "$TLS_BIN" -- \
		-l "$LISTEN:$(tls_port)" -b "$LISTEN:$PORT" \
		-c "$TLS_CERT" -k "$TLS_KEY" -L "$TLS_LOG" >/dev/null 2>&1
	sleep 1
	if tls_running; then echo "HTTPS: https://$LISTEN:$(tls_port)  (pid $(cat "$TLS_PID"))"
	else echo "не удалось поднять panel-tls (см. $TLS_LOG)"; return 1; fi
}

tls_stop() {
	_tsw=0; tls_running && _tsw=1
	_tso=$(tls_orphans)
	[ "$_tsw" = 1 ] || [ -n "$_tso" ] || return 0
	_tsp=$(cat "$TLS_PID" 2>/dev/null)
	_tsour=0; tls_pid_ours "$_tsp" && _tsour=1

	[ "$_tsw" = 1 ] && start-stop-daemon -K -p "$TLS_PID" -x "$TLS_BIN" >/dev/null 2>&1


	tls_pid_ours "$_tsp" && kill "$_tsp" 2>/dev/null
	for _o in $_tso; do kill "$_o" 2>/dev/null; done

	[ "$_tsour" = 1 ] && daemon_wait_gone "$_tsp" 5
	for _o in $_tso; do daemon_wait_gone "$_o" 5; done
	: > "$TLS_PID"
	echo "HTTPS остановлен"
}

wan_enabled() { [ -f "$WAN_FLAG" ]; }






command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
wan_addr() {
	i=$(wan_iface); [ -n "$i" ] || return 1
	ip -4 addr show dev "$i" 2>/dev/null | awk '/inet /{print $2; exit}' | cut -d/ -f1
}








wan_verdict() {
	a=$(wan_addr)
	[ -n "$a" ] || { echo none; return 0; }
	command -v is_private_ip >/dev/null 2>&1 && is_private_ip "$a" && { echo "private $a"; return 0; }
	echo "public $a"
}





wan_ip_watch() {
	new="$1"
	[ -n "$new" ] || return 0
	old=$(cat "$WAN_IP_FILE" 2>/dev/null)
	[ "$old" = "$new" ] && return 0
	echo "$new" > "$WAN_IP_FILE"


	[ -n "$old" ] || return 0
	[ -f "$ENODIA_DIR/notify-event.sh" ] || return 0


	v=$(wan_verdict); set -- $v
	[ "$1" = public ] || return 0
	p=$(tls_port)
	if [ "$(nf_lang)" = en ]; then
		sh "$ENODIA_DIR/notify-event.sh" panel-wan-ip 3600 "BE7000: router external address changed" \
"The ISP gave the router a new external address, so the old panel link no longer works.

Was:  $old
Now:  $new

Panel from outside: https://$new:$p
Access from outside is still on, the login is still the panel password." >/dev/null 2>&1
	else
		sh "$ENODIA_DIR/notify-event.sh" panel-wan-ip 3600 "BE7000: внешний адрес роутера сменился" \
"Провайдер выдал роутеру новый внешний адрес — старая ссылка на панель больше не работает.

Было:  $old
Стало: $new

Панель снаружи: https://$new:$p
Доступ снаружи по-прежнему открыт, вход — под тем же паролем панели." >/dev/null 2>&1
	fi
	return 0
}



wan_rule_apply() {
	wan_enabled || return 0
	tls_enabled || return 0     # без HTTPS наружу не открываем НИКОГДА (см. шапку)



	if ! tls_running; then
		if iptables -L "$WAN_CHAIN" -n >/dev/null 2>&1 || wan_rule_active; then wan_rule_clear; fi
		echo "HTTPS не работает — порт наружу закрыт до его подъёма"
		return 0
	fi
	iptables -L "$WAN_HOOK" -n >/dev/null 2>&1 || { echo "нет цепочки $WAN_HOOK (fw3 не поднят?)"; return 1; }
	p=$(tls_port)
	iptables -N "$WAN_CHAIN" 2>/dev/null
	iptables -F "$WAN_CHAIN" 2>/dev/null





	lim=1
	iptables -A "$WAN_CHAIN" -p tcp --dport "$p" -m connlimit \
		--connlimit-above "$WAN_CONN_MAX" --connlimit-mask 32 -j DROP 2>/dev/null || lim=0
	iptables -A "$WAN_CHAIN" -p tcp --dport "$p" -m conntrack --ctstate NEW -m hashlimit \
		--hashlimit-above "$WAN_RATE" --hashlimit-burst "$WAN_BURST" \
		--hashlimit-mode srcip --hashlimit-name paneltls -j DROP 2>/dev/null || lim=0
	iptables -A "$WAN_CHAIN" -p tcp --dport "$p" -j ACCEPT || { wan_rule_clear; echo "не удалось поставить правило"; return 1; }
	iptables -C "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null || iptables -I "$WAN_HOOK" 1 -j "$WAN_CHAIN"
	[ "$lim" = 1 ] || echo "ВНИМАНИЕ: ограничитель частоты подключений не встал — порт открыт без защиты от перебора"





	wi=$(wan_iface)
	if [ -n "$wi" ]; then
		iptables -t nat -N "$WAN_DNAT" 2>/dev/null
		iptables -t nat -F "$WAN_DNAT" 2>/dev/null
		iptables -t nat -A "$WAN_DNAT" -i "$wi" -p tcp --dport "$p" -j DNAT --to-destination "$LISTEN:$p" 2>/dev/null \
			|| echo "ВНИМАНИЕ: не удалось завернуть WAN-трафик на панель (DNAT) — снаружи не откроется"






		ha=$(wan_addr)
		wan_ip_watch "$ha"
		if [ -n "$ha" ]; then
			iptables -t nat -A "$WAN_DNAT" -i "$LAN_IF" -d "$ha" -p tcp --dport "$p" \
				-j DNAT --to-destination "$LISTEN:$p" 2>/dev/null \
				|| echo "ВНИМАНИЕ: не удалось завернуть домашний трафик на внешний адрес (hairpin)"
		fi
		iptables -t nat -C PREROUTING -j "$WAN_DNAT" 2>/dev/null || iptables -t nat -I PREROUTING 1 -j "$WAN_DNAT"
	else





		if [ "$(uptime_s)" -lt 300 ] 2>/dev/null; then
			echo "WAN-интерфейс ещё не поднят (бут) — правило доступа снаружи поставлю следующим тиком"
		else
			echo "ВНИМАНИЕ: WAN-интерфейс не определён — снаружи не откроется"
		fi
	fi
	return 0
}



wan_limits_ok() {
	n=$(iptables -S "$WAN_CHAIN" 2>/dev/null | grep -c 'j DROP')
	[ "${n:-0}" -ge 2 ] 2>/dev/null
}

wan_rule_clear() {

	while iptables -C "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null; do
		iptables -D "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null || break
	done
	iptables -F "$WAN_CHAIN" 2>/dev/null
	iptables -X "$WAN_CHAIN" 2>/dev/null
	while iptables -t nat -C PREROUTING -j "$WAN_DNAT" 2>/dev/null; do
		iptables -t nat -D PREROUTING -j "$WAN_DNAT" 2>/dev/null || break
	done
	iptables -t nat -F "$WAN_DNAT" 2>/dev/null
	iptables -t nat -X "$WAN_DNAT" 2>/dev/null




	ct_flush_dport "$(tls_port)"
	return 0
}



wan_rule_active() {
	iptables -C "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null || return 1
	iptables -t nat -C PREROUTING -j "$WAN_DNAT" 2>/dev/null
}



totp_on() {
	[ -f "$ENODIA_DIR/totp.sh" ] || return 1
	case "$(sh "$ENODIA_DIR/totp.sh" status 2>/dev/null | grep '^{' | tail -1)" in
		*'"on":true'*) return 0 ;;
	esac
	return 1
}













wan_on() {
	tls_enabled || { echo "сперва включите HTTPS ($0 tls-on) — наружу открываем только его"; return 1; }
	tls_running || { echo "HTTPS включён, но panel-tls не работает — сперва почините его"; return 1; }
	_2fa=0; totp_on && _2fa=1
	if [ "$1" != "--force" ] && [ "$_2fa" = 0 ]; then
		echo "сперва включите второй фактор (2FA) — наружу открываем только под ним:"
		echo "панель → «Панель» → «Доступ к панели» → «Второй фактор»."
		echo "осознанно открыть без него: $0 wan-on --force"
		return 1
	fi
	: > "$WAN_FLAG"
	wan_rule_apply || { rm -f "$WAN_FLAG"; return 1; }



	if [ "$_2fa" = 1 ] && ! totp_on; then
		wan_off >/dev/null 2>&1
		echo "второй фактор сняли в эту же минуту — вход снаружи не открыт"
		return 1
	fi
	v=$(wan_verdict); set -- $v
	case "$1" in
		public)  echo "открыт доступ снаружи: https://$2:$(tls_port)" ;;
		private) echo "правило поставлено, но WAN-адрес $2 приватный (CGNAT/двойной NAT) —"
		         echo "снаружи панель не откроется, пока провайдер не даст белый IP" ;;
		*)       echo "правило поставлено, но WAN-адрес определить не вышло" ;;
	esac


	if [ "$_2fa" = 1 ]; then
		echo "вход — пароль панели плюс код из приложения"
	else
		echo "ВТОРОГО ФАКТОРА НЕТ: вход держит один только пароль — он должен быть длинным"
	fi
}

wan_off() {
	rm -f "$WAN_FLAG"
	wan_rule_clear
	echo "доступ снаружи закрыт"
}




cmd_json() {
	ti=false; [ -x "$TLS_BIN" ] && ti=true
	to=false; tls_enabled && to=true
	tr_=false; tls_running && tr_=true
	wo=false; wan_enabled && wo=true
	wr=false; wan_rule_active && wr=true
	wl=true; wan_rule_active && { wan_limits_ok || wl=false; }
	up=false; is_running && up=true
	cert=false; [ -s "$TLS_CERT" ] && [ -s "$TLS_KEY" ] && cert=true



	twhy=""
	if [ "$to" = true ] && [ "$tr_" = false ]; then
		if [ "$ti" = false ]; then twhy=bin
		elif tls_port_foreign "$(tls_port)"; then twhy=port
		elif [ "$cert" = false ] && ! clock_sane; then twhy=clock
		fi
	fi
	v=$(wan_verdict); set -- $v; wkind="$1"; waddr="$2"


	ing=false; imsg=""; pkb=false; _imine=0






	if [ -f "$ENODIA_DIR/packages.sh" ]; then
		_ibj=$(sh "$ENODIA_DIR/packages.sh" busy tls 2>/dev/null); _ibc=$?
		[ "$_ibc" = 0 ] && pkb=true
		case "$_ibj" in *'"mine":true'*) _imine=1 ;; esac
		[ "$pkb" = true ] && [ "$_imine" = 1 ] && ing=true



		if [ "$_ibc" = 2 ] && [ -f /tmp/enodia-proto-install.pid ]; then
			[ -d "/proc/$(cat /tmp/enodia-proto-install.pid 2>/dev/null)" ] && { ing=true; pkb=true; }
		fi
	fi




	if [ "$_imine" = 1 ] || [ "${_ibc:-}" = 2 ]; then
		[ -f "$ENODIA_STATE/.proto-install.log" ] && imsg=$(tail -n1 "$ENODIA_STATE/.proto-install.log" 2>/dev/null | jesc 160)
	fi


	tf=""
	[ -f "$ENODIA_DIR/totp.sh" ] && tf=$(sh "$ENODIA_DIR/totp.sh" status 2>/dev/null | grep '^{' | tail -1)
	[ -n "$tf" ] || tf='{"on":false,"pending":false,"clock":true,"recovery":0,"sessions":0,"lock":0,"engine":false}'
	printf '{"up":%s,"lan":"%s","port":%s,"installed":%s,"cert":%s,"tls_on":%s,"tls_running":%s,"tls_why":"%s","tls_port":%s,"wan_on":%s,"wan_rule":%s,"wan_limits":%s,"wan_kind":"%s","wan_addr":"%s","installing":%s,"pkg_busy":%s,"install_msg":"%s","totp":%s}\n' \
		"$up" "$LISTEN" "$PORT" "$ti" "$cert" "$to" "$tr_" "$twhy" "$(tls_port)" "$wo" "$wr" "$wl" "$wkind" "$waddr" "$ing" "$pkb" "$imsg" "$tf"
}

setpass() {
	pass="$1"; _sp_flag="$2"



	if [ "$pass" = "--no-restart" ] && [ -z "$_sp_flag" ]; then pass=""; _sp_flag="--no-restart"; fi




	if [ -z "$pass" ]; then
		if [ -t 0 ]; then
			printf 'Новый пароль панели: '; IFS= read -r -s pass; echo
			printf 'Ещё раз: '; IFS= read -r -s _sp_again; echo
			[ -n "$pass" ] || { echo "пароль не введён — пароль НЕ сменён"; return 1; }
			[ "$pass" = "$_sp_again" ] || { echo "пароли не совпадают — пароль НЕ сменён"; return 1; }
		else


			echo "терминала нет — пароль читаю одной строкой со stdin, без скрытия и без повтора (скрытый ввод — по ssh с терминалом: ssh -t)" >&2
			IFS= read -r pass || true
			[ -n "$pass" ] || { echo "пароль не получен: stdin пуст — пароль НЕ сменён (с терминалом команда спросит его сама: sh ${ENODIA_BOOT:-/data/usr/app/enodia-boot}/boot.sh web-ui.sh setpass)"; return 1; }
		fi
	fi




	case "$pass" in *'
'*) echo "пароль: одна строка, без перевода строки — пароль НЕ сменён"; return 1 ;; esac
	printf '%s' "$pass" | grep -qE '^[!-~]{8,64}$' || { echo "пароль: 8..64 символов, латиница/цифры/знаки, без пробелов — пароль НЕ сменён"; return 1; }





	command -v pw_set >/dev/null 2>&1 || { echo "нет totp.sh (обновите панель)"; return 1; }





	_sp_same=1; command -v pw_verify >/dev/null 2>&1 && { pw_verify "$pass" || _sp_same=0; }
	pw_set "$pass" || { echo "не удалось записать хэш пароля"; return 1; }
	echo "пароль панели задан"













	if [ "$_sp_flag" != "--no-restart" ] && [ -z "${GATEWAY_INTERFACE:-}" ] && [ "$_sp_same" != 1 ] &&
	   command -v totp_sess_clear >/dev/null 2>&1 && [ -s "$TOTP_SESS" ]; then
		totp_sess_clear && echo "вошедшие устройства разлогинены (пароль сменился)"
	fi



	if [ "$_sp_flag" = "--no-restart" ] || [ -n "$GATEWAY_INTERFACE" ]; then return 0; fi
	if basic_running; then echo "снимаю HTTP-Basic (вход теперь формой) — перезапуск"; stop >/dev/null 2>&1; start; fi
}


basic_running() {
	is_running || return 1
	tr '\0' ' ' < "/proc/$(cat "$PIDFILE" 2>/dev/null)/cmdline" 2>/dev/null | grep -q ' -c '
}









start_why() {


	if ! ip -4 addr show 2>/dev/null | grep -q "inet ${LISTEN}[/ ]"; then
		echo "адреса $LISTEN нет ни на одном интерфейсе — сеть ещё не поднялась или LAN-IP роутера сменился"
		return 0
	fi
	_wb=$(netstat -ltn 2>/dev/null | grep "[.:]$PORT " | head -1)
	if [ -n "$_wb" ]; then
		echo "порт $PORT уже занят другим процессом ($_wb)"
		return 0
	fi
	_we=$(timeout -t 2 "$UHTTPD" "$@" 2>&1 | grep -v '^[[:space:]]*$' | head -2 | tr '\n' ' ')
	[ -n "$_we" ] && { echo "uhttpd отказался стартовать: $_we"; return 0; }
	echo "вручную uhttpd стартует, а фоновый запуск не удержался — проверьте $PIDFILE и место в /tmp"
}

start() {
	[ -x "$UHTTPD" ] || { echo "нет $UHTTPD"; return 1; }
	[ -f "$DOCROOT/index.html" ] || { echo "нет $DOCROOT/index.html"; return 1; }


	command -v pw_migrate >/dev/null 2>&1 || { echo "нет totp.sh — обновите панель"; return 1; }




	command -v totp_sess_clock_fix >/dev/null 2>&1 && totp_sess_clock_fix
	pw_migrate >/dev/null 2>&1 || true








	if [ -n "${TOTP_LEGACY_PASS:-}" ] && [ -e "$TOTP_LEGACY_PASS" ]; then



		if [ -s "$TOTP_LEGACY_PASS" ] && [ ! -s "$TOTP_PASS" ]; then
			echo "пароль не перенесён в $TOTP_PASS (место на /data?) — без переноса панель отдала бы хэш статикой, не поднимаю"; return 1
		fi
		rm -f "$TOTP_LEGACY_PASS" 2>/dev/null
		[ -e "$TOTP_LEGACY_PASS" ] && { echo "не убрать $TOTP_LEGACY_PASS — хэш пароля утёк бы статикой, панель не поднимаю"; return 1; }
	fi
	pw_exists || { echo "сначала задайте пароль: sh ${ENODIA_BOOT:-/data/usr/app/enodia-boot}/boot.sh web-ui.sh setpass"; return 1; }



	if is_running; then



		if basic_running && [ -z "$GATEWAY_INTERFACE" ]; then
			echo "снимаю HTTP-Basic (вход теперь формой) — перезапуск"; stop >/dev/null 2>&1
		else
			echo "уже работает (pid $(cat "$PIDFILE"))"; tls_start; wan_rule_apply; return 0
		fi
	fi
	[ -f "$PIDFILE" ] && : > "$PIDFILE"





	[ -x "$DOCROOT/htmlwrap" ] && set -- -i ".html=$DOCROOT/htmlwrap" || set --












	set -- -f -h "$DOCROOT" -x /cgi-bin \
		-t 180 -T 120 \
		-p "$LISTEN:$PORT" -I index.html -D -S "$@"
	start-stop-daemon -S -b -m -p "$PIDFILE" -x "$UHTTPD" -- "$@"
	sleep 1
	if is_running; then echo "поднят: http://$LISTEN:$PORT  (pid $(cat "$PIDFILE"))"
	else echo "не удалось поднять uhttpd: $(start_why "$@")"; return 1; fi
	tls_start
	wan_rule_apply
}

stop() {
	wan_rule_clear     # порт наружу без живой панели не держим (флаг остаётся — start вернёт)
	tls_stop           # сперва терминатор: без бэкенда он всё равно бесполезен
	if is_running; then
		start-stop-daemon -K -p "$PIDFILE" -x "$UHTTPD" 2>/dev/null


		daemon_wait_gone "$pid" 5
		: > "$PIDFILE"
		echo "остановлен"
	else
		echo "не запущен"
	fi
}

tls_on() {
	port="$1"
	[ -n "$port" ] || port=$(tls_port)
	port=$(port_norm "$port") || { echo "порт — число от 1 до 65535"; return 1; }
	[ "$port" = "$PORT" ] && { echo "порт $port занят самой панелью"; return 1; }
	[ -x "$TLS_BIN" ] || { echo "нет $TLS_BIN (обновите установку)"; return 1; }
	tls_port_foreign "$port" && { echo "порт $port уже занят другой службой роутера — выберите другой"; return 1; }


	if tls_running && [ "$port" = "$(tls_port)" ]; then
		wan_rule_apply >/dev/null 2>&1; panel_guard_move "$port" "$port"
		echo "HTTPS уже работает на порту $port"; return 0
	fi
	_gold=""; tls_enabled && _gold=$(tls_port)


	_old=""; tls_running && _old=$(tls_port)
	echo "$port" > "$TLS_FLAG"
	tls_stop >/dev/null 2>&1     # порт мог смениться — поднимаем заново



	_rc=0; _st=$(tls_start 2>&1) || _rc=1
	[ "$_rc" = 0 ] && [ -n "$_st" ] && echo "$_st"
	if [ "$_rc" != 0 ] && [ -n "$_old" ] && [ "$_old" != "$port" ]; then
		echo "$_old" > "$TLS_FLAG"; tls_start >/dev/null 2>&1 && echo "вернул прежний порт $_old"
	fi
	wan_rule_apply               # порт открыт наружу — правило пересобрать под ТОТ порт, что слушает терминатор
	panel_guard_move "$_gold" "$(tls_port)"
	[ "$_rc" = 0 ] || printf '%s\n' "$_st" | tail -n 1
	return "$_rc"
}






panel_guard_move() {   # $1 — прежний порт (пусто — не было), $2 — новый (пусто — HTTPS выключен)
	if [ -n "$1" ]; then while iptables -t mangle -D OUTPUT -p tcp --sport "$1" -j ACCEPT 2>/dev/null; do :; done; fi
	[ -n "$2" ] || return 0
	iptables -t mangle -S OUTPUT 2>/dev/null | grep -q -- '-j MARK' || return 0
	iptables -t mangle -C OUTPUT -p tcp --sport "$2" -j ACCEPT 2>/dev/null || iptables -t mangle -I OUTPUT 1 -p tcp --sport "$2" -j ACCEPT 2>/dev/null
	return 0
}



tls_cert_renew() {


	[ -s "$TLS_CERT" ] && mv -f "$TLS_CERT" "$TLS_CERT.old"
	[ -s "$TLS_KEY" ] && mv -f "$TLS_KEY" "$TLS_KEY.old"
	_rc=0
	if tls_ensure_cert; then
		rm -f "$TLS_CERT.old" "$TLS_KEY.old"
		tls_stop >/dev/null 2>&1; tls_start || _rc=1
	else
		_rc=1
		[ -s "$TLS_CERT.old" ] && mv -f "$TLS_CERT.old" "$TLS_CERT"
		[ -s "$TLS_KEY.old" ] && mv -f "$TLS_KEY.old" "$TLS_KEY"
	fi
	wan_rule_apply >/dev/null 2>&1
	return "$_rc"
}



tls_reload() {
	tls_running || return 0
	tls_stop >/dev/null 2>&1
	_rc=0; tls_start || _rc=1
	wan_rule_apply >/dev/null 2>&1
	return "$_rc"
}



tls_off() {
	wan_enabled && { wan_off; echo "(доступ снаружи снят вместе с HTTPS)"; }
	tls_enabled && panel_guard_move "$(tls_port)" ""
	tls_stop
	rm -f "$TLS_FLAG"
	echo "HTTPS выключен"
}

case "$1" in
	start)     start ;;
	stop)      stop ;;
	restart)   stop; start ;;
	setpass)   setpass "$2" "$3" ;;
	haspass)   pw_exists ;;        # код 0 — пароль задан (ПК при переустановке: Enter = «оставить прежний»)
	tls-on)    tls_on "$2" ;;
	tls-off)   tls_off ;;
	tls-cert)  tls_cert_renew ;;
	tls-reload) tls_reload ;;      # перечитать сертификат с диска (импорт бэкапа привёз свой)
	tls-running) tls_running ;;    # код 0 — терминатор бежит; пидфайл знает только этот файл
	wan-on)    wan_on "$2" ;;      # "$2" = --force: открыть порт БЕЗ второго фактора (только из CLI)
	wan-off)   wan_off ;;
	wan-rule)  wan_rule_apply ;;   # ручной переигрыш (после fw3 reload), тот же путь, что из start
	wan-enabled) wan_enabled ;;    # код 0 — вход снаружи включён (флаг); путь флага знает только этот файл
	json)      cmd_json ;;         # состояние для панели (cgi-bin/data?section=panel_access)
	status|"") if is_running; then echo "работает (pid $(cat "$PIDFILE")) на http://$LISTEN:$PORT"; else echo "не запущен"; fi
	           if tls_enabled; then
	                   if tls_running; then echo "HTTPS: работает (pid $(cat "$TLS_PID")) на https://$LISTEN:$(tls_port)"
	                   else echo "HTTPS: включён, но НЕ работает (порт $(tls_port); см. $TLS_LOG)"; fi
	           else echo "HTTPS: выключен"; fi
	           if wan_enabled; then
	                   v=$(wan_verdict); set -- $v
	                   if wan_rule_active; then st="правило стоит"; else st="ВКЛЮЧЁН, но правила НЕТ (fw3 смыл?)"; fi
	                   case "$1" in
	                           public)  echo "Снаружи: $st — https://$2:$(tls_port)" ;;
	                           private) echo "Снаружи: $st, но WAN-адрес $2 приватный — извне не достучаться" ;;
	                           *)       echo "Снаружи: $st, WAN-адрес не определён" ;;
	                   esac
	           else echo "Снаружи: закрыт"; fi


	           if [ -f "$ENODIA_DIR/totp.sh" ]; then
	                   case "$(sh "$ENODIA_DIR/totp.sh" status 2>/dev/null)" in
	                           *'"on":true'*) echo "Второй фактор (TOTP): включён" ;;
	                           *)             echo "Второй фактор (TOTP): выключен" ;;
	                   esac
	           fi ;;

	*) echo "usage: sh ${ENODIA_BOOT:-/data/usr/app/enodia-boot}/boot.sh web-ui.sh {start|stop|restart|status|setpass [пароль] [--no-restart]|tls-on [порт]|tls-off|tls-cert|wan-on [--force]|wan-off|wan-rule|json}"; exit 1 ;;
esac
