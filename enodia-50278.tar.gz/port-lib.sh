#!/bin/sh
































port_src_ok() {
	[ "$1" = any ] && return 0
	echo "$1" | grep -Eq '^(0|[1-9][0-9]{0,2})(\.(0|[1-9][0-9]{0,2})){3}$' || return 1
	_pli=$IFS; IFS=.; set -- $1; IFS=$_pli
	[ "$1" -le 255 ] && [ "$2" -le 255 ] && [ "$3" -le 255 ] && [ "$4" -le 255 ]
}
port_proto_ok() { case "$1" in udp|tcp|both) return 0 ;; *) return 1 ;; esac; }
port_dir_ok()   { case "$1" in vpn|direct|block|s2|s3|s4) return 0 ;; *) return 1 ;; esac; }



port_list_ok() {
	[ "$1" = all ] && return 0
	echo "$1" | grep -Eq '^[0-9]{1,5}(-[0-9]{1,5})?(,[0-9]{1,5}(-[0-9]{1,5})?)*$' || return 1
	for _plq in $(echo "$1" | tr ',' ' '); do



		_pla=${_plq%-*}; _plb=${_plq#*-}
		case "$_pla,$_plb" in 0*|*,0*) return 1 ;; esac
		[ "$_pla" -ge 1 ] && [ "$_pla" -le 65535 ] || return 1
		[ "$_plb" -ge 1 ] && [ "$_plb" -le 65535 ] || return 1
		[ "$_pla" -le "$_plb" ] || return 1
	done
	return 0
}


port_list_norm() { echo "$1" | tr -d ' \t\r' | sed -r 's/(^|[,-])0+([0-9])/\1\2/g'; }

port_width() {
	[ "$1" = all ] && { echo 65535; return 0; }
	_plw=0
	for _plq in $(echo "$1" | tr ',' ' '); do
		_pla=${_plq%-*}; _plb=${_plq#*-}
		_plw=$((_plw + _plb - _pla + 1))
	done
	echo "$_plw"
}

port_line_ok()  { port_src_ok "$1" && port_proto_ok "$2" && port_list_ok "$3" && port_dir_ok "$4"; }







port_rules_in_order() {
	[ -s "$1" ] || return 0
	_plf=$1; _plo=""; [ "$#" -ge 2 ] && _plo="=$2"
	_plt=$(printf '\t'); _plc=$(printf '\r')
	for _plp in dev any; do
		_pln=0
		while IFS="$_plt" read -r _pls _plr _plx _pld || [ -n "$_pls" ]; do
			_pld=${_pld%"$_plc"}   # файл из Блокнота (CRLF): «block\r» иначе не узнаёт ни один словарь
			[ -n "$_pld" ] || continue
			if [ "$_plp" = any ]; then
				[ "$_pls" = any ] || continue
			else
				[ "$_pls" != any ] || continue
				[ -z "$_plo" ] || [ "=$_pls" = "$_plo" ] || continue
			fi
			_plx=$(port_list_norm "$_plx")
			port_line_ok "$_pls" "$_plr" "$_plx" "$_pld" || continue
			_pln=$((_pln + 1)); _plw=$(port_width "$_plx"); [ "$_plr" = both ] && _plw=$((_plw * 2))
			printf '%06d\t%05d\t%s\t%s\t%s\t%s\n' "$_plw" "$_pln" "$_pls" "$_plr" "$_plx" "$_pld"
		done < "$_plf" | sort | cut -f3-
	done
}
