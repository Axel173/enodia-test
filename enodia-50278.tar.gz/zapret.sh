#!/bin/sh



























































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
if ! command -v ct_flush >/dev/null 2>&1; then
    ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }
    ct_flush_src()  { [ -n "$1" ] && conntrack -D --src "$1" >/dev/null 2>&1; return 0; }
fi


if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi

command -v carrier_barred >/dev/null 2>&1 || carrier_barred() { return 1; }
command -v carrier_run >/dev/null 2>&1 || carrier_run() { shift; "$@"; }



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}


command -v carrier_up_mark >/dev/null 2>&1 || carrier_up_mark() { return 0; }
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }




command -v bin_dest  >/dev/null 2>&1 || bin_dest()  { printf '%s' "$ENODIA_BIN/$1"; }
command -v bin_prune >/dev/null 2>&1 || bin_prune() { return 0; }


: "${BIN_DIR:=$ENODIA_DIR}"
NFQWS=$(bin_path nfqws)                # бинарь nfqws (bin/nfqws.user) — UPX-static aarch64
TLS_BIN="$ENODIA_DIR/zapret-tls.bin"      # фейк TLS-ClientHello (встроен base64 ниже)
QUIC_BIN="$ENODIA_DIR/zapret-quic.bin"    # фейк QUIC-Initial (встроен base64 ниже)
SET=zapret_set                         # ipset сайтов «десинк-direct» ПО ДОМЕНАМ (наполняет dnsmasq)








SET_CIDR=zapret_cidr





SET_DOM=zapret_dom





SET_GEO=geo_zapret
ZAPRET_SETS="$SET $SET_CIDR $SET_DOM $SET_GEO"
QNUM=212                                            # номер NFQUEUE
MARK=0x40000000                                     # метка nfqws на своих реинъектах (DESYNC_MARK)
MARKM="$MARK/$MARK"
NFQ_PID=/tmp/enodia-zapret-nfqws.pid
NFQ_LOG=/tmp/enodia-zapret-nfqws.log
ON_FLAG="$ENODIA_STATE/.zapret-on"
ARGS_FILE="$ENODIA_STATE/.zapret-args"
CATS_FILE="$ENODIA_STATE/.zapret-cats"
TRANSPORT_FLAG="$ENODIA_STATE/.transport"
DNS1=1.1.1.1                                        # прямой резолвер (туннеля нет → upstream dnsmasq мимо VPN)
DNS2=8.8.8.8
GH="$ENODIA_DIR/gh-update.sh"                       # апдейтер: gh-update.sh fetch-bin nfqws (панель-установка)
INSTALL_STATE="$ENODIA_STATE/.zapret-install.state" # прогресс фоновой install/remove (формат как proto-install)
INSTALL_LOG="$ENODIA_STATE/.zapret-install.log"     # лог фоновой install/remove (фронт поллит последнюю строку)
DNSMASQ_SNIPPET=/etc/dnsmasq.d/04-zapret.conf
DNSMASQ_LIVE=/tmp/dnsmasq.d/04-zapret.conf          # ЖИВАЯ копия того же сниппета (см. write_dnsmasq/del_dnsmasq)
SWEEP_LOCK=/tmp/enodia-zapret-sweep.lock            # браузер-свип идёт (timestamp)
SWEEP_BAK="$ENODIA_STATE/.zapret-args.sweepbak"     # бэкап исходной стратегии на время свипа
SWEEP_TTL=150                                       # свежесть lock (сек)


CB="-m connbytes --connbytes-dir original --connbytes-mode packets --connbytes 1:8"






DEFAULT_ARGS="--filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,sniext --dpi-desync-repeats=3 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic"




TLS_B64='FgMBAocBAAKDAwNfFWPLBuoc3UB29YxEUG4B86ODrMLiM2mG7KlnITC9JyC5zjH8AuwI5SWbkBxgsB4fErU45KaIuySqlj+mx/e02wAiEwETAxMCwCvAL8ypzKjALMAwwArACcATwBQAnACdAC8ANQEAAhgAAAATABEAAA53d3cuZ29vZ2xlLmNvbQAXAAD/AQABAAAKAA4ADAAdABcAGAAZAQABAQALAAIBAAAQAA4ADAJoMghodHRwLzEuMQAFAAUBAAAAAAAiAAoACAQDBQMGAwIDADMAawBpAB0AIHrBRo14u1yZ5ePVgAgeBwzYiWvmOe07TqRdXjKDSYx+ABcAQQTwQ0GH5mw8JFjPlmBpB53EXp4bh/BxiUK9zAIGmqsQCQNrvJHFqI6+toGn6rSl7SbMtFQQh/hzoWKsij5sr52tACsABQQDBAMDAA0AGAAWBAMFAwYDCAQIBQgGBAEFAQYBAgMCAQAcAAJAAf4NARkAAAEAAX8AIIt3byfmna7qvEsPOHznFjexjTEIZ9ajYlrBxP1CGVpJAO8mMk/Vk5ryi7d6gSiaXTAImHavEWFj2lEo4eL6ThF+93BwsM/10cZakX3laocEZSKm0aSbcHkTjtcSHxuMYElbInJ3sBVsvGtPvZIkgKwy4gwy7gEHygmFuJvL3tDG6GnMnJR8vyWQYCvhogH42VSbkteuSVI2wfYKVVtIrFedseO3tZb6m7Q5wbaC4+SN1gP2BCd3uiQgZzU4decymc/8uM6tEtJhoX13khLgmEXG6ggaJv2Q7hvq/V68Uh5wXcpgRFLUww5/5xG05hDzn694K9nTSl2n8F9BJBxA8xqwAFlYG+N7zk1dnwa0oJ7NqA=='
QUIC_B64='wwAAAAEIeOeYRrvzeYQAAESesuIbTYvML8k+74FJlUpbpjZLkRkbfQ7pPzj/kZL9Fu+3ogPlQ8dyMeP89o8Auy/DSwZaokXfGeuOwoSnfRtQe3OzcZK8imo9mFgmDBxr+y10Kbw8odbQHHk3KTKRDD0/8g5SJAkQBIKWNLqrjZ3+1tCq9p6GcDAc3qo+UCwnJkD6S+3zJDKp/T605OBNXZ0CWT78aGf6p7S4qYfZIhlTwaLpC3DRfnoU6fjOealCm82TouI15OZz2SddeAM94DLpdzpR6RsiF50yvp6XhGGrtG4aqVV+SzXrwxUkgyMrL8hjMlEGvRjXS7KHVda1WHEENZabAalpnEbSY4+7q+Tr21kWGdnpaXbSUHc9b+m8+EjZ9uSeFiAaTZuqjCrg8Awq/bM9kmxDHbj0SrXxGSUovKcBmjQg7N8N641Stbd0FYC2MKELnYtR3ZaDLCwz0eZsJKze/qh+ta8RSm0E97GPcKXE17ZdbfVt/eF+77Aq+J85nWxlCheLfrBJqNN2DDbV56uKq/9VIWHR29TXY/vWQ0UHzPn5KpG9VO2M4wjMzZoNfgTY9YcA+ClVuFOM0BHuCg6x2LAtsR8+Ofr6F0hh/BJzTmL1+dWoznqhCeW+PC4x9NQde8tShTbnhFpwuCRL1S0c+Py2rvQJtGzbj9NQCz+jHaSTpZ35hbdQabjb6jWtKB2Ws/tc3WSZgzVVSXLD2dOgwXCwbhp7vbEsQzBPAG8zcg01mp3zV3bA9u0N66Ne0on5Y30UI79cXsBhwuqivmYW2xpHNT+o8LL7ZhmimySIExeyLDWSOSSfPu33tffnIl4Pjl48p0G3BRdr3SnqhmW1DQFKl1XODREQTAwL5dYu00NgZ9gE9NHj6UGv0Wim7q9FVzLTK3C0nUrs2EVPBZhOcKaOgOHz8L4T06vK02haE+J/n1NsKxQffG9eOsZvmY/G8iAPd4rnRQV8w1vEPgcwyIgpAfREMDEjDZo0RLpAdW4HQ0gBmuFjeKSQ3yRQhRawu4mkrZOf6vfZRS6Wt74wx0s4CUSUwVyyU+WgHMPnWTrljlkoz61LHXDtedEZbg/lD1vjA3pt2/rYmYxmz7+P8+0ozYu4WAlRxG+BwMWZP0qvnwNQNtYUEHb9i/ffKVcW/IHO7/nSSb4JII/z5+oH7otIVVHSEqhxdAWZsDzKjCFInpRjxGL3awJBHnq+ULxEB3+nQbL6sQCjexBGocISAJ9oSXItUcPc6tBxeA/L97oMOpOyFMjR/OTYNWRJjKcDEw7UugROORI+ODAsOpgLte4By2IsGyMp7Ehsi45ZNYgT+OleAgSdkK0EIbkWgQE30NAVIERobsj6FGuIKLzlpVEIb296FBO7PbnJX3wtMjn3zF1wTxlKWyJJc/QshKIFdu9iOKzmx09T+RJuNApwts1ITGtRDc/RiHX6Zuihxw2lZHiKUXKyuNz1EzOj8shdnD8CkEawlP+301xKA9Gha+qp7SeDdC+KqFHKDFxkknOqOB3ZDJUijL+9n7RbDu32TGnEaaJCkE+VQEr94woNA8SxigFvW7dKtpEGSqPticyVBQsiI0atDHBW'




[ -f "$ENODIA_DIR/doh-lib.sh" ] && . "$ENODIA_DIR/doh-lib.sh"
command -v doh_apply_dns >/dev/null 2>&1 || doh_apply_dns() { return 1; }

command -v dns_upstream_put >/dev/null 2>&1 || dns_upstream_put() { mkdir -p /etc/dnsmasq.d; { echo no-resolv; for _dus in "$@"; do echo "server=$_dus"; done; } > /etc/dnsmasq.d/00-upstream.conf; /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null; }

log() { echo "[zapret] $*"; }


proc_alive() { p=$(cat "$1" 2>/dev/null | tr -d ' \r\n'); [ -n "$p" ] && kill -0 "$p" 2>/dev/null; }



SLOTS_SH="$ENODIA_DIR/slots.sh"




zt_transport_active() { ! carrier_barred && [ "$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')" = zapret ]; }

zt_any_slot_enabled() {
    carrier_barred && return 1
    [ -f "$SLOTS_SH" ] || return 1
    sh "$SLOTS_SH" list-enabled 2>/dev/null | while IFS="$(printf '\t')" read -r _sid _st _sc _sf; do
        [ "$_st" = zapret ] || continue
        [ "$_sid" = "$1" ] && continue
        echo x; break
    done | grep -q x
}



zt_any_src_wired() {
    iptables -t mangle -S POSTROUTING 2>/dev/null \
        | grep -e '-s [0-9]' | grep -q -e "--queue-num $QNUM"
}





zt_desync_live() { zt_transport_active || zt_any_slot_enabled || zt_any_src_wired; }








cmd_wired() { zt_desync_live || [ -f "$ON_FLAG" ] || proc_alive "$NFQ_PID"; }






zt_transport_wired() {
    _tw=$(iptables -t mangle -S POSTROUTING 2>/dev/null | grep -e "--queue-num $QNUM")
    for _tws in $ZAPRET_SETS; do
        case "$_tw" in *"--match-set $_tws dst"*) return 0 ;; esac
    done
    return 1
}





GEO_SH="$ENODIA_DIR/geo.sh"
CATS_MIG="$ENODIA_STATE/.zapret-cats.migrated"   # след разового переноса (файл-маркер, он же архив выбора)


geo_set_desync() {
    for _gk in "$@"; do
        sh "$GEO_SH" set "$_gk" desync >/dev/null 2>&1 && { echo "$_gk"; return 0; }
    done
    return 1
}


migrate_cats() {
    [ -f "$CATS_FILE" ] || return 0
    [ -f "$GEO_SH" ] || return 0
    _mv=""
    for _c in $(tr ',\r\n' '   ' < "$CATS_FILE"); do
        _k=""
        case "$_c" in
            youtube) _k=$(geo_set_desync v2fly-youtube) ;;
            google)  _k=$(geo_set_desync v2fly-google) ;;
            discord) _k=$(geo_set_desync v2fly-discord) ;;

            meta)    _k=$(geo_set_desync v2fly-meta v2fly-facebook)
                     _i=$(geo_set_desync v2fly-instagram) && _mv="$_mv $_i" ;;
        esac
        [ -n "$_k" ] && _mv="$_mv $_k"
    done
    mv "$CATS_FILE" "$CATS_MIG" 2>/dev/null
    if [ -n "$_mv" ]; then
        log "категории перенесены в гео (действие «в десинк»):$_mv"


        start-stop-daemon -S -b -m -p /tmp/enodia-zapret-migrate.pid -x /bin/sh -- "$GEO_SH" apply >/dev/null 2>&1 || true
    else
        log "перенос категорий: совпадений в каталоге гео не нашлось (выбор сохранён в $CATS_MIG)"
    fi
}



strip_sani() {
    printf '%s' "$1" | tr '\r\n' '  ' \
        | sed 's#[^A-Za-z0-9 +,.:/=_@-]##g; s#[[:space:]]\{1,\}# #g; s#^ ##; s# $##'
}

desync_args() {
    if [ -s "$ARGS_FILE" ]; then
        a=$(grep -vE '^[[:space:]]*#' "$ARGS_FILE" 2>/dev/null | tr '\n' ' ')
        a=$(strip_sani "$a")
        [ -n "$a" ] && { echo "$a"; return; }
    fi
    echo "$DEFAULT_ARGS"
}

resolve_args() { printf '%s' "$1" | sed "s#@tls#$TLS_BIN#g; s#@quic#$QUIC_BIN#g"; }


ensure_fakes() {
    [ -s "$TLS_BIN" ]  || printf '%s' "$TLS_B64"  | base64 -d > "$TLS_BIN"  2>/dev/null
    [ -s "$QUIC_BIN" ] || printf '%s' "$QUIC_B64" | base64 -d > "$QUIC_BIN" 2>/dev/null
}




ensure_set() {
    ipset list -n 2>/dev/null | grep -qx "$SET" || \
        ipset create "$SET" hash:net family inet hashsize 1024 maxelem 1000000
    ipset list -n 2>/dev/null | grep -qx "$SET_CIDR" || \
        ipset create "$SET_CIDR" hash:net family inet hashsize 4096 maxelem 1000000


    ipset list -n 2>/dev/null | grep -qx "$SET_DOM" || \
        ipset create "$SET_DOM" hash:net family inet hashsize 1024 maxelem 1000000



    ipset list -n 2>/dev/null | grep -qx "$SET_GEO" || \
        ipset create "$SET_GEO" hash:net family inet hashsize 4096 maxelem 1000000
}



pool_summary() {
    _ps=""
    for _zs in $ZAPRET_SETS; do
        _pn=$(ipset list "$_zs" 2>/dev/null | grep -c '^[0-9]'); case "$_pn" in ''|*[!0-9]*) _pn=0 ;; esac
        _ps="$_ps $_zs=$_pn"
    done
    printf '%s' "${_ps# }"
}










del_dnsmasq() {
    [ -f "$DNSMASQ_SNIPPET" ] || [ -f "$DNSMASQ_LIVE" ] || return 0
    rm -f "$DNSMASQ_SNIPPET" "$DNSMASQ_LIVE"



    sh "$ENODIA_DIR/dns-merge.sh" reload 2>/dev/null \
        || /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}







dns_direct_rules() {   # $1 = add|del
    for d in "$DNS1" "$DNS2"; do
        for ch in OUTPUT PREROUTING; do
            if [ "$1" = del ]; then
                while iptables -t mangle -C "$ch" -d "$d" -j RETURN 2>/dev/null; do
                    iptables -t mangle -D "$ch" -d "$d" -j RETURN 2>/dev/null || break
                done
            else
                iptables -t mangle -C "$ch" -d "$d" -j RETURN 2>/dev/null || \
                    iptables -t mangle -I "$ch" 1 -d "$d" -j RETURN
            fi
        done
    done
}
set_dnsmasq_direct() {
    dns_upstream_put "$DNS1" "$DNS2"
}
set_direct_dns() {
    doh_apply_dns direct && return 0    # DoH ВКЛ/авто → резолв через локальный прокси (резолвер :443 мимо марки); иначе → ниже
    dns_direct_rules add
    set_dnsmasq_direct
}





nfq_antiloop() {   # add|del
    if [ "$1" = del ]; then
        while iptables -t mangle -D OUTPUT -m mark --mark "$MARKM" -j RETURN 2>/dev/null; do :; done
    else
        iptables -t mangle -C OUTPUT -m mark --mark "$MARKM" -j RETURN 2>/dev/null || \
            iptables -t mangle -I OUTPUT 1 -m mark --mark "$MARKM" -j RETURN
    fi
}








ZCHAIN=ENODIA_ZAPRET
APPLY_SH="$ENODIA_DIR/apply-bypass.sh"
zt_chain_ensure() {
    iptables -t mangle -L "$ZCHAIN" -n >/dev/null 2>&1 || iptables -t mangle -N "$ZCHAIN"




    if ! iptables -t mangle -C PREROUTING -j "$ZCHAIN" 2>/dev/null; then
        iptables -t mangle -I PREROUTING 1 -j "$ZCHAIN"
        [ -f "$APPLY_SH" ] && sh "$APPLY_SH" order >/dev/null 2>&1
    fi
    return 0
}


zt_chain_gc() {
    iptables -t mangle -L "$ZCHAIN" -n >/dev/null 2>&1 || return 0
    _zc=$(iptables -t mangle -S "$ZCHAIN" 2>/dev/null | grep -c '^-A')
    case "$_zc" in ''|*[!0-9]*) _zc=0 ;; esac   # busybox: grep -c при нуле даёт код 1
    [ "$_zc" -gt 0 ] && return 0
    iptables -t mangle -D PREROUTING -j "$ZCHAIN" 2>/dev/null
    iptables -t mangle -X "$ZCHAIN" 2>/dev/null
    return 0
}










NFQ_CAP=/tmp/.enodia-zapret-nfq-cap
nfq_supported() {
    [ -f "$NFQ_CAP" ] && { [ "$(cat "$NFQ_CAP" 2>/dev/null)" = 1 ]; return $?; }


    iptables -t mangle -N ENODIA_NFQ_PROBE 2>/dev/null
    iptables -t mangle -A ENODIA_NFQ_PROBE -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null
    _nfqrc=$?
    iptables -t mangle -F ENODIA_NFQ_PROBE 2>/dev/null
    iptables -t mangle -X ENODIA_NFQ_PROBE 2>/dev/null






    case "$_nfqrc" in
        0) echo 1 > "$NFQ_CAP" 2>/dev/null; return 0 ;;
        2) echo 0 > "$NFQ_CAP" 2>/dev/null; return 1 ;;
        *) log "nfq-проба: iptables дал код $_nfqrc (лок занят/сбой вызова) — НЕ сужу, ответ не кэширую"
           return 0 ;;
    esac
}




nfq_set_rules() {   # <set> <add|del>
    _ns="$1"



    while iptables -t mangle -D PREROUTING -m set --match-set "$_ns" dst -j ACCEPT 2>/dev/null; do :; done
    if [ "$2" = del ]; then
        while iptables -t mangle -D "$ZCHAIN" -m set --match-set "$_ns" dst -j ACCEPT 2>/dev/null; do :; done
        for proto in tcp udp; do
            while iptables -t mangle -D POSTROUTING -p $proto --dport 443 -m set --match-set "$_ns" dst $CB -m mark ! --mark "$MARKM" -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null; do :; done
        done
        zt_chain_gc
    else
        zt_chain_ensure
        iptables -t mangle -C "$ZCHAIN" -m set --match-set "$_ns" dst -j ACCEPT 2>/dev/null || \
            iptables -t mangle -A "$ZCHAIN" -m set --match-set "$_ns" dst -j ACCEPT
        for proto in tcp udp; do
            iptables -t mangle -C POSTROUTING -p $proto --dport 443 -m set --match-set "$_ns" dst $CB -m mark ! --mark "$MARKM" -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null || \
                iptables -t mangle -I POSTROUTING 1 -p $proto --dport 443 -m set --match-set "$_ns" dst $CB -m mark ! --mark "$MARKM" -j NFQUEUE --queue-num "$QNUM" --queue-bypass
        done
    fi
}
















nfq_src_rules() {   # <ip> <add|del>
    _si="$1"
    if [ "$2" = del ]; then
        for proto in tcp udp; do
            while iptables -t mangle -D POSTROUTING -s "$_si" -p $proto --dport 443 $CB -m mark ! --mark "$MARKM" -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null; do :; done
        done
    else
        for proto in tcp udp; do
            iptables -t mangle -C POSTROUTING -s "$_si" -p $proto --dport 443 $CB -m mark ! --mark "$MARKM" -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null || \
                iptables -t mangle -I POSTROUTING 1 -s "$_si" -p $proto --dport 443 $CB -m mark ! --mark "$MARKM" -j NFQUEUE --queue-num "$QNUM" --queue-bypass
        done
    fi
}




rules_add() { for _zs in $ZAPRET_SETS; do nfq_set_rules "$_zs" add; done; nfq_antiloop add; }
rules_del() { for _zs in $ZAPRET_SETS; do nfq_set_rules "$_zs" del; done; }







spawn_nfqws() {
    : > "$NFQ_LOG" 2>/dev/null || true
    args=$(resolve_args "$(desync_args)")
    start-stop-daemon -S -b -m -p "$NFQ_PID" -x /bin/sh -- -c "exec '$NFQWS' --qnum=$QNUM $args >>'$NFQ_LOG' 2>&1"
}
stop_nfqws() {
    start-stop-daemon -K -p "$NFQ_PID" 2>/dev/null
    kill "$(cat "$NFQ_PID" 2>/dev/null)" 2>/dev/null
    rm -f "$NFQ_PID" 2>/dev/null
}



restart_nfqws() {
    stop_nfqws
    i=0; while [ $i -lt 3 ]; do ps w 2>/dev/null | grep -q 'nfqw[s]' || break; sleep 1; i=$((i+1)); done
    spawn_nfqws
    sleep 1
    proc_alive "$NFQ_PID" && return 0



    rm -f "$NFQ_PID" 2>/dev/null
    return 1
}





teardown() {
    rules_del
    del_dnsmasq




    ipset flush "$SET" 2>/dev/null || true



    if zt_any_slot_enabled || zt_any_src_wired; then
        ct_flush
        return 0
    fi
    nfq_antiloop del
    stop_nfqws
    ct_flush
}

cmd_apply() {
    if [ ! -f "$ON_FLAG" ]; then
        teardown
        return 0
    fi
    [ -x "$NFQWS" ] || { log "НЕТ бинаря $NFQWS — поставьте Zapret в «Роутер → Компоненты»"; return 1; }
    ensure_fakes
    ensure_set
    del_dnsmasq          # снять легаси-сниппет вшитых категорий (см. комментарий у функции)
    migrate_cats         # разовый перенос старого выбора в гео-реестр
    rules_add
    proc_alive "$NFQ_PID" || spawn_nfqws
    ct_flush
    log "десинк ВКЛ (пулы: $(pool_summary); стратегия: $(desync_args))"
}





cmd_rewire() {
    ensure_set
    [ -f "$ON_FLAG" ] || return 0
    rules_add
    ct_flush
}




cmd_off() { rm -f "$ON_FLAG"; teardown; log "десинк ВЫКЛ (правила сняты, nfqws остановлен, набор сброшен)"; }














cmd_t_up() {
    [ -x "$NFQWS" ] || { log "up: НЕТ бинаря $NFQWS — поставьте Zapret в «Роутер → Компоненты»"; return 1; }



    nfq_supported || {
        log "up: сборка iptables на этом роутере не умеет NFQUEUE (нет libxt_NFQUEUE) — десинк здесь невозможен"
        log "up: остаюсь без изменений; используйте VPN-транспорт (AmneziaWG/Xray/Hysteria2) или ByeDPI"
        return 1
    }
    touch "$ON_FLAG"
    cmd_apply || return 1
    set_direct_dns
    echo zapret > "$TRANSPORT_FLAG"
    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    carrier_up_mark         # грейс сторожу: демоны стартовали, но egress поднимается ещё секунды (clock-lib.sh)
    ct_flush
    log "транспорт = ZAPRET (десинк направо, БЕЗ VPS; весь трафик напрямую, категории через nfqws)"
}
cmd_t_down() {
    cmd_off                 # rm ON_FLAG + teardown (правила/nfqws/dnsmasq-сниппет/ipset)
    dns_direct_rules del    # снять наши DNS-RETURN (следующий транспорт поставит свой DNS)
    set_dnsmasq_direct      # dnsmasq на прямой резолвер — fail-open до подъёма следующего транспорта
    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    log "Zapret-несущая снята (релинквиш) → прямой режим. Следующий транспорт ставит оркестратор."
}
cmd_t_health() { [ -x "$NFQWS" ] && proc_alive "$NFQ_PID"; }
cmd_t_failover() {
    t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')
    [ "$t" = zapret ] || { log "failover: zapret не активен → эскалация на оркестраторе"; return 1; }
    if sweep_fresh; then log "failover: идёт браузер-свип — не вмешиваюсь"; return 0; fi
    log "failover: переподнимаю nfqws на месте (резервов-серверов нет — десинк локальный)…"
    touch "$ON_FLAG"; cmd_apply >/dev/null 2>&1
    proc_alive "$NFQ_PID" && { log "failover: nfqws снова жив — остаёмся на zapret"; return 0; }
    log "failover: nfqws переподнять не удалось → эскалация на оркестраторе (прямой режим)"; return 1
}








zt_slot_sets() { echo "grp_vpn_s$1 geo_vpn_s$1"; }











zt_ensure_slot_set() {
    ipset list -n 2>/dev/null | grep -qx "$1" && return 0
    case "$1" in
        geo_vpn_s*) ipset create "$1" hash:net hashsize 4096 maxelem 1000000 2>/dev/null ;;
        *)          ipset create "$1" hash:net hashsize 1024 maxelem 65536   2>/dev/null ;;
    esac
}
cmd_slot_up() {   # <id> <config-игнор> — поднять zapret-десинк для сетов слота
    _id="$1"
    case "$_id" in 2|3|4) ;; *) log "slot-up: битый id '$_id'"; return 1 ;; esac
    [ -x "$NFQWS" ] || { log "slot-up: НЕТ бинаря $NFQWS — установите (панель «Zapret»)"; return 1; }




    nfq_supported || {
        log "slot-up: сборка iptables на этом роутере не умеет NFQUEUE (нет libxt_NFQUEUE) — выход-десинк здесь невозможен"
        log "slot-up: ничего не меняю; обход без VPS на этом железе даёт ByeDPI"
        return 1
    }
    ensure_fakes





    for _s in $(zt_slot_sets "$_id"); do
        zt_ensure_slot_set "$_s"



        if ! ipset list -n 2>/dev/null | grep -qx "$_s"; then
            log "слот №$_id: набор $_s не создан — правило не ставлю (десинк этого набора не заработает)"
            continue
        fi
        nfq_set_rules "$_s" add
    done
    nfq_antiloop add
    proc_alive "$NFQ_PID" || spawn_nfqws
    ct_flush
    log "слот №$_id: zapret-десинк рядом с VPN (сеты grp_vpn_s$_id/geo_vpn_s$_id; стратегия: $(desync_args))"
    log "слот №$_id: правила стоят заранее — пока наборы пусты, десинк ничего не заворачивает и включится сам при первой привязке группы или гео-категории"
    return 0
}
cmd_slot_down() {   # <id> — снять zapret-десинк слота
    _id="$1"
    case "$_id" in 2|3|4) ;; *) return 1 ;; esac
    for _s in $(zt_slot_sets "$_id"); do nfq_set_rules "$_s" del; done


    if ! zt_transport_active && ! zt_any_slot_enabled "$_id" && ! zt_any_src_wired; then
        nfq_antiloop del
        stop_nfqws
    fi
    ct_flush
    log "слот №$_id: zapret-десинк снят"
    return 0
}









cmd_src_wire() {   # <ip>
    _sip=$(printf '%s' "$1" | tr -d ' \r\n')
    echo "$_sip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { log "src-wire: нужен IPv4"; return 1; }
    [ -x "$NFQWS" ] || { log "src-wire: НЕТ бинаря $NFQWS — поставьте Zapret в «Роутер → Компоненты»"; return 1; }

    nfq_supported || {
        log "src-wire: сборка iptables на этом роутере не умеет NFQUEUE (нет libxt_NFQUEUE) — десинк по источнику невозможен"
        log "src-wire: ничего не меняю; обход без VPS на этом железе даёт ByeDPI"
        return 1
    }
    ensure_fakes
    nfq_src_rules "$_sip" add
    nfq_antiloop add
    proc_alive "$NFQ_PID" || spawn_nfqws


    ct_flush_src "$_sip"
    log "устройство $_sip: десинк по источнику ВКЛ (стратегия: $(desync_args))"
    return 0
}
cmd_src_unwire() {   # <ip>
    _sip=$(printf '%s' "$1" | tr -d ' \r\n')
    echo "$_sip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || return 1
    nfq_src_rules "$_sip" del
    if ! zt_transport_active && ! zt_any_slot_enabled && ! zt_any_src_wired; then
        nfq_antiloop del
        stop_nfqws
    fi
    ct_flush_src "$_sip"
    log "устройство $_sip: десинк по источнику снят"
    return 0
}



cmd_src_list() {
    iptables -t mangle -S POSTROUTING 2>/dev/null \
        | grep -e "--queue-num $QNUM" \
        | sed -n 's/^-A POSTROUTING -s \([0-9.]*\)\/32 .*/\1/p' | sort -u
}



cmd_src_clear() {
    for _sip in $(cmd_src_list); do nfq_src_rules "$_sip" del; done
    return 0
}










iset_state() { echo "$1" > "$INSTALL_STATE.new" && mv -f "$INSTALL_STATE.new" "$INSTALL_STATE"; }
ilog() { printf '[%s] %s\n' "$(date '+%H:%M:%S')" "$*" >> "$INSTALL_LOG"; }

cmd_install() {   # $1 = update — заменить стоящий nfqws свежей сборкой (решает движок компонентов по bin-status)
    : > "$INSTALL_LOG"; iset_state RUNNING
    _zwas=0; [ -x "$NFQWS" ] && _zwas=1
    if [ "$_zwas" = 1 ] && [ "$1" != update ]; then


        ensure_fakes
        iset_state OK; ilog "nfqws уже установлен — качать ничего не нужно"; return 0
    fi



    [ -f "$GH" ] || { iset_state FAIL; ilog "нет gh-update.sh — обновите скрипты"; echo "[zapret] FAIL: нет gh-update.sh — обновите скрипты"; return 1; }
    ilog "Скачиваю nfqws с GitHub (~0.13 МБ)…"






    _dst=$(bin_dest nfqws)
    mkdir -p "${_dst%/*}" 2>/dev/null
    if sh "$GH" fetch-bin nfqws "$_dst" >> "$INSTALL_LOG" 2>&1; then
        chmod +x "$_dst" 2>/dev/null
        bin_prune nfqws
        NFQWS=$(bin_path nfqws)
        ensure_fakes


        if [ "$_zwas" = 1 ]; then iset_state OK; ilog "nfqws обновлён. Включённый десинк работает на прежней сборке до перезапуска (проще всего — перезагрузить роутер)"; return 0; fi
        [ -f "$ON_FLAG" ] && cmd_apply >> "$INSTALL_LOG" 2>&1
        iset_state OK; ilog "nfqws установлен. Десинк: $([ -f "$ON_FLAG" ] && echo ВКЛ || echo выключен)"
        return 0
    fi



    _zw=$(grep '^\[fetch-bin\] FAIL: ' "$INSTALL_LOG" 2>/dev/null | tail -n 1 | sed 's/^\[fetch-bin\] FAIL: //')
    [ -n "$_zw" ] || _zw="не скачался nfqws — нет связи с GitHub (или кончилось место)"
    iset_state FAIL; ilog "$_zw"; echo "[zapret] FAIL: $_zw"
    return 1
}

cmd_remove() {
    : > "$INSTALL_LOG"; iset_state RUNNING
    ilog "Удаляю zapret: снимаю правила/nfqws/dnsmasq, выключаю десинк…"




    cmd_src_clear >> "$INSTALL_LOG" 2>&1
    cmd_off >> "$INSTALL_LOG" 2>&1   # teardown + сброс .zapret-on (десинк больше не поднимется)



    rm -f "$ENODIA_BIN/nfqws" 2>/dev/null
    [ "$BIN_DIR" != "$ENODIA_BIN" ] && rm -f "$BIN_DIR/nfqws" 2>/dev/null
    iset_state OK; ilog "nfqws удалён, десинк выключен (интернет/туннель не затронуты)."
    return 0
}



cmd_reload() {
    zt_desync_live || { log "reload: десинк выключен — стратегия применится при включении"; return 0; }
    if restart_nfqws; then
        ct_flush
        log "nfqws перезапущен (стратегия: $(desync_args))"
        return 0
    fi

    log "reload: nfqws не перезапустился — десинк сейчас ВЫКЛЮЧЕН. Стратегия: $(desync_args)"
    log "reload: вывод nfqws:"; tail -n 15 "$NFQ_LOG" 2>/dev/null | grep . || log "  (пусто — бинарь не запустился вовсе?)"
    return 1
}



cmd_categories() { [ -f "$GEO_SH" ] && sh "$GEO_SH" desync-list 2>/dev/null; return 0; }

cmd_status() {
    on=ВЫКЛ; [ -f "$ON_FLAG" ] && on=ВКЛ
    echo "=== zapret (десинк-direct): $on ==="
    echo "--- в десинк по гео ---"; cmd_categories | sed 's/^/  /' | grep . || echo "  (не выбрано)"
    echo "--- стратегия ---"; desync_args
    echo "--- бинарь ---"; [ -x "$NFQWS" ] && echo "$NFQWS есть" || echo "НЕТ $NFQWS"





    echo "--- NFQUEUE в ядре ---"
    if nfq_supported; then echo "умеет"
    else echo "НЕ умеет (iptables без libxt_NFQUEUE) — десинк на этом роутере невозможен, обход без VPS даёт ByeDPI"; fi
    echo "--- nfqws ---"; proc_alive "$NFQ_PID" && echo "pid $(cat $NFQ_PID) жив" || echo "не запущен"
    for _zs in $ZAPRET_SETS; do
        zn=$(ipset list "$_zs" 2>/dev/null | grep -c '^[0-9]'); echo "--- ipset $_zs (IP): ${zn:-0} ---"
    done
    echo "--- устройства целиком в десинк (по источнику) ---"
    iptables -t mangle -S POSTROUTING 2>/dev/null | sed -n 's/^-A POSTROUTING -s \([0-9.]*\)\/32 .*--queue-num '"$QNUM"'.*/  \1/p' | sort -u | grep . \
        || echo "  (нет)"
    echo "--- правила mangle ---"


    iptables -t mangle -S "$ZCHAIN" 2>/dev/null | grep '^-A' || echo "  $ZCHAIN: нет"
    iptables -t mangle -S PREROUTING 2>/dev/null | grep -e "$ZCHAIN" -e "zapret_" || echo "  PREROUTING: нет"
    iptables -t mangle -S POSTROUTING 2>/dev/null | grep NFQUEUE || echo "  POSTROUTING NFQUEUE: нет"
    iptables -t mangle -S OUTPUT 2>/dev/null | grep "$MARK" || echo "  OUTPUT RETURN (анти-петля): нет"
    echo "--- offload (info; глушить НЕ нужно) ---"
    echo "  ecm stop ipv4/ipv6 = $(cat /sys/kernel/debug/ecm/front_end_ipv4_stop 2>/dev/null)/$(cat /sys/kernel/debug/ecm/front_end_ipv6_stop 2>/dev/null)"
}









cmd_presets() {
    cat <<'PRESETS'
Авто — multidisorder + QUIC (по умолчанию)|
Только QUIC fake (YouTube QUIC)|--filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Multisplit seqovl=568 (general)|--filter-tcp=443 --dpi-desync=multisplit --dpi-desync-split-pos=1 --dpi-desync-split-seqovl=568 --dpi-desync-split-seqovl-pattern=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Multisplit seqovl=652 pos=2 (ALT2)|--filter-tcp=443 --dpi-desync=multisplit --dpi-desync-split-pos=2 --dpi-desync-split-seqovl=652 --dpi-desync-split-seqovl-pattern=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Fake+fakedsplit fooling=ts (ALT)|--filter-tcp=443 --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Fake fooling=ts (SIMPLE FAKE, лёгкий)|--filter-tcp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Fake TLS AUTO — multidisorder+SNI (FAKE TLS AUTO)|--filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld --dpi-desync-repeats=11 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Fake badseq-increment (ALT8)|--filter-tcp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --dpi-desync-fake-tls=@tls --dpi-desync-fake-tls-mod=none --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Hostfakesplit (ALT9)|--filter-tcp=443 --dpi-desync=hostfakesplit --dpi-desync-repeats=4 --dpi-desync-fooling=ts,md5sig --dpi-desync-hostfakesplit-mod=host=ozon.ru --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Fake+hostfakesplit SNI (ALT3)|--filter-tcp=443 --dpi-desync=fake,hostfakesplit --dpi-desync-fake-tls=@tls --dpi-desync-fake-tls-mod=rnd,dupsid,sni=ya.ru --dpi-desync-hostfakesplit-mod=host=ya.ru,altorder=1 --dpi-desync-fooling=ts --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Multidisorder repeats=6 (Meta/Facebook)|--filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,sniext --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Multidisorder repeats=11 (агрессивный)|--filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,sniext --dpi-desync-repeats=11 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Fakedsplit (только TCP, лёгкий)|--filter-tcp=443 --dpi-desync=fakedsplit --dpi-desync-split-pos=1 --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls
Fake repeats=2 (минимальный TCP)|--filter-tcp=443 --dpi-desync=fake --dpi-desync-repeats=2 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls
Multisplit seqovl=336 pos=1 (лёгкий seqovl)|--filter-tcp=443 --dpi-desync=multisplit --dpi-desync-split-pos=1 --dpi-desync-split-seqovl=336 --dpi-desync-split-seqovl-pattern=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Multidisorder midsld repeats=8|--filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld --dpi-desync-repeats=8 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Fake+fakedsplit fooling=badseq repeats=8|--filter-tcp=443 --dpi-desync=fake,fakedsplit --dpi-desync-split-pos=1 --dpi-desync-repeats=8 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Multisplit seqovl=652 pos=2,sniext|--filter-tcp=443 --dpi-desync=multisplit --dpi-desync-split-pos=2,sniext --dpi-desync-split-seqovl=652 --dpi-desync-split-seqovl-pattern=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Multidisorder sniext repeats=4 fooling=ts|--filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,sniext --dpi-desync-repeats=4 --dpi-desync-fooling=ts --dpi-desync-fake-tls=@tls --new --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
Только QUIC fake repeats=6 (лёгкий)|--filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-fake-quic=@quic
PRESETS
}








sweep_fresh() {
    [ -f "$SWEEP_LOCK" ] || return 1
    ts=$(cat "$SWEEP_LOCK" 2>/dev/null | tr -d ' \r\n'); case "$ts" in ''|*[!0-9]*) return 1 ;; esac
    [ "$(age_since "$ts")" -lt "$SWEEP_TTL" ]
}
sweep_touch() { date +%s > "$SWEEP_LOCK"; }
sweep_restore() {
    if [ -f "$SWEEP_BAK" ]; then
        if [ -s "$SWEEP_BAK" ]; then mv "$SWEEP_BAK" "$ARGS_FILE" 2>/dev/null
        else rm -f "$ARGS_FILE" 2>/dev/null; fi
    fi
    rm -f "$SWEEP_LOCK" "$SWEEP_BAK" 2>/dev/null
}
cmd_sweep_begin() {
    zt_desync_live || { log "sweep-begin: десинк выключен — свип возможен только при включённом zapret (транспорт или доп-выход)"; return 1; }
    if [ ! -f "$SWEEP_BAK" ]; then
        if [ -f "$ARGS_FILE" ]; then cp "$ARGS_FILE" "$SWEEP_BAK" 2>/dev/null; else : > "$SWEEP_BAK"; fi
    fi
    sweep_touch
    log "sweep-begin: браузер-свип начат (исходная стратегия сохранена)"
    return 0
}

cmd_sweep_apply() {
    zt_desync_live || { log "sweep-apply: десинк выключен"; return 1; }
    [ -f "$SWEEP_BAK" ] || { log "sweep-apply: свип не начат — отказ"; return 1; }
    sweep_touch
    a=$(strip_sani "$1")
    if [ -n "$a" ]; then printf '%s\n' "$a" > "$ARGS_FILE.new" && mv "$ARGS_FILE.new" "$ARGS_FILE"; else rm -f "$ARGS_FILE"; fi
    if restart_nfqws; then
        ct_flush
        sweep_touch
        log "sweep-apply: применена стратегия ($(desync_args))"
        return 0
    fi
    sweep_touch
    log "sweep-apply: nfqws не поднялся на этой стратегии"
    return 1
}
cmd_sweep_end() {
    sweep_restore
    zt_desync_live && { restart_nfqws >/dev/null 2>&1; ct_flush; }
    log "sweep-end: исходная стратегия восстановлена, свип завершён"
    return 0
}








cmd_import() {
    _raw=$(cat 2>/dev/null)
    [ -n "$_raw" ] || { echo "[import] пусто — вставьте текст конфига" >&2; return 1; }


    _flat=$(printf '%s' "$_raw" | tr -d '\r"' | sed 's/\^$//' | tr '\n' ' ' | sed 's/[[:space:]]\{1,\}/ /g')
    _out=""; _dropw=""; _dropl=""; _dropf=""; _dropb=""; _warn=""; _unk=""



    set -f
    for _w in $_flat; do
        case "$_w" in

            --wf-tcp=*|--wf-udp=*|--wf-raw=*|--wf-l3=*|--ssid-filter=*|--nlm-filter=*) _dropw="$_dropw $_w"; continue ;;

            --hostlist=*|--hostlist-exclude=*|--hostlist-auto=*|--hostlist-auto-fail-threshold=*|--hostlist-auto-fail-time=*|--ipset=*|--ipset-exclude=*) _dropl="$_dropl $_w"; continue ;;

            --dpi-desync-fake-tls=*)  _out="$_out --dpi-desync-fake-tls=@tls";  continue ;;
            --dpi-desync-fake-quic=*) _out="$_out --dpi-desync-fake-quic=@quic"; continue ;;
            --dpi-desync-fake-*=*) _dropf="$_dropf $_w"; continue ;;

            --daemon|--pidfile=*|--user=*|--uid=*|--qnum=*|--queue-num=*) continue ;;
            "") continue ;;
        esac





        case "$_w" in --*) ;; *) _dropb="$_dropb $_w"; continue ;; esac




        case "$_w" in


            --filter-tcp=443|--filter-udp=443) ;;
            --filter-tcp=*|--filter-udp=*) _warn="$_warn $_w" ;;
        esac


        case "$_w" in
            *[!A-Za-z0-9+,.:/=_@-]*) _unk="$_unk $_w"; continue ;;
        esac
        _out="$_out $_w"
    done
    set +f
    _out=$(printf '%s' "$_out" | sed 's/^ //; s/ $//')

    [ -n "$_dropw" ] && echo "[import] выброшено (только для winws, nfqws не примет):$_dropw" >&2
    [ -n "$_dropl" ] && echo "[import] выброшено (списки у нас в ядре, файловых нет):$_dropl" >&2
    [ -n "$_dropf" ] && echo "[import] выброшено (свой файл фейка; у нас только @tls и @quic):$_dropf" >&2
    [ -n "$_unk"  ] && echo "[import] выброшено (символы, которых не принимает поле стратегии):$_unk" >&2
    [ -n "$_dropb" ] && echo "[import] выброшена обёртка запуска (не флаги nfqws):$_dropb" >&2
    [ -n "$_warn" ] && echo "[import] ВНИМАНИЕ: эти секции здесь не заработают — перехват идёт только по порту 443:$_warn" >&2
    if [ -z "$_out" ]; then
        echo "[import] после чистки не осталось ни одного флага nfqws — похоже, это не конфиг zapret" >&2
        return 1
    fi
    echo "[import] готово. Проверьте строку и нажмите «Сохранить» — сама по себе она не применяется" >&2




    printf 'ARGS:%s\n' "$_out"
    return 0
}

case "$1" in






    nfq-ok)    nfq_supported ;;



    up)        carrier_run cmd_t_down cmd_t_up ;;
    down)      cmd_t_down ;;
    cold)      : ;;                       # тёплого резерва нет: несущей у десинка нет вовсе (nfqws правит пакеты на форварде)
    health)    cmd_t_health ;;
    failover)  carrier_run cmd_t_down cmd_t_failover ;;

    slot-up)   carrier_run cmd_slot_down cmd_slot_up "$2" "$3" ;;
    slot-down) cmd_slot_down "$2" ;;

    src-wire)   cmd_src_wire "$2" ;;
    src-unwire) cmd_src_unwire "$2" ;;
    src-clear)  cmd_src_clear ;;
    src-list)   cmd_src_list ;;   # что РЕАЛЬНО проводнено в mangle (машинно, по строке на IP)
    dns)       set_direct_dns ;;   # переиграть DNS (DoH toggle/смена резолвера) — прямой режим через doh_apply_dns
    install)   cmd_install "$2" ;;
    remove)    cmd_remove ;;
    apply)     cmd_apply ;;
    rewire)    cmd_rewire ;;   # досборка правил под пулы источников (зовут lists-update.sh zapret-*)
    status)    cmd_status ;;
    wired)     cmd_wired ;;   # машинно: есть ли ЖИВОЙ десинк (0 да · 1 нет · 2 = старая копия не знает верба)
    t-wired)   zt_transport_wired ;;   # машинно: проводка ГЛАВНОГО транспорта (не выхода, не устройства)
    reload)    cmd_reload ;;
    import)    cmd_import ;;   # STDIN = десктопный конфиг → stdout: флаги nfqws, stderr: отчёт
    presets)   cmd_presets ;;
    defaults)  echo "$DEFAULT_ARGS" ;;
    categories) cmd_categories ;;
    sweep-begin) cmd_sweep_begin ;;
    sweep-apply) cmd_sweep_apply "$2" ;;
    sweep-end)   cmd_sweep_end ;;
    *) echo "usage: $0 up|down|cold|health|failover|nfq-ok|slot-up <id>|slot-down <id>|src-wire <ip>|src-unwire <ip>|src-clear|install [update]|remove|apply|rewire|status|wired|t-wired|reload|import|presets|defaults|categories|sweep-begin|sweep-apply <args>|sweep-end"; exit 2 ;;
esac
