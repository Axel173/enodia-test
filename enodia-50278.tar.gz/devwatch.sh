#!/bin/sh
























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi
if ! command -v ct_list_src >/dev/null 2>&1; then
    ct_list_src()   { [ -n "$1" ] && conntrack -L -s "$1" 2>/dev/null; return 0; }
fi
if ! command -v ct_list_all >/dev/null 2>&1; then
    ct_list_all()   { conntrack -L 2>/dev/null || cat /proc/net/nf_conntrack 2>/dev/null; return 0; }
fi



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi



if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi



if [ -f "$ENODIA_DIR/port-lib.sh" ]; then . "$ENODIA_DIR/port-lib.sh"; fi
if ! command -v age_since >/dev/null 2>&1; then

    age_since() { echo $(( $(date +%s) - $1 )); }
fi
SELF="$ENODIA_DIR/devwatch.sh"
QLOG="/tmp/enodia-dnsq.log"                 # лог dnsmasq (ОЗУ)
QCONF="/tmp/dnsmasq.d/07-querylog.conf"  # сниппет query-log в ЖИВОМ conf-dir
UNTIL="/tmp/enodia-devwatch.until"          # epoch, до которого наблюдаем (переживает окно, не ребут)
DEF_SECS=120; MIN_SECS=10; MAX_SECS=300








DEADLOG="/tmp/enodia-devwatch-dead.tsv"     # src dst dport proto tx first_seen last_seen (через пробел)
SPID="/tmp/enodia-devwatch-sampler.pid"     # ЧЕЙ сейчас сэмплер: перезапуск окна перебивает файл,


SAMPLE_EVERY=5                           # шаг опроса, с — вдвое меньше самого короткого таймаута
DEAD_MAX=200                             # потолок журнала: сканер портов не должен съесть ОЗУ
DEAD_SHOW=40                             # сколько отдаём панели (свежие сверху)



dns_restart() { /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null; }

now() { date +%s; }

watching() {  # код 0 = сейчас наблюдаем (until в будущем И конфиг на месте)
	[ -f "$QCONF" ] || return 1
	u=$(cat "$UNTIL" 2>/dev/null); case "$u" in ''|*[!0-9]*) return 1 ;; esac
	[ "$(now)" -lt "$u" ]
}

secs_left() {
	u=$(cat "$UNTIL" 2>/dev/null); case "$u" in ''|*[!0-9]*) echo 0; return ;; esac
	l=$((u - $(now))); [ "$l" -gt 0 ] && echo "$l" || echo 0
}

start() {
	s="$1"; case "$s" in ''|*[!0-9]*) s="$DEF_SECS" ;; esac
	[ "$s" -lt "$MIN_SECS" ] && s="$MIN_SECS"; [ "$s" -gt "$MAX_SECS" ] && s="$MAX_SECS"
	mkdir -p /tmp/dnsmasq.d 2>/dev/null




	: > "$SPID" 2>/dev/null                 # пустой владелец ≠ pid любого живого сэмплера
	: > "$QLOG" 2>/dev/null                 # чистим лог прошлого окна (свежий срез)
	: > "$DEADLOG" 2>/dev/null              # …и журнал «не ответили»: окно новое — срез новый
	printf 'log-queries\nlog-facility=%s\n' "$QLOG" > "$QCONF"
	echo $(( $(now) + s )) > "$UNTIL"
	dns_restart



	rm -f /tmp/enodia-devwatch-stop.*.pid 2>/dev/null
	start-stop-daemon -S -b -m -p "/tmp/enodia-devwatch-stop.$$.pid" -x /bin/sh -- "$SELF" _autostop "$s" 2>/dev/null
	printf '{"ok":true,"watching":true,"secs_left":%d}\n' "$s"
}

stop() {
	rm -f "$QCONF" "$UNTIL" 2>/dev/null
	dns_restart
	printf '{"ok":true,"watching":false,"secs_left":0}\n'
}


_autostop() {







	echo $$ > "$SPID" 2>/dev/null
	_dwleft="${1:-$DEF_SECS}"
	while [ "$_dwleft" -gt 0 ]; do
		[ "$(cat "$SPID" 2>/dev/null)" = "$$" ] || exit 0   # окно перезапустили — мы лишние
		watching || break                                   # истекло или нажали «Стоп»
		ct_list_all | ct_scan | awk '$5>0' | _dead_merge
		sleep "$SAMPLE_EVERY"
		_dwleft=$((_dwleft - SAMPLE_EVERY))
	done
	watching && exit 0        # UNTIL ещё в будущем → продлили, эта сплилка лишняя



	[ -f "$QCONF" ] || exit 0
	rm -f "$QCONF" "$UNTIL" 2>/dev/null
	dns_restart
}


























GRP_CONF=/tmp/dnsmasq.d/10-groups.conf          # группы и правила устройств (groups.sh)
GEO_CONF=/tmp/dnsmasq.d/11-geo.conf             # гео-категории (geo.sh)
CUSTOM_CONF=/etc/dnsmasq.d/enodia-custom.conf   # одиночные домены (domain.sh)
ZDOM_CONF=/tmp/dnsmasq.d/07-zapret-dom.conf     # доменный пул десинка (lists-update.sh)
load_dom_hits() {   # $1 = домены среза, по строке; $2 = noqlog — не читать журнал запросов → DOM_HITS
	DOM_HITS=" "


	_hnq=${2:-}
	_hw=/tmp/enodia-devwatch.want.$$
	printf '%s\n' "$1" | awk '{ d=$0; while(d!=""){ print d; if(d !~ /[.]/) break; sub("^[^.]*[.]", "", d) } }' > "$_hw" 2>/dev/null
	if [ ! -s "$_hw" ]; then rm -f "$_hw"; return 0; fi
	set -- "$_hw"



	_hfl="$GRP_CONF $GEO_CONF $CUSTOM_CONF $ZDOM_CONF"
	[ "$_hnq" = noqlog ] || _hfl="$_hfl $QLOG"
	for _hf in $_hfl; do
		if [ -f "$_hf" ]; then set -- "$@" "$_hf"; fi
	done
	DOM_HITS=" $(awk -v wf="$_hw" -v g="$GRP_CONF" -v e="$GEO_CONF" -v c="$CUSTOM_CONF" -v q="$QLOG" '
		FILENAME==wf { W[$0]=1; next }
		FILENAME==q {
			for(i=1;i<=NF-3;i++) if($i=="config" && $(i+2)=="is") {
				k=$(i+1); if((k in W) && ($(i+3)=="0.0.0.0" || $(i+3)=="::") && !(k in B)) { B[k]=1; printf " %s:B:blk", k }
				break }
			next }
		/^ipset=/ {
			l=substr($0, 8); k=l; sub("/.*", "", k)
			if(!(k in W)) next
			v=l; sub("^[^/]*/", "", v)
			if(v=="" || v ~ "/") next
			t=(FILENAME==g) ? "G" : ((FILENAME==e) ? "E" : ((FILENAME==c) ? "C" : "Z"))
			gsub(",", " " k ":" t ":", v)
			printf " %s:%s:%s", k, t, v }' "$@" 2>/dev/null) "
	rm -f "$_hw"
}






load_dev_rules() {   # $1 = IP клиента
	DEV_DOMS=" "




	DESYNC_SRC=0
	grep -qxF "$1" "$ENODIA_STATE/.desync-ips" 2>/dev/null && DESYNC_SRC=1
	[ -f "$ENODIA_DIR/groups.sh" ] || return 0
	_dvl=$(sh "$ENODIA_DIR/groups.sh" dev-list "$1" 2>/dev/null)
	[ -n "$_dvl" ] || return 0
	DEV_DOMS=" $(printf '%s\n' "$_dvl" | awk -F"$(printf '\t')" '
		$2 !~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(\/[0-9]+)?$/ {
			v = ($3=="vpn") ? (($4+0 > 0) ? "slot" $4 : "vpn") : (($3=="block") ? "block" : "bypass")
			printf "%s=%s ", $2, v }') "
}














on() { case "$1" in *" $2"*) return 0 ;; esac; return 1; }   # членство в списке «через пробел»




ip_in_net() {
	_nip=$1; _nnet=${2%/*}; _nlen=${2#*/}
	case "$2" in */*) ;; *) _nlen=32 ;; esac
	if [ "$_nlen" = 32 ]; then [ "$_nip" = "$_nnet" ]; return; fi
	case "$_nlen" in ''|*[!0-9]*) return 1 ;; esac
	_nI=$IFS; IFS=.
	set -- $_nip $_nnet
	IFS=$_nI
	[ $# -eq 8 ] || return 1
	_nk=1
	while [ "$_nlen" -gt 0 ]; do
		eval "_na=\${$_nk}; _nb=\${$((_nk+4))}"
		if [ "$_nlen" -ge 8 ]; then
			[ "$_na" = "$_nb" ] || return 1
			_nlen=$((_nlen-8))
		else
			_ns=$((8-_nlen))
			[ $((_na>>_ns)) -eq $((_nb>>_ns)) ] || return 1
			_nlen=0
		fi
		_nk=$((_nk+1))
	done
	return 0
}













load_marks() {   # $1 = IP клиента
	MARK_GO=" "; GUEST_MAIN=0; _lmip=$1
	_lmr=$(ip -4 rule show 2>/dev/null | awk '{ p=$1; sub(/:$/, "", p); f=""; m=""; t=""
		for(i=2;i<=NF;i++){ if($i=="from"){ i++; f=$i } else if($i=="fwmark"){ i++; m=$i } else if($i=="lookup" || $i=="table"){ i++; t=$i } }
		if(m!=""){ sub(/\/.*/, "", m); print "M " p " " m " " t } else if(f!="" && f!="all" && t=="main") print "F " p " " f }')
	_lmin=""; _lmI=$IFS; IFS='
'
	for _lm in $_lmr; do
		IFS=$_lmI
		set -- $_lm
		[ "$1" = M ] || continue
		[ -n "$_lmin" ] || _lmin=$2
		case "$MARK_GO" in *" $3:"*) continue ;; esac      # у метки действует ПЕРВОЕ правило (вывод — по pref)
		_lmgo=direct
		if ip -4 route show table "$4" 2>/dev/null | grep -q '^default'; then   # not-wan: таблица МЕТКИ (1000/100N), а не WAN
			case "$4" in 100[234]) _lmgo="slot${4#100}" ;; *) _lmgo=vpn ;; esac
		fi
		MARK_GO="$MARK_GO$3:$_lmgo "
	done
	IFS=$_lmI
	[ -n "$_lmin" ] || return 0            # меток нет вовсе — гостевой перебивать нечего
	IFS='
'
	for _lm in $_lmr; do
		IFS=$_lmI
		set -- $_lm
		[ "$1" = F ] || continue
		[ "$2" -lt "$_lmin" ] 2>/dev/null || continue
		if ip_in_net "$_lmip" "$3"; then GUEST_MAIN=1; break; fi
	done
	IFS=$_lmI
}
mark_go() {   # $1 = метка (0x1..0x4) → GO = vpn | slotN | direct
	case "$MARK_GO" in *" $1:"*) GO=${MARK_GO#*" $1:"}; GO=${GO%% *} ;; *) GO=direct ;; esac
}













load_walk() {   # $1 = IP клиента, $2 = интерфейс его станции Wi-Fi («» — кабель или неизвестно)
	_me=$1
	WALK=""; MARK_SETS=" "; ZAP_SETS=" "; KEEP_ON=" "; DEV_MARKS=" "
	SRC_FORCE=""; SRC_FVIA=""


	EMPTY_SETS=" $(ipset list -t 2>/dev/null | awk '$1=="Name:"{n=$2} /^Number of entries:/{ if($4+0==0) printf "%s ", n }') "
	_lw=$(iptables -t mangle -S 2>/dev/null | awk -v me="$1/32" -v ifc="$2" '
		$1!="-A" { next }
		$2=="PREROUTING" && $3=="-j" && NF==4 {
			if($4=="VPN_DEV" || $4=="VPN_KEEP" || $4=="VPN_EXCLUDE" || $4=="VPN_FORCE" || $4=="ENODIA_ZAPRET") P[++np]="J " $4
			next }
		$2!="PREROUTING" && $2!="VPN_DEV" && $2!="VPN_KEEP" && $2!="VPN_EXCLUDE" && $2!="VPN_FORCE" && $2!="ENODIA_ZAPRET" { next }
		{ s="-"; d="-"; p="-"; m="-"; md="dst"; t=""; k="-"; bad=0
		  for(i=3;i<=NF;i++){
		    if($i=="-s"){ i++; s=$i }
		    else if($i=="-d"){ i++; d=$i }
		    else if($i=="-m" && ($(i+1)=="physdev" || $(i+1)=="set")) i++
		    else if($i=="--physdev-in"){ i++; p=$i }
		    else if($i=="--match-set"){ i++; m=$i; i++; md=$i }
		    else if($i=="-j"){ i++; t=$i }
		    else if($i=="--set-xmark" || $i=="--set-mark"){ i++; k=$i }
		    else bad=1
		  }
		  if(bad || md!="dst") next
		  if(t!="MARK" && t!="ACCEPT" && t!="DROP" && t!="RETURN") next
		  if(t=="RETURN" && d!="-") next
		  if(p!="-") PD=1                       # правила ПО ИНТЕРФЕЙСУ станции в цепочках ЕСТЬ (см. WALK_PHYSDEV)
		  if(p!="-" && p!=ifc) next
		  if(s!="-" && s!=me && s ~ /\/32$/) next
		  if($2=="PREROUTING" && m=="-") next
		  sub(/\/.*/, "", k)
		  r=$2 " " s " " d " " p " " m " " t " " k
		  if($2=="PREROUTING") P[++np]="R " r; else { n[$2]++; R[$2 "#" n[$2]]=r } }
		END{ if(PD) print "@physdev"
		     for(i=1;i<=np;i++){ x=P[i]
		       if(substr(x,1,2)=="R "){ print substr(x,3); continue }
		       c=substr(x,3); for(j=1;j<=n[c];j++) print R[c "#" j] } }' 2>/dev/null)
	_lwI=$IFS; IFS='
'
	WALK_PHYSDEV=0
	for _l in $_lw; do
		IFS=$_lwI



		if [ "$_l" = "@physdev" ]; then WALK_PHYSDEV=1; continue; fi
		set -- $_l               # цепочка src dst physdev набор цель метка

		if [ "$2" != - ] && [ "$2" != "$_me/32" ]; then ip_in_net "$_me" "$2" || continue; fi
		WALK="$WALK$_l
"
		case "$1:$6" in
			PREROUTING:MARK) MARK_SETS="$MARK_SETS$5:$7 " ;;
			ENODIA_ZAPRET:ACCEPT) [ "$5" = - ] || ZAP_SETS="$ZAP_SETS$5 " ;;
			VPN_KEEP:MARK) [ "$5" = - ] || KEEP_ON="$KEEP_ON$5:$7 " ;;
			VPN_DEV:MARK) DEV_MARKS="$DEV_MARKS$7 " ;;
			VPN_FORCE:MARK)
				if [ -z "$SRC_FORCE" ] && [ "$3" = - ] && [ "$5" = - ]; then
					SRC_FORCE=$7
					if [ "$4" != - ]; then SRC_FVIA='режим сети'
					elif [ "$2" = - ]; then SRC_FVIA='весь трафик в VPN'
					else case "$2" in */32) SRC_FVIA='режим устройства' ;; *) SRC_FVIA='гостевая сеть' ;; esac; fi
				fi ;;
		esac
	done
	IFS=$_lwI
}




walk() {
	_wa=$1; W_T=""; W_M=""; W_C=""; W_S=""; W_D=""; W_P=""; W_SET=""; _wskip=""; _wls=""; _wlr=1
	_wI=$IFS; IFS='
'
	for _wl in $WALK; do
		IFS=$_wI
		set -- $_wl
		[ "$1" = "$_wskip" ] && continue
		if [ "$3" != - ]; then ip_in_net "$_wa" "$3" || continue; fi
		if [ "$5" != - ]; then

			if [ "$5" != "$_wls" ]; then
				_wls=$5; _wlr=1
				case "$EMPTY_SETS" in *" $5 "*) ;; *) ipset test "$5" "$_wa" >/dev/null 2>&1 && _wlr=0 ;; esac
			fi
			[ "$_wlr" = 0 ] || continue
		fi
		case "$6" in
			MARK)   W_M=$7; W_C=$1; W_S=$2; W_D=$3; W_P=$4; W_SET=$5 ;;
			ACCEPT) W_T=accept; [ -n "$W_M" ] || { W_C=$1; W_S=$2; W_D=$3; W_P=$4; W_SET=$5; }; break ;;
			DROP)   W_T=drop; W_C=$1; W_S=$2; W_D=$3; W_P=$4; W_SET=$5; break ;;
			RETURN) _wskip=$1 ;;
		esac
	done
	IFS=$_wI
}

set_label() {
	case "$1" in
		iplist_set)                SL='общий список' ;;
		grp_*)                     SL='группа' ;;
		geo_*)                     SL='гео' ;;
		enodia_list|enodia_bypass) SL='свой домен' ;;
		enodia_ip_vpn)             SL='свой адрес' ;;
		zapret_*)                  SL='десинк' ;;
		*)                         SL='правило' ;;
	esac
}



walk_via() {
	W_KIND=dst
	case "$W_C" in
		VPN_DEV) W_VIA='правило устройства' ;;
		VPN_FORCE)
			W_KIND=src
			if [ "$W_P" != - ]; then W_VIA='режим сети'
			elif [ "$W_S" = - ]; then W_VIA='весь трафик в VPN'
			else case "$W_S" in */32) W_VIA='режим устройства' ;; *) W_VIA='гостевая сеть' ;; esac; fi ;;
		VPN_EXCLUDE)
			if [ "$W_SET" != - ]; then set_label "$W_SET"; W_VIA=$SL
			elif [ "$W_D" != - ]; then W_VIA='вырез'
			elif [ "$W_P" != - ]; then W_KIND=src; W_VIA='режим сети'
			else W_KIND=src; W_VIA='режим устройства'; [ "$DESYNC_SRC" = 1 ] && W_KIND=dsrc
			fi ;;
		ENODIA_ZAPRET) W_KIND=zap; W_VIA='десинк' ;;
		*) set_label "$W_SET"; W_VIA=$SL ;;          # VPN_KEEP и маркировка PREROUTING — по набору
	esac
}







load_blk() {   # $1 = IP клиента
	BLK_SETS=""; BLK_ALLOW=""; _lbip=$1
	_lb=$(iptables -S 2>/dev/null | awk '
		$1=="-A" && $2=="FORWARD" && $3=="-j" && NF==4 && ($4=="ENODIA_GEOBLK" || $4=="ENODIA_BLK") { J[$4]=1; next }
		$1=="-A" && ($2=="ENODIA_GEOBLK" || $2=="ENODIA_BLK") {
			m=""; d=""; t=""; x=0
			for(i=3;i<=NF;i++){ if($i=="--match-set"){ m=$(i+1); d=$(i+2) } else if($i=="-j") t=$(i+1); else if($i=="-i") x=1 }
			if(x || m=="") next
			if(t=="DROP" && d=="dst") D[++nd]=$2 " " m
			else if(t=="RETURN") A[m]=1 }
		END{ for(i=1;i<=nd;i++){ c=D[i]; sub(/ .*/, "", c); if(c in J){ x=D[i]; sub(/^[^ ]* /, "", x); print "D " x } }
		     for(a in A) print "A " a }' 2>/dev/null)
	[ -n "$_lb" ] || return 0
	_lbI=$IFS; IFS='
'
	for _l in $_lb; do
		IFS=$_lbI
		set -- $_l
		case "$1" in
			D) BLK_SETS="$BLK_SETS $2" ;;
			A) BLK_ALLOW="$BLK_ALLOW $2" ;;
		esac
	done
	IFS=$_lbI
	for _ba in $BLK_ALLOW; do
		if ipset test "$_ba" "$_lbip" >/dev/null 2>&1; then BLK_SETS=""; return 0; fi
	done
	return 0
}






res() { R_ROUTE=$1; R_VIA=$2; R_WANT=$3; R_DSY=$4; }
res_direct() {   # $1 = direct|bypass, $2 = источник, $3 = адрес («» у домена), $4 = порт, $5 = намерение, $6 = десинк домена
	DESYNC_VIA=$6
	[ -n "$3" ] && desync_via "$3" "$4"

	if [ -z "$2" ] && [ -n "$DESYNC_VIA" ]; then res "$1" "$DESYNC_VIA" "$5" ''; else res "$1" "$2" "$5" "$DESYNC_VIA"; fi
}
res_mark() {   # $1 = метка, $2 = источник, $3 = адрес, $4 = порт, $5 = десинк домена
	if [ "$GUEST_MAIN" = 1 ]; then res_direct direct 'гостевая сеть' "$3" "$4" '' "$5"; return; fi
	mark_go "$1"
	_rw=vpn; [ "$1" = 0x1 ] || _rw="slot${1#0x}"
	case "$GO" in
		direct) res_direct direct "$2" "$3" "$4" "$_rw" "$5" ;;
		"$_rw") res "$GO" "$2" '' '' ;;
		*)      res "$GO" "$2" "$_rw" '' ;;         # выход упал на основной туннель (fallback=main)
	esac
}













load_desync_wired() {
	DESYNC_WIRED=$(iptables -t mangle -S POSTROUTING 2>/dev/null | awk '
		/-j NFQUEUE/{ _s=""; _p=""; _src="";
		  for(i=1;i<=NF;i++){
		    if($i=="--match-set") _s=$(i+1);
		    else if($i=="--dport") _p=$(i+1);
		    else if($i=="-s") _src=$(i+1);
		  }
		  if(_p=="") next;
		  if(_s!="") print _s":"_p; else if(_src!="") print "@src:"_p }' 2>/dev/null | sort -u | tr '
' ' ')
}











grp_name() {   # $1 = домен, $2 = слот (опц.; пусто = не проверять)
	for _gf in $(grep -lxF "$1" "$ENODIA_STATE/groups/"*.list 2>/dev/null); do
		_gid=$(basename "$_gf" .list)
		_gl=$(awk -F"$(printf '\t')" -v id="$_gid" '$1==id{print}' "$ENODIA_STATE/groups/groups.tsv" 2>/dev/null | head -1)
		[ -n "$_gl" ] || continue
		[ "$(printf '%s' "$_gl" | cut -f2)" = 1 ] || continue         # выключенная маршрут не задаёт



		[ -n "$(printf '%s' "$_gl" | cut -f6)" ] && continue
		if [ -n "$2" ] && [ "$(printf '%s' "$_gl" | cut -f4)" != "$2" ]; then continue; fi
		_gn=$(printf '%s' "$_gl" | cut -f5)
		[ -n "$_gn" ] && { printf 'группа «%s»' "$_gn"; return; }
	done
	printf 'группа'
}





















load_port_rules() {   # $1 = IP клиента
	PORT_RULES=""; PORT_DEV=false; PORT_ANY=false
	[ -s "$ENODIA_STATE/.port-rules" ] || return 0
	command -v port_rules_in_order >/dev/null 2>&1 || return 0
	_lpt=$(printf '	')
	_lprows=$(port_rules_in_order "$ENODIA_STATE/.port-rules" "$1")

	while IFS="$_lpt" read -r _psrc _ppro _ppts _pdir; do
		[ -n "$_pdir" ] || continue
		if [ "$_psrc" = any ]; then PORT_ANY=true; else PORT_DEV=true; fi
		PORT_RULES="$PORT_RULES $_ppro:$_ppts:$_pdir"
	done <<EOF_PR
$_lprows
EOF_PR
}





port_hit() {
	[ "$1" = all ] && return 0
	_hl=$1; _hp=$2; _hI=$IFS; IFS=','
	set -- $_hl
	IFS=$_hI
	for _ht in "$@"; do
		case "$_ht" in
			*-*) _ha=${_ht%-*}; _hb=${_ht#*-}
			     if [ "$_hp" -ge "$_ha" ] 2>/dev/null && [ "$_hp" -le "$_hb" ] 2>/dev/null; then return 0; fi ;;
			*)   [ "$_ht" = "$_hp" ] && return 0 ;;
		esac
	done
	return 1
}




port_route() {
	PORT_VERDICT=""
	[ -n "$PORT_RULES" ] || return 0
	case "$1" in udp|tcp) ;; *) return 0 ;; esac   # icmp и прочее правилами по портам не ловится
	case "$2" in ''|0|*[!0-9]*) return 0 ;; esac
	for _pr in $PORT_RULES; do
		_ppr=${_pr%%:*}; _pdr=${_pr##*:}; _ppl=${_pr#*:}; _ppl=${_ppl%:*}
		[ "$_ppr" = both ] || [ "$_ppr" = "$1" ] || continue
		port_hit "$_ppl" "$2" || continue
		PORT_VERDICT=$_pdr
		return 0
	done
	return 0
}







desync_via() {   # $1 = ip назначения, $2 = порт назначения
	DESYNC_VIA=""
	[ -n "$2" ] || return 0                 # порта нет (icmp) — nfqws такой пакет не видит

	case " $DESYNC_WIRED " in *" @src:$2 "*)
		[ "$DESYNC_SRC" = 1 ] && { DESYNC_VIA="десинк устройства"; return 0; } ;;
	esac
	for _dw in $DESYNC_WIRED; do
		case "$_dw" in @src:*) continue ;; esac
		[ "${_dw##*:}" = "$2" ] || continue      # правило заведено на ДРУГОЙ порт
		if ipset test "${_dw%:*}" "$1" >/dev/null 2>&1; then DESYNC_VIA=десинк; return 0; fi
	done
	return 0
}




















dom_route() {   # $1 = домен, $2 = порт (опц.; пусто = 443, как было у `view`)
	_dq=$1; _d=$1; R_OWN=0; _dp=${2:-443}
	_hb=""; _hdev=""; _hoo=""; _hog=""; _hoe=""; _hkeep=""; _hzap=""; _hzs=""; _hslot=""; _hvpn=""
	while [ -n "$_d" ]; do

		on "$DOM_HITS" "$_d:B:blk " && _hb=1
		if [ -z "$_hdev" ]; then case "$DEV_DOMS" in *" $_d="*) _hdev=${DEV_DOMS#*" $_d="}; _hdev=${_hdev%% *} ;; esac; fi
		_ow=0
		if on "$DOM_HITS" "$_d:C:enodia_bypass "; then _ow=1; _hoo=1; fi
		if on "$DOM_HITS" "$_d:C:enodia_list "; then
			_ow=1
			if [ -z "$_hkeep" ] && on "$KEEP_ON" "enodia_list:"; then _hkeep=own; fi
			if [ -z "$_hvpn" ] && on "$MARK_SETS" "enodia_list:"; then _hvpn=own; fi
		fi
		[ "$_d" = "$_dq" ] && R_OWN=$_ow
		if [ -z "$_hog" ] && on "$DOM_HITS" "$_d:G:grp_out "; then _hog=$_d; fi
		on "$DOM_HITS" "$_d:E:geo_out " && _hoe=1

		if on "$DOM_HITS" "$_d:E:geo_zapret " && on "$ZAP_SETS" "geo_zapret "; then _hzap=1; [ -n "$_hzs" ] || _hzs=geo_zapret; fi
		if on "$DOM_HITS" "$_d:Z:zapret_dom " && on "$ZAP_SETS" "zapret_dom "; then _hzap=1; [ -n "$_hzs" ] || _hzs=zapret_dom; fi
		for _dn in 2 3 4; do
			for _dt in G:grp_vpn_s E:geo_vpn_s; do
				on "$DOM_HITS" "$_d:$_dt$_dn " || continue

				if on "$ZAP_SETS" "${_dt#?:}$_dn "; then _hzap=1; [ -n "$_hzs" ] || _hzs="${_dt#?:}$_dn"
				elif [ -z "$_hslot" ] && on "$MARK_SETS" "${_dt#?:}$_dn:"; then _hslot="$_dn:$_d"; fi
			done
		done
		if on "$DOM_HITS" "$_d:G:grp_vpn "; then
			if [ -z "$_hkeep" ] && on "$KEEP_ON" "grp_vpn:"; then _hkeep="grp:$_d"; fi
			if [ -z "$_hvpn" ] && on "$MARK_SETS" "grp_vpn:"; then _hvpn="grp:$_d"; fi
		fi
		if [ -z "$_hvpn" ] && on "$DOM_HITS" "$_d:E:geo_vpn " && on "$MARK_SETS" "geo_vpn:"; then _hvpn=geo; fi
		case "$_d" in *.*) _d="${_d#*.}" ;; *) break ;; esac
	done





	_zd=""
	if [ "$_hzap" = 1 ]; then case " $DESYNC_WIRED " in *" $_hzs:$_dp "*) _zd='десинк' ;; esac; fi
	if [ -z "$_zd" ] && [ "$DESYNC_SRC" = 1 ]; then case " $DESYNC_WIRED " in *" @src:$_dp "*) _zd='десинк устройства' ;; esac; fi

	if [ -n "$_hb" ]; then res block 'список блокировки' '' ''; return; fi
	case "$_hdev" in                                   # VPN_DEV
		block)  res block 'правило устройства' '' ''; return ;;
		bypass) res_direct bypass 'правило устройства' '' '' '' "$_zd"; return ;;
		vpn)    res_mark 0x1 'правило устройства' '' '' "$_zd"; return ;;
		slot[234])

			_dm="0x${_hdev#slot}"; on "$DEV_MARKS" "$_dm " || _dm=0x1
			res_mark "$_dm" 'правило устройства' '' '' "$_zd"; return ;;
	esac
	case "$_hkeep" in                                  # VPN_KEEP — исключения из «мимо VPN»
		own)   res_mark 0x1 'свой домен' '' '' "$_zd"; return ;;
		grp:*) res_mark 0x1 "$(grp_name "${_hkeep#grp:}" 0)" '' '' "$_zd"; return ;;
	esac




	_wI=$IFS; IFS='
'
	for _wl in $WALK; do
		IFS=$_wI
		set -- $_wl
		[ "$1" = VPN_EXCLUDE ] && [ "$6" = ACCEPT ] || continue
		case "$5" in
			enodia_bypass) [ -n "$_hoo" ] || continue; res_direct bypass 'свой домен' '' '' '' "$_zd" ;;
			grp_out)       [ -n "$_hog" ] || continue; res_direct bypass "$(grp_name "$_hog" 0)" '' '' '' "$_zd" ;;
			geo_out)       [ -n "$_hoe" ] || continue; res_direct bypass 'гео' '' '' '' "$_zd" ;;
			-)             [ "$3" = - ] || continue
			               if [ "$4" != - ]; then res_direct direct 'режим сети' '' '' '' "$_zd"
			               elif [ "$DESYNC_SRC" = 1 ]; then res direct "${_zd:-режим устройства}" '' ''
			               else res_direct direct 'режим устройства' '' '' '' "$_zd"; fi ;;
			*)             continue ;;
		esac
		IFS=$_wI; return
	done
	IFS=$_wI
	if [ -n "$SRC_FORCE" ]; then res_mark "$SRC_FORCE" "$SRC_FVIA" '' '' "$_zd"; return; fi   # VPN_FORCE


	if [ "$_hzap" = 1 ]; then res direct "${_zd:-пул десинка}" '' ''; return; fi              # ENODIA_ZAPRET
	case "$_hslot" in ?:*) res_mark "0x${_hslot%%:*}" "$(grp_name "${_hslot#*:}" "${_hslot%%:*}")" '' '' "$_zd"; return ;; esac
	case "$_hvpn" in                                   # маркировка mark-core
		own)   res_mark 0x1 'свой домен' '' '' "$_zd"; return ;;
		geo)   res_mark 0x1 'гео' '' '' "$_zd"; return ;;
		grp:*) res_mark 0x1 "$(grp_name "${_hvpn#grp:}" 0)" '' '' "$_zd"; return ;;
	esac


	if [ "$GUEST_MAIN" = 1 ]; then res direct 'гостевая сеть' '' "$_zd"; return; fi
	if [ -n "$_zd" ] && [ "$DESYNC_SRC" = 1 ]; then res direct "$_zd" '' ''; return; fi
	res '' '' '' ''
}






ip_route() {
	_ia=$1; _ipr=$2; _ipt=$3
	for _ib in $BLK_SETS; do
		ipset test "$_ib" "$_ia" >/dev/null 2>&1 || continue
		_ibok=0
		for _iba in $BLK_ALLOW; do ipset test "$_iba" "$_ia" >/dev/null 2>&1 && { _ibok=1; break; }; done
		[ "$_ibok" = 1 ] && break
		case "$_ib" in geo_*) res block 'гео' '' '' ;; *) res block 'список блокировки' '' '' ;; esac
		return
	done



	port_route "$_ipr" "$_ipt"
	case "$PORT_VERDICT" in
		block)  res block 'правило по портам' '' ''; return ;;
		direct) if [ "$GUEST_MAIN" = 1 ]; then res_direct direct 'гостевая сеть' "$_ia" "$_ipt" '' ''
		        else res_direct direct 'правило по портам' "$_ia" "$_ipt" '' ''; fi; return ;;
		vpn)    res_mark 0x1 'правило по портам' "$_ia" "$_ipt" ''; return ;;
		s[234]) res_mark "0x${PORT_VERDICT#s}" 'правило по портам' "$_ia" "$_ipt" ''; return ;;
	esac
	walk "$_ia"; walk_via
	if [ "$W_T" = drop ]; then res block "$W_VIA" '' ''; return; fi
	if [ -n "$W_M" ]; then res_mark "$W_M" "$W_VIA" "$_ia" "$_ipt" ''; return; fi
	if [ "$W_T" = accept ]; then
		if [ "$GUEST_MAIN" = 1 ]; then res_direct direct 'гостевая сеть' "$_ia" "$_ipt" '' ''; return; fi
		case "$W_KIND" in
			src)  res_direct direct "$W_VIA" "$_ia" "$_ipt" '' '' ;;
			dsrc) desync_via "$_ia" "$_ipt"; res direct "${DESYNC_VIA:-режим устройства}" '' '' ;;


			zap)  desync_via "$_ia" "$_ipt"; if [ -n "$DESYNC_VIA" ]; then res direct 'десинк' '' ''; else res direct 'пул десинка' '' ''; fi ;;
			*)    res_direct bypass "$W_VIA" "$_ia" "$_ipt" '' '' ;;
		esac
		return
	fi

	if [ "$GUEST_MAIN" = 1 ]; then res_direct direct 'гостевая сеть' "$_ia" "$_ipt" '' ''; return; fi
	res_direct direct '' "$_ia" "$_ipt" '' ''
}

emit_domains() {  # emit_domains <ip>
	ip="$1"; LIMIT=50

	[ -f "$QLOG" ] || return

	_eds=$(awk -v ip="$ip" -v lim="$LIMIT" '
		{ for(i=1;i<=NF;i++) if($i=="from" && $(i+1)==ip){ a[++n]=$(i-1); break } }
		END{ c=0; for(i=n;i>=1;i--){ d=a[i]; gsub("[\"\\\\]", "", d); if(d!="" && !(d in seen)){ seen[d]=1; print d; if(++c>=lim) break } } }
	' "$QLOG" 2>/dev/null)
	[ -n "$_eds" ] || return
	load_dom_hits "$_eds"
	first=1
	printf '%s\n' "$_eds" | while IFS= read -r d; do
		[ -n "$d" ] || continue
		[ "$first" -eq 1 ] || printf ','
		first=0



		dom_route "$d"
		_ob=false; [ "$R_OWN" = 1 ] && _ob=true
		printf '{"name":"%s","route":"%s","via":"%s","own":%s,"want":"%s","dsy":"%s"}' \
			"$d" "$R_ROUTE" "$R_VIA" "$_ob" "$R_WANT" "$R_DSY"
	done
	printf ''
}



















ct_scan() {
	awk '
	{ s=""; d=""; p=""; pr=""; hdr=1; unrep=0; np=0; tx=0; syn=0;
	  for(i=1;i<=NF;i++){
	    if(substr($i,1,4)=="src="){ if(s=="") s=substr($i,5); hdr=0; continue }
	    if(hdr && ($i=="tcp" || $i=="udp")){ pr=$i; continue }
	    if($i ~ /^dst=/ && d==""){ d=substr($i,5); continue }
	    if($i ~ /^dport=/ && p==""){ p=substr($i,7); continue }
	    if($i ~ /^packets=/){ np++; if(np==1) tx=substr($i,9)+0; continue }
	    if($i=="[UNREPLIED]"){ unrep=1; continue }
	    if($i=="SYN_SENT"){ syn=1; continue }
	  }
	  if(s=="" || d=="") next
	  if(d ~ /^(10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.|22[4-9]\.|23[0-9]\.|0\.)/) next
	  nr=0; if(unrep && (tx>=3 || syn)) nr=(tx>0?tx:1)
	  print s" "d" "(p==""?0:p)" "(pr==""?"-":pr)" "nr }
	' 2>/dev/null
}













_dead_merge() {
	[ -f "$DEADLOG" ] || : > "$DEADLOG"




	awk -v now="$(now)" -v cap="$DEAD_MAX" '
		NF>=7 { k=$1" "$2" "$3" "$4; if(!(k in O)){O[k]=1; n++} TX[k]=$5+0; F[k]=$6+0; TS[k]=$7+0; next }
		NF==5 { k=$1" "$2" "$3" "$4
		  if(!(k in O)){ if(n>=cap) next; O[k]=1; n++; F[k]=now }
		  if($5+0>TX[k]) TX[k]=$5+0
		  TS[k]=now }
		END{ for(k in O) print k" "TX[k]" "F[k]" "TS[k] }
	' "$DEADLOG" - > "$DEADLOG.new" 2>/dev/null && mv "$DEADLOG.new" "$DEADLOG" 2>/dev/null
	rm -f "$DEADLOG.new" 2>/dev/null
}









emit_conns() {  # emit_conns <ip>
	ip="$1"; LIMIT=50

	BSET=" $(sed 's#/32$##' "$ENODIA_STATE/.bypass-dst" 2>/dev/null | tr '\n' ' ') "
	VSET=" $(sed 's#/32$##' "$ENODIA_STATE/.vpn-dst"    2>/dev/null | tr '\n' ' ') "
	first=1
	ct_list_src "$ip" | ct_scan | awk '
		# ДЕДУП ПО АДРЕСУ БЕРЁТ ХУДШИЙ ПОТОК, а не первый попавшийся: к одному серверу их бывает
		# несколько, и отвечающий keepalive прятал бы молчащий игровой порт — ровно тот случай,
		# ради которого метка и заведена. Печатаем в END, порядок всё равно задаёт sort ниже.
		{ d=$2; nr=$5+0; if(!(d in best) || nr>best[d]){ best[d]=nr; P[d]=$3; PR[d]=$4 } }
		END{
		  # Первое поле — приоритет для sort: мёртвые ВВЕРХ, иначе head -50 срезал бы именно их
		  # (замерено 28.08.2026: у активного ПК срез упирался в лимит). busybox sort без -k
		  # сортирует строку целиком, ведущая цифра и решает — ключ обязан быть ПЕРВЫМ полем.
		  for(d in best) print (best[d]?0:1)" "d" "P[d]" "PR[d]" "best[d]
		}
	' 2>/dev/null | sort | head -n "$LIMIT" | while read -r _dwpri cip cport cproto cnr; do
		[ -n "$cip" ] || continue





		rule=""; case "$BSET" in *" $cip "*) rule=bypass ;; esac
		[ -n "$rule" ] || case "$VSET" in *" $cip "*) rule=vpn ;; esac
		case "$cport" in ''|*[!0-9]*) cport=0 ;; esac
		case "$cproto" in udp|tcp) ;; *) cproto="" ;; esac
		case "$cnr" in ''|*[!0-9]*) cnr=0 ;; esac
		[ "$first" -eq 1 ] || printf ','
		first=0
		ip_route "$cip" "$cproto" "$cport"
		printf '{"ip":"%s","port":%d,"rule":"%s","route":"%s","via":"%s","noreply":%d,"want":"%s","dsy":"%s"}' \
			"$cip" "$cport" "$rule" "$R_ROUTE" "$R_VIA" "$cnr" "$R_WANT" "$R_DSY"
	done
	printf ''
}












emit_dead() {   # emit_dead <ip>
	[ -s "$DEADLOG" ] || return
	first=1
	awk -v me="$1" -v grace="$SAMPLE_EVERY" '$1==me && NF>=7 && ($7-$6)>=grace { print $7" "$2" "$3" "$4" "$5 }' "$DEADLOG" 2>/dev/null \
		| sort -r | head -n "$DEAD_SHOW" | while read -r dts dip dport dproto dtx; do
		[ -n "$dip" ] || continue
		case "$dport" in ''|*[!0-9]*) dport=0 ;; esac
		case "$dproto" in udp|tcp) ;; *) dproto="" ;; esac
		case "$dtx" in ''|*[!0-9]*) dtx=0 ;; esac
		[ "$first" -eq 1 ] || printf ','
		first=0
		ip_route "$dip" "$dproto" "$dport"
		printf '{"ip":"%s","port":%d,"proto":"%s","tx":%d,"ago":%d,"route":"%s","via":"%s","want":"%s","dsy":"%s"}' \
			"$dip" "$dport" "$dproto" "$dtx" "$(age_since "$dts")" "$R_ROUTE" "$R_VIA" "$R_WANT" "$R_DSY"
	done
	printf ''
}



view() {  # view <ip> [интерфейс станции Wi-Fi]
	ip="$1"; ifc="$2"



	load_marks "$ip"                # куда ведёт каждая метка и не гостевая ли «мимо» (правило маршрутизации)
	load_walk "$ip" "$ifc"          # цепочки ядра для ЭТОГО клиента: устройство, его сеть, «весь трафик в VPN»
	load_blk "$ip"                  # блок-листы filter FORWARD (рубят после маршрутизации)
	load_dev_rules "$ip"            # правила устройства по ИМЕНАМ — для доменов (адреса отвечает обход)
	load_port_rules "$ip"           # VPN_PORTS — первая цепочка, у правила есть порт
	load_desync_wired               # на каких «сет:порт» десинк РЕАЛЬНО стоит
	w=false; watching && w=true
	printf '{"watching":%s,"secs_left":%s,"domains":[' "$w" "$(secs_left)"
	emit_domains "$ip"
	printf '],"conns":['
	emit_conns "$ip"
	printf '],"dead":['
	emit_dead "$ip"
	printf ']}\n'
}
















ROUTE_MAX=8              # сколько адресов имени судим: у CDN их десятки, а ipset test — форк на каждый
ROUTE_NS_TIMEOUT=${ROUTE_NS_TIMEOUT:-5}   # потолок резолва: отвечаем человеку в панели, висеть на запертом DNS нельзя






ROUTE_LOCAL_NETS="10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 169.254.0.0/16 224.0.0.0/4 127.0.0.0/8"
route_lan() {   # $1 = адрес → 0, если он из локальных/служебных диапазонов
	for _rln in $ROUTE_LOCAL_NETS; do
		ip_in_net "$1" "$_rln" && return 0
	done
	return 1
}


route_resolve() {
	_rdns=skip; _rips="$_rq"; _rok=1
	_rnr=""; _rnv=""; _rnw=""; _rnd=""; _rno=0; _rnh2=false
	[ "$_rkind" = domain ] || return 0
	_rall=$(ns_ips "$_rq" "$ROUTE_NS_TIMEOUT" | awk '!S[$0]++')

	_rips=$(printf '%s\n' "$_rall" | grep -v '^0\.0\.0\.0$' | head -n "$ROUTE_MAX" | tr '\n' ' ')
	_rok=$(printf '%s\n' "$_rall" | grep -v '^0\.0\.0\.0$' | grep -c . 2>/dev/null || true)
	case "$_rok" in ''|*[!0-9]*) _rok=0 ;; esac
	if [ "$_rok" -gt 0 ]; then _rdns=ok
	elif printf '%s\n' "$_rall" | grep -qx '0\.0\.0\.0'; then _rdns=blocked





	elif timeout -t 2 nslookup localhost >/dev/null 2>&1; then _rdns=none
	else _rdns=fail; fi
}

route_load() {
	load_marks "$_rip"
	load_walk "$_rip" "$_rifc"
	load_blk "$_rip"
	load_dev_rules "$_rip"
	load_port_rules "$_rip"
	load_desync_wired
	_rports=false; [ -n "$PORT_RULES" ] && _rports=true
}
route_emit() {   # $1 = адрес → объект вердикта (R_* оставляет вызывающему: по ним считается split)

	_rel=false
	if route_lan "$1"; then _rel=true; res direct '' '' ''
	else ip_route "$1" "$ROUTE_PROTO" "$ROUTE_PORT"; fi
	printf '{"ip":"%s","route":"%s","via":"%s","want":"%s","dsy":"%s","lan":%s}' \
		"$1" "$R_ROUTE" "$R_VIA" "$R_WANT" "$R_DSY" "$_rel"
}
cmd_route() {   # <цель> <ip клиента> [ifc] [порт] [tcp|udp]
	_rq=$1; _rip=$2; _rifc=${3:-}; ROUTE_PORT=${4:-}; ROUTE_PROTO=${5:-}
	case "$ROUTE_PORT" in ''|*[!0-9]*) ROUTE_PORT=443 ;; esac


	while :; do case "$ROUTE_PORT" in 0?*) ROUTE_PORT=${ROUTE_PORT#0} ;; *) break ;; esac; done
	[ "$ROUTE_PORT" -gt 0 ] 2>/dev/null && [ "$ROUTE_PORT" -le 65535 ] 2>/dev/null || ROUTE_PORT=443
	case "$ROUTE_PROTO" in udp) ;; *) ROUTE_PROTO=tcp ;; esac


	_rkind=domain
	printf '%s' "$_rq" | grep -qE '^(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}$' && _rkind=ip

	if ! command -v ns_ips >/dev/null 2>&1 && [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi


	if ! command -v ns_ips >/dev/null 2>&1; then
		ns_ips() { timeout -t "${2:-5}" nslookup "$1" 2>/dev/null | awk '/^Name:/{f=1}
			f{for(i=1;i<=NF;i++) if ($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) print $i}'; }
	fi
	if [ "$_rkind" = domain ]; then
		if command -v dom_ok >/dev/null 2>&1; then
			dom_ok "$_rq" || { printf '{"error":"bad target"}\n'; return 1; }
		else
			printf '%s' "$_rq" | grep -qE '^[A-Za-z0-9_-]{1,63}(\.[A-Za-z0-9_-]{1,63})*$' \
				|| { printf '{"error":"bad target"}\n'; return 1; }
		fi
	fi





	route_resolve; route_load




	_rpd=false
	[ -z "$_rifc" ] && [ "${WALK_PHYSDEV:-0}" = 1 ] && _rpd=true
	if [ "$_rkind" = domain ]; then


		load_dom_hits "$_rq" noqlog




		[ "$_rdns" = blocked ] && DOM_HITS="$DOM_HITS$_rq:B:blk " 




		case "$DOM_HITS" in *:*) _rnh2=true ;; *) _rnh2=false ;; esac
		dom_route "$_rq" "$ROUTE_PORT"
		_rnr=$R_ROUTE; _rnv=$R_VIA; _rnw=$R_WANT; _rnd=$R_DSY; _rno=$R_OWN
	fi
	_rnh=false; [ -n "$_rnr" ] && _rnh=true
	_rob=false; [ "$_rno" = 1 ] && _rob=true


	printf '{"kind":"%s","q":"%s","ip":"%s","port":%d,"proto":"%s","ports":%s,"pdev":%s,"pany":%s,"physdev":%s,"dns":"%s","n":%d,"name":{"has":%s,"hit":%s,"route":"%s","via":"%s","want":"%s","dsy":"%s","own":%s},"addrs":[' \
		"$_rkind" "$_rq" "$_rip" "$ROUTE_PORT" "$ROUTE_PROTO" "$_rports" "$PORT_DEV" "$PORT_ANY" "$_rpd" "$_rdns" "$_rok" \
		"$_rnh" "$_rnh2" "$_rnr" "$_rnv" "$_rnw" "$_rnd" "$_rob"
	_rsig=""; _rsplit=false; _rfirst=1
	for _ra in $_rips; do
		[ "$_rfirst" = 1 ] || printf ','
		_rfirst=0
		route_emit "$_ra"









		_rs="$R_ROUTE|$R_WANT|$R_DSY|$_rel"
		case "$R_ROUTE" in bypass) _rs="direct|$R_WANT|$R_DSY|$_rel" ;; esac
		if [ "$_rsig" = "" ]; then _rsig=$_rs; elif [ "$_rs" != "$_rsig" ]; then _rsplit=true; fi
	done
	printf '],"split":%s}\n' "$_rsplit"
}

case "$1" in
	start)     start "$2" ;;
	stop)      stop ;;
	status)    w=false; watching && w=true; printf '{"watching":%s,"secs_left":%s}\n' "$w" "$(secs_left)" ;;

	view)      case "$2" in *[!0-9.]*|'') printf '{"error":"bad ip"}\n' ;;
	           *) case "$3" in *[!A-Za-z0-9._-]*) printf '{"error":"bad ifc"}\n' ;; *) view "$2" "$3" ;; esac ;; esac ;;



	route)     case "${2:-}" in -*|''|*[!A-Za-z0-9._-]*) printf '{"error":"bad target"}\n' ;;
	           *) case "${3:-}" in *[!0-9.]*|'') printf '{"error":"bad ip"}\n' ;;
	              *) case "${4:-}" in *[!A-Za-z0-9._-]*) printf '{"error":"bad ifc"}\n' ;;
	                 *) cmd_route "$2" "$3" "${4:-}" "${5:-}" "${6:-}" ;; esac ;; esac ;; esac ;;
	_autostop) _autostop "$2" ;;
	*)         echo "usage: $0 {start [secs]|stop|status|view <ip> [ifc]|route <цель> <ip> [ifc] [порт] [tcp|udp]}" >&2; exit 1 ;;
esac
