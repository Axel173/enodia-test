#!/bin/sh





















FWMARK=0x1
TABLE=1000





UNWIRE=0
[ "${1:-}" = unwire ] && UNWIRE=1










ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}









ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
if [ "$UNWIRE" = 0 ] && [ -f "$ENODIA_STATE/.vpn-off" ]; then
    echo "[mark-core] VPN выключен человеком (.vpn-off) — правил не ставлю (вернёт vpn-toggle.sh on)"
    exit 0
fi





if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi



















while iptables -t mangle -D PREROUTING -m addrtype --dst-type LOCAL -j ACCEPT 2>/dev/null; do :; done
if [ "$UNWIRE" = 0 ]; then
    if iptables -t mangle -I PREROUTING 1 -m addrtype --dst-type LOCAL -j ACCEPT 2>/dev/null; then
        echo "[mark-core] reply-guard: dst-LOCAL ACCEPT (обратный трафик к WAN-IP не метится)"
    else
        echo "[mark-core] ВНИМАНИЕ: addrtype недоступен — reply-guard НЕ поставлен (риск залипания возврата прямого трафика, если WAN-IP в iplist_set)"
    fi
fi

















for p in 465 587 25; do
    while iptables -t mangle -D OUTPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null; do :; done
    [ "$UNWIRE" = 0 ] && iptables -t mangle -I OUTPUT 1 -p tcp --dport "$p" -j ACCEPT 2>/dev/null
done
[ "$UNWIRE" = 0 ] && echo "[mark-core] notify-guard: router SMTP (465/587/25) мимо туннеля (письма-уведомления всегда напрямую)"













_ptls_port=$(cat "$ENODIA_STATE/.panel-tls" 2>/dev/null | tr -cd '0-9' | sed 's/^0*//')
if [ -n "$_ptls_port" ]; then
    while iptables -t mangle -D OUTPUT -p tcp --sport "$_ptls_port" -j ACCEPT 2>/dev/null; do :; done
    if [ "$UNWIRE" = 0 ]; then
        iptables -t mangle -I OUTPUT 1 -p tcp --sport "$_ptls_port" -j ACCEPT 2>/dev/null
        echo "[mark-core] panel-guard: ответы панели с :$_ptls_port мимо туннеля"
    fi
fi









_vsrv_port=$(cat "$ENODIA_STATE/server/port" 2>/dev/null | tr -cd '0-9')
if [ -n "$_vsrv_port" ]; then
    while iptables -t mangle -D OUTPUT -p udp --sport "$_vsrv_port" -j ACCEPT 2>/dev/null; do :; done
    if [ "$UNWIRE" = 0 ]; then
        iptables -t mangle -I OUTPUT 1 -p udp --sport "$_vsrv_port" -j ACCEPT 2>/dev/null
        echo "[mark-core] vpnsrv-guard: ответы VPN-сервера с :$_vsrv_port мимо туннеля"
    fi
fi

















SLOTS_SH="$ENODIA_DIR/slots.sh"




if [ -f "$SLOTS_SH" ]; then
    sh "$SLOTS_SH" list-enabled 2>/dev/null | while IFS="$(printf '\t')" read -r sid stransport _scfg sfb; do
        case "$sid" in 2|3|4) ;; *) continue ;; esac
        [ "$stransport" = zapret ] && continue
        for sset in "grp_vpn_s$sid" "geo_vpn_s$sid"; do
            ipset list -n 2>/dev/null | grep -qx "$sset" || continue

            for chain in PREROUTING OUTPUT; do
                while iptables -t mangle -D "$chain" -m set --match-set "$sset" dst -j ACCEPT 2>/dev/null; do :; done
                while iptables -t mangle -D "$chain" -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid" 2>/dev/null; do :; done
            done
            [ "$UNWIRE" = 1 ] && continue
            mpos=$(iptables -t mangle -nL PREROUTING --line-numbers 2>/dev/null | awk '/miwifi|ipt_compiler|NFQUEUE/{print $1; exit}')
            if [ -n "$mpos" ]; then
                iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$sset" dst -j ACCEPT
                iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid"
            else
                iptables -t mangle -A PREROUTING -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid"
                iptables -t mangle -A PREROUTING -m set --match-set "$sset" dst -j ACCEPT
            fi
            iptables -t mangle -A OUTPUT -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid"
            iptables -t mangle -A OUTPUT -m set --match-set "$sset" dst -j ACCEPT
        done










        ip rule del fwmark "0x$sid" table "100$sid" 2>/dev/null || true
        ip rule del fwmark "0x$sid" table 1000 2>/dev/null || true
        [ "$UNWIRE" = 1 ] && { echo "[mark-core] слот №$sid: марки и ip rule сняты"; continue; }
        starget="100$sid"
        if ! ip route show table "100$sid" 2>/dev/null | grep -q '^default'; then   # not-wan: несущая СЛОТА (table 100N), у неё свой владелец — slots.sh
            [ "$sfb" = main ] && starget=1000
        fi
        ip rule add fwmark "0x$sid" table "$starget" pref "9$sid"
        echo "[mark-core] слот №$sid ($stransport): марка 0x$sid -> table $starget (pref 9$sid)"
    done
fi



































for set in enodia_list iplist_set grp_vpn enodia_ip_vpn geo_vpn; do
    if ipset list -n 2>/dev/null | grep -qx "$set"; then

        while iptables -t mangle -D PREROUTING -m set --match-set "$set" dst -j ACCEPT 2>/dev/null; do :; done
        while iptables -t mangle -D PREROUTING -m set --match-set "$set" dst -j MARK --set-mark $FWMARK 2>/dev/null; do :; done


        while iptables -t mangle -D OUTPUT -m set --match-set "$set" dst -j MARK --set-mark $FWMARK 2>/dev/null; do :; done
        [ "$UNWIRE" = 1 ] && continue

        mpos=$(iptables -t mangle -nL PREROUTING --line-numbers 2>/dev/null | awk '/miwifi|ipt_compiler|NFQUEUE/{print $1; exit}')
        if [ -n "$mpos" ]; then


            iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$set" dst -j ACCEPT
            iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$set" dst -j MARK --set-mark $FWMARK
        else
            iptables -t mangle -A PREROUTING -m set --match-set "$set" dst -j MARK --set-mark $FWMARK
        fi
        iptables -t mangle -A OUTPUT -m set --match-set "$set" dst -j MARK --set-mark $FWMARK
    fi
done


ip rule del fwmark $FWMARK table $TABLE 2>/dev/null || true
if [ "$UNWIRE" = 1 ]; then


    echo "[mark-core] маркировка СНЯТА (правила ядра и ip rule убраны; сеты и default в table $TABLE — не наша забота)"
    exit 0
fi
ip rule add fwmark $FWMARK table $TABLE pref 99




if [ -f "$ENODIA_STATE/.vpn-off" ]; then
    echo "[mark-core] VPN выключили вручную, пока ставилась маркировка, — снимаю"
    exec sh "$ENODIA_DIR/mark-core.sh" unwire
fi

echo "[mark-core] маркировка применена (table $TABLE, fwmark $FWMARK; default ставит транспорт)"
