#!/bin/sh





















TABLE=1000
MARK=0x1
EXCLUDE_CHAIN_PRE="VPN_EXCLUDE"   # mangle PREROUTING исключения
ENODIA_LIST="enodia_list"
IPLIST_SET="iplist_set"
HEAL_LOCK="/tmp/enodia-heal.lock"
SWITCH_LOCK="/tmp/enodia-switching.lock"   # ОБЩАЯ идиома «идёт смена несущей — сторож и heal не вмешиваются» (transport.sh, switch-vpn.sh, cgi hold_switch); держим её и на подъёме несущей в cmd_on
ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}        # для apply-bypass.sh (персист исключений)
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}   # только для ПОДСКАЗОК человеку (см. ниже)






VPN_OFF_FLAG="$ENODIA_STATE/.vpn-off"




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }

command -v mss_clamp >/dev/null 2>&1 || { mss_clamp() { :; }; mss_unclamp() { :; }; }
if ! command -v ct_flush >/dev/null 2>&1; then
    ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }
    ct_flush_src_n(){ [ -n "$1" ] && conntrack -D --src "$1" 2>/dev/null | wc -l; return 0; }
fi


if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v wd_tick_alive >/dev/null 2>&1 || wd_tick_alive() { return 1; }
command -v heal_alive >/dev/null 2>&1 || heal_alive() { return 1; }
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -d "/proc/$1" ]; }
SETTLE_PID="/tmp/enodia-vpnoff-settle.pid"
WD_LOG="/tmp/enodia-watchdog.log"           # след доводчика — там же, где видны все смены несущей


settle_busy() { [ -e "$SWITCH_LOCK" ] || wd_tick_alive || heal_alive; }




SETTLE_LOCK="/tmp/enodia-vpnoff-settle.lock"
settle_lock_take() {
    _stw=0
    while ! ( set -C; echo $$ > "$SETTLE_LOCK" ) 2>/dev/null; do
        _sth=$(cat "$SETTLE_LOCK" 2>/dev/null | tr -cd '0-9')
        pid_runs "$_sth" 'vpn-toggle\.sh' || rm -f "$SETTLE_LOCK" 2>/dev/null
        [ "$_stw" -ge 60 ] && return 1
        sleep 1; _stw=$((_stw + 1))
    done
    return 0
}
settle_lock_drop() { [ "$(cat "$SETTLE_LOCK" 2>/dev/null)" = "$$" ] && rm -f "$SETTLE_LOCK" 2>/dev/null; return 0; }






















ensure_chain() {
    iptables -t mangle -L "$EXCLUDE_CHAIN_PRE" -n >/dev/null 2>&1 || {
        iptables -t mangle -N "$EXCLUDE_CHAIN_PRE"
    }


    iptables -t mangle -D PREROUTING -j "$EXCLUDE_CHAIN_PRE" 2>/dev/null
    iptables -t mangle -I PREROUTING 1 -j "$EXCLUDE_CHAIN_PRE"




    iptables -t mangle -D OUTPUT -j "$EXCLUDE_CHAIN_PRE" 2>/dev/null
    iptables -t mangle -I OUTPUT 1 -j "$EXCLUDE_CHAIN_PRE"




    [ -f "$ENODIA_DIR/apply-bypass.sh" ] && sh "$ENODIA_DIR/apply-bypass.sh" order >/dev/null 2>&1
    return 0
}

cmd_status() {



    [ -f "$VPN_OFF_FLAG" ] && echo "Тумблер: ВЫКЛЮЧЕН человеком (переживает ребут; вернуть — vpn-toggle.sh on)"
    if ip rule show | grep -q "fwmark $MARK"; then
        echo "VPN: ON (глобально)"
    else
        echo "VPN: OFF (глобально)"
    fi



    _slr=$(ip rule show 2>/dev/null | grep -c 'fwmark 0x[2-7]')
    case "$_slr" in ''|*[!0-9]*) _slr=0 ;; esac   # busybox: grep -c при нуле даёт код 1
    [ "$_slr" -gt 0 ] && echo "Доп-выходы: правил маршрутизации активно: $_slr"
    echo
    echo "awg0 интерфейс:"
    ip a show awg0 2>/dev/null | grep -E 'inet |state' | head -2
    echo
    echo "Исключённые IP (трафик идёт мимо VPN):"
    iptables -t mangle -L "$EXCLUDE_CHAIN_PRE" -n 2>/dev/null | awk '/ACCEPT/{print "  " $4}'
}






cmd_off() {



    mkdir -p "$ENODIA_STATE" 2>/dev/null

    [ "$OFF_SETTLE" = 1 ] || date +%s > "$VPN_OFF_FLAG" 2>/dev/null



    trap '' HUP PIPE


    _busy0=0; settle_busy && _busy0=1
    ip rule del fwmark $MARK table $TABLE 2>/dev/null
    for _s in 2 3 4 5 6 7; do
        ip rule del fwmark "0x$_s" table "100$_s" 2>/dev/null
        ip rule del fwmark "0x$_s" table $TABLE 2>/dev/null
    done


    [ -f "$ENODIA_DIR/road.sh" ] && sh "$ENODIA_DIR/road.sh" unwire >/dev/null 2>&1








    _offlk=0
    if [ ! -e "$SWITCH_LOCK" ] && : > "$SWITCH_LOCK" 2>/dev/null; then
        _offlk=1


        trap 'rm -f "$SWITCH_LOCK" 2>/dev/null' EXIT
        trap 'exit 1' INT TERM
    fi




























    [ -f "$ENODIA_DIR/traffic-acct.sh" ] && sh "$ENODIA_DIR/traffic-acct.sh" >/dev/null 2>&1
    _offt=$(active_transport)
    if [ "$_offt" != none ] && [ -f "$ENODIA_DIR/transport.sh" ]; then
        echo "Отпускаю несущую транспорта $_offt (маршрут и DNS — прямые)…"
        sh "$ENODIA_DIR/transport.sh" down "$_offt" >/dev/null 2>&1
    fi








    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        _offs=$(sh "$ENODIA_DIR/transport.sh" slots-down 2>&1)
        [ -n "$_offs" ] && printf '%s\n' "$_offs" | sed 's/^/  /'
    fi









    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        sh "$ENODIA_DIR/transport.sh" cold >/dev/null 2>&1
    fi


    if [ "$_offlk" = 1 ]; then
        trap - EXIT INT TERM
        rm -f "$SWITCH_LOCK" 2>/dev/null
    fi


    ct_flush








    if [ "$OFF_SETTLE" != 1 ] && { [ "$_busy0" = 1 ] || [ "$_offlk" = 0 ] || wd_tick_alive || heal_alive; }; then
        if command -v start-stop-daemon >/dev/null 2>&1; then
            start-stop-daemon -S -b -m -p "$SETTLE_PID" -x /bin/sh -- "$ENODIA_DIR/vpn-toggle.sh" off-settle >/dev/null 2>&1
        else
            ( sh "$ENODIA_DIR/vpn-toggle.sh" off-settle >/dev/null 2>&1 & )
        fi
    fi
    echo "VPN глобально ВЫКЛЮЧЕН. Трафик идёт через провайдера (включая доп-выходы)."
    echo "Не забудьте: ipconfig /flushdns на клиентах."
}








cmd_off_settle() {
    _osw=0
    while [ -f "$VPN_OFF_FLAG" ] && settle_busy; do sleep 2; _osw=$((_osw + 2)); done
    if settle_lock_take; then
        if [ ! -f "$VPN_OFF_FLAG" ]; then
            :                                   # пока ждали, VPN включили обратно — доводить нечего
        elif ! carrier_left; then
            echo "$(date '+%Y-%m-%d %H:%M:%S') vpn-toggle: VPN выключили посреди чужой смены несущей — ждал ${_osw} с, ничего не вернулось" >> "$WD_LOG" 2>/dev/null
        else
            echo "$(date '+%Y-%m-%d %H:%M:%S') vpn-toggle: VPN выключили посреди чужой смены несущей — довожу выключение (ждал ${_osw} с)" >> "$WD_LOG" 2>/dev/null
            OFF_SETTLE=1
            cmd_off >/dev/null 2>&1
        fi
        settle_lock_drop
    fi
    rm -f "$SETTLE_PID" 2>/dev/null
}




cmd_flag_clear() {
    _onl=0; settle_lock_take && _onl=1
    rm -f "$VPN_OFF_FLAG" 2>/dev/null
    [ "$_onl" = 1 ] && settle_lock_drop
    return 0
}
carrier_left() {
    [ -f "$ENODIA_DIR/transport.sh" ] || return 0
    sh "$ENODIA_DIR/transport.sh" live >/dev/null 2>&1
    [ "$?" != 1 ]
}






active_transport() {
    _at=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    if [ -z "$_at" ]; then
        _at=awg
        if [ -f "$ENODIA_DIR/transport.sh" ]; then
            sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1
            [ "$?" = 1 ] && _at=none
        fi
    fi
    printf '%s' "$_at"
}
















REPAIR_CARRIER=1
cmd_rules() { REPAIR_CARRIER=0; cmd_repair; }
cmd_repair() {







    repair_off=0
    if [ -f "$VPN_OFF_FLAG" ]; then
        repair_off=1
        echo "VPN выключен человеком — правила VPN не переигрываю, возвращаю только блокировки, запрет IPv6 и «доступ домой» (включить VPN: тумблер в панели или vpn-toggle.sh on)"
    fi









    repair_t=$(active_transport)


    if [ "$REPAIR_CARRIER" = 1 ] && [ "$repair_off" = 0 ] && [ "$repair_t" = "awg" ] && ! ip link show awg0 >/dev/null 2>&1; then







        if [ -f "$ENODIA_DIR/transport.sh" ] && ! sh "$ENODIA_DIR/transport.sh" list 2>/dev/null | grep -qx awg; then
            echo "AmneziaWG выбран транспортом, но его бинарей на роутере нет."
            echo "  Установите компонент «AmneziaWG» в панели: «Компоненты» — heal тут не поможет."
            return 1
        fi





        echo "awg0 не поднят — сначала запустите heal.sh:"
        echo "  rm -f $HEAL_LOCK && sh $ENODIA_BOOT/boot.sh heal.sh"
        return 1
    fi






    if [ "$repair_off" = 1 ]; then
        :
    elif [ "$repair_t" = none ]; then


        echo "транспорт не настроен — ядро маркировки и несущую пропускаю"
    elif [ -f "$ENODIA_DIR/mark-core.sh" ]; then
        sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1
    else
        ip rule del fwmark $MARK table $TABLE 2>/dev/null
        ip rule add fwmark $MARK table $TABLE pref 99
        for set in "$ENODIA_LIST" "$IPLIST_SET"; do
            if ipset list -n 2>/dev/null | grep -qx "$set"; then
                iptables -t mangle -C PREROUTING -m set --match-set "$set" dst -j MARK --set-mark $MARK 2>/dev/null || \
                    iptables -t mangle -A PREROUTING -m set --match-set "$set" dst -j MARK --set-mark $MARK
                iptables -t mangle -C OUTPUT -m set --match-set "$set" dst -j MARK --set-mark $MARK 2>/dev/null || \
                    iptables -t mangle -A OUTPUT -m set --match-set "$set" dst -j MARK --set-mark $MARK
            fi
        done
    fi








    if [ "$repair_off" = 1 ]; then
        :
    elif [ "$repair_t" = none ]; then
        echo "транспорт не настроен — вырезы «мимо VPN» не переигрываю"
    else
        ensure_chain



        [ -f "$ENODIA_DIR/apply-bypass.sh" ] && sh "$ENODIA_DIR/apply-bypass.sh" apply >/dev/null 2>&1
    fi


    if [ "$repair_off" = 1 ] || [ "$repair_t" = none ] || [ "$REPAIR_CARRIER" = 0 ]; then
        :
    elif [ "$repair_t" = "awg" ]; then

        ip route replace default dev awg0 table $TABLE 2>/dev/null
        iptables -t nat -C POSTROUTING -o awg0 -j MASQUERADE 2>/dev/null || \
            iptables -t nat -A POSTROUTING -o awg0 -j MASQUERADE
        mss_clamp awg0
        ipt_top FORWARD -o awg0 -j ACCEPT
        ipt_top FORWARD -i awg0 -j ACCEPT
    elif [ -f "$ENODIA_DIR/transport.sh" ]; then






        _rpu="/tmp/enodia-repair-up.$$"
        if ! sh "$ENODIA_DIR/transport.sh" up "$repair_t" >"$_rpu" 2>&1; then
            echo "ВНИМАНИЕ: несущая $repair_t не поднялась — правила восстановлены, поднимать её будет сторож:"
            tail -n 3 "$_rpu"
        fi
        rm -f "$_rpu" 2>/dev/null
    fi





    [ "$repair_off" = 0 ] && [ -f "$ENODIA_DIR/zapret.sh" ] && [ -f "$ENODIA_STATE/.zapret-on" ] && sh "$ENODIA_DIR/zapret.sh" apply >/dev/null 2>&1





    [ "$repair_off" = 0 ] && [ -f "$ENODIA_DIR/slots.sh" ] && [ -n "$(sh "$ENODIA_DIR/slots.sh" list-enabled 2>/dev/null)" ] && \
        [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" slots-up >/dev/null 2>&1









    [ -f "$ENODIA_DIR/vpn-server.sh" ] && [ -f "$ENODIA_STATE/server/.on" ] && \
        sh "$ENODIA_DIR/vpn-server.sh" up >/dev/null 2>&1







    [ -f "$ENODIA_DIR/lists-update.sh" ] && sh "$ENODIA_DIR/lists-update.sh" wire ipblock >/dev/null 2>&1
    [ -f "$ENODIA_DIR/geo.sh" ] && sh "$ENODIA_DIR/geo.sh" wire >/dev/null 2>&1
    [ -f "$ENODIA_DIR/net-tune.sh" ] && sh "$ENODIA_DIR/net-tune.sh" apply >/dev/null 2>&1


    [ -f "$ENODIA_DIR/access-sched.sh" ] && sh "$ENODIA_DIR/access-sched.sh" tick >/dev/null 2>&1



    ct_flush













    if [ "$repair_off" = 1 ]; then echo "OK: блокировки, запрет IPv6 и «доступ домой» восстановлены; VPN остаётся выключенным."
    elif [ "$REPAIR_CARRIER" = 1 ]; then echo "OK: правила восстановлены (транспорт: $repair_t)."
    else echo "OK: правила восстановлены без несущей (транспорт: $repair_t)."; fi
}

cmd_on() {


    cmd_flag_clear






    restore_cron























    if [ "$(active_transport)" = awg ] && ! ip link show awg0 >/dev/null 2>&1 \
       && [ ! -e "$SWITCH_LOCK" ] \
       && [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" ready awg >/dev/null 2>&1; then
        echo "Несущая AmneziaWG не поднята — поднимаю awg0…"
        _sl=0



        if : > "$SWITCH_LOCK" 2>/dev/null; then
            _sl=1
            trap 'rm -f "$SWITCH_LOCK" 2>/dev/null' EXIT
            trap 'exit 1' HUP INT TERM PIPE
        fi
        _up=$(sh "$ENODIA_DIR/transport.sh" up awg 2>&1)
        if [ "$_sl" = 1 ]; then
            trap - EXIT HUP INT TERM PIPE
            rm -f "$SWITCH_LOCK" 2>/dev/null
        fi
        if ip link show awg0 >/dev/null 2>&1; then
            echo "awg0 поднят."
        else
            echo "awg0 поднять не удалось:"
            echo "$_up" | tail -n 3
        fi
    fi


    cmd_repair || return 1







    if [ -f "$ENODIA_DIR/heal.sh" ]; then
        echo "Возвращаю группы, гео, списки, десинк и доп-выходы…"











        _rpf="/tmp/enodia-vpn-on-replay.$$"
        sh "$ENODIA_DIR/heal.sh" replay >"$_rpf" 2>/dev/null; _rc=$?
        _rp=$(cat "$_rpf" 2>/dev/null); rm -f "$_rpf" 2>/dev/null
        if [ -n "$_rp" ]; then echo "$_rp"; fi



        if [ "$_rc" = 3 ]; then
            echo "ВНИМАНИЕ: персист подсистем НЕ переигран — группы, гео, списки и десинк вернутся только после повтора: нажмите «Включить VPN» ещё раз, когда закончится смена сервера."
        elif [ "$_rc" != 0 ]; then
            echo "ВНИМАНИЕ: персист подсистем НЕ переигран (код $_rc) — группы, гео, списки и десинк могут не работать; разбор в /tmp/enodia-startup.log."
        fi
    fi
    echo "VPN глобально ВКЛЮЧЁН."
}
restore_cron() { if [ -f "$ENODIA_DIR/uninstall.sh" ]; then sh "$ENODIA_DIR/uninstall.sh" cron-restore >/dev/null 2>&1 || true; fi; }

cmd_exclude() {
    IP=$1
    [ -z "$IP" ] && { echo "укажите IP: vpn-toggle.sh exclude 192.168.31.50"; exit 1; }
    ensure_chain
    iptables -t mangle -C "$EXCLUDE_CHAIN_PRE" -s "$IP" -j ACCEPT 2>/dev/null && {
        echo "IP $IP уже исключён"; exit 0
    }
    iptables -t mangle -A "$EXCLUDE_CHAIN_PRE" -s "$IP" -j ACCEPT



    N=$(ct_flush_src_n "$IP")


    [ -f "$ENODIA_DIR/apply-bypass.sh" ] && sh "$ENODIA_DIR/apply-bypass.sh" add-ip "$IP" >/dev/null 2>&1
    echo "IP $IP исключён из VPN (трафик пойдёт напрямую).${N:+ Сброшено conntrack-записей: $N}"
    echo "Не забудьте на устройстве: ipconfig /flushdns"
}

cmd_include() {
    IP=$1
    [ -z "$IP" ] && { echo "укажите IP: vpn-toggle.sh include 192.168.31.50"; exit 1; }
    if iptables -t mangle -D "$EXCLUDE_CHAIN_PRE" -s "$IP" -j ACCEPT 2>/dev/null; then
        N=$(ct_flush_src_n "$IP")
        echo "IP $IP возвращён в VPN.${N:+ Сброшено conntrack-записей: $N}"
    else
        echo "IP $IP не был в исключениях."
    fi

    [ -f "$ENODIA_DIR/apply-bypass.sh" ] && sh "$ENODIA_DIR/apply-bypass.sh" del-ip "$IP" >/dev/null 2>&1
}

cmd_excluded() {
    iptables -t mangle -L "$EXCLUDE_CHAIN_PRE" -n 2>/dev/null | awk '/ACCEPT/{print $4}'
}

case "$1" in
    status|"")    cmd_status ;;
    off)          cmd_off ;;
    off-settle)   cmd_off_settle ;;     # внутренний: фон доводчика выключения (cmd_off)
    flag-clear)   cmd_flag_clear ;;     # внутренний: снять флаг выключения под локом доводчика (transport.sh switch --home)
    on)           cmd_on ;;
    repair)       cmd_repair ;;
    rules)        cmd_rules ;;
    exclude)      cmd_exclude "$2" ;;
    include)      cmd_include "$2" ;;
    excluded)     cmd_excluded ;;
    *)
        echo "Использование: $0 {status|on|off|repair|rules|exclude IP|include IP|excluded}"
        exit 1
        ;;
esac
