#!/bin/sh














































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
NOTIFY="$ENODIA_DIR/notify.sh"
NOTIFY_OFF="$ENODIA_STATE/.notify-off"
EVENTS="$ENODIA_DIR/events.sh"
LOG=/tmp/enodia-notify-event.log





if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}

KEY="$1"
THROTTLE="$2"
SUBJECT="$3"
BODY="$4"







if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi
command -v router_relabel >/dev/null 2>&1 && SUBJECT=$(router_relabel "$SUBJECT")

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >>"$LOG"; }










[ -f "$EVENTS" ] && sh "$EVENTS" add "$KEY" "$THROTTLE" "$SUBJECT" "$BODY" >/dev/null 2>&1


if [ -f "$NOTIFY_OFF" ]; then
    log "notify-event: .notify-off — пропуск '$SUBJECT' (key=$KEY)"
    exit 0
fi




if [ -f "$EVENTS" ]; then
    sh "$EVENTS" mail-ok "$KEY" >/dev/null 2>&1
    case "$?" in
        3) log "notify-event: повод выключен в панели — пропуск '$SUBJECT' (key=$KEY)"; exit 0 ;;
        4) log "notify-event: VPN выключен вручную — письмо о VPN не шлю '$SUBJECT' (key=$KEY)"; exit 0 ;;
    esac
fi



[ -f "$NOTIFY" ] || { log "notify-event: нет $NOTIFY — пропуск '$SUBJECT'"; exit 0; }


safe_key=$(printf '%s' "$KEY" | tr -c 'a-zA-Z0-9_-' '_')
STAMP="/tmp/enodia-notify-event.$safe_key.stamp"



now=$(date +%s)
case "$THROTTLE" in ''|*[!0-9]*) THROTTLE=0 ;; esac
if [ "$THROTTLE" -gt 0 ] && [ -f "$STAMP" ]; then
    last=$(cat "$STAMP" 2>/dev/null)
    case "$last" in ''|*[!0-9]*) last=0 ;; esac
    _age=$(age_since "$last")
    if [ "$last" -gt 0 ] && [ "$_age" -lt "$THROTTLE" ]; then
        log "notify-event: throttle (${_age}с < ${THROTTLE}с) — пропуск '$SUBJECT' (key=$safe_key)"
        exit 0
    fi
fi








sh "$NOTIFY" "$SUBJECT" "$BODY" >>"$LOG" 2>&1; _nrc=$?
if [ "$_nrc" = 3 ]; then
    log "notify-event: почта не настроена — письмо '$SUBJECT' не ушло (key=$safe_key)"
    exit 0
elif [ "$_nrc" = 0 ]; then
    echo "$now" > "$STAMP"
    log "notify-event: отправлено '$SUBJECT' (key=$safe_key)"
    exit 0
else
    log "notify-event: notify.sh НЕ подтвердил отправку '$SUBJECT' (key=$safe_key) — повтор при след. событии"
    exit 1
fi
