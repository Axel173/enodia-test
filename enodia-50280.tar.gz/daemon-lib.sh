#!/bin/sh































DAEMON_WAIT_STORE=${DAEMON_WAIT_STORE:-60}



DAEMON_PID_GRACE=${DAEMON_PID_GRACE:-3}

DAEMON_WAIT_WHY=''


daemon_wait_secs() {   # $1 = имя бинаря ; $2 = срок для флеша ; -> секунды
    _dws=${2:-8}
    if daemon_on_store "$1" && [ "$_dws" -lt "$DAEMON_WAIT_STORE" ]; then _dws=$DAEMON_WAIT_STORE; fi
    printf '%s' "$_dws"
}



daemon_on_store() {   # $1 = имя бинаря
    command -v bin_on_store >/dev/null 2>&1 || return 1
    bin_on_store "$1"
}







daemon_where_ru() {   # $1 = имя бинаря
    if daemon_on_store "$1"; then printf 'на накопителе'; return 0; fi
    command -v bin_where >/dev/null 2>&1 || { printf 'носитель неизвестен'; return 0; }
    case "$(bin_where "$1" 2>/dev/null)" in
        '') printf 'не найден' ;;
        *)  printf 'на флеше роутера' ;;
    esac
}








pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }









lists_work_alive() {
    _lwa=$(cat /proc/[0-9]*/cmdline 2>/dev/null | tr '\000' '\n')
    printf '%s\n' "$_lwa" | grep -qxF -e "$ENODIA_DIR/lists-update.sh" -e "$ENODIA_DIR/geo.sh" -e "$ENODIA_DIR/iplist-update.sh"
}







switch_holder_mark() { ENODIA_SWITCH_HOLDER=$$; export ENODIA_SWITCH_HOLDER; }



switch_work_alive() {   # $1 — пид держателя из лока
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    for _swf in $(grep -l "ENODIA_SWITCH_HOLDER=$1" /proc/[0-9]*/environ 2>/dev/null); do
        tr '\000' '\n' 2>/dev/null < "$_swf" | grep -qxF "ENODIA_SWITCH_HOLDER=$1" || continue
        tr '\000' '\n' 2>/dev/null < "${_swf%/environ}/cmdline" | awk -v d="$ENODIA_DIR/" \
            'substr($0, 1, length(d)) == d && substr($0, length($0) - 2) == ".sh" { f = 1 } END { exit f ? 0 : 1 }' && return 0
    done
    return 1
}






DL_WD_LOCK=${ENODIA_WD_LOCK:-/tmp/enodia-watchdog.lock}
DL_WD_PID=${ENODIA_WD_PID:-/tmp/enodia-watchdog.pid}
DL_HEAL_LOCK=${ENODIA_HEAL_LOCK:-/tmp/enodia-heal.lock}
wd_tick_alive() {
    [ -e "$DL_WD_LOCK" ] || return 1
    _wta=$(cat "$DL_WD_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_wta" 'watchdog\.sh'
}




DL_REPLAY_PID=${ENODIA_REPLAY_PID:-/tmp/enodia-heal-replay.pid}
heal_alive() {
    _hla=$(cat "$DL_HEAL_LOCK" 2>/dev/null | tr -d '\r'); _hla=${_hla%% *}
    case "$_hla" in ''|*[!0-9]*) _hla= ;; esac
    [ -n "$_hla" ] && pid_runs "$_hla" 'heal\.sh' && return 0
    _hlr=$(cat "$DL_REPLAY_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_hlr" 'heal\.sh'
}




DL_MODE_PID=${ENODIA_MODE_PID:-/tmp/enodia-store-mode.pid}
store_mode_alive() {
    _sma=$(cat "$DL_MODE_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_sma" 'usb-offload\.sh.* mode'
}



DL_PKG_LOCK=${ENODIA_PKG_INST_LOCK:-/tmp/enodia-pkg-install.lock}
pkg_install_alive() {
    _pia=$(cat "$DL_PKG_LOCK/pid" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_pia" 'pkg-install\.sh'
}



DL_UNINST_PID=${ENODIA_UNINST_PID:-/tmp/enodia-uninstall.pid}
uninstall_alive() {
    _ual=$(cat "$DL_UNINST_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_ual" 'uninstall\.sh (deactivate|purge)'
}










carrier_barred() { [ -f "$ENODIA_STATE/.vpn-off" ]; }
_crlog() { if command -v log >/dev/null 2>&1; then log "$1"; else echo "$1"; fi; }

carrier_run() {
    _cru=$1; _crf=$2; shift 2
    if carrier_barred; then _crlog "VPN выключен вручную — несущую не поднимаю"; return 1; fi
    "$_crf" "$@"; _crr=$?
    carrier_barred || return "$_crr"
    _crlog "VPN выключили вручную, пока поднималась несущая, — отпускаю её"
    "$_cru" "$@" >/dev/null 2>&1
    return 1
}




exe_deleted() { ls -l /proc/[0-9]*/exe 2>/dev/null | sed -n 's#^.* /proc/\([0-9][0-9]*\)/exe -> \(.*\) (deleted)$#\1 \2#p'; }





daemon_wait_gone() {   # $1 pid ; $2 потолок, с (по умолчанию 5) -> 0 процесса нет, 1 ещё жив
    case "$1" in ''|*[!0-9]*) return 0 ;; esac
    _dwg=0; _dwgm=$(( ${2:-5} * 10 ))
    while [ -d "/proc/$1" ]; do
        [ "$_dwg" -ge "$_dwgm" ] && return 1
        if command -v usleep >/dev/null 2>&1; then usleep 100000; else sleep 1; _dwg=$((_dwg+9)); fi
        _dwg=$((_dwg+1))
    done
    return 0
}
daemon_port_listens()  { netstat -ltn 2>/dev/null | grep -q "$1:$2 "; }
daemon_uport_listens() { netstat -lnu 2>/dev/null | grep -q "$1:$2 "; }   # UDP: резолвер DoH/DoT
daemon_dev_exists()    { ip link show "$1" >/dev/null 2>&1; }




_daemon_wait() {   # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 «чего ждём» словами ; далее — КОМАНДА-проба
    _dwpid="$1"; _dwbin="$2"; _dwwhat="$4"
    _dwmax=$(daemon_wait_secs "$_dwbin" "$3")
    shift 4



    _dwi=0; _dwt=0; _dwq=1; command -v usleep >/dev/null 2>&1 && _dwq=5
    while :; do
        if "$@"; then DAEMON_WAIT_WHY=''; return 0; fi






        _dwp=$(cat "$_dwpid" 2>/dev/null | tr -d ' \r\n')
        if [ -z "$_dwp" ]; then
            if [ "$_dwi" -ge "$DAEMON_PID_GRACE" ]; then
                DAEMON_WAIT_WHY="процесс НЕ ЗАПУСТИЛСЯ (пидфайл $_dwpid пуст через $_dwi с), $_dwwhat не появился"
                return 1
            fi
        elif [ ! -d "/proc/$_dwp" ]; then
            DAEMON_WAIT_WHY="процесс УМЕР через $_dwi с — $_dwwhat не появился"
            return 1
        fi
        [ "$_dwi" -ge "$_dwmax" ] && break
        if [ "$_dwq" = 5 ]; then usleep 200000; else sleep 1; fi
        _dwt=$((_dwt+1)); _dwi=$((_dwt/_dwq))
    done
    DAEMON_WAIT_WHY="процесс ЖИВ, но за $_dwmax с $_dwwhat не появился (бинарь $_dwbin $(daemon_where_ru "$_dwbin"))"
    return 1
}


daemon_wait_port() {   # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 адрес ; $5 порт
    _daemon_wait "$1" "$2" "$3" "порт $4:$5" daemon_port_listens "$4" "$5"
}



daemon_wait_uport() {  # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 адрес ; $5 порт
    _daemon_wait "$1" "$2" "$3" "порт $4:$5/udp" daemon_uport_listens "$4" "$5"
}


daemon_wait_dev() {    # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 имя интерфейса
    _daemon_wait "$1" "$2" "$3" "устройство $4" daemon_dev_exists "$4"
}
