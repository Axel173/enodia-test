#!/bin/sh












LOCK=/tmp/enodia-heal.lock




DOMWARM_STAMP=${DOMWARM_STAMP:-/tmp/enodia-domwarm.stamp}
SWITCH_LOCK=/tmp/enodia-switching.lock







HEAL_SKIPPED=/tmp/enodia-heal.skipped
LOG=/tmp/enodia-startup.log
ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}   # для ПОДСКАЗОК в письмах: команду человеку даём только через запускатель
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
TABLE=1000






[ -d "$ENODIA_STATE" ] || { mkdir -p "$ENODIA_STATE" 2>/dev/null; chmod 700 "$ENODIA_STATE" 2>/dev/null; }
[ -d "$ENODIA_BIN" ]   || { mkdir -p "$ENODIA_BIN" 2>/dev/null; chmod 755 "$ENODIA_BIN" 2>/dev/null; }







if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi


if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi
command -v lan_if >/dev/null 2>&1 || lan_if() { echo br-lan; }   # lan-lit: шим без router-lib.sh
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }




if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}


if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }



if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
command -v doh_enabled >/dev/null 2>&1 || doh_enabled() { return 1; }
command -v doh_want >/dev/null 2>&1 || doh_want() { return 1; }   # старая lib без авто-режима




if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }




















REPLAY=0
if [ "${1:-}" = replay ]; then REPLAY=1; fi



REPLAY_HELD=0; [ "$REPLAY" = 1 ] && [ "${2:-}" = held ] && REPLAY_HELD=1

















HEAL_TRY=1
if [ "$REPLAY" = 0 ] && [ -e "$LOCK" ]; then
    _hlk=$(cat "$LOCK" 2>/dev/null | tr -d '\r')
    case "$_hlk" in
        done*|'') exit 0 ;;
    esac
    _hlp=${_hlk%% *}
    case "$_hlp" in ''|*[!0-9]*) exit 0 ;; esac          # непонятное содержимое = чужой лок
    if [ -d "/proc/$_hlp" ]; then




        case "$(tr '\000' ' ' < "/proc/$_hlp/cmdline" 2>/dev/null)" in
            ''|*heal.sh*) exit 0 ;;
        esac
    fi
    _hlr=${_hlk#* }; _hlr=${_hlr%% *}; _hlr=${_hlr#try}  # «try<N>» из второго поля
    case "$_hlr" in ''|*[!0-9]*) _hlr=1 ;; esac
    if [ "$_hlr" -ge 3 ]; then
        echo "done (три прогона подряд оборвались — heal в эту загрузку остановлен) $(date 2>/dev/null)" > "$LOCK" 2>/dev/null
        exit 0
    fi
    HEAL_TRY=$((_hlr + 1))
    rm -f "$LOCK" 2>/dev/null
fi






if [ -e "$SWITCH_LOCK" ]; then



    if [ "$REPLAY" = 0 ]; then
        : > "$HEAL_SKIPPED" 2>/dev/null || true
        exit 0
    fi








    _rw=0
    while [ "$REPLAY_HELD" = 0 ] && [ -e "$SWITCH_LOCK" ] && [ "$_rw" -lt 15 ]; do sleep 1; _rw=$((_rw + 1)); done
    if [ "$REPLAY_HELD" = 0 ] && [ -e "$SWITCH_LOCK" ]; then
        echo "Переигрыш НЕ выполнен: идёт смена транспорта/сервера (занят $SWITCH_LOCK). Персист подсистем не тронут — повторите, когда операция закончится."
        echo "===== heal.sh replay $(date 2>/dev/null): отказ, занят $SWITCH_LOCK =====" >> "$LOG" 2>/dev/null
        exit 3
    fi
fi




REPLAY_PID=/tmp/enodia-heal-replay.pid
if [ "$REPLAY" = 1 ]; then
    echo $$ > "$REPLAY_PID" 2>/dev/null
    trap '[ "$(cat "$REPLAY_PID" 2>/dev/null)" = "$$" ] && rm -f "$REPLAY_PID" 2>/dev/null' EXIT
    trap 'exit 1' HUP INT TERM
fi

if [ "$REPLAY" = 0 ]; then











    ( set -C; echo "$$ try$HEAL_TRY $(date 2>/dev/null)" > "$LOCK" ) 2>/dev/null || exit 0






    i=0
    while [ $i -lt 6 ]; do
        ip route get 1.1.1.1 >/dev/null 2>&1 && break
        sleep 5; i=$((i+1))
    done

    : > "$LOG"
else



    exec 3>&1
fi
exec >>"$LOG" 2>&1
if [ "$REPLAY" = 1 ]; then
    echo "===== heal.sh replay $(date) ====="
else
    echo "===== heal.sh $(date) ====="
fi

cd "$ENODIA_DIR" || exit 1








active_t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')








if [ -z "$active_t" ]; then
    active_t=awg                                   # исторический фолбэк: роутер старше флага
    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1
        [ "$?" = 1 ] && active_t=none
    fi
fi















vpn_off=0
vpn_off_now() { [ -f "$ENODIA_STATE/.vpn-off" ] && vpn_off=1; [ "$vpn_off" = 1 ]; }
vpn_off_now
skip_vpn() { [ "$active_t" = none ] || vpn_off_now; }
why_skip() { if [ "$vpn_off" = 1 ]; then echo "VPN выключен человеком"; else echo "транспорт не настроен"; fi; }







[ -f "$ENODIA_DIR/usb-offload.sh" ] && sh "$ENODIA_DIR/usb-offload.sh" mount-ensure














active_ready=1
if [ "$active_t" != none ] && [ -f "$ENODIA_DIR/transport.sh" ]; then
    sh "$ENODIA_DIR/transport.sh" ready "$active_t" >/dev/null 2>&1
    [ "$?" = 1 ] && active_ready=0
fi




awg_ready=1
if [ -f "$ENODIA_DIR/transport.sh" ]; then
    sh "$ENODIA_DIR/transport.sh" ready awg >/dev/null 2>&1
    [ "$?" = 1 ] && awg_ready=0
fi




















if [ "$REPLAY" = 0 ] && command -v clock_boot_sync >/dev/null 2>&1 && ! clock_synced; then
    echo "--- часы: сверка с HTTP-датой мимо туннеля (DNS-free; до панели и несущей) ---"
    clock_boot_sync || true
    [ -n "$CLOCK_MSG" ] && echo "$CLOCK_MSG"
fi







if [ "$REPLAY" = 0 ] && [ -f ./web-ui.sh ] && ip -4 addr show "$(lan_if)" 2>/dev/null | grep -q 'inet '; then
    echo "--- панель: поднимаю uhttpd:8088 (рано, до сетевых шагов) ---"



    sh ./web-ui.sh start 2>&1 3>&- || true
fi












if [ "$REPLAY" = 0 ] && vpn_off_now && [ -f "$ENODIA_STATE/awg.conf" ]; then
    echo "VPN выключен человеком — awg0 не поднимаю даже тёплым резервом (везти ему нечего)"
elif [ "$REPLAY" = 0 ] && [ -f "$ENODIA_STATE/awg.conf" ] && [ "$awg_ready" = 0 ]; then
    echo "awg.conf есть, а компонента AmneziaWG нет (бинари не установлены) — awg0 не трогаю"
elif [ "$REPLAY" = 0 ] && [ -f "$ENODIA_STATE/awg.conf" ]; then
    echo "--- preparing awg config ---"
    if grep -qE '^I[1-5]\s*=\s*$' "$ENODIA_STATE/awg.conf" 2>/dev/null; then
        sed -i '/^I[1-5]\s*=\s*$/d' "$ENODIA_STATE/awg.conf"
        echo "cleaned empty I1..I5 from awg.conf"
    fi

    if [ ! -f "$ENODIA_STATE/amnezia_for_awg.conf" ]; then
        cp "$ENODIA_STATE/awg.conf" "$ENODIA_STATE/amnezia_for_awg.conf"
        echo "amnezia_for_awg.conf recreated from awg.conf"
    fi

    if [ -f "$ENODIA_STATE/awg0.conf" ] && grep -qE '^I[1-5]\s*=\s*$' "$ENODIA_STATE/awg0.conf"; then
        sed -i '/^I[1-5]\s*=\s*$/d' "$ENODIA_STATE/awg0.conf"
    fi


    echo "--- bringing up awg0 ---"
    ip link del awg0 2>/dev/null
    sh ./awg_setup.sh
fi






mkdir -p /etc/dnsmasq.d


if [ "$REPLAY" = 1 ]; then
    echo "DNS: replay — upstream не трогаю (его владелец — активный транспорт / DoH)"
elif skip_vpn || [ "$active_ready" = 0 ]; then




    _dnswhy=$(why_skip); skip_vpn || _dnswhy="транспорт $active_t выбран, но поднять его нечем"























    if command -v doh_apply_dns >/dev/null 2>&1 && doh_apply_dns direct; then
        echo "DNS: $_dnswhy — резолв ведёт шифрованный DNS (прямой режим), upstream не трогаю"
    elif command -v doh_release_upstream >/dev/null 2>&1 && doh_release_upstream; then
        echo "DNS: $_dnswhy — снял указатель на погашенный шифрованный DNS, резолв стоковый"
    elif [ -f /etc/dnsmasq.d/00-upstream.conf ] || [ -f /tmp/dnsmasq.d/00-upstream.conf ]; then






        _dnsprv=0
        command -v is_private_ip >/dev/null 2>&1 || _dnsprv=1
        for _dnsf in /etc/dnsmasq.d/00-upstream.conf /tmp/dnsmasq.d/00-upstream.conf; do
            [ -f "$_dnsf" ] || continue
            for _dnsa in $(sed -n 's/^server=\([0-9][0-9.]*\).*/\1/p' "$_dnsf" 2>/dev/null); do
                command -v is_private_ip >/dev/null 2>&1 && is_private_ip "$_dnsa" && _dnsprv=1
            done
        done
        if [ "$_dnsprv" = 1 ]; then
            rm -f /etc/dnsmasq.d/00-upstream.conf /tmp/dnsmasq.d/00-upstream.conf 2>/dev/null
            echo "DNS: $_dnswhy — снял наш upstream (в нём остался туннельный адрес), резолв стоковый"
        else
            echo "DNS: $_dnswhy — в upstream публичный резолвер, он работает и без туннеля — не трогаю"
        fi
    else
        echo "DNS: $_dnswhy — нашего upstream нет, резолв стоковый (как у стока)"
    fi
elif [ "$active_t" = awg ] && { [ -f ./transport.sh ] || [ -f ./transport-awg.sh ]; }; then











    echo "DNS: upstream ставит плагин awg при подъёме несущей (5.6) — на буте не трогаю"
elif [ "$active_t" = awg ]; then

    VPN_DNS=$(grep -E '^DNS\s*=' "$ENODIA_STATE/awg.conf" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | awk -F',' '{print $1}' | tr -d ' ')
    [ -z "$VPN_DNS" ] && VPN_DNS=172.29.172.254
    echo "VPN_DNS: $VPN_DNS (нет плагина awg — ставлю сам)"
    cat > /etc/dnsmasq.d/00-upstream.conf <<UPSTREAM
no-resolv
server=$VPN_DNS
UPSTREAM
else
    echo "DNS: транспорт $active_t — upstream ставит его плагин (секция 5.6), туннельный DNS не прописываю"
fi


grep -q '^conf-dir=/etc/dnsmasq.d' /etc/dnsmasq.conf || \
    echo 'conf-dir=/etc/dnsmasq.d,*.conf' >> /etc/dnsmasq.conf









if [ -f ./domain.sh ]; then
    echo "--- custom domains: восстановление из персиста (.enodia-custom.conf) ---"
    sh ./domain.sh restore || true
fi






if skip_vpn && [ ! -s "$ENODIA_STATE/.enodia-custom.conf" ]; then
    echo "$(why_skip), доменных правил нет — сеты не развожу (нечего)"
else
    [ -f ./domain.sh ] && sh ./domain.sh apply 2>/dev/null || true
fi









if [ -f "$ENODIA_STATE/.dhcp-static" ] && [ -f ./dhcp-static.sh ]; then
    echo "--- dhcp: восстановление закреплённых адресов ---"
    sh ./dhcp-static.sh apply norestart 2>/dev/null || true
fi





[ "$active_t" = awg ] && [ -n "$VPN_DNS" ] && ip route replace "$VPN_DNS/32" dev awg0 2>/dev/null




sh "$ENODIA_DIR/dns-merge.sh" reload 2>/dev/null || /etc/init.d/dnsmasq restart 2>/dev/null






ipset list -n 2>/dev/null | grep -qx enodia_list || \
    ipset create enodia_list hash:net family inet hashsize 1024 maxelem 1000000




_ipl_n=$(ipset list iplist_set 2>/dev/null | grep -c '^[0-9]' || true)
case "$_ipl_n" in ''|*[!0-9]*) _ipl_n=0 ;; esac
if [ "$REPLAY" = 1 ] && [ "$_ipl_n" -gt 0 ]; then
    echo "iplist: replay — набор уже наполнен ($_ipl_n), перекачку пропускаю"
elif [ -f ./iplist-update.sh ]; then
    sh ./iplist-update.sh
fi





echo "--- mark-core (ядро: маркировка + ip rule) ---"
if skip_vpn; then



    echo "$(why_skip) — ядро маркировки не ставлю (роутер работает как сток)"
elif [ -f ./mark-core.sh ]; then
    sh ./mark-core.sh
elif [ -f ./split-route.sh ]; then
    sh ./split-route.sh
else
    ip rule del fwmark 0x1 table $TABLE 2>/dev/null
    ip rule add fwmark 0x1 table $TABLE pref 99
    for set in enodia_list iplist_set; do
        if ipset list -n 2>/dev/null | grep -qx "$set"; then
            iptables -t mangle -C PREROUTING -m set --match-set "$set" dst -j MARK --set-mark 0x1 2>/dev/null || \
                iptables -t mangle -A PREROUTING -m set --match-set "$set" dst -j MARK --set-mark 0x1
            iptables -t mangle -C OUTPUT -m set --match-set "$set" dst -j MARK --set-mark 0x1 2>/dev/null || \
                iptables -t mangle -A OUTPUT -m set --match-set "$set" dst -j MARK --set-mark 0x1
        fi
    done
fi












if skip_vpn; then
    echo "$(why_skip) — вырезы «мимо VPN» не переигрываю (нечего и не от чего)"
elif [ -f ./apply-bypass.sh ]; then
    echo "--- restoring bypass carve-outs ---"
    sh ./apply-bypass.sh apply
fi





echo "--- active transport: $active_t ---"













if [ "$active_ready" = 0 ] && [ "$active_t" != awg ] && ! skip_vpn && [ -f ./transport.sh ] && sh ./transport.sh ready "$active_t" >/dev/null 2>&1; then
    echo "транспорт $active_t: программа появилась, пока heal бежал (накопитель примонтировался) — поднимаю"
    active_ready=1
fi
if skip_vpn; then
    if [ "$vpn_off" = 1 ]; then
        echo "VPN выключен человеком — несущую не поднимаю (включить: тумблер в панели :8088)"
    else
        echo "транспорт не настроен — несущую не поднимаю (всё через панель: «Компоненты» → «Серверы»)"
    fi
elif [ "$active_ready" = 0 ]; then









    echo "транспорт $active_t выбран, но поднять его нечем (нет программы/конфига) — несущую не поднимаю, см. панель :8088"
    echo "  (если программа появится позже — например вместе с накопителем, — несущую поднимет сторож)"
elif [ -f ./transport.sh ]; then
    sh ./transport.sh up "$active_t"
else
    case "$active_t" in
        xray) [ -f ./xray-transport.sh ] && sh ./xray-transport.sh up ;;
        *)    [ -f ./transport-awg.sh ] && sh ./transport-awg.sh up ;;
    esac
fi










if [ -f ./zapret.sh ] && [ -f "$ENODIA_STATE/.zapret-on" ] && [ "$active_t" != zapret ]; then
    echo "--- zapret: миграция parallel→transport (снимаю старый параллельный десинк) ---"
    rm -f "$ENODIA_STATE/.zapret-on"
    sh ./zapret.sh apply
fi







if [ -f ./lists-update.sh ]; then



    _optc="adblock ipblock zapret-cidr zapret-dom"   # шим-фолбэк: старый lists-lib.sh без ls_opt_cats
    [ -f ./lists-lib.sh ] && _optc=$( . ./lists-lib.sh 2>/dev/null; ls_opt_cats 2>/dev/null )
    [ -n "$_optc" ] || _optc="adblock ipblock zapret-cidr zapret-dom"
    for bc in $_optc; do





        [ -f "$ENODIA_STATE/lists/$bc/.enabled" ] || continue




        sh ./lists-update.sh reapply "$bc" >/dev/null 2>&1 || true
        echo "--- blocklist $bc включён — фоновая перекачка списков в ОЗУ ---"



        start-stop-daemon -S -b -m -p "/tmp/enodia-lists-$bc.pid" \
            -x /bin/sh -- "$ENODIA_DIR/lists-update.sh" update "$bc" 3>&-
    done
fi




if [ -f ./dns-hosts.sh ] && [ -s "$ENODIA_STATE/.dns-hosts" ]; then
    echo "--- DNS-hosts: переигрываю оверрайды ---"
    sh ./dns-hosts.sh apply >/dev/null 2>&1
fi






if [ -f ./dns-split.sh ] && [ -f "$ENODIA_STATE/.split-runet" ]; then
    echo "--- split-runet: переигрываю раздельный резолв рунета ---"
    sh ./dns-split.sh apply >/dev/null 2>&1
fi



if [ -f ./net-tune.sh ]; then
    sh ./net-tune.sh apply >/dev/null 2>&1
fi







if [ -f ./groups.sh ] && [ -s "$ENODIA_STATE/groups/groups.tsv" ]; then
    echo "--- groups: переигрываю группы правил ---"
    sh ./groups.sh apply 2>&1 | tail -1
fi





if [ -f ./geo.sh ] && [ -s "$ENODIA_STATE/geo/actions.tsv" ]; then
    echo "--- geo: офлайн-восстановление гео-категорий из снимка ---"
    sh ./geo.sh reapply 2>&1 | tail -1






    _geo_pid=$(cat /tmp/enodia-geo-update.pid 2>/dev/null | tr -d ' \r\n')
    if [ -n "$_geo_pid" ] && kill -0 "$_geo_pid" 2>/dev/null; then
        echo "--- geo: перекачка уже идёт (её начал импорт настроек) — второй раз не запускаю ---"
    else
        echo "--- geo: фоновая перекачка гео-источников ---"


        start-stop-daemon -S -b -m -p /tmp/enodia-geo-update.pid \
            -x /bin/sh -- "$ENODIA_DIR/geo.sh" update >/dev/null 2>&1 3>&-
    fi
fi










if skip_vpn; then
    echo "$(why_skip) — доп-выходы (слоты) не поднимаю"
elif [ -f ./slots.sh ] && [ -n "$(sh ./slots.sh list-enabled 2>/dev/null)" ]; then
    echo "--- slots: доп-выходы (несущие + слот-марки) ---"



    [ -f ./transport.sh ] && sh ./transport.sh slots-up 3>&-
fi










if [ -f ./vpn-server.sh ] && [ -f "$ENODIA_STATE/server/.on" ]; then
    echo "--- vpn-server: доступ домой (несущая awgs0 + правила) ---"
    sh ./vpn-server.sh up || echo "    [!] доступ домой не поднялся"
fi







if doh_want 2>/dev/null && ! doh_running 2>/dev/null; then
    echo "--- DoH: поднимаю https_dns_proxy (включён/авто, но не запущен) ---"


    doh_start 3>&-
fi







SYSLOG_KB=8192
if command -v uci >/dev/null 2>&1; then
    _cur=$(uci -q get system.@system[0].log_size 2>/dev/null)
    case "$_cur" in ''|*[!0-9]*) _cur=0 ;; esac
    if [ "$_cur" -lt "$SYSLOG_KB" ]; then
        echo "--- syslog: расширяю кольцо ${_cur}K -> ${SYSLOG_KB}K ---"
        uci set system.@system[0].log_size="$SYSLOG_KB" 2>/dev/null && \
        uci commit system 2>/dev/null && \
        /etc/init.d/syslog-ng restart >/dev/null 2>&1
    fi
fi









if [ -f ./domain.sh ]; then
    echo "--- domains: прогрев правил (после подъёма транспорта) ---"



    sleep 1
    _warmout=$(sh ./domain.sh warm 2>&1 || true)
    printf '%s\n' "$_warmout"







    case "$_warmout" in
        *"не попал"*|*ПЕРЕПОЛНЕН*|*"не ответил"*) echo "domains: прогрев прошёл НЕ ПОЛНОСТЬЮ — отметку не ставлю, сторож повторит" ;;
        *) date +%s > "$DOMWARM_STAMP" 2>/dev/null || true ;;
    esac
fi












if [ -f ./web-ui.sh ] && ip -4 addr show "$(lan_if)" 2>/dev/null | grep -q 'inet '; then
    echo "--- панель: второй заход (TLS + доступ снаружи; сама панель уже поднята в 0b) ---"
    sh ./web-ui.sh start 2>&1 3>&- || true
fi



if [ "$REPLAY" = 1 ]; then
    _n_sets=$(ipset list -n 2>/dev/null | grep -c -E '^(awg_|iplist_|grp_|geo_|zapret_)' || true)
    case "$_n_sets" in ''|*[!0-9]*) _n_sets=0 ;; esac
    echo "--- replay: готово (наборов в ядре: $_n_sets) ---"
    echo "Переигрыш завершён: наборов в ядре $_n_sets. Подробности — $LOG" >&3
    exit 0
fi






echo "--- awg0 ---"
_awg_bin=$(bin_path awg); [ -n "$_awg_bin" ] || _awg_bin=./awg
if [ -x "$_awg_bin" ]; then "$_awg_bin" show awg0 2>&1 | head -20
else echo "(awg не установлен — несущая не AmneziaWG)"; fi
echo "--- iplist_set ---"




echo "элементов: $(if [ -f ./lists-lib.sh ]; then . ./lists-lib.sh; ipset_count iplist_set; else echo '?'; fi 2>/dev/null)"
ipset list iplist_set 2>&1 | head -14
echo "--- ip rule ---"
ip rule show
echo "--- FORWARD (first 5) ---"
iptables -L FORWARD -v -n | head -5




echo "--- verdict ---"
NOTIFY_EVENT="$ENODIA_DIR/notify-event.sh"







BOOT_MAIL_THROTTLE=21600


WG=""
[ -x "$ENODIA_BIN/awg" ] && WG="$ENODIA_BIN/awg"
[ -z "$WG" ] && command -v wg >/dev/null 2>&1 && WG=wg

hs=0
if ip link show awg0 >/dev/null 2>&1 && [ -n "$WG" ]; then
    i=0
    while [ $i -lt 25 ]; do
        hs=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
        case "$hs" in ''|*[!0-9]*) hs=0 ;; esac
        [ "$hs" -gt 0 ] && [ "$(age_since "$hs")" -lt 300 ] && break
        sleep 1; i=$((i+1))
    done
fi




heal_t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
[ -z "$heal_t" ] && heal_t=awg

tlabel=$(case "$heal_t" in xray) echo "Xray" ;; hy2) echo "Hysteria2" ;; byedpi) echo "ByeDPI" ;; zapret) echo "Zapret" ;; awg) echo "AmneziaWG" ;; *) echo "$heal_t" ;; esac)
if [ "$heal_t" != "awg" ] && [ -f "$ENODIA_DIR/transport.sh" ]; then


    if "$ENODIA_DIR/transport.sh" health "$heal_t" >/dev/null 2>&1; then hs=$(date +%s); else hs=0; fi
fi



if [ "$heal_t" != "awg" ]; then

    _hl_acta=$(cat "$ENODIA_STATE/.$heal_t-active" 2>/dev/null | tr -d '\r')
    active="$tlabel ${_hl_acta:-?}"
else


    _hl_act=$(cat "$ENODIA_STATE/.active" 2>/dev/null | tr -d '\r')
    active="AmneziaWG ${_hl_act:-?}"
fi
NF_LANG=$(nf_lang)   # язык boot-письма (панельный pref); ru-ветки ниже — байт-в-байт прежние





HEAL_REASON=/tmp/enodia-heal.reason




_heal_unplanned=0
[ -e "$HEAL_REASON" ] && _heal_unplanned=1
heal_why=$(cat "$HEAL_REASON" 2>/dev/null | tr -d ' \r\n')
rm -f "$HEAL_REASON" 2>/dev/null
[ "$_heal_unplanned" = 1 ] && [ -z "$heal_why" ] && heal_why="вручную"
if [ -n "$heal_why" ]; then
    echo "verdict: внеплановый прогон (причина: $heal_why) — бутовое письмо не шлю, о событии сообщает watchdog"
    NOTIFY_EVENT=""
fi



if skip_vpn; then
    if [ "$vpn_off" = 1 ]; then
        echo "verdict: VPN выключен человеком — роутер работает напрямую, включить в панели :8088"
    else
        echo "verdict: транспорт не настроен — роутер работает напрямую, настройка в панели :8088"
    fi
    NOTIFY_EVENT=""
fi




if [ "$active_ready" = 0 ]; then
    echo "verdict: транспорт $active_t выбран, но поднять его нечем (нет программы/конфига) — настройка в панели :8088"
    NOTIFY_EVENT=""
fi
if [ -f "$NOTIFY_EVENT" ]; then
    if [ "$hs" -gt 0 ]; then
        age=$(age_since "$hs")
        ip=$(probe_ext_ip "" 5)
        if [ "$heal_t" != "awg" ]; then hs_line="Проверка связи: OK"; else hs_line="Handshake: ${age} сек назад"; fi
        if [ "$NF_LANG" = en ]; then
            if [ "$heal_t" != "awg" ]; then hs_line="Link check: OK"; else hs_line="Handshake: ${age} s ago"; fi
        fi
        echo "verdict: VPN up (транспорт $heal_t)"
        if [ "$NF_LANG" = en ]; then
            sh "$NOTIFY_EVENT" boot-ok "$BOOT_MAIL_THROTTLE" "BE7000: boot OK, VPN up" \
"After startup/reboot the router brought the tunnel up.
Config: ${active:-?}. ${hs_line}.
External IP: ${ip:-unknown}.

(This email is sent once per boot — if the router rebooted on its own,
that's a signal: power spike, crash, or someone rebooted it.)" >/dev/null 2>&1
        else
            sh "$NOTIFY_EVENT" boot-ok "$BOOT_MAIL_THROTTLE" "BE7000: загрузка OK, VPN поднят" \
"После запуска/перезагрузки роутер поднял туннель.
Конфиг: ${active:-?}. ${hs_line}.
Внешний IP: ${ip:-неизвестен}.

(Письмо приходит раз за загрузку — если роутер ребутнулся сам,
это сигнал: скачок питания, краш или кто-то перезагрузил.)" >/dev/null 2>&1
        fi
    else
        if [ "$heal_t" != "awg" ]; then


            if { [ "$heal_t" = "xray" ] || [ "$heal_t" = "hy2" ]; } && ip link show xtun >/dev/null 2>&1; then
                carrier_state="xtun есть, но проба egress не прошла"
                [ "$NF_LANG" = en ] && carrier_state="xtun exists but egress probe failed"
            elif [ "$heal_t" = "xray" ] || [ "$heal_t" = "hy2" ]; then
                carrier_state="xtun не создан"
                [ "$NF_LANG" = en ] && carrier_state="xtun not created"
            else
                carrier_state="несущая $tlabel не поднялась"
                [ "$NF_LANG" = en ] && carrier_state="$tlabel carrier did not come up"
            fi
            echo "verdict: $heal_t down ($carrier_state)"
            if [ "$NF_LANG" = en ]; then
                sh "$NOTIFY_EVENT" boot-fail "$BOOT_MAIL_THROTTLE" "BE7000: VPN did NOT come up after boot" \
"heal.sh ran, but transport $tlabel did not come up ($carrier_state).
Config: ${active:-?}. Traffic to listed sites is not flowing right now.
Check via SSH: cat /tmp/enodia-startup.log; sh $ENODIA_BOOT/boot.sh status.sh test

(If the VPS is simply dead — the watchdog will switch the router to
direct mode within 2 min and send its own email.)" >/dev/null 2>&1
            else
                sh "$NOTIFY_EVENT" boot-fail "$BOOT_MAIL_THROTTLE" "BE7000: после загрузки VPN НЕ поднялся" \
"heal.sh отработал, но транспорт $tlabel не поднялся ($carrier_state).
Конфиг: ${active:-?}. Трафик к сайтам из списка сейчас не идёт.
Загляните по SSH: cat /tmp/enodia-startup.log; sh $ENODIA_BOOT/boot.sh status.sh test

(Если VPS просто мёртв — watchdog в ближайшие 2 мин переведёт роутер
в прямой режим и пришлёт своё письмо.)" >/dev/null 2>&1
            fi
        else
            if ip link show awg0 >/dev/null 2>&1; then awg0_state="есть, но handshake не пришёл"; else awg0_state="не создан"; fi
            if [ "$NF_LANG" = en ]; then
                if ip link show awg0 >/dev/null 2>&1; then awg0_state="exists but no handshake"; else awg0_state="not created"; fi
            fi
            echo "verdict: awg0 down ($awg0_state)"
            if [ "$NF_LANG" = en ]; then
                sh "$NOTIFY_EVENT" boot-fail "$BOOT_MAIL_THROTTLE" "BE7000: VPN did NOT come up after boot" \
"heal.sh ran, but the tunnel did not come up (awg0: $awg0_state).
Config: ${active:-?}. Traffic to listed sites is not flowing right now.
Check via SSH: cat /tmp/enodia-startup.log; sh $ENODIA_BOOT/boot.sh status.sh test

(If the VPS is simply dead — the watchdog will switch the router to
direct mode within 2 min and send its own email.)" >/dev/null 2>&1
            else
                sh "$NOTIFY_EVENT" boot-fail "$BOOT_MAIL_THROTTLE" "BE7000: после загрузки VPN НЕ поднялся" \
"heal.sh отработал, но туннель не поднялся (awg0: $awg0_state).
Конфиг: ${active:-?}. Трафик к сайтам из списка сейчас не идёт.
Загляните по SSH: cat /tmp/enodia-startup.log; sh $ENODIA_BOOT/boot.sh status.sh test

(Если VPS просто мёртв — watchdog в ближайшие 2 мин переведёт роутер
в прямой режим и пришлёт своё письмо.)" >/dev/null 2>&1
            fi
        fi
    fi
fi



[ "$REPLAY" = 0 ] && echo "done $(date 2>/dev/null)" > "$LOCK" 2>/dev/null
echo "===== heal.sh done $(date) ====="
