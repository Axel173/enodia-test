#!/bin/sh


































































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }
G="$ENODIA_STATE/groups"
REG="$G/groups.tsv"
SET_VPN=grp_vpn
SET_OUT=grp_out
DNSCONF=/tmp/dnsmasq.d/10-groups.conf
TAB=$(printf '\t')

mkdir -p "$G" 2>/dev/null
[ -f "$REG" ] || : > "$REG"





if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
if ! command -v dom_ok >/dev/null 2>&1; then
	dom_ok() { [ -n "$1" ] && [ "${#1}" -le 253 ] || return 1
	           printf '%s' "$1" | grep -qE '^[A-Za-z0-9_-]{1,63}(\.[A-Za-z0-9_-]{1,63})*$'; }
fi























UTF8_TAIL=$(printf 's/[\300-\337]$//;s/[\340-\357]$//;s/[\340-\357][\200-\277]$//;s/[\360-\367]$//;s/[\360-\367][\200-\277]$//;s/[\360-\367][\200-\277][\200-\277]$//')
san() {


	_sn=$(printf '%s' "$1" | tr -d "$TAB\"\\\\\r\n" | tr -d '\001-\037\177' | cut -c1-40)
	_sn2=$(printf '%s' "$_sn" | LC_ALL=C sed "$UTF8_TAIL" 2>/dev/null)
	[ -n "$_sn2" ] || _sn2="$_sn"   # страховка: sed без байтовых классов вернул бы пусто
	printf '%s' "$_sn2"
}
is_cidr() { echo "$1" | grep -qE '^[0-9]{1,3}(\.[0-9]{1,3}){3}(/[0-9]{1,2})?$'; }
is_ip4()  { echo "$1" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; }
dev_set() { printf 'grp_dev_%s' "$1"; }   # сет группы устройства (префикс grp_ — его знает uninstall)







is_dom()  { dom_ok "$1" || return 1
            echo "$1" | grep -qE '\.([A-Za-z]{2,}|xn--[A-Za-z0-9-]{2,})$' || \
            { echo "$1" | grep -qE '^[A-Za-z0-9][A-Za-z0-9-]{1,62}$' && ! echo "$1" | grep -qE '^[0-9]+$'; }; }
is_slot() { case "$1" in 0|2|3|4) return 0 ;; *) return 1 ;; esac; }
valid_id() { echo "$1" | grep -qE '^g[0-9]+$'; }







migrate_reg() {
	[ -s "$REG" ] || return 0
	awk -F"$TAB" 'NF>0 && NF!=5 && NF!=6{c=1} END{exit c?0:1}' "$REG" || return 0
	awk -F"$TAB" -v OFS="$TAB" 'NF==4{print $1,$2,$3,"0",$4; next} NF>0{print}' "$REG" > "$REG.mig" \
		&& mv "$REG.mig" "$REG"
}
migrate_reg
mfile() { printf '%s/%s.list' "$G" "$1"; }

reg_get() { grep "^$1$TAB" "$REG" 2>/dev/null | head -1; }


next_id() {
	_m=$(cut -f1 "$REG" 2>/dev/null | sed -n 's/^g\([0-9][0-9]*\)$/\1/p' | sort -n | tail -1)
	case "$_m" in ''|*[!0-9]*) _m=0 ;; esac
	printf 'g%s' $((_m + 1))
}
reg_write() {  # stdin → реестр (атомарно: tmp+mv, чтобы обрыв записи не побил файл)
	cat > "$REG.new" && mv "$REG.new" "$REG"
}
reg_del_line() { grep -v "^$1$TAB" "$REG" 2>/dev/null | reg_write; }






norm_member() {
	_nm=$(printf '%s' "$1" | sed 's|^[a-zA-Z][a-zA-Z0-9+.-]*://||; s|/$||; s|^www\.||')
	if is_cidr "$_nm"; then printf '%s' "$_nm"; return 0; fi
	_nm=$(printf '%s' "$_nm" | sed 's|/.*$||; s|:[0-9]*$||' | tr 'A-Z' 'a-z')
	is_dom "$_nm" && { printf '%s' "$_nm"; return 0; }
	return 1
}






store_members() {
	_sm_f="$1"; _sm_n=0
	: > "$_sm_f.new"
	for _raw in $(tr ',;\r\n' '    '); do
		_v=$(norm_member "$_raw") || continue
		grep -qxF "$_v" "$_sm_f.new" 2>/dev/null && continue
		echo "$_v" >> "$_sm_f.new"
		_sm_n=$((_sm_n + 1))
	done
	mv "$_sm_f.new" "$_sm_f"
	echo "$_sm_n"
}






if [ -f "$ENODIA_DIR/set-lib.sh" ]; then . "$ENODIA_DIR/set-lib.sh"; fi



if ! command -v set_sync >/dev/null 2>&1; then
	set_ensure() { ipset list -n 2>/dev/null | grep -qx "$1" || ipset create "$1" hash:net hashsize 1024 maxelem 65536 2>/dev/null; }
	set_fill() {
		_s="$1"; _f="$2"
		set_ensure "$_s"
		ipset destroy "${_s}_new" 2>/dev/null
		ipset create "${_s}_new" hash:net hashsize 1024 maxelem 65536 2>/dev/null || return 1
		if [ -s "$_f" ]; then
			awk -v s="${_s}_new" '/^[0-9]/{print "add " s " " $1}' "$_f" | ipset restore -exist 2>/dev/null
		fi
		ipset swap "${_s}_new" "$_s" 2>/dev/null
		ipset destroy "${_s}_new" 2>/dev/null
	}
	set_sync() { set_fill "$1" "$2"; }
fi





if [ -f "$ENODIA_DIR/lists-lib.sh" ]; then . "$ENODIA_DIR/lists-lib.sh"; fi
if ! command -v ls_lock_take >/dev/null 2>&1; then
	ls_lock_take() { return 0; }
	ls_lock_drop() { return 0; }
fi
GRP_LOCK=/tmp/.enodia-grp-apply.lock
GRP_DIRTY=/tmp/.enodia-grp-apply.dirty




grp_sync() {
	_gs_d="/tmp/.enodia-grp-dom.$$"
	awk -F"$TAB" -v s="$1" '$2==s{print $1}' "$3" 2>/dev/null > "$_gs_d"
	set_sync "$1" "$2" "$_gs_d"; _gs_rc=$?
	rm -f "$_gs_d" 2>/dev/null
	return $_gs_rc   # код от set_sync, а не от `rm` (иначе провал заливки читался бы как успех)
}

set_count() {  # число членов ipset; фолбэк для ядра 4.4 (нет «Number of entries») — канон см. ipset_count в lists-lib.sh
	_n=$(ipset list "$1" 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)
	case "$_n" in ''|*[!0-9]*) _n=$(ipset list "$1" 2>/dev/null | grep -cE '^[0-9]') ;; esac
	case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
	printf '%s' "$_n"
}

















emit_dnsconf() {



	_ed_n="$DNSCONF.$$.new"
	: > "$_ed_n"
	if [ -s "$1" ]; then
		sort -u "$1" | awk -F"$TAB" '
			{ have[$1 SUBSEP $2] = 1; dom[$1] = 1; st[$2] = 1 }
			END {
				for (d in dom) {
					out = ""
					for (t in st) {
						hit = 0; p = d
						if ((d SUBSEP t) in have) hit = 1
						else while (sub(/^[^.]+\./, "", p)) if ((p SUBSEP t) in have) { hit = 1; break }
						if (hit) out = (out == "" ? t : out "," t)
					}
					if (out != "") print "ipset=/" d "/" out
				}
			}' | sort >> "$_ed_n"
	fi
	mv "$_ed_n" "$DNSCONF"
}







dev_wire() {
	if [ -n "$1" ] || iptables -t mangle -L VPN_DEV -n >/dev/null 2>&1; then
		sh "$ENODIA_DIR/apply-bypass.sh" dev-rebind >/dev/null 2>&1 || true
	fi


	for _os in $(ipset list -n 2>/dev/null | grep '^grp_dev_'); do
		case " $1 " in *" ${_os#grp_dev_} "*) continue ;; esac
		ipset destroy "$_os" 2>/dev/null || true
	done
}






wire_rules() {
	iptables -t mangle -C PREROUTING -m set --match-set "$SET_VPN" dst -j MARK --set-mark 0x1 2>/dev/null \
		|| iptables -t mangle -C PREROUTING -m set --match-set "$SET_VPN" dst -j ACCEPT 2>/dev/null \
		|| sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1 || true


	sh "$ENODIA_DIR/apply-bypass.sh" set-dst-ensure "$SET_OUT" >/dev/null 2>&1 || true
}








_apply_pass() {
	mkdir -p /tmp/dnsmasq.d 2>/dev/null
	_tp="/tmp/.enodia-grp.$$"
	_cv="$_tp-vpn.cidr"; _co="$_tp-out.cidr"; _pairs="$_tp-pairs"
	: > "$_cv"; : > "$_co"; : > "$_pairs"



	for _n in 2 3 4; do : > "$_tp-vpn-s$_n.cidr"; : > "$_tp-vpn-s$_n.dom"; done
	_any_slot=0; _dev_ids=""



	_en_slots=" "
	[ -f "$ENODIA_DIR/slots.sh" ] && _en_slots=" $(sh "$ENODIA_DIR/slots.sh" list-enabled 2>/dev/null | cut -f1 | tr '\n' ' ') "



	_old_ifs="$IFS"; IFS="$TAB"
	while read -r _id _en _dir _slot _name _src; do
		[ -n "$_id" ] || continue
		[ "$_en" = 1 ] || continue
		_f=$(mfile "$_id"); [ -f "$_f" ] || continue
		case "$_slot" in 2|3|4) ;; *) _slot=0 ;; esac
		if [ -n "$_src" ]; then



			_set=$(dev_set "$_id"); _cf="$_tp-dev-$_id.cidr"; : > "$_cf"
			_dev_ids="$_dev_ids $_id"
		else

			[ "$_slot" != 0 ] && case "$_en_slots" in *" $_slot "*) ;; *) _slot=0 ;; esac

			if [ "$_dir" = bypass ]; then
				_set="$SET_OUT"; _cf="$_co"
			elif [ "$_slot" != 0 ]; then
				_set="grp_vpn_s$_slot"; _cf="$_tp-vpn-s$_slot.cidr"; _any_slot=1
			else
				_set="$SET_VPN"; _cf="$_cv"
			fi
		fi

		IFS="$_old_ifs"
		while read -r _m; do
			[ -n "$_m" ] || continue
			if is_cidr "$_m"; then
				echo "$_m" >> "$_cf"
			elif is_dom "$_m"; then




				printf '%s\t%s\n' "$_m" "$_set" >> "$_pairs"




				[ -z "$_src" ] && [ "$_slot" != 0 ] && echo "$_m" >> "$_tp-vpn-s$_slot.dom"
			fi
		done < "$_f"
		IFS="$TAB"
	done < "$REG"
	IFS="$_old_ifs"
	emit_dnsconf "$_pairs"

	_fail=""
	grp_sync "$SET_VPN" "$_cv" "$_pairs" || _fail="$_fail $SET_VPN"
	grp_sync "$SET_OUT" "$_co" "$_pairs" || _fail="$_fail $SET_OUT"


	for _gid in $_dev_ids; do grp_sync "$(dev_set "$_gid")" "$_tp-dev-$_gid.cidr" "$_pairs" || _fail="$_fail $(dev_set "$_gid")"; done


	for _n in 2 3 4; do
		_sf="$_tp-vpn-s$_n.cidr"; _df="$_tp-vpn-s$_n.dom"
		if [ -s "$_sf" ] || [ -s "$_df" ] || ipset list -n 2>/dev/null | grep -qx "grp_vpn_s$_n"; then
			grp_sync "grp_vpn_s$_n" "$_sf" "$_pairs" || _fail="$_fail grp_vpn_s$_n"   # домены наполнит dnsmasq — важно, что сет СОЗДАН (зеркало geo.sh)
		fi
	done
	wire_rules
	dev_wire "$_dev_ids"



	[ "$_any_slot" = 1 ] && [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" slots-up >/dev/null 2>&1
	dns_reload





	sed -n 's|^ipset=/\([^/]*\)/.*|\1|p' "$DNSCONF" 2>/dev/null | while read -r _d; do
		[ -n "$_d" ] || continue
		nslookup "$_d" >/dev/null 2>&1 || true
	done
	rm -f "$_cv" "$_co" "$_pairs" 2>/dev/null
	for _gid in $_dev_ids; do rm -f "$_tp-dev-$_gid.cidr" 2>/dev/null; done
	for _n in 2 3 4; do rm -f "$_tp-vpn-s$_n.cidr" "$_tp-vpn-s$_n.dom" 2>/dev/null; done


	ct_flush


	if [ "$_fail" != "" ]; then
		printf 'группы применены ЧАСТИЧНО: не удалось залить наборы:%s (маршрут для них остался прежним)\n' "$_fail"
		return 1
	fi
	printf 'группы применены: в VPN %s, мимо VPN %s (адресов в сетах)\n' "$(set_count "$SET_VPN")" "$(set_count "$SET_OUT")"
}







do_apply() {
	if ! ls_lock_take "$GRP_LOCK" "$GRP_DIRTY" 1; then
		echo 'группы: сборка уже идёт — учту свежий состав в ней'
		return 0
	fi
	trap 'ls_lock_drop "$GRP_LOCK"' EXIT INT TERM
	_sum=''; _rc=0
	while :; do
		rm -f "$GRP_DIRTY" 2>/dev/null   # сброс ДО чтения реестра: пойманный dirty ⇒ реестр прочитан ПОСЛЕ мутации
		_sum=$(_apply_pass); _rc=$?
		[ -f "$GRP_DIRTY" ] || break
	done
	trap - EXIT INT TERM
	ls_lock_drop "$GRP_LOCK"
	[ -z "$_sum" ] || echo "$_sum"
	return $_rc
}





dns_reload() { sh "$ENODIA_DIR/dns-merge.sh" reload 2>/dev/null \
	|| /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null; }




emit_json() {
	printf '{"groups":['
	_first=1
	_old_ifs="$IFS"; IFS="$TAB"
	while read -r _id _en _dir _slot _name _src; do
		[ -n "$_id" ] || continue
		[ "$_first" -eq 1 ] || printf ','
		_first=0
		case "$_slot" in 2|3|4) ;; *) _slot=0 ;; esac
		_f=$(mfile "$_id"); _nd=0; _nc=0
		IFS="$_old_ifs"
		if [ -f "$_f" ]; then
			_nc=$(grep -cE '^[0-9]{1,3}(\.[0-9]{1,3}){3}(/[0-9]{1,2})?$' "$_f" 2>/dev/null)
			case "$_nc" in ''|*[!0-9]*) _nc=0 ;; esac



			_nl=$(grep -c . "$_f" 2>/dev/null)
			case "$_nl" in ''|*[!0-9]*) _nl=0 ;; esac
			_nd=$((_nl - _nc)); [ "$_nd" -ge 0 ] || _nd=0
		fi



		printf '{"id":"%s","enabled":%s,"dir":"%s","slot":%s,"src":"%s","name":"%s","domains":%s,"cidrs":%s,"members":[' \
			"$_id" "$([ "$_en" = 1 ] && echo true || echo false)" "$_dir" "$_slot" "$_src" "$_name" "$_nd" "$_nc"
		_mf=1
		if [ -f "$_f" ]; then
			while read -r _m; do
				[ -n "$_m" ] || continue
				_m=$(printf '%s' "$_m" | tr -d '"\\')
				[ "$_mf" -eq 1 ] || printf ','
				_mf=0
				printf '"%s"' "$_m"
			done < "$_f"
		fi
		printf ']}'
		IFS="$TAB"
	done < "$REG"
	IFS="$_old_ifs"
	printf '],"set_vpn":%s,"set_out":%s}\n' "$(set_count "$SET_VPN")" "$(set_count "$SET_OUT")"
}

case "$1" in
	list) emit_json ;;

	add)  # add <vpn|bypass> <имя…>
		_dir="$2"; shift 2; _name=$(san "$*")
		case "$_dir" in vpn|bypass) ;; *) echo "направление: vpn|bypass"; exit 1 ;; esac
		[ -n "$_name" ] || { echo "нужно имя группы"; exit 1; }
		_id=$(next_id)
		printf '%s\t1\t%s\t0\t%s\n' "$_id" "$_dir" "$_name" >> "$REG"
		: > "$(mfile "$_id")"
		echo "группа «$_name» создана ($_id)"
		;;

	add-bound)  # add-bound <slot> <имя…> — создать «в VPN»-группу, СРАЗУ привязанную к доп-выходу



		_slot="$2"; shift 2; _name=$(san "$*")
		is_slot "$_slot" || { echo "слот: 0|2|3|4"; exit 1; }
		[ -n "$_name" ] || { echo "нужно имя группы"; exit 1; }
		_id=$(next_id)
		printf '%s\t1\tvpn\t%s\t%s\n' "$_id" "$_slot" "$_name" >> "$REG"
		: > "$(mfile "$_id")"



		_msg="пул «$_name» создан ($_id), выход №$_slot"
		do_apply >/dev/null
		echo "$_msg"
		;;

	del)
		valid_id "$2" || { echo "битый id"; exit 1; }
		reg_del_line "$2"
		rm -f "$(mfile "$2")" 2>/dev/null
		do_apply >/dev/null
		echo "группа удалена"
		;;

	rename)
		valid_id "$2" || { echo "битый id"; exit 1; }
		_id="$2"; shift 2; _name=$(san "$*")
		[ -n "$_name" ] || { echo "нужно имя группы"; exit 1; }
		reg_get "$_id" >/dev/null || { echo "нет такой группы"; exit 1; }
		awk -F"$TAB" -v OFS="$TAB" -v id="$_id" -v nm="$_name" '$1==id{$5=nm} {print}' "$REG" | reg_write
		echo "переименована в «$_name»"
		;;

	dir)  # dir <id> <vpn|bypass> — сменить направление группы (bypass сбрасывает доп-выход в 0)
		valid_id "$2" || { echo "битый id"; exit 1; }
		case "$3" in vpn|bypass) ;; *) echo "направление: vpn|bypass"; exit 1 ;; esac
		reg_get "$2" >/dev/null || { echo "нет такой группы"; exit 1; }



		[ -n "$(reg_get "$2" | cut -f6)" ] && { echo "это правило устройства — меняется на экране устройства (dev-add/dev-del)"; exit 1; }
		awk -F"$TAB" -v OFS="$TAB" -v id="$2" -v d="$3" '$1==id{$3=d; if(d=="bypass")$4=0} {print}' "$REG" | reg_write
		do_apply >/dev/null
		echo "направление: $([ "$3" = vpn ] && echo 'в VPN' || echo 'мимо VPN')"
		;;

	slot)  # slot <id> <0|2|3|4> — привязать группу к доп-выходу (0 = основной; только для «в VPN»)
		valid_id "$2" || { echo "битый id"; exit 1; }
		is_slot "$3" || { echo "слот: 0|2|3|4"; exit 1; }
		_line=$(reg_get "$2"); [ -n "$_line" ] || { echo "нет такой группы"; exit 1; }
		if [ "$3" != 0 ] && [ "$(printf '%s' "$_line" | cut -f3)" != vpn ]; then
			echo "доп-выход только для групп «в VPN»"; exit 1
		fi
		[ -n "$(printf '%s' "$_line" | cut -f6)" ] && { echo "это правило устройства — меняется на экране устройства (dev-add/dev-del)"; exit 1; }
		awk -F"$TAB" -v OFS="$TAB" -v id="$2" -v s="$3" '$1==id{$4=s} {print}' "$REG" | reg_write
		do_apply >/dev/null
		echo "выход: $([ "$3" = 0 ] && echo 'Основной' || echo "слот №$3")"
		;;

	toggle)  # toggle <id> <0|1>
		valid_id "$2" || { echo "битый id"; exit 1; }
		case "$3" in 0|1) ;; *) echo "нужно 0|1"; exit 1 ;; esac
		reg_get "$2" >/dev/null || { echo "нет такой группы"; exit 1; }




		[ -n "$(reg_get "$2" | cut -f6)" ] && { echo "это правило устройства — снимается на экране устройства (dev-del)"; exit 1; }
		awk -F"$TAB" -v OFS="$TAB" -v id="$2" -v e="$3" '$1==id{$2=e} {print}' "$REG" | reg_write
		do_apply >/dev/null
		echo "группа $([ "$3" = 1 ] && echo включена || echo выключена)"
		;;

	set-members)  # set-members <id> < stdin (по записи на строку; домены и IP/CIDR вперемешку)
		valid_id "$2" || { echo "битый id"; exit 1; }
		reg_get "$2" >/dev/null || { echo "нет такой группы"; exit 1; }



		[ -n "$(reg_get "$2" | cut -f6)" ] && { echo "это правило устройства — состав меняется на экране устройства (dev-add/dev-del)"; exit 1; }


		_added=$(store_members "$(mfile "$2")")
		do_apply >/dev/null
		echo "в группе записей: $_added"
		;;

	new)  # new <vpn|bypass> <slot> <имя…> < stdin(состав) — создать группу ВМЕСТЕ с составом




		_dir="$2"; _slot="$3"; shift 3; _name=$(san "$*")
		case "$_dir" in vpn|bypass) ;; *) echo "направление: vpn|bypass"; exit 1 ;; esac
		is_slot "$_slot" || { echo "слот: 0|2|3|4"; exit 1; }
		[ "$_dir" = vpn ] || _slot=0    # доп-выход применим только к «в VPN» (зеркало верба dir)
		[ -n "$_name" ] || { echo "нужно имя группы"; exit 1; }






		_tm="$G/.new.$$"
		_added=$(store_members "$_tm")
		case "$_added" in ''|*[!0-9]*) _added=0 ;; esac
		if [ "$_added" -eq 0 ]; then
			rm -f "$_tm" 2>/dev/null
			echo "ни одного домена или адреса — группа не создана"; exit 1
		fi
		_id=$(next_id)
		mv "$_tm" "$(mfile "$_id")"
		printf '%s\t1\t%s\t%s\t%s\n' "$_id" "$_dir" "$_slot" "$_name" >> "$REG"
		_out=$(printf '%s\t%s' "$_id" "$_added")   # собрать ДО do_apply: он затирает _id
		do_apply >/dev/null
		printf '%s\n' "$_out"
		;;







	dev-add)   # dev-add <IP> <vpn|bypass|block> <0|2|3|4> <домен|CIDR>
		is_ip4 "$2" || { echo "нужен IPv4 устройства"; exit 1; }
		case "$3" in vpn|bypass|block) ;; *) echo "направление: vpn|bypass|block"; exit 1 ;; esac
		is_slot "$4" || { echo "выход: 0|2|3|4"; exit 1; }
		_dip="$2"; _ddir="$3"; _dsl="$4"; [ "$_ddir" = vpn ] || _dsl=0
		_val=$(norm_member "$5") || { echo "нужен домен или IP/CIDR"; exit 1; }





		if [ "$_dsl" != 0 ] && [ -f "$ENODIA_DIR/slots.sh" ] &&
		   sh "$ENODIA_DIR/slots.sh" list 2>/dev/null | awk -F"$TAB" -v i="$_dsl" '$1==i && $3=="zapret"{f=1} END{exit !f}'; then
			echo "выход №$_dsl — десинк (zapret): он работает по адресам назначения, направить в него правило устройства нельзя"; exit 1
		fi

		_gid=$(awk -F"$TAB" -v ip="$_dip" -v d="$_ddir" -v s="$_dsl" '$6==ip && $3==d && $4==s{print $1; exit}' "$REG" 2>/dev/null)
		if [ -z "$_gid" ]; then




			case "$_ddir" in
				vpn)    _dnm="в VPN" ;;
				bypass) _dnm="напрямую" ;;
				*)      _dnm="блок" ;;
			esac
			[ "$_dsl" = 0 ] || _dnm="выход №$_dsl"
			_gid=$(next_id)
			printf '%s\t1\t%s\t%s\t%s\t%s\n' "$_gid" "$_ddir" "$_dsl" "$(san "$_dip · $_dnm")" "$_dip" >> "$REG"
			: > "$(mfile "$_gid")"
		fi



		for _og in $(awk -F"$TAB" -v ip="$_dip" -v keep="$_gid" '$6==ip && $1!=keep{print $1}' "$REG" 2>/dev/null); do
			_omf=$(mfile "$_og"); [ -f "$_omf" ] || continue
			grep -qxF "$_val" "$_omf" 2>/dev/null || continue
			grep -vxF "$_val" "$_omf" > "$_omf.tmp" 2>/dev/null
			mv "$_omf.tmp" "$_omf"
			[ -s "$_omf" ] || { reg_del_line "$_og"; rm -f "$_omf" 2>/dev/null; }
		done
		grep -qxF "$_val" "$(mfile "$_gid")" 2>/dev/null || echo "$_val" >> "$(mfile "$_gid")"


		_msg="правило устройства $_dip: $_val"
		do_apply >/dev/null
		echo "$_msg"
		;;

	dev-del)   # dev-del <IP> <домен|CIDR> — снять правило (опустевшая группа удаляется целиком)
		is_ip4 "$2" || { echo "нужен IPv4 устройства"; exit 1; }
		_val=$(norm_member "$3") || { echo "нужен домен или IP/CIDR"; exit 1; }
		_hit=0
		for _gid in $(awk -F"$TAB" -v ip="$2" '$6==ip{print $1}' "$REG" 2>/dev/null); do
			_mf=$(mfile "$_gid"); [ -f "$_mf" ] || continue
			grep -qxF "$_val" "$_mf" 2>/dev/null || continue
			grep -vxF "$_val" "$_mf" > "$_mf.tmp" 2>/dev/null
			mv "$_mf.tmp" "$_mf"
			_hit=1


			[ -s "$_mf" ] || { reg_del_line "$_gid"; rm -f "$_mf" 2>/dev/null; }
		done
		[ "$_hit" = 1 ] || { echo "такого правила у устройства нет"; exit 1; }
		do_apply >/dev/null
		echo "правило снято"
		;;

	dev-list)  # dev-list [IP] — TSV «ip⇥значение⇥dir⇥slot» для панели (человеческий текст парсить нельзя)
		_want="$2"
		_old_ifs="$IFS"; IFS="$TAB"
		while read -r _id _en _dir _slot _name _src; do
			[ -n "$_src" ] || continue
			[ -z "$_want" ] || [ "$_src" = "$_want" ] || continue
			_f=$(mfile "$_id"); [ -f "$_f" ] || continue
			IFS="$_old_ifs"
			while read -r _m; do
				[ -n "$_m" ] || continue
				printf '%s\t%s\t%s\t%s\n' "$_src" "$_m" "$_dir" "$_slot"
			done < "$_f"
			IFS="$TAB"
		done < "$REG"
		IFS="$_old_ifs"
		;;

	dev-rules) # машинный TSV для apply-bypass.sh: src⇥сет⇥dir⇥slot (по строке на ВКЛЮЧЁННУЮ группу).


		awk -F"$TAB" -v OFS="$TAB" 'NF>=6 && $6!="" && $2==1 {print $6, "grp_dev_" $1, $3, $4}' "$REG" 2>/dev/null
		;;

	dev-purge) # dev-purge <IP> — снять ВСЕ правила устройства разом
		is_ip4 "$2" || { echo "нужен IPv4 устройства"; exit 1; }
		for _gid in $(awk -F"$TAB" -v ip="$2" '$6==ip{print $1}' "$REG" 2>/dev/null); do
			reg_del_line "$_gid"; rm -f "$(mfile "$_gid")" 2>/dev/null
		done
		do_apply >/dev/null
		echo "правила устройства сняты"
		;;

	apply|reapply) do_apply ;;

	*)
		echo "groups.sh — именованные группы правил «в VPN / мимо VPN»"
		echo "  list | add <vpn|bypass> <имя> | del <id> | rename <id> <имя>"
		echo "  dir <id> <vpn|bypass> | slot <id> <0|2|3|4> | toggle <id> <0|1> | set-members <id> < stdin | apply"
		echo "  new <vpn|bypass> <slot> <имя> < stdin  (создать группу с составом; печатает «id<TAB>членов»)"
		echo "  правила устройства: dev-add <IP> <vpn|bypass|block> <0|2|3|4> <домен|CIDR> | dev-del <IP> <значение>"
		echo "                      dev-list [IP] | dev-rules | dev-purge <IP>"
		exit 1
		;;
esac
