#!/bin/sh



















































ENODIA_DIR="${ENODIA_DIR:-$(cd "$(dirname "$0")" && pwd)}"
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
STORE="$ENODIA_STATE/.dhcp-static"
CONF_NAME=05-dhcp-static.conf
CONF_LIVE="${CONF_LIVE:-/tmp/dnsmasq.d/$CONF_NAME}"
CONF_ETC="/etc/dnsmasq.d/$CONF_NAME"      # НЕ пишем — только сносим: см. разбор в шапке
TAB=$(printf '\t')

if [ -f "$ENODIA_DIR/lease-lib.sh" ]; then . "$ENODIA_DIR/lease-lib.sh"; fi
if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi


command -v mac_ok >/dev/null 2>&1 || mac_ok() { printf '%s' "$1" | grep -qE '^[0-9a-f]{2}(:[0-9a-f]{2}){5}$'; }
ip_ok()  { printf '%s' "$1" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; }



lan_ip_ok() {
    ip_ok "$1" || return 1
    if command -v is_private_ip >/dev/null 2>&1; then is_private_ip "$1" || return 1; fi
    case "$1" in *.0|*.255) return 1 ;; esac
    return 0
}

if command -v mac_norm >/dev/null 2>&1; then norm_mac() { mac_norm "$1"; }
else norm_mac() { printf '%s' "$1" | tr 'A-Z' 'a-z' | tr -d ' \t\r\n'; }; fi


store_row_by() { [ -f "$STORE" ] || return 1; awk -F'\t' -v c="$1" -v w="$2" '$c==w{print; exit}' "$STORE" 2>/dev/null; }





build_conf() {   # $1 = куда писать


    {
        echo "# создан dhcp-static.sh — не править руками, истина в $STORE"
        if [ -f "$STORE" ]; then






            while IFS="$TAB" read -r _bm _bi _bh || [ -n "$_bm" ]; do
                mac_ok "$_bm" || continue
                lan_ip_ok "$_bi" || continue
                printf 'dhcp-host=%s,%s\n' "$_bm" "$_bi"
            done < "$STORE"
        fi
    } > "$1" 2>/dev/null
}



real_cfg() {
    for _dp in /proc/[0-9]*; do
        case "$(tr '\0' ' ' < "$_dp/cmdline" 2>/dev/null)" in
            *dnsmasq*-C\ *)
                _dc2=$(tr '\0' '\n' < "$_dp/cmdline" 2>/dev/null | awk '$0=="-C"{f=1;next} f{print;exit}')
                [ -f "$_dc2" ] && { printf '%s' "$_dc2"; return 0; } ;;
        esac
    done
    printf '/etc/dnsmasq.conf'
}




conf_test() {
    [ -x /usr/sbin/dnsmasq ] || return 0
    _dt=$(/usr/sbin/dnsmasq --test -C "$(real_cfg)" 2>&1)
    case "$_dt" in
        *"syntax check OK"*) return 0 ;;
        "") return 0 ;;
    esac
    printf '%s' "$_dt" | tail -2 >&2
    return 1
}







dns_ok() {
    _dwk=0
    while [ "$_dwk" -lt 8 ]; do
        if pidof dnsmasq >/dev/null 2>&1 && nslookup localhost 2>/dev/null | grep -q '^Address'; then
            return 0
        fi
        _dwk=$((_dwk + 1)); sleep 1
    done
    return 1
}

dns_reload() {



    if [ -f "$ENODIA_DIR/dns-merge.sh" ]; then
        sh "$ENODIA_DIR/dns-merge.sh" reload >/dev/null 2>&1 && return 0
    fi
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}

same_file() { [ -f "$1" ] && [ -f "$2" ] && [ "$(md5sum < "$1" 2>/dev/null)" = "$(md5sum < "$2" 2>/dev/null)" ]; }



place_conf() {   # $1 = готовый кандидат
    mkdir -p /tmp/dnsmasq.d 2>/dev/null
    cp "$1" "/tmp/.enodia-$CONF_NAME.stage" 2>/dev/null && mv "/tmp/.enodia-$CONF_NAME.stage" "$CONF_LIVE" 2>/dev/null || return 1


    rm -f "$CONF_ETC" 2>/dev/null
    return 0
}

drop_conf() { rm -f "$CONF_ETC" "$CONF_LIVE" "/tmp/.enodia-$CONF_NAME.stage" 2>/dev/null; }




cmd_apply() {
    _dc=/tmp/.enodia-dhcp-static.cand.$$
    build_conf "$_dc"


    if ! grep -q '^dhcp-host=' "$_dc" 2>/dev/null; then
        rm -f "$_dc" 2>/dev/null
        [ -f "$CONF_LIVE" ] || [ -f "$CONF_ETC" ] || return 0
        drop_conf
        [ "$1" = norestart ] || dns_reload
        return 0
    fi



    if same_file "$_dc" "$CONF_LIVE" && [ ! -f "$CONF_ETC" ]; then
        rm -f "$_dc" 2>/dev/null
        return 0
    fi

    _dbl=/tmp/.enodia-dhcp-static.bak-live.$$
    [ -f "$CONF_LIVE" ] && cp "$CONF_LIVE" "$_dbl" 2>/dev/null
    if ! place_conf "$_dc"; then
        rm -f "$_dc" "$_dbl" 2>/dev/null
        echo "[dhcp-static] не удалось выложить $CONF_NAME" >&2
        return 1
    fi



    if ! conf_test; then
        drop_conf
        [ -f "$_dbl" ] && place_conf "$_dbl" >/dev/null 2>&1
        rm -f "$_dc" "$_dbl" 2>/dev/null
        echo "[dhcp-static] dnsmasq отверг такой конфиг — резервация НЕ применена, DNS не тронут" >&2
        return 1
    fi
    if [ "$1" = norestart ]; then
        rm -f "$_dc" "$_dbl" 2>/dev/null
        return 0
    fi
    dns_reload
    if ! dns_ok; then
        drop_conf
        [ -f "$_dbl" ] && place_conf "$_dbl" >/dev/null 2>&1
        dns_reload
        rm -f "$_dc" "$_dbl" 2>/dev/null
        echo "[dhcp-static] dnsmasq не поднялся с резервациями — откатил, DNS восстановлен" >&2
        return 1
    fi
    rm -f "$_dc" "$_dbl" 2>/dev/null
    return 0
}

cmd_add() {   # $1 = IP, $2 = MAC (необязателен: возьмём нынешнего владельца адреса)
    _di="$1"; _dm=$(norm_mac "$2")
    lan_ip_ok "$_di" || { echo "[dhcp-static] не адрес локальной сети: $1" >&2; return 1; }
    if [ -z "$_dm" ] && command -v ip_owner_now >/dev/null 2>&1; then _dm=$(ip_owner_now "$_di"); fi
    mac_ok "$_dm" || { echo "[dhcp-static] не знаю MAC устройства на $_di (нет аренды и молчит в сети) — закреплять нечего" >&2; return 1; }





    _dst=$(cmd_stock 2>/dev/null)
    if [ -n "$_dst" ]; then
    	_dsi=$(printf '%s
' "$_dst" | awk -F'	' -v i="$_di" '$2==i{print $1; exit}')
    	if [ -n "$_dsi" ]; then
    		echo "[dhcp-static] $_di уже закреплён в настройках роутера (за $_dsi) — снимите там" >&2
    		return 1
    	fi
    	_dsm=$(printf '%s
' "$_dst" | awk -F'	' -v m="$_dm" 'toupper($1)==toupper(m){print $2; exit}')
    	if [ -n "$_dsm" ]; then
    		echo "[dhcp-static] у этого устройства уже есть закреплённый адрес в настройках роутера: $_dsm" >&2
    		return 1
    	fi
    fi

    _dex=$(store_row_by 2 "$_di")
    if [ -n "$_dex" ]; then
        _dexm=$(printf '%s' "$_dex" | cut -f1)
        [ "$_dexm" = "$_dm" ] && { echo "уже закреплён: $_di за $_dm"; return 0; }
        echo "[dhcp-static] $_di уже закреплён за $_dexm — сначала снимите закрепление" >&2
        return 1
    fi
    _dh=""
    command -v lease_host_of >/dev/null 2>&1 && _dh=$(lease_host_of "$_di")
    _dtmp="$STORE.tmp.$$"


    { [ -f "$STORE" ] && awk -F'\t' -v m="$_dm" '$1!=m' "$STORE" 2>/dev/null
      printf '%s\t%s\t%s\n' "$_dm" "$_di" "$_dh"
    } > "$_dtmp" 2>/dev/null && mv "$_dtmp" "$STORE" 2>/dev/null || { rm -f "$_dtmp" 2>/dev/null; echo "[dhcp-static] не записать $STORE" >&2; return 1; }
    if cmd_apply; then
        if command -v mac_is_random >/dev/null 2>&1 && mac_is_random "$_dm"; then
            echo "закреплён $_di за $_dm; ВНИМАНИЕ: это случайный (приватный) MAC — устройство меняет его само, и тогда закрепление перестанет действовать"
        else
            echo "закреплён $_di за $_dm"
        fi
        return 0
    fi

    cmd_del "$_di" >/dev/null 2>&1
    return 1
}

cmd_del() {   # $1 = IP либо MAC
    _dk="$1"; _dkm=$(norm_mac "$1")
    [ -f "$STORE" ] || { echo "нечего снимать"; return 0; }
    _dtmp="$STORE.tmp.$$"
    awk -F'\t' -v k="$_dk" -v m="$_dkm" '$1!=m && $2!=k' "$STORE" 2>/dev/null > "$_dtmp" || { rm -f "$_dtmp" 2>/dev/null; return 1; }
    mv "$_dtmp" "$STORE" 2>/dev/null || { rm -f "$_dtmp" 2>/dev/null; return 1; }
    cmd_apply || return 1
    echo "закрепление снято: $1"
    return 0
}











STOCK_CFG="${STOCK_CFG:-/etc/config/dhcp}"
cmd_stock() {
	[ -f "$STOCK_CFG" ] || return 0


	awk '
		/^[ 	]*config[ 	]+host([ 	]|$)/ { if (inh && m != "" && i != "") print m "	" i; inh=1; m=""; i=""; next }
		/^[ 	]*config[ 	]/ { if (inh && m != "" && i != "") print m "	" i; inh=0; next }
		inh && /^[ 	]*(option|list)[ 	]+mac[ 	]/ { m=$3 }
		inh && /^[ 	]*option[ 	]+ip[ 	]/ { i=$3 }
		END { if (inh && m != "" && i != "") print m "	" i }
	' "$STOCK_CFG" 2>/dev/null | tr -d "'\""
}

cmd_json() {
    printf '{"pins":['
    _df=1
    if [ -f "$STORE" ]; then


        while IFS="$TAB" read -r _jm _ji _jh || [ -n "$_jm" ]; do
            mac_ok "$_jm" || continue
            [ "$_df" -eq 1 ] || printf ','
            _df=0
            printf '{"mac":"%s","ip":"%s","host":"%s"}' "$_jm" "$_ji" "$(printf '%s' "$_jh" | tr -d '"\\')"
        done < "$STORE"
    fi
    printf ']}\n'
}

case "$1" in
    add)    cmd_add "$2" "$3" ;;
    del|rm) cmd_del "$2" ;;
    apply)  cmd_apply "$2" ;;
    list)   [ -f "$STORE" ] && cat "$STORE" || true ;;
    stock)  cmd_stock ;;   # чужие (стоковые) резервации из /etc/config/dhcp, только чтение
    json)   cmd_json ;;
    clear)  rm -f "$STORE" 2>/dev/null; drop_conf; dns_reload; echo "все закрепления сняты" ;;
    *)      echo "usage: $0 {add <ip> [mac]|del <ip|mac>|apply [norestart]|list|stock|json|clear}" >&2; exit 1 ;;
esac
