#!/bin/sh



























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




BIN_DIR="$ENODIA_BIN"
if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi


OUR_BINS="amneziawg-go awg xray hysteria hev byedpi ciadpi nfqws panel-tls https-dns-proxy dot-proxy"

TOPN=8            # столько чужих процессов показываем поимённо, остальные — одной строкой

meminfo_kb() {    # meminfo_kb <ключ> → КБ (0, если поля нет)
    _v=$(awk -v k="$1:" '$1==k{print $2; exit}' /proc/meminfo 2>/dev/null)
    case "$_v" in ''|*[!0-9]*) _v=0 ;; esac
    echo "$_v"
}








scan_procs() {
    for _d in /proc/[0-9]*; do
        [ -r "$_d/status" ] || continue
        _pl=$(awk '/^Name:/{n=$2} /^VmRSS:/{r=$2+0} END{if(r>0) print r" "n}' "$_d/status" 2>/dev/null)
        [ -n "$_pl" ] || continue
        _rss=${_pl%% *}; _nm=${_pl#* }
        case "$_rss" in ''|*[!0-9]*) continue ;; esac
        _cl=$(tr '\0' ' ' < "$_d/cmdline" 2>/dev/null)

        _kind=other
        case "$_cl" in
            *"$ENODIA_DIR/"*|*"$ENODIA_BIN/"*) _kind=our ;;
        esac
        if [ "$_kind" = other ] && [ "$BIN_DIR" != "$ENODIA_BIN" ]; then
            case "$_cl" in *"$BIN_DIR/"*) _kind=our ;; esac
        fi
        if [ "$_kind" = other ]; then
            case " $OUR_BINS " in *" $_nm "*) _kind=our ;; esac
        fi

        _lbl="$_nm"
        if [ "$_kind" = our ]; then





            case "$_nm" in
                amneziawg-go)
                    _if=${_cl#* }; _if=${_if%% *}
                    case "$_if" in awg*) _lbl="amneziawg-go $_if" ;; esac ;;



                sh|ash|busybox) _lbl="скрипты проекта" ;;
                uhttpd) _lbl="uhttpd (панель)" ;;
            esac




            case "$_cl" in
                *"$ENODIA_DIR/web/cgi-bin/"*) _lbl="запросы панели" ;;
            esac
        fi



        case "$_lbl" in
            *'"'*|*'\'*) _lbl=$(printf '%s' "$_lbl" | tr -d '"\\') ;;
        esac
        printf '%s\t%s\t%s\n' "$_rss" "$_kind" "$_lbl"
    done
    return 0
}













group_by_label() {
    awk -F'\t' '{ print $3 "\t" $1 }' |
    sort |
    awk -F'\t' '
        { if($1!=k){ if(k!=""){ printf "%d\t%d\t%s\n", s, c, k } k=$1; s=0; c=0 } s+=$2; c++ }
        END{ if(k!=""){ printf "%d\t%d\t%s\n", s, c, k } }' |
    sort -rn
}














TMP_DNSQ=""            # наши конфиги dnsmasq в ОЗУ (их же отдельно приписываем dnsmasq ниже)
for _f in /tmp/dnsmasq.d/[0-9][0-9]-*.conf /tmp/dnsmasq.d/enodia-*.conf /tmp/dnsmasq.d/awg-*.conf; do   # legacy-name: awg-* — сниппеты прежних установок
    [ -f "$_f" ] && TMP_DNSQ="$TMP_DNSQ $_f"
done
TMP_OURS="$TMP_DNSQ"
for _d in /tmp/enodia-geo /tmp/enodia-lists; do
    [ -d "$_d" ] && TMP_OURS="$TMP_OURS $_d"
done
if [ -f "$ENODIA_DIR/clean.sh" ]; then
    TMP_OURS="$TMP_OURS $(sh "$ENODIA_DIR/clean.sh" ramlogs-list 2>/dev/null | tr '\n' ' ')"
fi




du_k_of() {
    [ -n "$1" ] || { echo 0; return 0; }
    du -xsk $1 2>/dev/null | awk '{s+=$1} END{printf "%d", s+0}'
}
TMPFS_K=$(du_k_of "$TMP_OURS")
DNSQ_CONF_K=$(du_k_of "$TMP_DNSQ")











SET_PREFIXES="enodia_ iplist_ grp_ geo_ zapret_ blocklist_ xiaomi_"
if [ -f "$ENODIA_DIR/uninstall.sh" ]; then
    _sp=$(sed -n 's/^SET_PREFIXES="\(.*\)"$/\1/p' "$ENODIA_DIR/uninstall.sh" 2>/dev/null | head -1)
    [ -n "$_sp" ] && SET_PREFIXES="$_sp"
fi
ipset_mem_b() {
    _im=0
    for _s in $(ipset list -n 2>/dev/null); do
        _ours=0
        for _p in $SET_PREFIXES; do
            case "$_s" in "$_p"*) _ours=1; break ;; esac
        done
        [ "$_ours" = 1 ] || continue
        _sz=$(ipset list "$_s" -terse 2>/dev/null | sed -n 's/^Size in memory: *\([0-9]*\).*/\1/p' | head -1)
        case "$_sz" in ''|*[!0-9]*) _sz=0 ;; esac
        _im=$((_im + _sz))
    done
    printf '%s' "$_im"
}
IPSET_B=$(ipset_mem_b)

SCAN=$(scan_procs)
OURS=$(printf '%s\n' "$SCAN" | awk -F'\t' '$2=="our"')
OTHERS=$(printf '%s\n' "$SCAN" | awk -F'\t' '$2=="other"')
sum_kb()  { awk -F'\t' '{s+=$1} END{printf "%d", s+0}'; }
count_n() { awk -F'\t' 'NF{c++} END{printf "%d", c+0}'; }

TOT_K=$(meminfo_kb MemTotal)
FREE_K=$(meminfo_kb MemFree)
AVAIL_K=$(meminfo_kb MemAvailable)
BUF_K=$(meminfo_kb Buffers)
CACHE_K=$(meminfo_kb Cached)
[ "$AVAIL_K" -gt 0 ] 2>/dev/null || AVAIL_K=$((FREE_K + BUF_K + CACHE_K))

OURS_K=$(printf '%s\n' "$OURS"   | sum_kb)
OURS_N=$(printf '%s\n' "$OURS"   | count_n)
OTH_K=$(printf '%s\n' "$OTHERS"  | sum_kb)
OTH_N=$(printf '%s\n' "$OTHERS"  | count_n)




if [ "${1:-}" = json ]; then
    kb() { echo $(( ${1:-0} * 1024 )); }
    printf '{"total_b":%s,"free_b":%s,"avail_b":%s,"buffers_b":%s,"cached_b":%s,' \
        "$(kb "$TOT_K")" "$(kb "$FREE_K")" "$(kb "$AVAIL_K")" "$(kb "$BUF_K")" "$(kb "$CACHE_K")"
    printf '"ours_b":%s,"ours_n":%s,"others_b":%s,"others_n":%s,' \
        "$(kb "$OURS_K")" "$OURS_N" "$(kb "$OTH_K")" "$OTH_N"



    printf '"tmpfs_b":%s,"dnsmasq_conf_b":%s,"ipset_b":%s,"procs":[' \
        "$(kb "$TMPFS_K")" "$(kb "$DNSQ_CONF_K")" "$IPSET_B"
    _first=1


    while IFS="$(printf '\t')" read -r _b _n _l; do
        [ -n "$_l" ] || continue
        [ "$_first" = 1 ] || printf ','
        _first=0
        printf '{"name":"%s","n":%s,"rss_b":%s}' "$_l" "$_n" "$(kb "$_b")"
    done <<EOF
$(printf '%s\n' "$OURS" | group_by_label)
EOF
    printf '],"others":['


    _first=1; _rest_b=0; _rest_n=0; _i=0
    while IFS="$(printf '\t')" read -r _b _n _l; do
        [ -n "$_l" ] || continue
        _i=$((_i + 1))
        if [ "$_i" -le "$TOPN" ]; then
            [ "$_first" = 1 ] || printf ','
            _first=0
            printf '{"name":"%s","n":%s,"rss_b":%s}' "$_l" "$_n" "$(kb "$_b")"
        else
            _rest_b=$((_rest_b + _b)); _rest_n=$((_rest_n + _n))
        fi
    done <<EOF
$(printf '%s\n' "$OTHERS" | group_by_label)
EOF
    printf '],"rest_b":%s,"rest_n":%s}\n' "$(kb "$_rest_b")" "$_rest_n"
    exit 0
fi




hum() { awk -v k="${1:-0}" 'BEGIN{ if(k<1024) printf "%d КБ", k; else printf "%.1f МБ", k/1024 }'; }

echo "=== Оперативная память ==="
printf 'всего %s · доступно %s · кэш и буферы %s\n' \
    "$(hum "$TOT_K")" "$(hum "$AVAIL_K")" "$(hum $((BUF_K + CACHE_K)))"
printf 'проект: %s в %s процессах + %s файлами в /tmp + %s наборами ipset · остальное: %s в %s\n' \
    "$(hum "$OURS_K")" "$OURS_N" "$(hum "$TMPFS_K")" "$(hum $((IPSET_B / 1024)))" "$(hum "$OTH_K")" "$OTH_N"
[ "$DNSQ_CONF_K" -gt 0 ] 2>/dev/null && printf 'из них %s — конфиги, которые мы отдали dnsmasq (он в «остальном», но растёт от них)\n' \
    "$(hum "$DNSQ_CONF_K")"
echo ""
echo "=== Наши процессы (RSS) ==="
printf '%s\n' "$OURS" | group_by_label |
    awk -F'\t' '{ printf "%9.1f МБ  %s%s\n", $1/1024, $3, ($2>1 ? "  ×"$2 : "") }'
echo ""
echo "=== Остальное на роутере (топ по памяти) ==="
printf '%s\n' "$OTHERS" | group_by_label | head -15 |
    awk -F'\t' '{ printf "%9.1f МБ  %s%s\n", $1/1024, $3, ($2>1 ? "  ×"$2 : "") }'
echo ""

echo "NB: сумма RSS с системным «занято» не сходится в обе стороны: общие страницы засчитаны КАЖДОМУ процессу, а память ядра и драйверов не принадлежит ни одному."
