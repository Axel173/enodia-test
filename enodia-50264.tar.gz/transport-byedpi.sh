#!/bin/sh













































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }


if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}


command -v carrier_up_mark >/dev/null 2>&1 || carrier_up_mark() { return 0; }
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }





if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi

command -v carrier_barred >/dev/null 2>&1 || carrier_barred() { return 1; }
command -v carrier_run >/dev/null 2>&1 || carrier_run() { shift; "$@"; }
command -v daemon_wait_port >/dev/null 2>&1 || daemon_wait_port() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0; sleep 1; _dwi=$((_dwi+1)); done
    netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
command -v daemon_wait_dev >/dev/null 2>&1 || daemon_wait_dev() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do ip link show "$4" >/dev/null 2>&1 && return 0; sleep 1; _dwi=$((_dwi+1)); done
    ip link show "$4" >/dev/null 2>&1 && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
TABLE=1000
TUN=xtun
SOCKS_ADDR=127.0.0.1
SOCKS_PORT=10808                                # ТОТ ЖЕ порт, что у xray/hy2 → общий hev.yaml несёт любого
CIADPI=$(bin_path byedpi)        # самосборный статик-бинарь ciadpi (bin/byedpi.user)
HEV=$(bin_path hev)
HEV_YAML="$ENODIA_DIR/hev.yaml"
ARGS_FILE="$ENODIA_STATE/.byedpi-args"          # десинк-аргументы (пишет панель/ПК); нет → DEFAULT_ARGS
CIADPI_PID=/tmp/enodia-byedpi.pid
HEV_PID=/tmp/enodia-hev.pid
CIADPI_LOG=/tmp/enodia-byedpi.log
HEV_LOG=/tmp/enodia-hev.log
TRANSPORT_FLAG="$ENODIA_STATE/.transport"
SWITCH_LOCK=/tmp/enodia-switching.lock          # ручная смена транспорта (панель/меню/оркестратор) держит его → health/failover не вмешиваются
DNS1=1.1.1.1
DNS2=8.8.8.8
FWMARK=0x1
BYEDPI_UID=65534                                # nobody (см. /etc/passwd) — под ним гоняем ciadpi, его egress мимо маркировки
SWEEP_LOCK=/tmp/enodia-byedpi-sweep.lock        # браузер-свип идёт (timestamp). Свежий → health/failover НЕ вмешиваются
SWEEP_BAK="$ENODIA_STATE/.byedpi-args.sweepbak" # бэкап исходной стратегии на время свипа (пустой файл = исходная была авто)
SWEEP_TTL=150                                   # свежесть lock (сек): браузер рефрешит на каждом apply; протух → свип брошен






DEFAULT_ARGS="-L 3 -T 5 -u 3600 -s 1+s -f 2+s -t 4 -A torst,redirect,ssl_err -d 1+s -A torst,redirect,ssl_err -s 1+s -A torst,redirect,ssl_err -r 1+s"




if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }



if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
command -v doh_apply_dns >/dev/null 2>&1 || doh_apply_dns() { return 1; }

log() { echo "[byedpi-transport] $*"; }


proc_alive() { p=$(cat "$1" 2>/dev/null | tr -d ' \r\n'); [ -n "$p" ] && kill -0 "$p" 2>/dev/null; }






socks_ours() { slot_socks_is_ours "$SOCKS_PORT" "$CIADPI_PID"; }






strip_unsupported() {
    printf '%s' "$1" | tr ' ' '\n' | grep -vxE '\-S|--md5sig' | tr '\n' ' ' \
        | sed 's/[[:space:]]\{1,\}/ /g; s/^ //; s/ $//'
}





args_from_file() {   # $1 = путь
    [ -s "$1" ] || return 0
    _af=$(grep -vE '^[[:space:]]*#' "$1" 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g; s/^ //; s/ $//')
    strip_unsupported "$_af"
}
desync_args() {
    _da=$(args_from_file "$ARGS_FILE"); [ -n "$_da" ] && { echo "$_da"; return; }
    strip_unsupported "$DEFAULT_ARGS"
}



owner_rule_add() {
    iptables -t mangle -C OUTPUT -m owner --uid-owner "$BYEDPI_UID" -j RETURN 2>/dev/null || \
        iptables -t mangle -I OUTPUT 1 -m owner --uid-owner "$BYEDPI_UID" -j RETURN
}
owner_rule_del() {
    while iptables -t mangle -C OUTPUT -m owner --uid-owner "$BYEDPI_UID" -j RETURN 2>/dev/null; do
        iptables -t mangle -D OUTPUT -m owner --uid-owner "$BYEDPI_UID" -j RETURN 2>/dev/null || break
    done
}








dns_direct_rules() {   # $1 = add|del
    for d in "$DNS1" "$DNS2"; do
        for ch in OUTPUT PREROUTING; do
            if [ "$1" = del ]; then
                while iptables -t mangle -C "$ch" -d "$d" -j RETURN 2>/dev/null; do
                    iptables -t mangle -D "$ch" -d "$d" -j RETURN 2>/dev/null || break
                done
            else
                iptables -t mangle -C "$ch" -d "$d" -j RETURN 2>/dev/null || \
                    iptables -t mangle -I "$ch" 1 -d "$d" -j RETURN
            fi
        done
    done
}
set_dnsmasq_direct() {
    mkdir -p /etc/dnsmasq.d
    printf 'no-resolv\nserver=%s\nserver=%s\n' "$DNS1" "$DNS2" > /etc/dnsmasq.d/00-upstream.conf
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}
set_direct_dns() {
    doh_apply_dns direct && return 0    # DoH ВКЛ/авто → резолв через локальный прокси (резолвер :443 мимо марки); иначе → ниже
    dns_direct_rules add
    set_dnsmasq_direct
}




free_foreign_socks() {
    own=$(cat "$CIADPI_PID" 2>/dev/null | tr -d ' \r\n')
    holder=$(netstat -ltnp 2>/dev/null | grep "$SOCKS_ADDR:$SOCKS_PORT " | awk '{print $NF}' | cut -d/ -f1 | head -n1)
    case "$holder" in ''|*[!0-9]*) return 0 ;; esac
    [ "$holder" = "$own" ] && return 0
    log "socks $SOCKS_PORT держит чужой pid $holder — освобождаю (своп транспорта/рестарт)"
    kill "$holder" 2>/dev/null
    i=0; while [ $i -lt 5 ]; do netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$SOCKS_PORT" || break; sleep 1; i=$((i+1)); done
}



spawn_byedpi() {
    : > "$CIADPI_LOG" 2>/dev/null || true
    chmod 666 "$CIADPI_LOG" 2>/dev/null || true   # nobody должен дописывать
    args=$(desync_args)
    start-stop-daemon -S -b -c nobody -m -p "$CIADPI_PID" -x /bin/sh -- -c "exec '$CIADPI' -i $SOCKS_ADDR -p $SOCKS_PORT $args >>'$CIADPI_LOG' 2>&1"
}












TMP_SOCKS_PORT=10809
TMP_SOCKS_PID=/tmp/enodia-byedpi-fetch.pid
TMP_SOCKS_LOG=/tmp/enodia-byedpi-fetch.log






TMP_SOCKS_REF=/tmp/enodia-byedpi-fetch.users
_ref_add() {   # $1 = метка (pid вызывающего)
    mkdir -p "$TMP_SOCKS_REF" 2>/dev/null || return 0
    : > "$TMP_SOCKS_REF/${1:-anon}" 2>/dev/null || true
    return 0
}
_ref_others_alive() {   # $1 = снимаемая метка; 0 = демон нужен ещё кому-то
    rm -f "$TMP_SOCKS_REF/${1:-anon}" 2>/dev/null
    [ -d "$TMP_SOCKS_REF" ] || return 1
    _rl=1
    for _rf in "$TMP_SOCKS_REF"/*; do
        [ -e "$_rf" ] || continue
        _rt=${_rf##*/}
        case "$_rt" in





            ''|*[!0-9]*) rm -f "$_rf" 2>/dev/null ;;
            *) if [ -d "/proc/$_rt" ]; then _rl=0; else rm -f "$_rf" 2>/dev/null; fi ;;
        esac
    done
    return "$_rl"
}


cmd_socks_up() {   # $1 = метка вызывающего (pid) для ref-счёта
    if proc_alive "$CIADPI_PID" && socks_ours; then
        _ref_add "$1"
        echo "$SOCKS_ADDR:$SOCKS_PORT"; return 0
    fi
    [ -x "$CIADPI" ] || { log "нет бинаря ciadpi — служебный socks не поднять"; return 1; }
    if ! proc_alive "$TMP_SOCKS_PID"; then
        : > "$TMP_SOCKS_LOG" 2>/dev/null || true
        chmod 666 "$TMP_SOCKS_LOG" 2>/dev/null || true
        start-stop-daemon -S -b -c nobody -m -p "$TMP_SOCKS_PID" -x /bin/sh -- \
            -c "exec '$CIADPI' -i $SOCKS_ADDR -p $TMP_SOCKS_PORT $(desync_args) >>'$TMP_SOCKS_LOG' 2>&1"
    fi

    if daemon_wait_port "$TMP_SOCKS_PID" byedpi 8 "$SOCKS_ADDR" "$TMP_SOCKS_PORT" \
       && slot_socks_is_ours "$TMP_SOCKS_PORT" "$TMP_SOCKS_PID"; then
        _ref_add "$1"
        echo "$SOCKS_ADDR:$TMP_SOCKS_PORT"; return 0
    fi
    log "служебный ciadpi не забиндил $TMP_SOCKS_PORT (${DAEMON_WAIT_WHY:-порт держит ЧУЖОЙ демон}). Лог:"; tail -n 10 "$TMP_SOCKS_LOG" 2>/dev/null
    cmd_socks_down "$1"
    return 1
}


cmd_socks_down() {   # $1 = метка вызывающего
    _ref_others_alive "$1" && return 0        # прокси занят другой закачкой — не наше дело




    if proc_alive "$TMP_SOCKS_PID" && slot_socks_is_ours "$TMP_SOCKS_PORT" "$TMP_SOCKS_PID"; then
        start-stop-daemon -K -p "$TMP_SOCKS_PID" >/dev/null 2>&1 || true
    fi
    rm -f "$TMP_SOCKS_PID"
    rmdir "$TMP_SOCKS_REF" 2>/dev/null || true
    return 0
}

start_daemons() {
    [ -x "$CIADPI" ] || { log "НЕТ бинаря $CIADPI — поставьте его в панели: «Компоненты»"; return 1; }
    [ -x "$HEV" ]    || { log "НЕТ бинаря $HEV"; return 1; }
    [ -s "$HEV_YAML" ] || { log "НЕТ $HEV_YAML"; return 1; }

    free_foreign_socks
    if ! proc_alive "$CIADPI_PID"; then
        log "запускаю ciadpi (десинк: $(desync_args))…"
        spawn_byedpi
    fi
    if ! daemon_wait_port "$CIADPI_PID" byedpi 8 "$SOCKS_ADDR" "$SOCKS_PORT"; then
        log "ciadpi не слушает $SOCKS_PORT: $DAEMON_WAIT_WHY. Лог:"; tail -n 15 "$CIADPI_LOG" 2>/dev/null
        return 1
    fi
    socks_ours || { log "socks $SOCKS_PORT держит ЧУЖОЙ демон — наш ciadpi не забиндил (не поднимаю несущую поверх чужого socks)"; return 1; }
    if ! proc_alive "$HEV_PID"; then
        log "запускаю hev (tun2socks)…"
        start-stop-daemon -S -b -m -p "$HEV_PID" -x "$HEV" -- "$HEV_YAML"
    fi
    daemon_wait_dev "$HEV_PID" hev 6 "$TUN" || {
        log "tun $TUN не создан: $DAEMON_WAIT_WHY. Лог hev:"; tail -n 15 "$HEV_LOG" 2>/dev/null; return 1; }
    return 0
}
stop_daemons() {
    start-stop-daemon -K -p "$HEV_PID"    2>/dev/null
    start-stop-daemon -K -p "$CIADPI_PID" 2>/dev/null
    ip link del "$TUN" 2>/dev/null



    rm -f "$HEV_PID" "$CIADPI_PID" 2>/dev/null
}








restart_byedpi() {
    start-stop-daemon -K -p "$CIADPI_PID" 2>/dev/null
    i=0; while [ $i -lt 6 ] && proc_alive "$CIADPI_PID"; do sleep 1; i=$((i+1)); done
    rm -f "$CIADPI_PID" 2>/dev/null
    free_foreign_socks
    spawn_byedpi
    daemon_wait_port "$CIADPI_PID" byedpi 8 "$SOCKS_ADDR" "$SOCKS_PORT" || { log "restart_byedpi: $DAEMON_WAIT_WHY"; return 1; }
    socks_ours          # успех = порт слушает И держит НАШ pid (иначе ложно-положительный, см. выше)
}







reup_carrier() {
    free_foreign_socks
    if ! proc_alive "$CIADPI_PID"; then
        log "reup: ciadpi мёртв (accept-EINVAL?) — перезапускаю на месте"
        spawn_byedpi
    fi
    daemon_wait_port "$CIADPI_PID" byedpi 8 "$SOCKS_ADDR" "$SOCKS_PORT" || { log "reup: socks $SOCKS_PORT не поднялся — $DAEMON_WAIT_WHY"; return 1; }
    socks_ours || { log "reup: socks $SOCKS_PORT держит чужой демон — несущую не считаю поднятой"; return 1; }
    if ! proc_alive "$HEV_PID"; then
        log "reup: hev мёртв — перезапускаю"
        start-stop-daemon -S -b -m -p "$HEV_PID" -x "$HEV" -- "$HEV_YAML"
        daemon_wait_dev "$HEV_PID" hev 6 "$TUN" || log "reup: $DAEMON_WAIT_WHY"
    fi
    ip link show "$TUN" >/dev/null 2>&1 || { log "reup: нет $TUN"; return 1; }
    owner_rule_add          # анти-петля могла слететь? переутверждаем (идемпотентно)
    apply_byedpi_routing
    ct_flush   # сбросить залипшие маршруты (грабля NSS/conntrack)
    return 0
}


apply_byedpi_routing() {
    ip link set "$TUN" up 2>/dev/null
    ipt_top FORWARD -o "$TUN" -j ACCEPT
    ipt_top FORWARD -i "$TUN" -j ACCEPT
    ip route replace default dev "$TUN" table "$TABLE"
}


cmd_up() {
    [ -f "$SWEEP_BAK" ] && sweep_restore   # подчистить брошенный браузер-свип (вернуть исходную стратегию)
    owner_rule_add          # анти-петля ДО подъёма (egress ciadpi мимо маркировки)
    if ! start_daemons; then
        log "запуск не удался — несущая не поднята (оркестратор решит, что дальше)"
        stop_daemons
        bd_any_byedpi_slot || owner_rule_del   # ref-count: анти-петля общая с byedpi-ВЫХОДАМИ (см. cmd_down)
        return 1
    fi
    apply_byedpi_routing
    set_direct_dns
    echo byedpi > "$TRANSPORT_FLAG"
    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    carrier_up_mark         # грейс сторожу: демоны стартовали, но egress поднимается ещё секунды (clock-lib.sh)
    ct_flush
    log "транспорт = BYEDPI (default table $TABLE -> $TUN, десинк напрямую). Общие правила сохранены."
    cmd_status
}

cmd_down() {


    [ -f "$SWEEP_BAK" ] && sweep_restore   # свип шёл при down → вернуть исходную стратегию, снять lock
    stop_daemons
    iptables -D FORWARD -o "$TUN" -j ACCEPT 2>/dev/null
    iptables -D FORWARD -i "$TUN" -j ACCEPT 2>/dev/null
    ip route flush table "$TABLE" 2>/dev/null || true






    bd_any_byedpi_slot || owner_rule_del
    dns_direct_rules del    # снять наши DNS-RETURN (следующий транспорт поставит свой DNS)
    set_dnsmasq_direct      # dnsmasq на прямой резолвер — fail-open до подъёма следующего транспорта
    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    ct_flush
    log "ByeDPI-несущая снята (релинквиш) -> прямой режим (fail-open). Следующий транспорт ставит оркестратор."
}

cmd_status() {




    t=; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    echo "=== транспорт: ${t:-(флаг пуст — транспорт не выбран)} ==="




    echo "--- десинк-аргументы ---"; desync_args; echo
    echo "--- default в table $TABLE ---"; ip route show table "$TABLE" 2>/dev/null | grep default   # raw-print: сырой вывод человеку в `status`, вердикта тут нет
    echo "--- демоны ---"
    proc_alive "$CIADPI_PID" && echo "ciadpi: pid $(cat $CIADPI_PID) жив" || echo "ciadpi: не запущен"
    proc_alive "$HEV_PID"    && echo "hev:    pid $(cat $HEV_PID) жив"    || echo "hev:    не запущен"
    echo "--- tun $TUN ---"; ip -o link show "$TUN" 2>/dev/null || echo "нет"
    echo "--- socks $SOCKS_PORT ---"; netstat -ltn 2>/dev/null | grep "$SOCKS_PORT" || echo "не слушает"
    echo "--- owner-RETURN (анти-петля) ---"; iptables -t mangle -S OUTPUT 2>/dev/null | grep "owner" || echo "нет"
    if [ "$t" = byedpi ]; then
        echo "--- egress через ciadpi socks ---"
        probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$SOCKS_PORT" 8; echo
    fi
    echo "--- awg0 (тёплый резерв) ---"; ip link show awg0 >/dev/null 2>&1 && echo "поднят" || echo "нет"
}





cmd_health() {
    t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    [ "$t" = byedpi ] || return 0





    [ -e "$SWITCH_LOCK" ] && { log "health: идёт смена транспорта (lock) — не вмешиваюсь"; return 0; }



    if sweep_fresh; then return 0; fi
    if [ -f "$SWEEP_LOCK" ]; then
        log "health: браузер-свип брошен (lock протух) — восстанавливаю исходную стратегию"
        sweep_restore; restart_byedpi >/dev/null 2>&1; ct_flush
    fi





    if ! proc_alive "$CIADPI_PID" || ! proc_alive "$HEV_PID" || ! ip link show "$TUN" >/dev/null 2>&1; then
        log "health: несущая byedpi просела (ciadpi/hev/tun) — переподнимаю на месте"
        reup_carrier || { log "health: переподнять byedpi не удалось — отдаю эскалацию оркестратору"; return 1; }
    fi










    for hip in 1.1.1.1 8.8.8.8; do
        code=$(curl -sk -o /dev/null -w '%{http_code}' --max-time 6 --socks5 "$SOCKS_ADDR:$SOCKS_PORT" "https://$hip" 2>/dev/null)
        case "$code" in ''|000) ;; *) return 0 ;; esac
    done
    log "health: проба egress по IP не прошла (ciadpi не форвардит наружу)"; return 1
}







cmd_failover() {
    t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    [ "$t" = byedpi ] || { log "byedpi-failover: byedpi не активен → эскалация на оркестраторе"; return 1; }



    [ -e "$SWITCH_LOCK" ] && { log "byedpi-failover: идёт смена транспорта (lock) — не вмешиваюсь"; return 0; }
    if sweep_fresh; then log "byedpi-failover: идёт браузер-свип — остаёмся на byedpi"; return 0; fi
    log "byedpi-failover: переподнимаю локальный десинк на месте (без ухода на VPS/awg)…"
    if reup_carrier; then
        log "byedpi-failover: ciadpi/hev снова подняты — остаёмся на byedpi"
        return 0
    fi
    log "byedpi-failover: переподнять не удалось → эскалация на оркестраторе (cross/прямой)"
    return 1
}





cmd_reload() {
    t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    [ "$t" = byedpi ] || { log "reload: byedpi не активен — новые args применятся при следующем up"; return 0; }
    if restart_byedpi; then
        ct_flush
        log "ciadpi перезапущен (десинк: $(desync_args))"
        return 0
    fi
    log "reload: ciadpi не перезапустился. Лог:"; tail -n 15 "$CIADPI_LOG" 2>/dev/null
    return 1
}






cmd_presets() {
    cat <<'PRESETS'
Авто (по умолчанию)|
ByeDPI стандарт (oob+tlsrec)|-o1 -a1 -r-5+se
Disorder+split простой|-d1 -s3+s
Split+fake (на тесте брал YouTube)|-s1+s -f2+s -t4
Disorder по SNI (Discord)|-d1+s
OOB+tlsrec лёгкий|-o1 -r-5+se
Disorder+split+tlsrec+fake|-d1 -s1+s -r1+s -f-1 -t8
OOB+disorder авто (лёгкий)|-o1 -a1 -At,r,s -d1 -a1
Лесенка сплитов по SNI|-d1 -s1+s -s3+s -s6+s -s9+s -s12+s -s15+s -s20+s -s30+s -a1
Чередование disorder/split по SNI|-d1 -s1+s -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -a1
Мульти-сплит+tlsrec (YouTube, тест-пресет №2)|-d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -r1+s -a1 -As -d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -a1
OOB+disorder авто-эскалация|-o1 -d1 -a1 -At,r,s -s1 -d1 -s5+s -s10+s -s15+s -s20+s -r1+s -a1 -As -s1 -d1 -s5+s -s10+s -s15+s -s20+s -a1
Disorder+fake многоступенчатый|-d1+s -s50+s -a1 -As -f20 -r2+s -a1 -At -d2 -s1+s -s5+s -s10+s -s15+s -s25+s -s35+s -s50+s -s60+s -a1
tlsrec+сплит авто|-r5+s -s25+s -a1 -At,r,s -s50 -r5+s -s50+s -a1
OOB+fake авто по триггерам|-o1 -a1 -At,r,s -f-1 -a1 -Ar,s -o1 -a1 -At -r1+s -f-1 -t6 -a1
Сплит+tlsrec+mod-http (агрессивный)|-q2 -s2 -s3+s -r3 -s4 -r4 -s5+s -r5+s -s6 -s7+s -r8 -s9+s -Qr -Mh,d,r -a1 -At,r -s2+s -r2 -d2 -s3 -r3 -r4 -s4 -d5+s -r5 -d6 -s7+s -d7 -a1
Disorder+oob+fake авто|-d1 -o1 -a1 -Ar -o1 -a1 -At -f-1 -r1+s -a1
disoob+oob+tlsrec|-r8 -o2 -s7 -q4+s -a1
OOB+split+tlsrec короткий|-o1+s -d3+s -a1
Disorder@7 + split@2|-d7 -s2 -a1
OOB@3 + disorder@7|-o3 -d7 -a1
tlsrec глубокий (r25)|-q1 -r25+s -a1
OOB + двойной split|-o1 -s4 -s6 -a1
Двойной split + mod|-s5+s -s35+s -m4 -a1
Disorder + fake-http + OOB|-d6+s -q4+hm -o2 -a1
Disorder+OOB+split+tlsrec|-d1+s -o2 -s5 -r5 -a1
Split+disorder, авто-tlsrec|-s1 -d3+s -a1 -At -r1+s -a1
Лесенка disorder→split|-d1 -d3+s -s6+s -d9+s -s20+s -d25+s -s30+s -a1
Чередование (плотное)|-d1 -s4 -d8 -s1+s -d5+s -s10+s -d20+s -a1
Полный набор (disorder+split+tlsrec+oob+fake)|-d1 -s1+s -r1+s -e1 -m1 -o1+s -f-1 -t2 -a1
Плотные сплиты + TTL12 авто|-d1 -d3+s -s6+s -d6+s -s7+s -d8+s -s10+s -a1 -t12 -At,s -r3
PRESETS
}













sweep_fresh() {   # 0 = идёт свежий свип → не вмешиваться
    [ -f "$SWEEP_LOCK" ] || return 1
    ts=$(cat "$SWEEP_LOCK" 2>/dev/null | tr -d ' \r\n'); case "$ts" in ''|*[!0-9]*) return 1 ;; esac
    [ "$(age_since "$ts")" -lt "$SWEEP_TTL" ]
}
sweep_touch() { date +%s > "$SWEEP_LOCK"; }





sweep_target() {
    case "${1:-}" in
        '')      SW_ARGS="$ARGS_FILE"; SW_BAK="$SWEEP_BAK"; SW_SLOT="" ;;
        2|3|4)   SW_ARGS="$ENODIA_STATE/.byedpi-args-s$1"; SW_BAK="$ENODIA_STATE/.byedpi-args-s$1.sweepbak"; SW_SLOT="$1" ;;
        *)       return 1 ;;
    esac
    return 0
}


sweep_target_live() {
    if [ -z "$SW_SLOT" ]; then
        t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
        [ "$t" = byedpi ] && return 0
        return 1
    fi
    sh "$ENODIA_DIR/slots.sh" list-enabled 2>/dev/null | grep -q "^$SW_SLOT	byedpi	"
}

sweep_restart() {
    if [ -z "$SW_SLOT" ]; then restart_byedpi; return $?; fi
    cmd_slot_reload "$SW_SLOT" >/dev/null 2>&1
}


sweep_restore() {
    _ba="${SW_BAK:-$SWEEP_BAK}"; _aa="${SW_ARGS:-$ARGS_FILE}"
    if [ -f "$_ba" ]; then
        if [ -s "$_ba" ]; then mv "$_ba" "$_aa" 2>/dev/null
        else rm -f "$_aa" 2>/dev/null; fi
    fi
    rm -f "$SWEEP_LOCK" "$_ba" 2>/dev/null
}





cmd_sweep_begin() {
    sweep_target "$1" || { log "sweep-begin: битая цель '$1'"; return 1; }
    sweep_target_live || { log "sweep-begin: цель не несёт трафик — свип возможен только на боевой несущей/включённом выходе"; return 1; }
    if [ ! -f "$SW_BAK" ]; then
        if [ -f "$SW_ARGS" ]; then cp "$SW_ARGS" "$SW_BAK" 2>/dev/null; else : > "$SW_BAK"; fi
    fi
    sweep_touch
    log "sweep-begin: браузер-свип начат (исходная стратегия сохранена в $SW_BAK)"
    return 0
}


cmd_sweep_apply() {
    sweep_target "$2" || { log "sweep-apply: битая цель '$2'"; return 1; }
    sweep_target_live || { log "sweep-apply: цель не несёт трафик"; return 1; }
    [ -f "$SW_BAK" ] || { log "sweep-apply: свип не начат (нет бэкапа) — отказ"; return 1; }
    sweep_touch
    a=$(printf '%s' "$1" | tr '\r\n' '  ' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[[:space:]]\{1,\}/ /g')
    if [ -n "$a" ]; then printf '%s\n' "$a" > "$SW_ARGS.new" && mv "$SW_ARGS.new" "$SW_ARGS"; else rm -f "$SW_ARGS"; fi
    if sweep_restart; then
        ct_flush
        sweep_touch          # рестарт занял время — обновляем lock, чтобы не протух среди пробы
        log "sweep-apply: применена стратегия${SW_SLOT:+ выхода №$SW_SLOT} ($a)"
        return 0
    fi
    sweep_touch
    log "sweep-apply: ciadpi не поднялся на этой стратегии (провал)"
    return 1
}



sweep_end_restart() {
    if [ -n "$SW_SLOT" ]; then
        sweep_restart >/dev/null 2>&1; ct_flush
    else
        t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
        if [ "$t" = byedpi ]; then restart_byedpi >/dev/null 2>&1; ct_flush; fi
    fi
    return 0
}
cmd_sweep_end() {
    sweep_target "$1" || sweep_target ''
    sweep_restore
    carrier_run sweep_undo sweep_end_restart '' "$SW_SLOT"
    log "sweep-end: исходная стратегия восстановлена, свип завершён"
    return 0
}


















SLOTS_SH="$ENODIA_DIR/slots.sh"




if [ -f "$ENODIA_DIR/slot-tun-lib.sh" ]; then . "$ENODIA_DIR/slot-tun-lib.sh"; else SLOT_LIB_MISSING=1; fi
slot_lib_ok() { [ -z "$SLOT_LIB_MISSING" ] && return 0
    echo "[byedpi] слот-слой недоступен: нет $ENODIA_DIR/slot-tun-lib.sh — обновите скрипты" >&2; return 1; }



command -v slot_socks_is_ours >/dev/null 2>&1 || slot_socks_is_ours() { return 0; }
slot_ciadpi_pid() { echo "/tmp/enodia-byedpi-s$1.pid"; }
slot_ciadpi_log() { echo "/tmp/enodia-byedpi-s$1.log"; }
slot_args_file()  { echo "$ENODIA_STATE/.byedpi-args-s$1"; }   # per-slot стратегия (нет → общий DEFAULT_ARGS)





slot_desync_args() {   # $1 = id
    _sa=$(args_from_file "$(slot_args_file "$1")"); [ -n "$_sa" ] && { echo "$_sa"; return; }
    _sa=$(args_from_file "$ARGS_FILE");             [ -n "$_sa" ] && { echo "$_sa"; return; }
    strip_unsupported "$DEFAULT_ARGS"
}


bd_transport_active() { [ "$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')" = byedpi ]; }





bd_any_byedpi_slot() {   # $1 = exclude id (опц.)
    [ -f "$SLOTS_SH" ] || return 1
    sh "$SLOTS_SH" list-enabled 2>/dev/null | while IFS="$(printf '\t')" read -r _sid _st _rest; do
        [ "$_st" = byedpi ] || continue
        { [ -n "$1" ] && [ "$_sid" = "$1" ]; } && continue
        echo hit
    done | grep -q hit
}
owner_rule_needed() {   # $1 = exclude slot id (опц.); код 0 = ещё нужна (НЕ снимать)
    bd_transport_active && return 0
    bd_any_byedpi_slot "$1" && return 0
    return 1
}


slot_spawn_ciadpi() {   # $1 = id
    _id="$1"; _port=$(slot_socks_port "$_id"); _log=$(slot_ciadpi_log "$_id")
    : > "$_log" 2>/dev/null || true
    chmod 666 "$_log" 2>/dev/null || true          # nobody должен дописывать
    _a=$(slot_desync_args "$_id")
    start-stop-daemon -S -b -c nobody -m -p "$(slot_ciadpi_pid "$_id")" -x /bin/sh -- -c "exec '$CIADPI' -i $SOCKS_ADDR -p $_port $_a >>'$_log' 2>&1"
}

slot_start_daemons() {   # $1 = id ; 0 = ciadpi+hev+tun подняты
    [ -x "$CIADPI" ] || { log "слот №$1: НЕТ бинаря ciadpi ($CIADPI) — установите ByeDPI"; return 1; }
    [ -x "$HEV" ]    || { log "слот №$1: НЕТ бинаря hev"; return 1; }   # проверяем ДО старта ciadpi (не плодим лишний демон)
    _id="$1"; _port=$(slot_socks_port "$_id")
    slot_free_socks "$_id" "$(slot_ciadpi_pid "$_id")"
    if ! proc_alive "$(slot_ciadpi_pid "$_id")"; then
        log "слот №$_id: запускаю ciadpi на :$_port (десинк: $(slot_desync_args "$_id"))…"
        slot_spawn_ciadpi "$_id"
    fi
    if ! slot_wait_socks "$_port" "$(slot_ciadpi_pid "$_id")" byedpi; then
        log "слот №$_id: ciadpi не слушает :$_port ($DAEMON_WAIT_WHY). Лог:"; tail -n 15 "$(slot_ciadpi_log "$_id")" 2>/dev/null
        return 1
    fi
    slot_hev_up "$_id"          # hev + ожидание xtunN (общий слой)
}
slot_stop_daemons() {   # $1 = id
    _id="$1"
    slot_hev_down "$_id"        # hev + снятие xtunN + чистка пидфайла (общий слой)
    start-stop-daemon -K -p "$(slot_ciadpi_pid "$_id")" 2>/dev/null
    rm -f "$(slot_ciadpi_pid "$_id")" 2>/dev/null   # не копить stale-пидфайлы (риск переиспользования pid)
}



cmd_slot_up() {   # $1 = id ; $2 = cfg (игнор)
    _id="$1"
    case "$_id" in 2|3|4) ;; *) log "слот: id = 2..4"; return 1 ;; esac
    owner_rule_add          # анти-петля (egress ciadpi мимо маркировки) ДО подъёма; ref-count держит её
    if ! slot_start_daemons "$_id"; then
        log "слот №$_id: несущая byedpi не поднялась -> выход живёт по fallback-политике (mark-core)"
        slot_stop_daemons "$_id"
        owner_rule_needed "$_id" || owner_rule_del
        return 1
    fi
    slot_apply_routing "$_id"
    ct_flush
    log "слот №$_id: byedpi-несущая $(slot_tun "$_id") в table $(slot_table "$_id") (десинк напрямую)"
    return 0
}
cmd_slot_down() {   # $1 = id
    _id="$1"
    case "$_id" in 2|3|4) ;; *) log "слот: id = 2..4"; return 1 ;; esac
    slot_remove_routing "$_id"
    slot_stop_daemons "$_id"
    owner_rule_needed "$_id" || owner_rule_del   # снять анти-петлю, если не нужна ни транспорту, ни др. byedpi-слоту
    rm -f "$(slot_hev_yaml "$_id")" 2>/dev/null
    ct_flush
    log "слот №$_id: byedpi-несущая снята"
    return 0
}





cmd_slot_reload() {   # $1 = id
    _id="$1"
    case "$_id" in 2|3|4) ;; *) log "слот: id = 2..4"; return 1 ;; esac
    _pid=$(slot_ciadpi_pid "$_id"); _port=$(slot_socks_port "$_id")
    proc_alive "$_pid" || { log "слот №$_id: ciadpi не запущен — новая стратегия применится при включении выхода"; return 0; }







    start-stop-daemon -K -p "$_pid" 2>/dev/null
    i=0; while [ $i -lt 6 ] && proc_alive "$_pid"; do sleep 1; i=$((i+1)); done
    rm -f "$_pid" 2>/dev/null
    slot_free_socks "$_id" "$_pid"
    slot_spawn_ciadpi "$_id"

    if slot_wait_socks "$_port" "$_pid" byedpi && slot_socks_is_ours "$_port" "$_pid"; then

        ct_flush
        log "слот №$_id: ciadpi перезапущен (десинк: $(slot_desync_args "$_id"))"
        return 0
    fi


    log "слот №$_id: ciadpi не перезапустился — пробую поднять выход целиком. Лог:"; tail -n 15 "$(slot_ciadpi_log "$_id")" 2>/dev/null
    cmd_slot_up "$_id" && return 0
    return 1
}








cmd_slot_health() {   # $1 = id
    _id="$1"
    case "$_id" in 2|3|4) ;; *) return 1 ;; esac


    sweep_fresh && return 0
    proc_alive "$(slot_ciadpi_pid "$_id")" || { log "слот №$_id health: ciadpi не жив"; return 1; }
    proc_alive "$(slot_hev_pid "$_id")"    || { log "слот №$_id health: hev не жив"; return 1; }
    ip link show "$(slot_tun "$_id")" >/dev/null 2>&1 || { log "слот №$_id health: нет $(slot_tun "$_id")"; return 1; }
    _sp=$(slot_socks_port "$_id")
    for _hip in 1.1.1.1 8.8.8.8; do

        _code=$(curl -sk -o /dev/null -w '%{http_code}' --max-time 6 --socks5 "$SOCKS_ADDR:$_sp" "https://$_hip" 2>/dev/null)
        case "$_code" in ''|000) ;; *) return 0 ;; esac
    done
    log "слот №$_id health: проба egress не прошла (ciadpi не форвардит наружу)"
    return 1
}


sweep_undo() { if [ -n "$2" ]; then cmd_slot_down "$2"; else cmd_down; fi; }

case "$1" in



    up)       carrier_run cmd_down cmd_up ;;
    down)     cmd_down ;;
    cold)     : ;;                        # тёплого резерва нет: демонов гасит сам `down` (stop_daemons)
    status)   cmd_status ;;
    health)   carrier_run cmd_down cmd_health ;;
    failover) carrier_run cmd_down cmd_failover ;;
    dns)      set_direct_dns ;;      # переиграть DNS (DoH toggle/смена резолвера) — прямой режим через doh_apply_dns
    reload)   carrier_run cmd_down cmd_reload ;;   # перезапустить ciadpi с текущими .byedpi-args (без обрыва несущей)
    defaults) strip_unsupported "$DEFAULT_ARGS" ;;  # дефолтный авто-набор (для показа в панели; -S вырезан)
    presets)  cmd_presets ;;         # курированная библиотека готовых стратегий (label|args)


    socks-up)   cmd_socks_up "$2" ;;      # $2 = pid вызывающего (ref-счёт: прокси общий на процессы)
    socks-down) cmd_socks_down "$2" ;;


    sweep-begin) cmd_sweep_begin "$2" ;;      # снять бэкап исходной стратегии + поставить lock
    sweep-apply) carrier_run sweep_undo cmd_sweep_apply "$2" "$3" ;; # применить ОДНУ стратегию вживую (0=поднялся,1=нет)
    sweep-end)   cmd_sweep_end "$2" ;;        # восстановить исходную стратегию, снять lock

    slot-up)   slot_lib_ok || exit 2; carrier_run cmd_slot_down cmd_slot_up "$2" "$3" ;;   # доп-выход (Ф1c): поднять ciadpi+hev+xtunN в table 100N (cfg игнор)
    slot-down) slot_lib_ok || exit 2; cmd_slot_down "$2" ;;      # доп-выход: снять несущую слота (-> fallback-политика mark-core)
    slot-health) slot_lib_ok || exit 2; cmd_slot_health "$2" ;;  # доп-выход: жив ли выход (watchdog; egress-проба, не только pid)
    slot-reload) slot_lib_ok || exit 2; carrier_run cmd_slot_down cmd_slot_reload "$2" ;;  # доп-выход: перечитать .byedpi-args-s<id> (перезапуск только ciadpi слота)
    slot-iface)  slot_lib_ok || exit 2; slot_tun "$2" ;;         # имя несущей слота — учёту трафика (владелец имени один: slot-tun-lib.sh)
    *) echo "usage: $0 up|down|cold|status|health|failover|reload|defaults|presets|socks-up [pid]|socks-down [pid]|sweep-begin|sweep-apply|sweep-end|slot-up <id>|slot-down <id>|slot-health <id>|slot-reload <id>|slot-iface <id>"; exit 2 ;;
esac
