#!/bin/sh























































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}






ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}
if [ ! -f "$ENODIA_DIR/VERSION" ] && [ -f "$ENODIA_BOOT/boot.sh" ]; then
    _bp=$(sh "$ENODIA_BOOT/boot.sh" paths 2>/dev/null)
    _bd=$(printf '%s\n' "$_bp" | sed -n 's/^dir=//p' | tail -1)
    _bs=$(printf '%s\n' "$_bp" | sed -n 's/^state=//p' | tail -1)
    _bb=$(printf '%s\n' "$_bp" | sed -n 's/^bin=//p' | tail -1)
    case "$_bd" in /*) ENODIA_DIR="$_bd" ;; esac
    case "$_bs" in /*) ENODIA_STATE="$_bs" ;; esac
    case "$_bb" in /*) ENODIA_BIN="$_bb" ;; esac
    unset _bp _bd _bs _bb
fi









OUR_DIRS="$ENODIA_DIR $ENODIA_STATE $ENODIA_BIN $ENODIA_BOOT"


if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
DRY=0
MODE=text



case "${1:-}" in
    "")     : ;;
    dryrun) DRY=1 ;;
    json)   MODE=json ;;
    clean)  MODE=clean ;;





    ramlogs-list) MODE=ramlogs-list ;;
    *) echo "usage: $0 [dryrun|json|clean [junk snaps ramlogs stocklogs]|ramlogs-list]" >&2; exit 2 ;;
esac











sz_k() {                        # суммарный размер СУЩЕСТВУЮЩИХ путей, КБ
    _t=0
    for _p in "$@"; do
        [ -e "$_p" ] || continue
        _v=$(du -xsk "$_p" 2>/dev/null | awk '{print $1}')
        case "$_v" in ''|*[!0-9]*) _v=0 ;; esac
        _t=$((_t+_v))
    done
    echo "$_t"
}









df_k_at()  { df -k "$1" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{print $(NF-4)" "$(NF-3)" "$(NF-2)}'; }
df_mp_at() { _dmp=$(df -k "$1" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{print $NF}'); printf '%s' "${_dmp:-/data}"; }
df_k()  { df_k_at "$ENODIA_DIR"; }
df_mp() { df_mp_at "$ENODIA_DIR"; }





junk_targets() {







    for _t in "$ENODIA_DIR/.gh-backup" "$ENODIA_STATE/.gh-backup" "$ENODIA_DIR/backups" "$ENODIA_DIR/.dl"; do
        [ -e "$_t" ] && echo "$_t"
    done










    for _d in $OUR_DIRS; do
        for _t in "$_d"/*.bak "$_d"/*.new "$_d"/.*.new "$_d"/*.tar.gz "$_d"/*.tgz "$_d"/*.zip "$_d"/*.log; do
            [ -e "$_t" ] && echo "$_t"
        done
    done




    _dls=""
    for _d in $OUR_DIRS; do
        for _t in "$_d"/*.dl "$_d"/.*.dl; do [ -f "$_t" ] && _dls="$_dls $_t"; done
    done
    if [ -n "$_dls" ] && ! dl_writer_alive; then
        for _t in $_dls; do echo "$_t"; done
    fi
    return 0
}


dl_writer_alive() {
    command -v pid_runs >/dev/null 2>&1 || return 0
    for _p in /proc/[0-9]*; do pid_runs "${_p#/proc/}" 'gh-update\.sh' && return 0; done
    return 1
}


snap_targets() {
    for _t in "$ENODIA_STATE/.iplist.snapshot" "$ENODIA_STATE"/geo/.snap-* \
              "$ENODIA_STATE"/lists/*/.snapshot; do
        [ -e "$_t" ] && echo "$_t"
    done
    return 0
}



RAM_LOGS="enodia-dnsq enodia-restore enodia-startup enodia-store-mode enodia-watchdog
enodia-byedpi enodia-byedpi-test-run enodia-byedpi-fetch enodia-doh enodia-hev enodia-hysteria
enodia-iplist-update enodia-notify enodia-notify-event enodia-panel-tls enodia-subs-update
enodia-support enodia-switch-vpn-setup enodia-transport-awg-setup enodia-xiaomi-bypass
enodia-zapret-nfqws hytest ussl-dbg xray xray-access
byedpi byedpi-test-run doh hev hysteria iplist-update notify notify-event panel-tls
subs-update support switch-vpn-setup transport-awg-setup xiaomi-bypass zapret-nfqws"
















RAM_LOGS_SLOT="xray enodia-hev enodia-hysteria enodia-byedpi hev hysteria byedpi"  # демоны с пер-слотовым инстансом (+ имена до префикса)
RAM_SLOT_IDS="2 3 4"                        # диапазон номеров выходов (slots.sh)
RAM_XTEST_PORTS="10812 10813 10814 10815 10816 10817 10818 10819"   # xray-test.sh
ramlog_targets() {
    for _n in $RAM_LOGS; do [ -s "/tmp/$_n.log" ] && echo "/tmp/$_n.log"; done
    for _i in $RAM_SLOT_IDS; do
        for _n in $RAM_LOGS_SLOT; do [ -s "/tmp/$_n-s$_i.log" ] && echo "/tmp/$_n-s$_i.log"; done
        [ -s "/tmp/xray-s$_i.access.log" ] && echo "/tmp/xray-s$_i.access.log"
    done
    for _p in $RAM_XTEST_PORTS; do
        [ -s "/tmp/xray-test.$_p.log" ] && echo "/tmp/xray-test.$_p.log"
        [ -s "/tmp/xray-test.$_p.access.log" ] && echo "/tmp/xray-test.$_p.access.log"
    done
    return 0
}




bin_targets() {
    for _f in "$ENODIA_BIN"/*; do
        [ -f "$_f" ] || continue



        case "$_f" in
            *.sh|*.conf|*.json|*.yaml|*.yml|*.txt|*.md|*.example|*.bak|*.new|*.dl|*.tar.gz|*.tgz|*.zip|*.log|*/VERSION) continue ;;
        esac
        [ -x "$_f" ] && echo "$_f"
    done


    [ -d "$ENODIA_DIR/bin" ] && echo "$ENODIA_DIR/bin"
    return 0
}
cfg_targets() {
    for _t in "$ENODIA_STATE/configs" "$ENODIA_STATE/xray-configs" "$ENODIA_STATE/server" \
              "$ENODIA_STATE"/*.conf "$ENODIA_STATE"/*.json "$ENODIA_STATE"/*.yaml \
              "$ENODIA_STATE"/*.yml; do
        [ -e "$_t" ] && echo "$_t"
    done
    return 0
}
lst_targets() {
    for _t in "$ENODIA_STATE/lists" "$ENODIA_STATE/geo"; do [ -e "$_t" ] && echo "$_t"; done
    [ -e "$ENODIA_STATE/.iplist.snapshot" ] && echo "$ENODIA_STATE/.iplist.snapshot"
    return 0
}
sh_targets() { for _t in "$ENODIA_DIR"/*.sh; do [ -e "$_t" ] && echo "$_t"; done; return 0; }
















sys_walk() {
    for _p in "$1"/* "$1"/.[!.]*; do
        [ -e "$_p" ] || continue
        _ours=0
        for _o in $OUR_DIRS; do
            if [ "$_p" = "$_o" ]; then _ours=1; break; fi
            case "$_o" in "$_p"/*) _ours=2 ;; esac
        done
        if [ "$_ours" = 1 ]; then continue; fi
        if [ "$_ours" = 2 ]; then sys_walk "$_p"; else echo "$_p"; fi
    done
    return 0
}

















STOCK_LOG_DIR=/data/usr/log
stocklog_rotated() {   # ротации — удаляем
    for _t in "$STOCK_LOG_DIR"/messages.*; do [ -f "$_t" ] && echo "$_t"; done
    return 0
}
stocklog_live() {      # живой лог, если он на этой прошивке лежит на флеше, — обрезаем
    [ -s "$STOCK_LOG_DIR/messages" ] && echo "$STOCK_LOG_DIR/messages"
    return 0
}
stocklog_targets() { stocklog_rotated; stocklog_live; return 0; }

sum_of() { sz_k $("$@" | tr '\n' ' '); }   # КБ по списку из функции-перечислителя





if [ "$MODE" = ramlogs-list ]; then
    ramlog_targets
    exit 0
fi




if [ "$MODE" = json ]; then
    set -- $(df_k); TOT_K=${1:-0}; USED_K=${2:-0}; FREE_K=${3:-0}

    ENODIA_K=$(sz_k $OUR_DIRS)
    BIN_K=$(sum_of bin_targets)
    WEB_K=$(sz_k "$ENODIA_DIR/web")
    SCR_K=$(sum_of sh_targets)
    CFG_K=$(sum_of cfg_targets)
    LST_K=$(sum_of lst_targets)
    JNK_K=$(sum_of junk_targets)
    SNP_K=$(sum_of snap_targets)


    BOOT_K=$(sz_k "$ENODIA_BOOT")




    ST_K=$((ENODIA_K - BIN_K - WEB_K - SCR_K - CFG_K - LST_K - JNK_K - BOOT_K))
    [ "$ST_K" -lt 0 ] && ST_K=0











    DATA_K=$(sz_k /data)
    SYS_LIST=$(sys_walk /data | while read -r _p; do
        [ -n "$_p" ] && echo "$(sz_k "$_p") $_p"
    done | sort -rn)
    SYS_K=0
    for _v in $(echo "$SYS_LIST" | awk '{print $1}'); do
        case "$_v" in ''|*[!0-9]*) continue ;; esac
        SYS_K=$((SYS_K+_v))
    done
    OTH_K=$((DATA_K - ENODIA_K - SYS_K)); [ "$OTH_K" -lt 0 ] && OTH_K=0

    kb() { echo $(( ${1:-0} * 1024 )); }
    printf '{"total_b":%s,"used_b":%s,"free_b":%s,"awg_b":%s,"data_b":%s,"sys_b":%s,"cats":[' \
        "$(kb "$TOT_K")" "$(kb "$USED_K")" "$(kb "$FREE_K")" "$(kb "$ENODIA_K")" "$(kb "$DATA_K")" \
        "$(kb "$SYS_K")"
    _first=1
    for _c in "bin $BIN_K" "web $WEB_K" "scripts $SCR_K" "configs $CFG_K" \
              "lists $LST_K" "state $ST_K" "junk $JNK_K" "boot $BOOT_K" "other $OTH_K"; do
        set -- $_c
        [ "$_first" = 1 ] || printf ','
        _first=0
        printf '{"id":"%s","b":%s}' "$1" "$(kb "$2")"
    done


    printf '],"sys":['
    _first=1




    echo "$SYS_LIST" | while read -r _b _p; do
        [ -n "$_p" ] || continue
        [ "$_first" = 1 ] || printf ','
        _first=0
        case "${_p##*/}" in enodia|enodia-*|enodia.*) _ou=true ;; *) _ou=false ;; esac
        printf '{"path":"%s","b":%s,"ours":%s}' "$_p" "$(kb "$_b")" "$_ou"
    done
    printf '],"junk":['
    _first=1
    junk_targets | while read -r _p; do
        [ "$_first" = 1 ] || printf ','
        _first=0
        printf '{"path":"%s","b":%s}' "$_p" "$(kb "$(sz_k "$_p")")"
    done
    printf '],"junk_b":%s,"snaps_b":%s,"snaps_n":%s,"ramlogs_b":%s,"ramlogs_n":%s,"stocklogs_b":%s,"stocklogs_n":%s}\n' \
        "$(kb "$JNK_K")" "$(kb "$SNP_K")" "$(snap_targets | wc -l)" \
        "$(kb "$(sum_of ramlog_targets)")" "$(ramlog_targets | wc -l)" \
        "$(kb "$(sum_of stocklog_targets)")" "$(stocklog_targets | wc -l)"
    exit 0
fi




if [ "$MODE" = clean ]; then
    shift




    CL_GROUPS=$(echo "$*" | tr ',' ' ')
    [ -z "$CL_GROUPS" ] && CL_GROUPS=junk
    has_g() { case " $CL_GROUPS " in *" $1 "*) return 0 ;; esac; return 1; }

    set -- $(df_k); BEFORE_K=${3:-0}
    freed_ram=0; n=0





    CODE_ON_STORE=""; [ -d "$ENODIA_BOOT" ] && [ "$(df_mp)" != "$(df_mp_at "$ENODIA_BOOT")" ] && CODE_ON_STORE=1
    LOG_APART=""; [ -d "$STOCK_LOG_DIR" ] && [ "$(df_mp_at "$STOCK_LOG_DIR")" != "$(df_mp)" ] && LOG_APART=1
    LBEFORE_K=0; if [ -n "$LOG_APART" ]; then set -- $(df_k_at "$STOCK_LOG_DIR"); LBEFORE_K=${3:-0}; fi

    if has_g junk;  then junk_targets | while read -r _p; do rm -rf "$_p" 2>/dev/null; done; fi
    if has_g snaps; then snap_targets | while read -r _p; do rm -rf "$_p" 2>/dev/null; done; fi


    if has_g ramlogs; then
        freed_ram=$(sum_of ramlog_targets)
        ramlog_targets | while read -r _p; do : > "$_p" 2>/dev/null; done
    fi



    if has_g stocklogs; then
        stocklog_rotated | while read -r _p; do rm -f "$_p" 2>/dev/null; done
        stocklog_live    | while read -r _p; do : > "$_p" 2>/dev/null; done
    fi


    sync 2>/dev/null
    set -- $(df_k); AFTER_K=${3:-0}
    n=$((AFTER_K - BEFORE_K)); [ "$n" -lt 0 ] && n=0
    nl=0
    if [ -n "$LOG_APART" ]; then set -- $(df_k_at "$STOCK_LOG_DIR"); nl=$(( ${3:-0} - LBEFORE_K )); [ "$nl" -lt 0 ] && nl=0; fi






    hum() { awk -v k="${1:-0}" 'BEGIN{ if(k<1024) printf "%d КБ", k; else printf "%.1f МБ", k/1024 }'; }
    msg=""
    if [ "$n" -gt 0 ]; then
        if [ -n "$CODE_ON_STORE" ]; then msg="освобождено $(hum "$n") на накопителе"; else msg="освобождено $(hum "$n") на флеше"; fi
    fi
    if [ "$nl" -gt 0 ]; then
        [ -n "$msg" ] && msg="$msg, "
        msg="${msg}освобождено $(hum "$nl") на флеше"
    fi
    if [ "$freed_ram" -gt 0 ]; then
        [ -n "$msg" ] && msg="$msg, "
        msg="${msg}освобождено $(hum "$freed_ram") в ОЗУ (логи)"
    fi
    [ -z "$msg" ] && msg="чистить было нечего"

    printf '{"ok":1,"freed_b":%s,"freed_log_b":%s,"freed_ram_b":%s,"free_b":%s,"msg":"%s"}\n' \
        $((n * 1024)) $((nl * 1024)) $((freed_ram * 1024)) $((AFTER_K * 1024)) "$msg"
    exit 0
fi





echo "=== df $(df_mp) ДО ==="
df -h "$ENODIA_DIR" 2>/dev/null | tail -1

echo ""
echo "=== ТОП потребителей в наших каталогах (KB, du) ==="



for _d in $OUR_DIRS; do du -xsk "$_d"/* "$_d"/.[!.]* 2>/dev/null; done | sort -rn | head -25 \
    | awk '{printf "%8d KB  %s\n",$1,$2}'

echo ""









echo "=== покусочно (KB, du): НАШЕ — каталоги проекта; стоковое — $(df_mp_at /data) ==="
for _d in $OUR_DIRS; do
    printf "%8d KB  %s  <-- наше\n" "$(sz_k "$_d")" "$_d"
done
sys_walk /data | while read -r _p; do
    [ -n "$_p" ] && echo "$(sz_k "$_p") $_p"
done | sort -rn | head -15 | awk '{printf "%8d KB  %s\n",$1,$2}'


rm_target() {
    t="$1"
    [ -e "$t" ] || return 0
    sz=$(du -xsk "$t" 2>/dev/null | awk '{print $1}')
    if [ "$DRY" = 1 ]; then
        echo "  [dry] удалил бы: $t (${sz:-?} KB)"
    else
        rm -rf "$t" 2>/dev/null && echo "  удалено: $t (${sz:-?} KB)" || echo "  НЕ удалить: $t"
    fi
}

echo ""
echo "=== ЧИСТКА (мусор: бэкапы/temp/архивы; конфиги и бинари НЕ трогаем) ==="
[ "$DRY" = 1 ] && echo "(режим DRYRUN — ничего не удаляю, только показываю кандидатов)"


free_k() { set -- $(df_k); echo "${3:-}"; }   # третье поле df_k = свободно (второй копии выражения не заводим)
freed_before=$(free_k)

junk_targets | while read -r t; do rm_target "$t"; done





_stk=$(sum_of stocklog_targets)
if [ "$_stk" -gt 0 ]; then
    echo "  (не трогаю: стоковый лог роутера $STOCK_LOG_DIR — ${_stk} KB; снимается переключателем «Системный лог роутера» на экране «Место и накопитель»)"
fi



[ "$DRY" != 1 ] && sync 2>/dev/null

echo ""
echo "=== df $(df_mp) ПОСЛЕ ==="
df -h "$ENODIA_DIR" 2>/dev/null | tail -1
freed_after=$(free_k)
if [ "$DRY" != 1 ] && [ -n "$freed_before" ] && [ -n "$freed_after" ]; then



    freed_k=$((freed_after - freed_before)); [ "$freed_k" -lt 0 ] && freed_k=0
    echo "Освобождено: $(awk -v k="$freed_k" 'BEGIN{ if(k<1024) printf "%d КБ", k; else printf "%.1f МБ", k/1024 }')"
fi
echo "=== готово ==="
