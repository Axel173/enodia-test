#!/bin/sh












































BOOT_DIR=${ENODIA_BOOT:-/data/usr/app/enodia-boot}



DATA_DIR=/data/usr/app/enodia            # boot-lit: бутстрап и решает, оставить этот путь или подменить
DATA_STATE=/data/usr/app/enodia-state
DATA_BIN=/data/usr/app/enodia-bin




STORE_CACHE="$BOOT_DIR/.store-cache"
STUB_PID=/tmp/enodia-stub.pid
STUB_PORT=8088                          # тот же порт, что у панели (web-ui.sh: PORT) — заглушка

SCAN_STAMP=/tmp/enodia-boot-scan        # когда последний раз искали накопитель (аптайм, секунды)
SCAN_EVERY=45                           # чаще незачем: строк cron семь, а поиск монтирует кандидатов
BOOT_LOCK=/tmp/enodia-boot.lock         # событий одной флешки бывает несколько — второму делать нечего
HEAL_LOCK=/tmp/enodia-heal.lock         # лок heal.sh (пид / «done …»): hotplug-тик ждёт по нему «отработал»
HOTPLUG_WAIT=${HOTPLUG_WAIT:-240}       # потолок ожидания ЖИВОГО heal (с закачкой списков он идёт до ~170 с)
HOTPLUG_NOLOCK_WAIT=${HOTPLUG_NOLOCK_WAIT:-60}   # …а когда лок пуст/держит труп — ждать нечего: минута на старт heal по cron
HOTPLUG_PID=/tmp/enodia-hotplug-tick.pid   # его же передаём start-stop-daemon: два литерала на один файл разъехались бы молча
BOOT_SYNC_LOCK=/tmp/enodia-boot-sync.lock   # переливка бутстрапа: цели cron бегут ВПЕРЕМЕШКУ
CRON=/etc/crontabs/root                 # только для ПЕРЕВОДА прежних строк на бутстрап (cron_to_boot)
HOOK=/etc/hotplug.d/block/99-enodia-usb


PERSIST_PROBE=/etc/enodia-persist



BOOT_ID=/proc/sys/kernel/random/boot_id
INIT_SCRIPT=/etc/init.d/enodia-early
INIT_LINK=/etc/rc.d/S20enodia-early
INIT_TAG='# enodia early v1 — ранний подъём шифрованного DNS (кладёт boot.sh)'
HOOK_TAG='# enodia hotplug v1 — кладётся boot.sh на каждом прогоне (/etc/hotplug.d = ramfs)'



BOOT_FILES='boot.sh mount-lib.sh store-lib.sh router-lib.sh'





target_ok() {
    case "$1" in
        *.sh) ;;
        *) return 1 ;;
    esac
    case "$1" in
        */*|..*|-*) return 1 ;;
    esac
    return 0
}

















code_of() {
    CODE_OF=
    [ -f "$1" ] || return 1
    while read -r _co_l; do
        case "$_co_l" in CODE=*) CODE_OF=${_co_l#CODE=} ;; esac
    done < "$1"
    [ -n "$CODE_OF" ]
}










boot_sync_lock() {      # $1 = сколько секунд ждать (пусто = не ждать вовсе)
    _bl_w=${1:-0}; _bl_i=0; _bl_b=0; _bl_e=0
    while :; do
        if mkdir "$BOOT_SYNC_LOCK" 2>/dev/null; then
            printf '%s\n' "$$" > "$BOOT_SYNC_LOCK/pid" 2>/dev/null
            return 0
        fi



        _bl_p=
        [ -f "$BOOT_SYNC_LOCK/pid" ] && read -r _bl_p < "$BOOT_SYNC_LOCK/pid" 2>/dev/null
        case "$_bl_p" in




            ''|*[!0-9]*)
                _bl_e=$((_bl_e + 1))
                if [ "$_bl_e" -ge 3 ] && [ "$_bl_b" -lt 3 ]; then
                    rm -rf "$BOOT_SYNC_LOCK" 2>/dev/null; _bl_b=$((_bl_b + 1)); _bl_e=0; continue
                fi ;;
            *) _bl_e=0
               if [ ! -d "/proc/$_bl_p" ] && [ "$_bl_b" -lt 3 ]; then
                   rm -rf "$BOOT_SYNC_LOCK" 2>/dev/null; _bl_b=$((_bl_b + 1)); continue
               fi ;;
        esac
        [ "$_bl_i" -ge "$_bl_w" ] && return 1
        _bl_i=$((_bl_i + 1)); sleep 1
    done
}

boot_refresh() {     # $1 = каталог кода, $2 = "force" (сборка бутстрапа с нуля)
    code_of "$1/VERSION" || return 0
    _br_a="$CODE_OF"
    if [ "$2" != force ]; then
        code_of "$BOOT_DIR/VERSION" || CODE_OF=
        [ "$_br_a" = "$CODE_OF" ] && return 0
    fi


    if [ "$2" = force ]; then
        boot_sync_lock 10 || { echo "boot: переливку бутстрапа держит другой процесс" >&2; return 1; }
    else
        boot_sync_lock || return 0
    fi
    mkdir -p "$BOOT_DIR" 2>/dev/null
    _br_rc=0
    for _br_f in $BOOT_FILES; do





        if [ ! -f "$1/$_br_f" ]; then
            [ "$2" = force ] || continue
            echo "boot: в $1 нет $_br_f — бутстрап собирать НЕ из чего" >&2
            _br_rc=1
            break
        fi
        cp "$1/$_br_f" "$BOOT_DIR/$_br_f.new" 2>/dev/null || continue
        if sh -n "$BOOT_DIR/$_br_f.new" 2>/dev/null; then
            mv "$BOOT_DIR/$_br_f.new" "$BOOT_DIR/$_br_f"
        else
            rm -f "$BOOT_DIR/$_br_f.new"
            echo "boot: $_br_f из $1 не разбирается — оставляю прежний" >&2
            _br_rc=1
            break
        fi
    done
    if [ "$_br_rc" = 0 ]; then
        chmod +x "$BOOT_DIR/boot.sh" 2>/dev/null      # его зовёт cron, а cron не наш
        if [ -f "$1/web/stub/index.html" ]; then
            mkdir -p "$BOOT_DIR/stub" 2>/dev/null
            cp "$1/web/stub/index.html" "$BOOT_DIR/stub/index.html.new" 2>/dev/null \
                && mv "$BOOT_DIR/stub/index.html.new" "$BOOT_DIR/stub/index.html"
        fi
        cp "$1/VERSION" "$BOOT_DIR/VERSION.new" 2>/dev/null && mv "$BOOT_DIR/VERSION.new" "$BOOT_DIR/VERSION"
    fi
    rm -rf "$BOOT_SYNC_LOCK" 2>/dev/null
    return $_br_rc
}














cron_to_boot() {
    [ -f "$CRON" ] || return 0
    grep -q "$DATA_DIR/" "$CRON" 2>/dev/null || return 0     # прежних строк нет — тишина
    sed -i "s#$DATA_DIR/\([A-Za-z0-9_-]*\.sh\)#$BOOT_DIR/boot.sh \1#g" "$CRON" 2>/dev/null || return 1
    /etc/init.d/cron restart >/dev/null 2>&1 || /etc/init.d/crond restart >/dev/null 2>&1 \
        || killall -HUP crond 2>/dev/null || true
    echo "boot: cron-строки переведены на бутстрап ($BOOT_DIR/boot.sh)"
    return 0
}



libs_loaded=
load_libs() {
    [ -n "$libs_loaded" ] && return 0



    if [ -f "$BOOT_DIR/store-lib.sh" ]; then . "$BOOT_DIR/store-lib.sh"; fi
    if [ -f "$BOOT_DIR/mount-lib.sh" ]; then . "$BOOT_DIR/mount-lib.sh"; fi
    command -v store_locate >/dev/null 2>&1 || return 1
    libs_loaded=1
    return 0
}











ram_mig() {     # $1 = каталог кода
    if [ -f "$1/ram-lib.sh" ]; then ( . "$1/ram-lib.sh"; ram_migrate ) 2>/dev/null || :; fi
}













uptime_read() {
    UPTIME_S=0
    read -r UPTIME_S _us_rest < /proc/uptime 2>/dev/null || UPTIME_S=0   # raw-uptime: резидентный бутстрап, библиотеки может ещё не быть
    UPTIME_S=${UPTIME_S%%.*}
    case "$UPTIME_S" in ''|*[!0-9]*) UPTIME_S=0 ;; esac
}




store_repair() {     # $1 = каталог-хранилище
    [ -d "$1/enodia" ] && return 0
    if [ -f "$1/enodia.new/heal.sh" ]; then
        mv "$1/enodia.new" "$1/enodia" 2>/dev/null && echo "boot: доиграл прерванный переезд ($1/enodia.new)"
    elif [ -f "$1/enodia.old/heal.sh" ]; then
        mv "$1/enodia.old" "$1/enodia" 2>/dev/null && echo "boot: вернул код из $1/enodia.old — переезд не удался"
    fi
    [ -d "$1/enodia" ]
}





find_store() {
    FOUND_STORE=
    if [ -f "$STORE_CACHE" ]; then
        _fs_c=
        read -r _fs_c < "$STORE_CACHE" 2>/dev/null || :
        if [ -n "$_fs_c" ] && [ -f "$_fs_c/enodia/heal.sh" ]; then
            FOUND_STORE="$_fs_c"; return 0
        fi
    fi
    load_libs || return 1
    uptime_read
    _fs_now="$UPTIME_S"
    if [ -f "$SCAN_STAMP" ]; then
        _fs_last=0
        read -r _fs_last < "$SCAN_STAMP" 2>/dev/null || _fs_last=0
        case "$_fs_last" in ''|*[!0-9]*) _fs_last=0 ;; esac

        [ $((_fs_now - _fs_last)) -lt "$SCAN_EVERY" ] && return 1
    fi
    printf '%s\n' "$_fs_now" > "$SCAN_STAMP" 2>/dev/null
    store_locate || return 1
    store_repair "$STORE_FOUND" || return 1
    [ -f "$STORE_FOUND/enodia/heal.sh" ] || return 1

    _fs_old=
    [ -f "$STORE_CACHE" ] && read -r _fs_old < "$STORE_CACHE" 2>/dev/null
    [ "$_fs_old" = "$STORE_FOUND" ] || printf '%s\n' "$STORE_FOUND" > "$STORE_CACHE" 2>/dev/null
    FOUND_STORE="$STORE_FOUND"
    return 0
}






stub_running() {
    [ -f "$STUB_PID" ] || return 1
    _sr_p=
    read -r _sr_p < "$STUB_PID" 2>/dev/null || return 1
    [ -n "$_sr_p" ] && [ -d "/proc/$_sr_p" ]
}

stub_up() {
    stub_running && return 0
    [ -f "$BOOT_DIR/stub/index.html" ] || return 1
    [ -x /usr/sbin/uhttpd ] || return 1
    if [ -f "$BOOT_DIR/router-lib.sh" ]; then . "$BOOT_DIR/router-lib.sh"; fi
    command -v lan_if >/dev/null 2>&1 || return 1
    _su_if=$(lan_if)
    [ -n "$_su_if" ] || return 1
    _su_ip=$(ip -4 addr show "$_su_if" 2>/dev/null | awk '/inet /{print $2; exit}' | cut -d/ -f1)


    [ -n "$_su_ip" ] || return 1

    netstat -ltn 2>/dev/null | grep -q "[.:]$STUB_PORT " && return 0
    start-stop-daemon -S -b -m -p "$STUB_PID" -x /usr/sbin/uhttpd -- \
        -f -h "$BOOT_DIR/stub" -p "$_su_ip:$STUB_PORT" -I index.html -D -S
}


stub_down() {
    stub_running || { rm -f "$STUB_PID" 2>/dev/null; return 0; }
    start-stop-daemon -K -p "$STUB_PID" -x /usr/sbin/uhttpd >/dev/null 2>&1
    rm -f "$STUB_PID" 2>/dev/null
}







hook_ensure() {


    _he_d=${HOOK%/*}
    [ -d "$_he_d" ] || mkdir -p "$_he_d" 2>/dev/null || return 1
    if [ -f "$HOOK" ]; then
        _he1=; _he2=
        { read -r _he1; read -r _he2; } < "$HOOK" 2>/dev/null
        [ "$_he2" = "$HOOK_TAG" ] && return 0
    fi
    {
        echo '#!/bin/sh'
        echo "$HOOK_TAG"
        echo '[ "$ACTION" = add ] || exit 0'
        echo 'case "$DEVNAME" in sd*) ;; *) exit 0 ;; esac'
        echo "$BOOT_DIR/boot.sh hotplug >/dev/null 2>&1"
    } > "$HOOK.new" 2>/dev/null || return 1
    chmod +x "$HOOK.new" 2>/dev/null
    mv "$HOOK.new" "$HOOK" 2>/dev/null
}
















etc_persistent() {
    _ep_now=
    read -r _ep_now < "$BOOT_ID" 2>/dev/null || return 1
    [ -n "$_ep_now" ] || return 1
    _ep_was=
    [ -f "$PERSIST_PROBE" ] && read -r _ep_was < "$PERSIST_PROBE" 2>/dev/null
    if [ -z "$_ep_was" ]; then
        printf '%s\n' "$_ep_now" > "$PERSIST_PROBE" 2>/dev/null
        return 1
    fi
    [ "$_ep_was" != "$_ep_now" ]
}





init_ensure() {
    etc_persistent || return 1


    _ie_d=${INIT_SCRIPT%/*}
    [ -d "$_ie_d" ] || return 1
    if [ -f "$INIT_SCRIPT" ]; then
        _ie1=; _ie2=
        { read -r _ie1; read -r _ie2; } < "$INIT_SCRIPT" 2>/dev/null
        [ "$_ie2" = "$INIT_TAG" ] && [ -e "$INIT_LINK" ] && return 0
    fi
    {
        echo '#!/bin/sh /etc/rc.common'
        echo "$INIT_TAG"
        echo 'START=20'
        echo 'start() {'

        echo "    $BOOT_DIR/boot.sh doh-early >/dev/null 2>&1 &"
        echo '}'
        echo 'stop() { :; }'
    } > "$INIT_SCRIPT.new" 2>/dev/null || return 1
    chmod +x "$INIT_SCRIPT.new" 2>/dev/null
    mv "$INIT_SCRIPT.new" "$INIT_SCRIPT" 2>/dev/null || return 1
    mkdir -p "${INIT_LINK%/*}" 2>/dev/null
    ln -sf "$INIT_SCRIPT" "$INIT_LINK" 2>/dev/null
    return 0
}



hook_wanted() {
    [ -f "$DATA_DIR/heal.sh" ] || return 0
    [ -f "$DATA_STATE/.bin-store" ]
}






resolve() {
    R_MODE=; R_DIR=; R_STATE=; R_BIN=; R_STORE=
    if [ -f "$DATA_DIR/heal.sh" ]; then
        if [ -f "$DATA_STATE/.bin-store" ]; then R_MODE=bins; else R_MODE=data; fi
        R_DIR="$DATA_DIR"; R_STATE="$DATA_STATE"; R_BIN="$DATA_BIN"
        return 0
    fi
    find_store || return 1
    R_MODE=full
    R_STORE="$FOUND_STORE"
    R_DIR="$FOUND_STORE/enodia"
    R_STATE="$FOUND_STORE/enodia-state"
    R_BIN="$FOUND_STORE/bin"
    return 0
}

export_paths() {
    ENODIA_DIR="$R_DIR"
    ENODIA_STATE="$R_STATE"
    ENODIA_BIN="$R_BIN"
    ENODIA_BOOT="$BOOT_DIR"
    export ENODIA_DIR ENODIA_STATE ENODIA_BIN ENODIA_BOOT
}



cmd_hotplug() {








    if [ "$DEVTYPE" = disk ] && [ -n "$DEVNAME" ] && load_libs && dev_has_parts "$DEVNAME"; then return 0; fi



    ENODIA_ONLY_DEV=; [ -n "$DEVTYPE" ] && ENODIA_ONLY_DEV=$DEVNAME


    mkdir "$BOOT_LOCK" 2>/dev/null || return 0
    trap 'rm -rf "$BOOT_LOCK"' EXIT HUP INT TERM PIPE
    rm -f "$SCAN_STAMP" 2>/dev/null          # событие важнее троттла: ищем немедленно
    hook_ensure
    if resolve; then
        if [ "$R_MODE" = full ]; then
            stub_down
            boot_refresh "$R_DIR"
            export_paths
            [ -f "$R_DIR/web-ui.sh" ] && sh "$R_DIR/web-ui.sh" start >/dev/null 2>&1
            [ -f "$R_DIR/heal.sh" ] && sh "$R_DIR/heal.sh" >/dev/null 2>&1
        else


            _mnt_ok=1
            [ -f "$R_DIR/usb-offload.sh" ] && { ENODIA_ONLY_DEV="$ENODIA_ONLY_DEV" sh "$R_DIR/usb-offload.sh" mount-ensure >/dev/null 2>&1; _mnt_ok=$?; }















            [ "$_mnt_ok" = 0 ] && [ -f "$R_DIR/watchdog.sh" ] && start-stop-daemon -S -b -m -p "$HOTPLUG_PID" \
                -x /bin/sh -- "$BOOT_DIR/boot.sh" hotplug-tick >/dev/null 2>&1
        fi
    fi
    rm -rf "$BOOT_LOCK"
    trap - EXIT HUP INT TERM PIPE
    return 0
}















cmd_hotplug_tick() {
    _ht=0
    while : ; do
        _hl=$(cat "$HEAL_LOCK" 2>/dev/null | tr -d '\r')
        case "$_hl" in done*) break ;; esac
        _hp=${_hl%% *}
        case "$_hp" in
            ''|*[!0-9]*) _hp='' ;;
            *) if [ -d "/proc/$_hp" ]; then




                   case "$(tr '\000' ' ' < "/proc/$_hp/cmdline" 2>/dev/null)" in
                       ''|*heal.sh*) ;;
                       *) _hp='' ;;
                   esac
               else _hp=''; fi ;;                    # лок держит труп — ждать нечего
        esac


        [ -n "$_hp" ] || { [ "$_ht" -ge "$HOTPLUG_NOLOCK_WAIT" ] && break; }
        [ "$_ht" -lt "$HOTPLUG_WAIT" ] || break
        sleep 5; _ht=$((_ht + 5))
    done



    rm -f "$HOTPLUG_PID" 2>/dev/null
    exec sh "$0" watchdog.sh
}









cmd_doh_early() {
    resolve || return 1
    export_paths
    [ -f "$R_DIR/doh-lib.sh" ] || return 1
    sh "$R_DIR/doh-lib.sh" start
}

cmd_paths() {
    if resolve; then
        echo "mode=$R_MODE"
        echo "dir=$R_DIR"
        echo "state=$R_STATE"
        echo "bin=$R_BIN"
        echo "store=$R_STORE"
    else
        echo "mode=none"
    fi
    echo "boot=$BOOT_DIR"
    echo "data_dir=$DATA_DIR"
    echo "data_state=$DATA_STATE"
    echo "data_bin=$DATA_BIN"
    [ -n "$R_MODE" ]
}

cmd_status() {
    if ! resolve; then
        echo "Режим: full (код на накопителе), но накопитель НЕ НАЙДЕН"
        if stub_running; then echo "Заглушка: поднята (порт $STUB_PORT)"; else echo "Заглушка: не поднята"; fi
        return 1
    fi
    case "$R_MODE" in
        data) echo "Режим: data — всё на флеше роутера" ;;
        bins) echo "Режим: bins — бинари на накопителе, код и настройки на флеше роутера" ;;
        full) echo "Режим: full — код, настройки и бинари на накопителе ($R_STORE)" ;;
    esac
    echo "Код: $R_DIR"
    echo "Настройки: $R_STATE"
    echo "Бинари: $R_BIN"
    code_of "$BOOT_DIR/VERSION" || CODE_OF='?'
    _cs_b="$CODE_OF"
    code_of "$R_DIR/VERSION" || CODE_OF='?'
    echo "Бутстрап: $BOOT_DIR (сборка $_cs_b, код $CODE_OF)"
    stub_running && echo "Заглушка: поднята (порт $STUB_PORT)"
    return 0
}



case "$1" in
    ''|-h|--help|help)
        echo "usage: $0 <имя>.sh [аргументы] | hotplug | hotplug-tick | doh-early | ram-migrate | sync [каталог] | paths | status"
        exit 2
        ;;
    hotplug)   cmd_hotplug;   exit $? ;;
    hotplug-tick) cmd_hotplug_tick; exit $? ;;   # фон из cmd_hotplug: дождаться heal и дать тик сторожу
    doh-early) cmd_doh_early; exit $? ;;






    ram-migrate) resolve || :; ram_mig "$R_DIR"; exit 0 ;;
    paths)   cmd_paths;   exit $? ;;
    status)  cmd_status;  exit $? ;;
    sync)


        _sy=${2:-$DATA_DIR}
        [ -f "$_sy/VERSION" ] || { echo "boot: нет $_sy/VERSION — нечего собирать" >&2; exit 1; }
        boot_refresh "$_sy" force || exit 1




        cron_to_boot
        echo "boot: бутстрап собран в $BOOT_DIR"
        exit 0
        ;;
esac

target=$1
target_ok "$target" || { echo "boot: недопустимая цель «$target»" >&2; exit 2; }
shift





if [ -f "$DATA_DIR/$target" ]; then
    hook_wanted && hook_ensure
    init_ensure





    [ -f "$STUB_PID" ] && stub_down
    boot_refresh "$DATA_DIR"
    ram_mig "$DATA_DIR"
    exec sh "$DATA_DIR/$target" "$@"
fi


hook_ensure
init_ensure
if ! find_store; then
    stub_up
    exit 1
fi
stub_down
boot_refresh "$FOUND_STORE/enodia"
if [ ! -f "$FOUND_STORE/enodia/$target" ]; then
    echo "boot: нет $FOUND_STORE/enodia/$target" >&2
    exit 1
fi
R_DIR="$FOUND_STORE/enodia"
R_STATE="$FOUND_STORE/enodia-state"
R_BIN="$FOUND_STORE/bin"
export_paths
ram_mig "$R_DIR"
exec sh "$R_DIR/$target" "$@"
