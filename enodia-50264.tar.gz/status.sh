#!/bin/sh











ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}


ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}
ENODIA_LIST_NAME="enodia_list"
IPLIST_NAME="iplist_set"



if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }
command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
command -v carrier_iface >/dev/null 2>&1 || carrier_iface() { ip route show table 1000 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}'; }



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

WG=""
if command -v wg >/dev/null 2>&1; then WG=wg
elif [ -x "$ENODIA_BIN/awg" ]; then WG="$ENODIA_BIN/awg"
fi

header() { echo ""; printf "${BOLD}${BLUE}══════ %s ══════${NC}\n" "$1"; }
status() {
    label="$1"; value="$2"; color="${3:-$GREEN}"
    printf "  %-30s ${color}%s${NC}\n" "$label" "$value"
}
num() {
    case "$1" in
        ''|*[!0-9]*) echo 0 ;;
        *)           echo "$1" ;;
    esac
}




ipset_count() {
    _c=$(ipset list "$1" 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)
    case "$_c" in ''|*[!0-9]*) _c=$(ipset list "$1" 2>/dev/null | grep -cE '^[0-9]') ;; esac
    case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
    printf '%s' "$_c"
}

detect_awg_version() {
    conf="$ENODIA_STATE/awg.conf"
    [ ! -f "$conf" ] && { echo "?"; return; }
    if   grep -qE "^S3\s*=" "$conf" || grep -qE "^S4\s*=" "$conf"; then echo "2.0"
    elif grep -qE "^H[1-4]\s*=\s*[0-9]+-[0-9]+" "$conf";          then echo "2.0"
    elif grep -qE "^I1\s*=" "$conf";                              then echo "1.5"
    elif grep -qE "^(Jc|S1|H1)\s*=" "$conf";                      then echo "1.0 (Legacy)"
    else echo "обычный WireGuard"
    fi
}


detect_binary_version() {
    for cand in "$ENODIA_BIN/amneziawg-go" "$ENODIA_BIN/awg" amneziawg-go wg; do
        if [ -x "$cand" ] || command -v "$cand" >/dev/null 2>&1; then
            v=$("$cand" --version 2>&1 | head -1 | tr -d '\r' | head -c 80)

            case "$v" in
                *[0-9]*) echo "$v"; return ;;
            esac
        fi
    done

    if [ -f "$ENODIA_BIN/amneziawg-go" ]; then
        d=$(date -r "$ENODIA_BIN/amneziawg-go" "+%Y-%m-%d" 2>/dev/null)
        [ -n "$d" ] && echo "amneziawg-go от $d"
    fi
}






header "Транспорт VPN"
TRANSPORT=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')




if [ -z "$TRANSPORT" ]; then
    TRANSPORT=awg
    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1
        [ "$?" = 1 ] && TRANSPORT=none
    fi
fi



case "$TRANSPORT" in
    hy2)     status "Активный протокол:" "Hysteria2 (через xtun)" "$GREEN" ;;
    byedpi)  status "Активный протокол:" "ByeDPI — десинк через локальный socks, VPS не участвует" "$GREEN" ;;
    zapret)  status "Активный протокол:" "Zapret — десинк напрямую (nfqws/NFQUEUE), туннеля нет" "$GREEN"


             _zp=$(cat /tmp/enodia-zapret-nfqws.pid 2>/dev/null | tr -d ' \r\n')
             if [ -n "$_zp" ] && kill -0 "$_zp" 2>/dev/null; then status "Демон nfqws:" "жив (pid $_zp)" "$GREEN"
             else status "Демон nfqws:" "НЕ запущен" "$RED"; fi


             if iptables -t mangle -C PREROUTING -j ENODIA_ZAPRET 2>/dev/null; then
                 status "Проводка (mangle -j ENODIA_ZAPRET):" "на месте" "$GREEN"
             else
                 status "Проводка (mangle -j ENODIA_ZAPRET):" "СНЕСЕНА — десинк мёртв при живом демоне" "$RED"
             fi ;;
    none)    status "Активный протокол:" "нет — установлена только панель, транспорт не выбран" "$YELLOW"
             status "Что делать:" "панель :8088 → «Компоненты» (поставить) → «Серверы» (включить)" ;;
    xray)    : ;;    # подробности ниже — у xray своя развёрнутая ветка
    awg)     : ;;
    *)       status "Активный протокол:" "$TRANSPORT (диагностика этого транспорта не описана)" "$YELLOW" ;;
esac
if [ "$TRANSPORT" = "xray" ]; then
    active_xray=$(cat "$ENODIA_STATE/.xray-active" 2>/dev/null | tr -d '\r')
    status "Активный протокол:" "Xray (xtun)" "$GREEN"
    status "Активный xray-конфиг:" "${active_xray:-?}"
    if [ -f /tmp/enodia-xray.pid ] && kill -0 "$(cat /tmp/enodia-xray.pid 2>/dev/null)" 2>/dev/null; then
        status "Демон xray:" "жив (pid $(cat /tmp/enodia-xray.pid))" "$GREEN"
    else
        status "Демон xray:" "НЕ запущен" "$RED"
    fi
    if [ -f /tmp/enodia-hev.pid ] && kill -0 "$(cat /tmp/enodia-hev.pid 2>/dev/null)" 2>/dev/null; then
        status "tun2socks (hev):" "жив (pid $(cat /tmp/enodia-hev.pid))" "$GREEN"
    else
        status "tun2socks (hev):" "НЕ запущен" "$RED"
    fi
    if ip link show xtun >/dev/null 2>&1; then
        status "Интерфейс xtun:" "поднят" "$GREEN"
    else
        status "Интерфейс xtun:" "НЕ создан" "$RED"
    fi



    ip_xray=$(probe_ext_ip "--socks5-hostname 127.0.0.1:10808" 8)
    if [ -n "$ip_xray" ]; then
        status "Выходной IP (xray):" "$ip_xray" "$GREEN"
    else
        status "Выходной IP (xray):" "недоступен" "$RED"
    fi
    status "AmneziaWG (awg0):" "тёплый резерв" "$BLUE"
elif [ "$TRANSPORT" = "awg" ]; then
    active_awg=$(cat "$ENODIA_STATE/.active" 2>/dev/null | tr -d '\r')
    status "Активный протокол:" "AmneziaWG (awg0)" "$GREEN"
    status "Активный конфиг:" "${active_awg:-?}"
else






    case "$TRANSPORT" in
        hy2|byedpi)
            if ip link show xtun >/dev/null 2>&1; then status "Интерфейс xtun:" "поднят" "$GREEN"
            else status "Интерфейс xtun:" "НЕ создан" "$RED"; fi
            ip_alt=$(probe_ext_ip "--socks5-hostname 127.0.0.1:10808" 8)
            if [ -n "$ip_alt" ]; then status "Выходной IP (socks 10808):" "$ip_alt" "$GREEN"
            else status "Выходной IP (socks 10808):" "недоступен" "$RED"; fi
            ;;
    esac


    if [ "$TRANSPORT" != "none" ]; then
        if ip link show awg0 >/dev/null 2>&1; then status "AmneziaWG (awg0):" "поднят, но трафик несёт НЕ он" "$BLUE"
        else status "AmneziaWG (awg0):" "не поднят (транспорт его не использует)" "$BLUE"; fi
    fi
fi







COMP_MISSING=0
if [ "$TRANSPORT" != "none" ] && [ -f "$ENODIA_DIR/transport.sh" ]; then
    sh "$ENODIA_DIR/transport.sh" installed "$TRANSPORT" >/dev/null 2>&1
    if [ "$?" = 1 ]; then
        COMP_MISSING=1
        status "Компонент:" "НЕ УСТАНОВЛЕН — бинарей этого транспорта на роутере нет" "$RED"
        status "Что делать:" "панель :8088 → «Компоненты» (поставить); до этого весь трафик идёт напрямую" "$YELLOW"
    fi
fi




if [ "$TRANSPORT" != "none" ]; then
header "Интерфейс awg0"
if ip link show awg0 >/dev/null 2>&1; then
    status "Состояние:" "поднят" "$GREEN"
    awg_ip=$(ip -4 addr show awg0 | awk '/inet / {print $2}' | head -1)
    status "Внутренний IP:" "$awg_ip"


    hs_ago=-1
    if [ -n "$WG" ]; then
        hs=$(num "$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')")
        if [ "$hs" -gt 0 ]; then
            hs_ago=$(age_since "$hs")
        fi
    fi


    awg_ver=$(detect_awg_version)
    bin_ver=$(detect_binary_version)

    case "$awg_ver" in
        "2.0")

            if [ "$hs_ago" -ge 0 ] && [ "$hs_ago" -lt 600 ]; then
                status "Версия протокола:" "AWG 2.0 — работает (handshake идёт)" "$GREEN"
            elif [ "$hs_ago" -ge 0 ]; then
                status "Версия протокола:" "AWG 2.0 — handshake давний, проверьте VPS" "$YELLOW"
            else
                status "Версия протокола:" "AWG 2.0 — handshake нет, возможно бинарь старый" "$YELLOW"
            fi
            ;;
        "1.5")    status "Версия протокола:" "AWG 1.5 — поддерживается" "$GREEN" ;;
        "1.0"*)   status "Версия протокола:" "AWG 1.0 (Legacy) — стабильно работает" "$GREEN" ;;
        *)        status "Версия протокола:" "$awg_ver" "$YELLOW" ;;
    esac
    [ -n "$bin_ver" ] && status "Бинарь:" "$bin_ver" "$BLUE"





    _st_act=$(cat "$ENODIA_STATE/.active" 2>/dev/null | tr -d '\r')
    [ -f "$ENODIA_STATE/.active" ] && status "Активный конфиг:" "${_st_act:-?}"
    endpoint=$(grep -E "^Endpoint" "$ENODIA_STATE/awg.conf" 2>/dev/null | head -1 | awk -F'= *' '{print $2}')
    [ -n "$endpoint" ] && status "Endpoint VPS:" "$endpoint"


    if [ "$hs_ago" -ge 0 ]; then
        if   [ "$hs_ago" -lt 180 ]; then status "Последний handshake:" "$hs_ago сек назад" "$GREEN"
        elif [ "$hs_ago" -lt 600 ]; then status "Последний handshake:" "$hs_ago сек назад (давно)" "$YELLOW"
        else                             status "Последний handshake:" "$hs_ago сек назад — СТАРЫЙ" "$RED"
        fi
    elif [ -n "$WG" ]; then
        status "Последний handshake:" "никогда — VPS не отвечает!" "$RED"
    else
        status "Бинарь wg/awg:" "не найден" "$YELLOW"
    fi

    if [ -n "$WG" ]; then
        xfer=$($WG show awg0 transfer 2>/dev/null | awk 'NR==1{print $2" "$3}')
        rx=$(num "$(echo "$xfer" | awk '{print $1}')")
        tx=$(num "$(echo "$xfer" | awk '{print $2}')")
        if [ "$rx" -gt 0 ] || [ "$tx" -gt 0 ]; then
            status "Принято/передано:" "$((rx/1024/1024)) MB / $((tx/1024/1024)) MB"
        fi
    fi
else






    if [ -f "$ENODIA_STATE/.vpn-off" ]; then
        status "Состояние:" "не поднят — VPN выключен человеком (норма; тумблер переживает ребут)" "$BLUE"
    else
        status "Состояние:" "НЕ ПОДНЯТ" "$RED"
    fi
fi
fi   # конец секции «Интерфейс awg0» (пропущена целиком при TRANSPORT=none)


header "ipset $ENODIA_LIST_NAME — IP резолвленных доменов"
if ipset list -n 2>/dev/null | grep -qx "$ENODIA_LIST_NAME"; then
    cnt=$(ipset_count "$ENODIA_LIST_NAME")
    if [ "$cnt" -gt 0 ]; then
        status "Состояние:" "наполнен" "$GREEN"
        status "IP-адресов:" "$cnt"
    else
        status "Состояние:" "пустой (ОК если CIDR-список наполнен)" "$YELLOW"
        status "IP-адресов:" "0"
    fi
else
    status "Состояние:" "НЕ СОЗДАН" "$RED"
fi


header "ipset $IPLIST_NAME — подсети CIDR от iplist.opencck.org"
if ipset list -n 2>/dev/null | grep -qx "$IPLIST_NAME"; then
    cnt=$(ipset_count "$IPLIST_NAME")
    if   [ "$cnt" -gt 100 ]; then status "Состояние:" "наполнен" "$GREEN";          status "CIDR-подсетей:" "$cnt"
    elif [ "$cnt" -gt 0 ];   then status "Состояние:" "подозрительно мало" "$YELLOW"; status "CIDR-подсетей:" "$cnt"
    else                          status "Состояние:" "пустой — запустите iplist-update.sh" "$RED"
    fi
    if [ -f /tmp/enodia-iplist-update.log ]; then
        last=$(grep -E "^=====" /tmp/enodia-iplist-update.log | tail -1 | sed 's/===== //; s/ =====//')
        [ -n "$last" ] && status "Обновлён:" "$last"
    fi
else
    status "Состояние:" "НЕ СОЗДАН — запустите iplist-update.sh" "$RED"
fi


header "Тест: куда идёт трафик"




wan_if=$(wan_iface)
ip_direct=$(probe_ext_ip "${wan_if:+--interface $wan_if}" 5)
if [ -n "$ip_direct" ]; then
    status "Прямой IP (без VPN):" "$ip_direct"
else
    status "Прямой IP (без VPN):" "недоступен (проба не ответила)" "$YELLOW"
fi
if ip link show awg0 >/dev/null 2>&1; then
    ip_vpn=$(probe_ext_ip "--interface awg0" 5)



    if [ "$TRANSPORT" = "xray" ]; then vpn_label="IP awg0 (резерв):"; else vpn_label="IP через VPN:"; fi
    if [ -n "$ip_vpn" ]; then
        if [ "$TRANSPORT" != "xray" ] && [ -n "$ip_direct" ] && [ "$ip_direct" = "$ip_vpn" ]; then
            status "$vpn_label" "$ip_vpn — СОВПАДАЕТ С ПРЯМЫМ!" "$RED"
        else
            status "$vpn_label" "$ip_vpn" "$GREEN"
        fi
    else





        status "$vpn_label" "недоступен (проба не ответила)" "$YELLOW"
    fi
fi


header "Правила маршрутизации"
fwmark_rules=$(ip rule 2>/dev/null | grep -c "fwmark 0x1")
mangle_awg=$(iptables -t mangle -L PREROUTING -v -n 2>/dev/null | grep -c "match-set $ENODIA_LIST_NAME")
mangle_ipl=$(iptables -t mangle -L PREROUTING -v -n 2>/dev/null | grep -c "match-set $IPLIST_NAME")
mangle_total=$((mangle_awg + mangle_ipl))
nat_rules=$(iptables -t nat -L POSTROUTING -v -n 2>/dev/null | grep -c "MASQUERADE.*awg0")










carrier_dev=$(carrier_iface); route_dst=0; [ -n "$carrier_dev" ] && route_dst=1




if [ -f "$ENODIA_STATE/.vpn-off" ]; then





    if [ "$fwmark_rules" = 0 ]; then
        status "VPN выключен человеком:" "тумблер снят (переживает ребут) — метки холостые, трафик идёт напрямую" "$BLUE"
        _rc="$BLUE"
    else
        status "VPN выключен, а маршрут жив:" "тумблер снят, но ip rule fwmark→1000 на месте — трафик всё ещё уходит в туннель" "$YELLOW"
        _rc="$YELLOW"
    fi
elif [ "$TRANSPORT" = "zapret" ]; then


    status "Маркировка в туннель:" "у Zapret её нет и быть не должно — проводка проверена выше" "$BLUE"
    _rc="$BLUE"
elif [ "$TRANSPORT" = "none" ] || [ "$COMP_MISSING" = 1 ]; then
    if [ "$mangle_total" = 0 ] && [ "$fwmark_rules" = 0 ]; then
        status "Наших правил нет:" "норма — транспорт не выбран/не установлен, роутер работает как сток" "$BLUE"
        _rc="$BLUE"
    else
        status "Метки без маршрута:" "остались от прежней настройки; трафик идёт НАПРЯМУЮ (fail-open) — вреда нет, эффекта тоже" "$YELLOW"
        _rc="$YELLOW"
    fi
elif [ "$mangle_total" -ge 2 ] && [ "$fwmark_rules" -ge 1 ] && [ "$route_dst" -ge 1 ]; then
    _rc="$GREEN"
else
    status "Маршрутизация НЕПОЛНАЯ:" "метка есть, а вести её некуда (или наоборот) — «Починить правила» в панели" "$RED"
    _rc="$RED"
fi
status "iptables-метки PREROUTING:" "$mangle_awg ($ENODIA_LIST_NAME) + $mangle_ipl ($IPLIST_NAME)" "$_rc"
status "ip rule с fwmark 0x1:" "$fwmark_rules шт." "$_rc"
status "default в table 1000:" "$([ "$route_dst" = 1 ] && echo "есть → $carrier_dev" || echo "НЕТ (метка холостая)")" "$_rc"
status "MASQUERADE на awg0:" "$nat_rules шт." "$_rc"


header "Списки доменов (dnsmasq)"




if [ -f /etc/dnsmasq.d/enodia-domains.conf ]; then
    main_count=$(num "$(grep -c '^ipset=' /etc/dnsmasq.d/enodia-domains.conf 2>/dev/null)")
    main_size=$(du -h /etc/dnsmasq.d/enodia-domains.conf 2>/dev/null | awk '{print $1}')
    main_age=$(date -r /etc/dnsmasq.d/enodia-domains.conf "+%Y-%m-%d %H:%M" 2>/dev/null || echo "?")
    status "ОСТАТОК легаси re-filter:" "$main_count правил, $main_size — подсистема удалена, файл лишний" "$YELLOW"
    status "  обновлён:" "$main_age"
fi
if [ -f /etc/dnsmasq.d/enodia-custom.conf ]; then
    cust=$(num "$(grep -c '^ipset=' /etc/dnsmasq.d/enodia-custom.conf 2>/dev/null)")
    status "Ваши добавления:" "$cust доменов"
fi


if [ "$1" = "test" ]; then
    header "Проверка популярных сайтов"
    for domain in youtube.com chatgpt.com claude.ai instagram.com discord.com github.com; do
        ip_first=$(nslookup "$domain" 127.0.0.1 2>/dev/null | grep -A1 'Name:' | tail -1 | awk '{print $NF}')
        if [ -n "$ip_first" ]; then
            in_awg=0; in_ipl=0
            ipset test "$ENODIA_LIST_NAME" "$ip_first" 2>/dev/null && in_awg=1
            ipset test "$IPLIST_NAME"   "$ip_first" 2>/dev/null && in_ipl=1
            if [ "$in_awg" = "1" ] || [ "$in_ipl" = "1" ]; then
                tag=""
                [ "$in_awg" = "1" ] && tag="${tag}enodia_list "
                [ "$in_ipl" = "1" ] && tag="${tag}iplist_set"
                status "$domain:" "ЧЕРЕЗ VPN ($ip_first, $tag)" "$GREEN"
            else
                status "$domain:" "НАПРЯМУЮ ($ip_first)" "$YELLOW"
            fi
        fi
    done
fi


header "Автозапуск (главное — cron)"
if grep -q "heal.sh" /etc/crontabs/root 2>/dev/null; then
    heal_line=$(grep "heal.sh" /etc/crontabs/root | head -1 | awk '{print $1,$2,$3,$4,$5}')
    status "cron heal.sh:" "включён ($heal_line)" "$GREEN"
else
    status "cron heal.sh:" "ОТСУТСТВУЕТ — после ребута всё развалится!" "$RED"
fi
if grep -q "iplist-update" /etc/crontabs/root 2>/dev/null; then
    upd_line=$(grep "iplist-update" /etc/crontabs/root | head -1 | awk '{print $1,$2,$3,$4,$5}')
    status "cron iplist-update:" "включён ($upd_line)" "$GREEN"
else
    status "cron iplist-update:" "выключен — CIDR не обновляются" "$YELLOW"
fi
if grep -q "AWG-SETUP-BE7000" /etc/rc.local 2>/dev/null; then
    status "rc.local:" "блок есть (бонус)" "$GREEN"
else



    status "rc.local:" "пусто (норм — автозапуск у нас через cron)" "$BLUE"
fi









header "Ресурсы роутера"
mt=$(num "$(awk '/^MemTotal:/{print $2}'     /proc/meminfo 2>/dev/null)")
mf=$(num "$(awk '/^MemFree:/{print $2}'      /proc/meminfo 2>/dev/null)")
ma=$(num "$(awk '/^MemAvailable:/{print $2}' /proc/meminfo 2>/dev/null)")
if [ "$mt" -gt 0 ]; then

    if [ "$ma" -gt 0 ]; then avail_mb=$((ma/1024)); else avail_mb=$((mf/1024)); fi
    txt="$((mf/1024)) МБ свободно из $((mt/1024)) МБ"
    [ "$ma" -gt 0 ] && txt="$txt (доступно $((ma/1024)) МБ)"
    if   [ "$avail_mb" -lt 30 ]; then status "RAM:" "$txt" "$RED"
    elif [ "$avail_mb" -lt 60 ]; then status "RAM:" "$txt" "$YELLOW"
    else                              status "RAM:" "$txt" "$GREEN"
    fi
fi

















_ourmp=$(df -k "$ENODIA_DIR" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{print $NF}')







_flashdir="$ENODIA_BOOT"; [ -d "$_flashdir" ] || _flashdir="$ENODIA_DIR"
_bootmp=$(df -k "$_flashdir" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{print $NF}')
_mps="${_bootmp:-${_ourmp:-/data}}"
if [ -n "$_ourmp" ] && [ -n "$_bootmp" ] && [ "$_ourmp" != "$_bootmp" ]; then _mps="$_mps $_ourmp"; fi
for m in $_mps /tmp; do
    dline=$(df "$m" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{printf "%.1fM своб из %.1fM (занято %.0f%%)", $(NF-2)/1024, $(NF-4)/1024, ($(NF-4)-$(NF-2))*100/$(NF-4)}')
    [ -n "$dline" ] && status "Диск $m:" "$dline"
done




logsz=$(sh "$ENODIA_DIR/clean.sh" ramlogs-list 2>/dev/null | while read -r _lp; do
            ls -l "$_lp" 2>/dev/null
        done | awk '{s+=$5} END{if (NR>0) printf "%d КБ в %d файл(ах)", (s+1023)/1024, NR}')
[ -n "$logsz" ] && status "Логи в /tmp:" "$logsz"

echo ""
printf "${BLUE}Совет:${NC} '${BOLD}status.sh test${NC}' покажет, какие сайты идут через VPN.\n"
echo ""
