#!/bin/sh



























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }


if [ -f "$ENODIA_DIR/lists-lib.sh" ]; then . "$ENODIA_DIR/lists-lib.sh"; else
	echo "нет $ENODIA_DIR/lists-lib.sh — обновите установку (панель → «Обновление» или переустановка с компьютера)" >&2; exit 1
fi

CMD="$1"; CAT="$2"

valid_cat() {
	case "$1" in tunnel-cidr|tunnel-domains|bypass-ip|adblock|ipblock|zapret-cidr|zapret-dom) return 0 ;; *) return 1 ;; esac
}
kind_of() {  # «вид» результата категории
	case "$1" in adblock|tunnel-domains|zapret-dom) echo domains ;; *) echo cidr ;; esac
}
jesc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }






migrate_tunnel_cidr() {
	_reg=$(reg_path tunnel-cidr); [ -f "$_reg" ] && return 0
	IPLIST_URL=''; IPLIST_SITES=''; IPLIST_CUSTOM_MODE=''; IPLIST_CUSTOM_FILE="$ENODIA_STATE/iplist.custom"
	[ -f "$ENODIA_STATE/iplist.conf" ] && . "$ENODIA_STATE/iplist.conf"
	_base='https://iplist.opencck.org/?format=text&data=cidr4'
	if   [ -n "$IPLIST_URL" ];   then _u="$IPLIST_URL"; _l="свой URL"
	elif [ -n "$IPLIST_SITES" ]; then _u="$_base"; for _s in $IPLIST_SITES; do _u="$_u&site=$_s"; done; _l="сайты: $IPLIST_SITES"
	else _u="$_base"; _l="весь список opencck"; fi
	[ "$IPLIST_CUSTOM_MODE" = only ] || reg_add tunnel-cidr url 1 cidr "$_l" "$_u" >/dev/null
	if [ -s "$IPLIST_CUSTOM_FILE" ]; then
		_en=0; [ -n "$IPLIST_CUSTOM_MODE" ] && _en=1
		_cid=$(reg_add tunnel-cidr file "$_en" cidr "iplist.custom" "")
		cp "$IPLIST_CUSTOM_FILE" "$(blob_path tunnel-cidr "$_cid")" 2>/dev/null
	fi
}

[ "$CAT" = tunnel-cidr ] && migrate_tunnel_cidr


ensure_mark_rule() {  # tunnel-cidr: mangle MARK по iplist_set (как в iplist-update.sh)





	if [ -f "$ENODIA_DIR/transport.sh" ]; then
		sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1
		[ "$?" = 1 ] && return 0
	fi




	[ -f "$ENODIA_STATE/.vpn-off" ] && return 0
	iptables -t mangle -C PREROUTING -m set --match-set iplist_set dst -j MARK --set-mark 0x1 2>/dev/null || \
		iptables -t mangle -A PREROUTING -m set --match-set iplist_set dst -j MARK --set-mark 0x1 2>/dev/null
}






ensure_block_rules() {
	ipset list -n 2>/dev/null | grep -qx blocklist_set || \
		ipset create blocklist_set hash:net hashsize 4096 maxelem 1000000 2>/dev/null
	ensure_allow_set                                   # слой 1: критичные IP в blocklist_allow
	_wif=$(wan_iface)
	del_legacy_block_rules                             # снять прямые правила старых версий (до ENODIA_BLK)
	if iptables -nL ENODIA_BLK >/dev/null 2>&1; then iptables -F ENODIA_BLK 2>/dev/null
	else iptables -N ENODIA_BLK 2>/dev/null; fi
	iptables -A ENODIA_BLK -m set --match-set blocklist_allow src -j RETURN 2>/dev/null
	iptables -A ENODIA_BLK -m set --match-set blocklist_allow dst -j RETURN 2>/dev/null
	[ -n "$_wif" ] && iptables -A ENODIA_BLK -i "$_wif" -m set --match-set blocklist_set src -j DROP 2>/dev/null
	iptables -A ENODIA_BLK -m set --match-set blocklist_set dst -j DROP 2>/dev/null
	iptables -C INPUT   -j ENODIA_BLK 2>/dev/null || iptables -I INPUT   -j ENODIA_BLK 2>/dev/null
	iptables -C FORWARD -j ENODIA_BLK 2>/dev/null || iptables -I FORWARD -j ENODIA_BLK 2>/dev/null
}
del_legacy_block_rules() {  # прямые INPUT/FORWARD-правила версий ДО цепочки ENODIA_BLK
	for spec in "FORWARD dst" "FORWARD src" "INPUT src"; do
		ch=${spec% *}; dir=${spec#* }
		while iptables -C "$ch" -m set --match-set blocklist_set "$dir" -j DROP 2>/dev/null; do
			iptables -D "$ch" -m set --match-set blocklist_set "$dir" -j DROP 2>/dev/null || break
		done
	done
}
del_block_rules() {
	iptables -D INPUT   -j ENODIA_BLK 2>/dev/null
	iptables -D FORWARD -j ENODIA_BLK 2>/dev/null
	iptables -F ENODIA_BLK 2>/dev/null
	iptables -X ENODIA_BLK 2>/dev/null
	del_legacy_block_rules
}







adblock_conf() { echo /tmp/dnsmasq.d/06-adblock.conf; }






ZAPRET_CIDR_SET=zapret_cidr


zapret_rewire() { [ -f "$ENODIA_DIR/zapret.sh" ] && sh "$ENODIA_DIR/zapret.sh" rewire >/dev/null 2>&1; return 0; }







ZAPRET_DOM_SET=zapret_dom
zapret_dom_conf() { echo /tmp/dnsmasq.d/07-zapret-dom.conf; }


ensure_dom_set() {
	ipset list -n 2>/dev/null | grep -qx "$ZAPRET_DOM_SET" || \
		ipset create "$ZAPRET_DOM_SET" hash:net family inet hashsize 1024 maxelem 1000000 2>/dev/null
	return 0
}

applied_count() {  # текущий размер результата в цели (для UI)
	case "$1" in
		tunnel-cidr) ipset_count iplist_set ;;
		ipblock)     ipset_count blocklist_set ;;
		zapret-cidr) ipset_count "$ZAPRET_CIDR_SET" ;;
		zapret-dom)  grep -c '^ipset=/' "$(zapret_dom_conf)" 2>/dev/null ;;    # доменов в пуле = ipset=-строк
		adblock)     grep -c '/0\.0\.0\.0$' "$(adblock_conf)" 2>/dev/null ;;   # доменов = A-строк (не всех, их 2×)
		*) echo 0 ;;
	esac
}


teardown() {
	case "$1" in
		adblock) rm -f "$(adblock_conf)" 2>/dev/null; dnsmasq_reload ;;
		ipblock) del_block_rules; ipset flush blocklist_set 2>/dev/null; ipset destroy blocklist_allow 2>/dev/null; ct_flush ;;



		zapret-cidr) ipset flush "$ZAPRET_CIDR_SET" 2>/dev/null; ct_flush ;;



		zapret-dom)  rm -f "$(zapret_dom_conf)" 2>/dev/null; dnsmasq_reload
		             ipset flush "$ZAPRET_DOM_SET" 2>/dev/null; ct_flush ;;
	esac
}




ustate() { _usd=$(ram_dir "$CAT"); echo "$1" > "$_usd/.update.state.new" && mv -f "$_usd/.update.state.new" "$_usd/.update.state"; }  # прогресс/лог — в ОЗУ (панель читает через list)

gstate() { echo "$2" > "$1/.guard.state.new" && mv -f "$1/.guard.state.new" "$1/.guard.state"; }
ulog()   { echo "$*" >> "$(ram_dir "$CAT")/.update.log"; }




_update_pass() {
	echo "===== $(date) update $CAT ====="


	if ! cat_enabled "$CAT"; then
		echo "category disabled → teardown"
		teardown "$CAT"; return 0
	fi

	kind=$(kind_of "$CAT")
	reg=$(reg_path "$CAT")
	work=$W/.work; : > "$work"
	nsrc=0    # источников, реально давших данные в этом проходе











	nen=0

	if [ -f "$reg" ]; then
		while IFS="$TAB" read -r id type en fmt cnt ts label value; do
			[ -n "$id" ] || continue
			[ "$en" = 1 ] || { echo "skip $id (disabled)"; continue; }
			nen=$((nen + 1))
			raw=$W/.raw.$id; : > "$raw"
			case "$type" in
				url)



					fresh=1
					if fetch_url "$value" "$raw"; then
						cp "$raw" "$(cache_path "$CAT" "$id")" 2>/dev/null
						echo "src $id url ok: $value"
					elif [ -s "$(cache_path "$CAT" "$id")" ]; then
						cp "$(cache_path "$CAT" "$id")" "$raw"; fresh=0
						echo "src $id url FAILED → cache: $value"
					else
						echo "src $id url FAILED, no cache: $value"; reg_set_meta "$CAT" "$id" 0 "$ts"; rm -f "$raw"; continue
					fi ;;
				file|text)
					fresh=1
					if [ -s "$(blob_path "$CAT" "$id")" ]; then cp "$(blob_path "$CAT" "$id")" "$raw"
					else echo "src $id blob missing"; rm -f "$raw"; continue; fi ;;
				*) rm -f "$raw"; continue ;;
			esac

			[ "$fmt" = auto ] || [ -z "$fmt" ] && { det=$(detect_format < "$raw"); reg_set_format "$CAT" "$id" "$det"; }
			norm=$W/.norm.$id
			normalize "$kind" "$fmt" < "$raw" | sort -u > "$norm"
			scnt=$(grep -c '' "$norm" 2>/dev/null); case "$scnt" in ''|*[!0-9]*) scnt=0 ;; esac
			cat "$norm" >> "$work"
			if [ "$fresh" = 1 ]; then reg_set_meta "$CAT" "$id" "$scnt" "$(date +%s)"; else reg_set_meta "$CAT" "$id" "$scnt" "$ts"; fi
			echo "src $id: $scnt записей ($kind)"
			nsrc=$((nsrc + 1)); rm -f "$raw" "$norm"
		done < "$reg"
	fi


	all=$W/.all; sort -u "$work" > "$all" 2>/dev/null; rm -f "$work"
	total=$(grep -c '' "$all" 2>/dev/null); case "$total" in ''|*[!0-9]*) total=0 ;; esac
	echo "источников: $nsrc, суммарно уникальных: $total"



	if ! cat_enabled "$CAT"; then echo "category disabled during pass → teardown"; teardown "$CAT"; return 0; fi


	case "$CAT" in
		tunnel-cidr)









			_b=$(grep -c '' "$all" 2>/dev/null); case "$_b" in ''|*[!0-9]*) _b=0 ;; esac
			strip_bogon 4 < "$all" > "$all.safe" && mv "$all.safe" "$all"   # порог 4, а не 8 — см. strip_bogon
			_a=$(grep -c '' "$all" 2>/dev/null); case "$_a" in ''|*[!0-9]*) _a=0 ;; esac
			echo "tunnel-cidr bogon-фильтр: $_b → $_a CIDR (приватка/CGNAT вырезаны — защита LAN)"
			if n=$(apply_ipset iplist_set "$all"); then
				ensure_mark_rule; snap_write "$CAT" "$all"
				echo "iplist_set: $n записей"
			elif [ "$nen" = 0 ]; then






				ipset flush iplist_set 2>/dev/null; ensure_mark_rule; snap_write "$CAT" "$all"
				echo "включённых источников нет → iplist_set очищен"
			else

				if [ -s "$(snap_path "$CAT")" ]; then apply_ipset iplist_set "$(snap_path "$CAT")" >/dev/null && ensure_mark_rule; echo "источники пусты → снимок"
				else echo "источники пусты, снимка нет — set не тронут"; fi
			fi ;;
		ipblock)


			_b=$(grep -c '' "$all" 2>/dev/null); case "$_b" in ''|*[!0-9]*) _b=0 ;; esac
			strip_bogon < "$all" > "$all.safe" && mv "$all.safe" "$all"
			_a=$(grep -c '' "$all" 2>/dev/null); case "$_a" in ''|*[!0-9]*) _a=0 ;; esac
			echo "ipblock bogon-фильтр: $_b → $_a CIDR (приватка/широкие вырезаны — защита LAN)"
			ensure_block_rules
			if n=$(apply_ipset blocklist_set "$all"); then echo "blocklist_set: $n записей"
			else ipset flush blocklist_set 2>/dev/null; echo "blocklist пуст"; fi
			ct_flush
			snap_write "$CAT" "$all" ;;
		zapret-cidr)




			_b=$(grep -c '' "$all" 2>/dev/null); case "$_b" in ''|*[!0-9]*) _b=0 ;; esac
			strip_bogon < "$all" > "$all.safe" && mv "$all.safe" "$all"
			_a=$(grep -c '' "$all" 2>/dev/null); case "$_a" in ''|*[!0-9]*) _a=0 ;; esac
			echo "zapret-cidr bogon-фильтр: $_b → $_a CIDR (приватка/широкие вырезаны — защита LAN)"
			if n=$(apply_ipset "$ZAPRET_CIDR_SET" "$all"); then
				zapret_rewire; snap_write "$CAT" "$all"
				echo "$ZAPRET_CIDR_SET: $n записей"
			elif [ "$nen" = 0 ]; then

				ipset flush "$ZAPRET_CIDR_SET" 2>/dev/null; zapret_rewire; snap_write "$CAT" "$all"
				echo "включённых источников нет → $ZAPRET_CIDR_SET очищен"
			else


				if [ -s "$(snap_path "$CAT")" ]; then apply_ipset "$ZAPRET_CIDR_SET" "$(snap_path "$CAT")" >/dev/null && zapret_rewire; echo "источники пусты → снимок"
				else echo "источники пусты, снимка нет — set не тронут"; fi
			fi
			ct_flush ;;
		adblock)
			n=$(apply_dnsmasq_block "$(adblock_conf)" "$all" "$(allow_path "$CAT")")
			echo "adblock: $n доменов заблокировано"
			snap_write "$CAT" "$all" ;;
		zapret-dom)


			ensure_dom_set
			if [ -s "$all" ]; then
				n=$(apply_dnsmasq_ipset "$(zapret_dom_conf)" "$all" "$ZAPRET_DOM_SET" "$(allow_path "$CAT")")
				zapret_rewire; snap_write "$CAT" "$all"
				echo "$ZAPRET_DOM_SET: $n доменов в пуле десинка"
			elif [ "$nen" = 0 ]; then



				rm -f "$(zapret_dom_conf)" 2>/dev/null; dnsmasq_reload
				ipset flush "$ZAPRET_DOM_SET" 2>/dev/null
				echo "включённых источников нет → пул очищен"
			else


				if [ -s "$(snap_path "$CAT")" ]; then
					n=$(apply_dnsmasq_ipset "$(zapret_dom_conf)" "$(snap_path "$CAT")" "$ZAPRET_DOM_SET" "$(allow_path "$CAT")")
					zapret_rewire; echo "источники пусты → снимок ($n доменов)"
				else echo "источники пусты, снимка нет — пул не тронут"; fi
			fi ;;
	esac
	rm -f "$all"
	return 0
}








do_update() {
	valid_cat "$CAT" || { echo "unknown category: $CAT" >&2; return 2; }
	W=$(ram_dir "$CAT")                       # ОЗУ: сюда ВСЕ закачки/рабочие файлы (не на флеш!)
	lock="$W/.update.lock"
	ls_lock_take "$lock" "$W/.update.dirty" || return 0   # держатель жив → он переиграет под свежий реестр
	trap 'ls_lock_drop "$lock"' EXIT INT TERM

	: > "$W/.update.log"; ustate RUNNING
	exec >>"$W/.update.log" 2>&1
	while :; do
		rm -f "$W/.update.dirty"   # сброс ДО чтения реестра: пойманный dirty ⇒ реестр прочитан ПОСЛЕ мутации
		_update_pass
		[ -f "$W/.update.dirty" ] || break
		echo "--- реестр менялся во время обновления → переигрываю проход ---"
	done
	ustate DONE
	trap - EXIT INT TERM
	ls_lock_drop "$lock"
	return 0
}




do_reapply() {
	valid_cat "$CAT" || return 2
	if ! cat_enabled "$CAT"; then teardown "$CAT"; return 0; fi
	_snap=$(snap_path "$CAT"); [ -s "$_snap" ] || return 0
	case "$CAT" in


		tunnel-cidr) _ts=$(ram_dir "$CAT")/.reapply.safe; strip_bogon 4 < "$_snap" > "$_ts"
		             apply_ipset iplist_set "$_ts" >/dev/null 2>&1 && ensure_mark_rule
		             rm -f "$_ts" ;;
		ipblock)     ensure_block_rules
		             _ss=$(ram_dir "$CAT")/.reapply.safe; strip_bogon < "$_snap" > "$_ss"   # защита LAN и на reapply
		             apply_ipset blocklist_set "$_ss" >/dev/null 2>&1; rm -f "$_ss"
		             ct_flush ;;
		zapret-cidr) _zs=$(ram_dir "$CAT")/.reapply.safe; strip_bogon < "$_snap" > "$_zs"   # защита LAN и на reapply
		             apply_ipset "$ZAPRET_CIDR_SET" "$_zs" >/dev/null 2>&1; rm -f "$_zs"
		             zapret_rewire ;;
		adblock)     apply_dnsmasq_block "$(adblock_conf)" "$_snap" "$(allow_path "$CAT")" >/dev/null 2>&1 ;;
		zapret-dom)  ensure_dom_set
		             apply_dnsmasq_ipset "$(zapret_dom_conf)" "$_snap" "$ZAPRET_DOM_SET" "$(allow_path "$CAT")" >/dev/null 2>&1
		             zapret_rewire ;;
	esac
	return 0
}






wire_due() {   # 0 — цепочка блокировки ОБЯЗАНА стоять; гейты общие у `wire` и `wired`, иначе вопрос и починка разъедутся
	[ "$CAT" = ipblock ] || return 1
	cat_enabled ipblock || return 1
	guard_live ipblock && return 1
	[ "$(ipset_count blocklist_set)" -gt 0 ] 2>/dev/null
}
do_wire() {
	wire_due || return 0




	_wlk="$(ram_dir ipblock)/.update.lock"
	ls_lock_take "$_wlk" "$(ram_dir ipblock)/.update.dirty" || return 0
	trap 'ls_lock_drop "$_wlk"' EXIT INT TERM
	ensure_block_rules
	ls_lock_drop "$_wlk"; trap - EXIT INT TERM
}



do_wired() {
	wire_due || return 0
	command -v ipt_jump_state >/dev/null 2>&1 || return 2
	ipt_jump_state INPUT ENODIA_BLK; _wdi=$?
	ipt_jump_state FORWARD ENODIA_BLK; _wdf=$?
	[ "$_wdi" = 2 ] || [ "$_wdf" = 2 ] && return 2
	[ "$_wdi" = 0 ] && [ "$_wdf" = 0 ] && return 0
	return 3
}









GUARD_GRACE=60
guard_live() {  # guard_live <cat> → 0, если проверка связи идёт (пид жив ИЛИ только что начата)
	_gl=$(ram_dir "$1")
	[ "$(cat "$_gl/.guard.state" 2>/dev/null | tr -d ' \r\n')" = APPLYING ] || return 1
	_gp=$(cat "$_gl/.guard.pid" 2>/dev/null | tr -cd '0-9')

	[ -n "$_gp" ] && cat "/proc/$_gp/cmdline" 2>/dev/null | tr '\0' ' ' | grep -q lists-update && return 0
	_gt=$(cat "$_gl/.guard.ts" 2>/dev/null | tr -cd '0-9')
	[ -n "$_gt" ] && [ "$(age_since "$_gt")" -lt "$GUARD_GRACE" ]
}


guard_begin() {
	guard_live "$1" && return 1
	_gb=$(ram_dir "$1")


	if guard_cancelled "$1"; then
		_gp=$(cat "$_gb/.guard.pid" 2>/dev/null | tr -cd '0-9')
		[ -n "$_gp" ] && cat "/proc/$_gp/cmdline" 2>/dev/null | tr '\0' ' ' | grep -q lists-update && return 2
	fi
	rm -f "$_gb/.guard.pid" 2>/dev/null
	date +%s > "$_gb/.guard.ts"
	gstate "$_gb" APPLYING
	return 0
}





guard_gw_ok()  { _gg=$(wan_gateway); [ -n "$_gg" ] && ping -c 1 -W 3 "$_gg" >/dev/null 2>&1; }
guard_net_ok() {
	for _h in 1.1.1.1 8.8.8.8; do
		curl -sk -o /dev/null -m 6 --connect-timeout 5 "https://$_h" 2>/dev/null && return 0
	done
	return 1
}






guard_notify() {
	[ -f "$ENODIA_DIR/notify-event.sh" ] || return 0
	if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
	command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }
	if [ "$(nf_lang)" = en ]; then
		case "$1" in
			lan) _gn="the list contained home network addresses" ;; gw) _gn="after enabling, the provider gateway stopped answering" ;;
			net) _gn="after enabling, the router could not reach the internet" ;; nonet) _gn="the internet was not answering even before enabling" ;;
			*) _gn="connectivity dropped while enabling" ;;
		esac
		sh "$ENODIA_DIR/notify-event.sh" ipblock-reverted 3600 "Blocking by address was removed automatically" \
			"Reason: $_gn. The network works as before; the lists and your exceptions are kept." >/dev/null 2>&1
	else
		case "$1" in
			lan) _gn="в список попали адреса домашней сети" ;; gw) _gn="после включения перестал отвечать шлюз провайдера" ;;
			net) _gn="после включения роутер не достучался до интернета" ;; nonet) _gn="интернет не отвечал ещё до включения" ;;
			*) _gn="при включении прерывалась связь" ;;
		esac
		sh "$ENODIA_DIR/notify-event.sh" ipblock-reverted 3600 "Блокировка по адресам снята автоматически" \
			"Причина: $_gn. Сеть работает как прежде; списки и ваши исключения сохранены." >/dev/null 2>&1
	fi
	return 0
}
guard_cancelled() { [ "$(cat "$(ram_dir "$1")/.guard.state" 2>/dev/null | tr -d ' \r\n')" = CANCELLED ]; }
guarded_enable() {
	_c="$1"
	_g=$(ram_dir "$_c")

	guard_cancelled "$_c" && return 0   # до флага
	: > "$(enable_path "$_c")"



	echo $$ > "$_g/.guard.pid"
	gstate "$_g" APPLYING
	[ -f "$_g/.guard.ts" ] || date +%s > "$_g/.guard.ts"
	_gw0=0; _net0=0
	if [ "$_c" = ipblock ]; then guard_gw_ok && _gw0=1; guard_net_ok && _net0=1; fi
	CAT="$_c" do_update






	_gw_n=0; _gw_max=${LISTS_GUARD_WAIT:-600}; case "$_gw_max" in ''|*[!0-9]*|??????*) _gw_max=600 ;; esac
	while [ -d "$_g/.update.lock" ] && ! _lock_stale "$_g/.update.lock" && [ "$_gw_n" -lt "$_gw_max" ] && ! guard_cancelled "$_c"; do sleep 1; _gw_n=$((_gw_n + 1)); done
	guard_cancelled "$_c" && return 0   # ждали чужой проход
	if [ -d "$_g/.update.lock" ] && ! _lock_stale "$_g/.update.lock"; then gstate "$_g" ABORTED; return 1; fi
	[ "$_c" = ipblock ] || { gstate "$_g" OK; return 0; }
	sleep 3
	_ok=1; _why=''

	for _p in 192.168.31.1 192.168.31.0 10.0.0.1 100.64.0.1; do
		ipset test blocklist_set "$_p" >/dev/null 2>&1 && { _ok=0; [ -n "$_why" ] || _why=lan; }
	done

	[ "$_gw0" = 1 ] && { guard_gw_ok || { _ok=0; [ -n "$_why" ] || _why=gw; }; }


	if [ "$_net0" = 1 ]; then guard_net_ok || { _ok=0; [ -n "$_why" ] || _why=net; }
	else _ok=0; [ -n "$_why" ] || _why=nonet; fi
	guard_cancelled "$_c" && return 0   # до вердикта
	if [ "$_ok" != 1 ]; then
		ulog "SELF-TEST FAILED ($_why) → авто-откат ipblock (связь/резолв или приватка в сете)"
		rm -f "$(enable_path "$_c")"; teardown "$_c"; ct_flush
		echo "$_why" > "$_g/.guard.why"
		gstate "$_g" REVERTED
		guard_notify "$_why"
		return 1
	fi
	gstate "$_g" OK
	return 0
}








presets_lines() {
	case "$1" in
		adblock)
			cat <<'EOF'
Hagezi Light|https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/dnsmasq/light.txt|dnsmasq|rec|~44k|https://github.com/hagezi/dns-blocklists|мягкий, почти без ложных срабатываний
OISD Small|https://small.oisd.nl/dnsmasq|dnsmasq|rec|~56k|https://oisd.nl|реклама, трекеры, фишинг — сбалансированно
Peter Lowe|https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext|hosts|rec|~3.5k|https://pgl.yoyo.org|только рекламные серверы, очень лёгкий
AdGuard DNS filter|https://cdn.jsdelivr.net/gh/AdguardTeam/AdGuardSDNSFilter@gh-pages/Filters/filter.txt|adblock|rec|~155k|https://github.com/AdguardTeam/AdGuardSDNSFilter|базовый фильтр AdGuard DNS
Hagezi Normal|https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/dnsmasq/multi.txt|dnsmasq|aggr|~160k|https://github.com/hagezi/dns-blocklists|сбалансированный, шире охват
Hagezi Pro|https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/dnsmasq/pro.txt|dnsmasq|aggr|~230k|https://github.com/hagezi/dns-blocklists|жёсткий, максимум охвата
OISD Big|https://big.oisd.nl/dnsmasq|dnsmasq|aggr|~500k|https://oisd.nl|расширенный список OISD
StevenBlack hosts|https://cdn.jsdelivr.net/gh/StevenBlack/hosts@master/hosts|hosts|aggr|~78k|https://github.com/StevenBlack/hosts|классический hosts-список
EOF
			;;
		ipblock)
			cat <<'EOF'
FireHOL level1|https://cdn.jsdelivr.net/gh/firehol/blocklist-ipsets@master/firehol_level1.netset|cidr|rec|~4.6k|https://iplists.firehol.org|минимум ложных срабатываний, базовые угрозы
Spamhaus DROP|https://cdn.jsdelivr.net/gh/firehol/blocklist-ipsets@master/spamhaus_drop.netset|cidr|rec|~1.6k|https://www.spamhaus.org/blocklists/do-not-route-or-peer/|заведомо враждебные сети (спам, малварь)
Spamhaus EDROP|https://cdn.jsdelivr.net/gh/firehol/blocklist-ipsets@master/spamhaus_edrop.netset|cidr|rec|~0.3k|https://www.spamhaus.org/blocklists/do-not-route-or-peer/|дополнение к DROP
FireHOL level2|https://cdn.jsdelivr.net/gh/firehol/blocklist-ipsets@master/firehol_level2.netset|cidr|aggr|~29k|https://iplists.firehol.org|+ атакующие сети и ботнеты за сутки
FireHOL level3|https://cdn.jsdelivr.net/gh/firehol/blocklist-ipsets@master/firehol_level3.netset|cidr|aggr|~13k|https://iplists.firehol.org|более широкий охват угроз
EOF
			;;











		zapret-cidr)
			cat <<'EOF'
Google + googlevideo (официальный)|https://www.gstatic.com/ipranges/goog.json|cidr|rec|~99|https://www.gstatic.com/ipranges/goog.json|официальные диапазоны Google — накрывают googlevideo целиком
YouTube (opencck)|https://iplist.opencck.org/?format=text&data=cidr4&site=youtube.com|cidr|rec|~0.8k|https://iplist.opencck.org|подсети YouTube — точнее, но без части googlevideo
Discord (opencck)|https://iplist.opencck.org/?format=text&data=cidr4&site=discord.com|cidr|rec|~0.1k|https://iplist.opencck.org|подсети Discord (сайт и медиа)
Google (runetfreedom geoip)|https://cdn.jsdelivr.net/gh/runetfreedom/russia-blocked-geoip@release/text/google.txt|cidr|aggr|~2.9k|https://github.com/runetfreedom/russia-blocked-geoip|шире официального: весь Google по данным РКН-списков
Instagram (opencck)|https://iplist.opencck.org/?format=text&data=cidr4&site=instagram.com|cidr|aggr|~0.1k|https://iplist.opencck.org|подсети Instagram/Meta CDN
Facebook (opencck)|https://iplist.opencck.org/?format=text&data=cidr4&site=facebook.com|cidr|aggr|~0.2k|https://iplist.opencck.org|подсети Facebook/Meta CDN
X / Twitter (opencck)|https://iplist.opencck.org/?format=text&data=cidr4&site=x.com|cidr|aggr|~16|https://iplist.opencck.org|подсети X (бывший Twitter)
EOF
			;;








		zapret-dom)
			cat <<'EOF'
YouTube (RU-блокировки)|https://cdn.jsdelivr.net/gh/runetfreedom/russia-blocked-geosite@release/youtube.txt|domain|rec|~178|https://github.com/runetfreedom/russia-blocked-geosite|домены YouTube из РКН-списков
Google (RU-блокировки)|https://cdn.jsdelivr.net/gh/runetfreedom/russia-blocked-geosite@release/google.txt|domain|rec|~1.1k|https://github.com/runetfreedom/russia-blocked-geosite|домены Google (поиск, сервисы, Gemini)
Discord (RU-блокировки)|https://cdn.jsdelivr.net/gh/runetfreedom/russia-blocked-geosite@release/discord.txt|domain|rec|~28|https://github.com/runetfreedom/russia-blocked-geosite|домены Discord (сайт, медиа, вложения)
Telegram (v2fly)|https://cdn.jsdelivr.net/gh/v2fly/domain-list-community@master/data/telegram|domain|rec|~21|https://github.com/v2fly/domain-list-community|домены Telegram (веб, API, CDN)
Instagram (v2fly)|https://cdn.jsdelivr.net/gh/v2fly/domain-list-community@master/data/instagram|domain|rec|~76|https://github.com/v2fly/domain-list-community|домены Instagram/Meta CDN
OpenAI / ChatGPT (v2fly)|https://cdn.jsdelivr.net/gh/v2fly/domain-list-community@master/data/openai|domain|rec|~30|https://github.com/v2fly/domain-list-community|домены OpenAI (ChatGPT, API)
Все домены, заблокированные в РФ|https://cdn.jsdelivr.net/gh/runetfreedom/russia-blocked-geosite@release/ru-blocked.txt|domain|aggr|~79.5k|https://github.com/runetfreedom/russia-blocked-geosite|весь РКН-реестр доменов — тяжёлый, снимок на флеш не поместится
EOF
			;;
	esac
}
emit_presets() {
	printf '['
	first=1
	while IFS='|' read -r lbl url fmt grp approx site desc; do
		[ -n "$lbl" ] || continue
		[ "$first" = 1 ] || printf ','
		first=0
		[ -n "$grp" ] || grp=rec
		printf '{"label":"%s","url":"%s","format":"%s","group":"%s","approx":"%s","site":"%s","desc":"%s"}' \
			"$(jesc "$lbl")" "$(jesc "$url")" "$(jesc "$fmt")" "$(jesc "$grp")" "$(jesc "$approx")" "$(jesc "$site")" "$(jesc "$desc")"
	done <<EOF
$(presets_lines "$1")
EOF
	printf ']'
}





cat_state() {

	en=true; cat_enabled "$CAT" || { [ "$CAT" = ipblock ] && guard_live ipblock; } || en=false
	st=$(cat "$(ram_dir "$CAT")/.update.state" 2>/dev/null | tr -d ' \r\n'); [ -n "$st" ] || st=IDLE





	_lk="$(ram_dir "$CAT")/.update.lock"
	if [ "$st" = RUNNING ] && { [ ! -d "$_lk" ] || _lock_stale "$_lk"; }; then
		st=$(cat "$(ram_dir "$CAT")/.update.state" 2>/dev/null | tr -d ' \r\n'); [ "$st" = RUNNING ] && st=ABORTED; [ -n "$st" ] || st=IDLE
	fi
	gs=$(cat "$(ram_dir "$CAT")/.guard.state" 2>/dev/null | tr -d ' \r\n'); [ -n "$gs" ] || gs=NONE

	if [ "$gs" = APPLYING ] && ! guard_live "$CAT"; then
		gs=$(cat "$(ram_dir "$CAT")/.guard.state" 2>/dev/null | tr -d ' \r\n'); [ "$gs" = APPLYING ] && gs=ABORTED; [ -n "$gs" ] || gs=NONE
	fi
	gw=''; [ "$gs" = REVERTED ] && gw=$(cat "$(ram_dir "$CAT")/.guard.why" 2>/dev/null | tr -cd 'a-z')



	bl=null; [ "$CAT" = ipblock ] && { bl=false; iptables -C INPUT -j ENODIA_BLK 2>/dev/null && bl=true; }
	return 0
}

emit_state() {
	cat_state

	_ns=0; [ -f "$(reg_path "$CAT")" ] && _ns=$(awk -F"$TAB" '$1!="" && $3==1' "$(reg_path "$CAT")" 2>/dev/null | grep -c '' || true)
	case "$_ns" in ''|*[!0-9]*) _ns=0 ;; esac



	_ac=$(applied_count "$CAT"); case "$_ac" in ''|*[!0-9]*) _ac=0 ;; esac
	printf '{"cat":"%s","kind":"%s","enabled":%s,"update_state":"%s","guard_state":"%s","guard_why":"%s","blk_live":%s,"nsrc":%s,"count":%s}\n' \
		"$CAT" "$(kind_of "$CAT")" "$en" "$st" "$gs" "$gw" "$bl" "$_ns" "$_ac"
}

emit_list() {
	cat_state
	ac=$(applied_count "$CAT"); case "$ac" in ''|*[!0-9]*) ac=0 ;; esac
	al=0; [ -s "$(allow_path "$CAT")" ] && { al=$(grep -c '' "$(allow_path "$CAT")" 2>/dev/null); case "$al" in ''|*[!0-9]*) al=0 ;; esac; }





	ca=$(ipset_count blocklist_allow 2>/dev/null); case "$ca" in ''|*[!0-9]*) ca=0 ;; esac







	ab=''; acut=false
	if [ -s "$(allow_path "$CAT")" ]; then
		if [ "$(wc -c < "$(allow_path "$CAT")" 2>/dev/null || echo 0)" -gt 32768 ]; then acut=true
		else ab=$(base64 < "$(allow_path "$CAT")" 2>/dev/null | tr -d '\n\r'); fi
	fi
	printf '{"cat":"%s","kind":"%s","enabled":%s,"count":%s,"allow_count":%s,"allow_b64":"%s","allow_cut":%s,"update_state":"%s","guard_state":"%s","guard_why":"%s","critical_count":%s,' \
		"$CAT" "$(kind_of "$CAT")" "$en" "$ac" "$al" "$ab" "$acut" "$st" "$gs" "$gw" "$ca"






	_bl=''; _bw=''
	if [ "$CAT" = ipblock ]; then
		if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi
		command -v lan_if >/dev/null 2>&1 || lan_if() { echo br-lan; }   # lan-lit: шим без router-lib.sh
		_bl=$(lan_if 2>/dev/null | tr -cd 'A-Za-z0-9._-'); _bw=$(wan_iface 2>/dev/null | tr -cd 'A-Za-z0-9._-')
	fi



	_al=false; addr_block_live && _al=true
	_as=0; ipset list -n 2>/dev/null | grep -qx blocklist_allow && _as=1
	printf '"lan":"%s","wan":"%s","addr_live":%s,"blk_live":%s,"critical":[' "$_bl" "$_bw" "$_al" "$bl"
	if [ "$CAT" = ipblock ]; then
		collect_critical 2>/dev/null | awk -F"$TAB" '$1!="" && $2!="user" && !s[$1]++' | while IFS="$TAB" read -r _ci _cw _cd; do
			_cin=null
			if [ "$_as" = 1 ]; then _cin=false; ipset test blocklist_allow "$_ci" >/dev/null 2>&1 && _cin=true; fi
			printf '%s\t%s\t%s\t%s\n' "$_ci" "$_cw" "$_cd" "$_cin"
		done | awk -F"$TAB" '{ gsub(/[\\"]/,"",$3); if (n++) printf ","
			printf "{\"ip\":\"%s\",\"why\":\"%s\",\"dev\":\"%s\",\"in\":%s}", $1, $2, $3, $4 }'
	fi
	printf '],"sources":['
	first=1; reg=$(reg_path "$CAT"); mx=0
	if [ -f "$reg" ]; then
		while IFS="$TAB" read -r id type enb fmt cnt ts label value; do
			[ -n "$id" ] || continue
			eb=false; [ "$enb" = 1 ] && eb=true
			case "$cnt" in ''|*[!0-9]*) cnt=0 ;; esac
			case "$ts"  in ''|*[!0-9]*) ts=0 ;; esac
			[ "$enb" = 1 ] && [ "$ts" -gt "$mx" ] && mx=$ts
			[ "$first" = 1 ] || printf ','
			first=0
			printf '{"id":"%s","type":"%s","enabled":%s,"format":"%s","count":%s,"ts":%s,"label":"%s","value":"%s"}' \
				"$(jesc "$id")" "$(jesc "$type")" "$eb" "$(jesc "$fmt")" "$cnt" "$ts" "$(jesc "$label")" "$(jesc "$value")"
		done < "$reg"
	fi




	ua=-1; [ "$mx" -gt 0 ] && { ua=$(( $(date +%s) - mx )); [ "$ua" -ge 0 ] || ua=0; }
	printf '],"upd_age":%s,"presets":' "$ua"; emit_presets "$CAT"; printf '}\n'
}
















ALLOW_IP_RE='^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(/([89]|[12][0-9]|3[0-2]))?$'


bg_update() {
	rm -f "/tmp/enodia-lists-$1.pid" 2>/dev/null   # как spawn_bg: протухший пидфайл не должен запретить запуск
	if command -v start-stop-daemon >/dev/null 2>&1; then
		start-stop-daemon -S -b -m -p "/tmp/enodia-lists-$1.pid" -x /bin/sh -- "$ENODIA_DIR/lists-update.sh" update "$1" >/dev/null 2>&1
	else ( sh "$ENODIA_DIR/lists-update.sh" update "$1" >/dev/null 2>&1 & ); fi
	return 0
}
allow_set() {  # allow_set <cat> <файл>
	_af=$(allow_path "$1"); _ai="$(ram_dir "$1")/.allow.in"





	if [ "$1" = adblock ]; then
		tr -d '\r' < "$2" | sed 's/[#;].*$//; s/^[[:space:]]*@@//; s/^[[:space:]]*0\.0\.0\.0[[:space:]][[:space:]]*//; s/^[[:space:]]*127\.0\.0\.1[[:space:]][[:space:]]*//; s/^[[:space:]]*::1*[[:space:]][[:space:]]*//'
	else tr -d '\r' < "$2" | sed 's/[#;].*$//'; fi | tr ', \t' '\n\n\n' | grep -v '^$' > "$_ai"
	_tot=$(grep -c '' "$_ai" 2>/dev/null); case "$_tot" in ''|*[!0-9]*) _tot=0 ;; esac

	_raw=$(tr -d '\r' < "$2" | grep -c '[^[:space:]]'); case "$_raw" in ''|*[!0-9]*) _raw=0 ;; esac
	[ "$_tot" = 0 ] && [ "$_raw" -gt 0 ] && _tot=$_raw
	if [ "$1" = ipblock ]; then grep -E "$ALLOW_IP_RE" "$_ai" > "$_ai.ok" 2>/dev/null
	else norm_domains < "$_ai" > "$_ai.ok"; fi
	_val=$(grep -c '' "$_ai.ok" 2>/dev/null); case "$_val" in ''|*[!0-9]*) _val=0 ;; esac
	if [ "$_val" = 0 ] && [ "$_tot" -gt 0 ] && [ -s "$_af" ]; then
		rm -f "$_ai" "$_ai.ok"; echo "kept=0 dropped=$_tot applied=reject"; return 1
	fi

	_gone=0
	if [ "$1" = ipblock ] && [ -s "$_af" ]; then
		sort -u "$_ai.ok" > "$_ai.new"


		if [ ! -s "$_ai.new" ]; then _gone=1
		else grep -vxF -f "$_ai.new" "$_af" 2>/dev/null | grep -q . && _gone=1; fi
		rm -f "$_ai.new"
	fi
	sort -u "$_ai.ok" > "$_af.new" && mv "$_af.new" "$_af"
	_kept=$(grep -c '' "$_af" 2>/dev/null); case "$_kept" in ''|*[!0-9]*) _kept=0 ;; esac
	rm -f "$_ai" "$_ai.ok"
	_app=off
	if [ "$1" = ipblock ]; then


		if addr_block_live; then ensure_allow_set; [ "$_gone" = 1 ] && ct_flush; _app=now
		elif cat_enabled ipblock; then _app=later; fi
	elif cat_enabled "$1"; then


		_alk="$(ram_dir "$1")/.update.lock"
		if ls_lock_take "$_alk" "$(ram_dir "$1")/.update.dirty"; then
			if [ -s "$(snap_path "$1")" ]; then CAT="$1" do_reapply; _app=now; else _app=later; fi
			ls_lock_drop "$_alk"


			if [ -f "$(ram_dir "$1")/.update.dirty" ] && [ -f "$ENODIA_DIR/lists-update.sh" ]; then bg_update "$1"; fi
		else _app=later; fi
	fi
	echo "kept=$_kept dropped=$((_tot - _val)) applied=$_app"
}


case "$CMD" in
	update)   do_update ;;
	reapply)  do_reapply ;;
	wire)     do_wire ;;
	wired)    do_wired; exit $? ;;
	list)    valid_cat "$CAT" || { echo '{"error":"unknown category"}'; exit 1; }; emit_list ;;
	state)    valid_cat "$CAT" || { echo '{"error":"unknown category"}'; exit 1; }; emit_state ;;
	presets)  valid_cat "$CAT" || { printf '[]\n'; exit 1; }; emit_presets "$CAT"; echo ;;
	add-url)
		valid_cat "$CAT" || { echo "unknown category" >&2; exit 1; }
		url="$3"; fmt="${4:-auto}"; label="$5"
		case "$url" in http://*|https://*) ;; *) echo "bad url" >&2; exit 1 ;; esac
		[ -n "$label" ] || label="$url"
		reg_add "$CAT" url 1 "$fmt" "$label" "$url" ;;
	add-blob)
		valid_cat "$CAT" || { echo "unknown category" >&2; exit 1; }
		btype="$3"; fmt="${4:-auto}"; label="$5"; path="$6"
		case "$btype" in file|text) ;; *) echo "bad type" >&2; exit 1 ;; esac
		[ -s "$path" ] || { echo "empty blob" >&2; exit 1; }
		id=$(reg_add "$CAT" "$btype" 1 "$fmt" "$label" "")
		cp "$path" "$(blob_path "$CAT" "$id")" && printf '%s' "$id" ;;
	get-blob)   # вывести содержимое blob file/text-источника (для просмотра/правки в панели)
		valid_cat "$CAT" || exit 1
		f=$(blob_path "$CAT" "$3"); [ -f "$f" ] || { echo "no blob" >&2; exit 1; }
		cat "$f" ;;
	set-blob)   # перезаписать содержимое СУЩЕСТВУЮЩЕГО blob (правка вставленного текста/файла)
		valid_cat "$CAT" || exit 1
		id="$3"; path="$4"
		[ -s "$path" ] || { echo "empty blob" >&2; exit 1; }
		[ -f "$(blob_path "$CAT" "$id")" ] || { echo "no such blob" >&2; exit 1; }
		cp "$path" "$(blob_path "$CAT" "$id")" ;;
	del)      valid_cat "$CAT" || exit 1; reg_del "$CAT" "$3" ;;
	toggle)   valid_cat "$CAT" || exit 1; case "$4" in 0|1) reg_toggle "$CAT" "$3" "$4" ;; *) exit 1 ;; esac ;;
	set-format) valid_cat "$CAT" || exit 1; reg_set_format "$CAT" "$3" "$4" ;;
	enable)
		valid_cat "$CAT" || exit 1
		case "$3" in
			1) : > "$(enable_path "$CAT")" ;;


			0) rm -f "$(enable_path "$CAT")"; teardown "$CAT"

			   [ "$(cat "$(ram_dir "$CAT")/.guard.state" 2>/dev/null | tr -d ' \r\n')" = APPLYING ] && gstate "$(ram_dir "$CAT")" CANCELLED
			   _elk="$(ram_dir "$CAT")/.update.lock"
			   if [ -d "$_elk" ] && ! _lock_stale "$_elk"; then : > "$(ram_dir "$CAT")/.update.dirty"; fi ;;
			*) exit 1 ;;
		esac ;;
	safe-enable)   # включить + собрать/применить + self-test с авто-откатом (слой 3); зовётся CGI фоном
		valid_cat "$CAT" || exit 1
		guarded_enable "$CAT" ;;
	guard-begin)   # синхронное начало проверки связи (CGI — до фонового safe-enable); код 1 — проверка уже идёт
		valid_cat "$CAT" || exit 1
		guard_begin "$CAT" ;;
	allow-set)
		case "$CAT" in adblock|ipblock) ;; *) echo "исключения есть только у adblock и ipblock" >&2; exit 1 ;; esac
		[ -f "$3" ] || { echo "no file" >&2; exit 1; }
		allow_set "$CAT" "$3" ;;




	allow-sync)
		ipset list -n 2>/dev/null | grep -qx blocklist_allow && ensure_allow_set
		exit 0 ;;
	*) echo "usage: lists-update.sh update|list|presets|add-url|add-blob|get-blob|set-blob|del|toggle|set-format|enable|allow-set <cat> … | allow-sync" >&2; exit 2 ;;
esac
