#!/bin/sh































DAEMON_WAIT_STORE=${DAEMON_WAIT_STORE:-60}



DAEMON_PID_GRACE=${DAEMON_PID_GRACE:-3}

DAEMON_WAIT_WHY=''


daemon_wait_secs() {   # $1 = имя бинаря ; $2 = срок для флеша ; -> секунды
    _dws=${2:-8}
    if daemon_on_store "$1" && [ "$_dws" -lt "$DAEMON_WAIT_STORE" ]; then _dws=$DAEMON_WAIT_STORE; fi
    printf '%s' "$_dws"
}



daemon_on_store() {   # $1 = имя бинаря
    command -v bin_on_store >/dev/null 2>&1 || return 1
    bin_on_store "$1"
}







daemon_where_ru() {   # $1 = имя бинаря
    if daemon_on_store "$1"; then printf 'на накопителе'; return 0; fi
    command -v bin_where >/dev/null 2>&1 || { printf 'носитель неизвестен'; return 0; }
    case "$(bin_where "$1" 2>/dev/null)" in
        '') printf 'не найден' ;;
        *)  printf 'на флеше роутера' ;;
    esac
}








pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' < "/proc/$1/cmdline" 2>/dev/null | grep -qE "$2"; }






DL_WD_LOCK=${ENODIA_WD_LOCK:-/tmp/enodia-watchdog.lock}
DL_WD_PID=${ENODIA_WD_PID:-/tmp/enodia-watchdog.pid}
DL_HEAL_LOCK=${ENODIA_HEAL_LOCK:-/tmp/enodia-heal.lock}
wd_tick_alive() {
    [ -e "$DL_WD_LOCK" ] || return 1
    _wta=$(cat "$DL_WD_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_wta" 'watchdog\.sh'
}




DL_REPLAY_PID=${ENODIA_REPLAY_PID:-/tmp/enodia-heal-replay.pid}
heal_alive() {
    _hla=$(cat "$DL_HEAL_LOCK" 2>/dev/null | tr -d '\r'); _hla=${_hla%% *}
    case "$_hla" in ''|*[!0-9]*) _hla= ;; esac
    [ -n "$_hla" ] && pid_runs "$_hla" 'heal\.sh' && return 0
    _hlr=$(cat "$DL_REPLAY_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_hlr" 'heal\.sh'
}










carrier_barred() { [ -f "$ENODIA_STATE/.vpn-off" ]; }
_crlog() { if command -v log >/dev/null 2>&1; then log "$1"; else echo "$1"; fi; }

carrier_run() {
    _cru=$1; _crf=$2; shift 2
    if carrier_barred; then _crlog "VPN выключен вручную — несущую не поднимаю"; return 1; fi
    "$_crf" "$@"; _crr=$?
    carrier_barred || return "$_crr"
    _crlog "VPN выключили вручную, пока поднималась несущая, — отпускаю её"
    "$_cru" "$@" >/dev/null 2>&1
    return 1
}
daemon_port_listens()  { netstat -ltn 2>/dev/null | grep -q "$1:$2 "; }
daemon_uport_listens() { netstat -lnu 2>/dev/null | grep -q "$1:$2 "; }   # UDP: резолвер DoH/DoT
daemon_dev_exists()    { ip link show "$1" >/dev/null 2>&1; }




_daemon_wait() {   # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 «чего ждём» словами ; далее — КОМАНДА-проба
    _dwpid="$1"; _dwbin="$2"; _dwwhat="$4"
    _dwmax=$(daemon_wait_secs "$_dwbin" "$3")
    shift 4
    _dwi=0
    while :; do
        if "$@"; then DAEMON_WAIT_WHY=''; return 0; fi






        _dwp=$(cat "$_dwpid" 2>/dev/null | tr -d ' \r\n')
        if [ -z "$_dwp" ]; then
            if [ "$_dwi" -ge "$DAEMON_PID_GRACE" ]; then
                DAEMON_WAIT_WHY="процесс НЕ ЗАПУСТИЛСЯ (пидфайл $_dwpid пуст через $_dwi с), $_dwwhat не появился"
                return 1
            fi
        elif [ ! -d "/proc/$_dwp" ]; then
            DAEMON_WAIT_WHY="процесс УМЕР через $_dwi с — $_dwwhat не появился"
            return 1
        fi
        [ "$_dwi" -ge "$_dwmax" ] && break
        sleep 1; _dwi=$((_dwi+1))
    done
    DAEMON_WAIT_WHY="процесс ЖИВ, но за $_dwmax с $_dwwhat не появился (бинарь $_dwbin $(daemon_where_ru "$_dwbin"))"
    return 1
}


daemon_wait_port() {   # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 адрес ; $5 порт
    _daemon_wait "$1" "$2" "$3" "порт $4:$5" daemon_port_listens "$4" "$5"
}



daemon_wait_uport() {  # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 адрес ; $5 порт
    _daemon_wait "$1" "$2" "$3" "порт $4:$5/udp" daemon_uport_listens "$4" "$5"
}


daemon_wait_dev() {    # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 имя интерфейса
    _daemon_wait "$1" "$2" "$3" "устройство $4" daemon_dev_exists "$4"
}
