#!/bin/sh






























































set -e


RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

if [ -n "$INSTALL_FROM_PKG" ]; then RED=''; GREEN=''; YELLOW=''; BLUE=''; NC=''; fi

log()  { printf "${BLUE}[INFO]${NC}  %s\n" "$1"; }
ok()   { printf "${GREEN}[ OK ]${NC}  %s\n" "$1"; }
warn() { printf "${YELLOW}[WARN]${NC}  %s\n" "$1"; }
err()  { printf "${RED}[FAIL]${NC}  %s\n" "$1" >&2; }

ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}
CRON_RUN="$ENODIA_BOOT/boot.sh"




if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi


if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi
command -v lan_if >/dev/null 2>&1 || lan_if() { echo br-lan; }   # lan-lit: шим без router-lib.sh


if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
command -v bin_path    >/dev/null 2>&1 || bin_path()    { printf '%s' "$ENODIA_BIN/$1"; }
command -v bin_install >/dev/null 2>&1 || bin_install() { mv -f "$1" "$ENODIA_BIN/$2" && chmod +x "$ENODIA_BIN/$2"; }
: "${BIN_DIR:=$ENODIA_DIR}"



put_bin() { bin_install "$1" "$2" || { err "Не удалось положить $2 на место (нет места на /data / накопителе? файл занят?)"; exit 1; }; }
AWG_CONF="$ENODIA_STATE/awg.conf"
INSTALL_SCRIPT_URL="https://github.com/alexandershalin/amneziawg-be7000/raw/refs/heads/main/awg_setup.sh"
RC_LOCAL="/etc/rc.local"
DNSMASQ_CONF="/etc/dnsmasq.conf"
DNSMASQ_DIR="/etc/dnsmasq.d"
ENODIA_LIST_NAME="enodia_list"
ROUTE_TABLE="1000"
FWMARK="0x1"




















INSTALL_ALT="${INSTALL_ALT:-}"













_purge_bin() {
    _n=${1##*/}; _hit=0
    if [ -f "$ENODIA_BIN/$_n" ]; then rm -f "$ENODIA_BIN/$_n"; _hit=1; fi
    if [ "$BIN_DIR" != "$ENODIA_BIN" ] && [ -f "$BIN_DIR/$_n" ]; then rm -f "$BIN_DIR/$_n"; _hit=1; fi
    if [ "$_hit" = 1 ]; then ok "Снят бинарь $2 (оставляем: ${INSTALL_ALT})"; fi
    return 0
}






_slot_carrier_in_use() {   # $1 = ключ транспорта (xray|hy2|byedpi); 0 = бинарь нужен выходу
    [ -s "$ENODIA_STATE/.slots" ] || return 1
    cut -f3 "$ENODIA_STATE/.slots" 2>/dev/null | grep -qx "$1"
}

_purge_alt_bin() {   # $1 = путь бинаря ; $2 = метка ; $3 = ключ транспорта
    if _slot_carrier_in_use "$3"; then
        [ -f "$1" ] && warn "$2 оставлен: он несёт дополнительный выход (см. «Соединение → Дополнительные выходы»)."
        return 0
    fi
    _purge_bin "$1" "$2"
}


_hev_in_use_by_slot() { _slot_carrier_in_use byedpi || _slot_carrier_in_use xray || _slot_carrier_in_use hy2; }






_kill_alt_daemon() { [ -f "$1" ] || return 0; start-stop-daemon -K -p "$1" 2>/dev/null || true; rm -f "$1"; return 0; }










_relinquish_if_active() {
    cur=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    [ "$cur" = "$1" ] || return 0
    [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" down "$1" >/dev/null 2>&1
    warn "Убираемый альт ($1) нёс трафик — несущая снята (релинквиш → прямой режим до подъёма новой)."
}





_alt_bin()   { case "$1" in xray) bin_path xray ;; hy2) bin_path hysteria ;; byedpi) bin_path byedpi ;; esac; }
_alt_label() { case "$1" in xray) echo "Xray" ;; hy2) echo "Hysteria2" ;; byedpi) echo "ByeDPI" ;; esac; }
_alt_pid()   { case "$1" in xray) echo /tmp/enodia-xray.pid ;; hy2) echo /tmp/enodia-hysteria.pid ;; byedpi) echo /tmp/enodia-byedpi.pid ;; esac; }
purge_unselected_alt() {
    [ -n "$INSTALL_ALT" ] || return 0
    _keep=$(printf '%s' "$INSTALL_ALT" | tr ',' ' ')
    case " $_keep " in *" none "*) _keep="" ;; esac      # «none» = не оставляем ни одного
    for _a in xray hy2 byedpi; do
        case " $_keep " in *" $_a "*) continue ;; esac
        _relinquish_if_active "$_a"
        _kill_alt_daemon "$(_alt_pid "$_a")"
        _purge_alt_bin "$(_alt_bin "$_a")" "$(_alt_label "$_a")" "$_a"
    done



    _hev_keep=0
    for _a in xray hy2 byedpi; do [ -f "$(_alt_bin "$_a")" ] && { _hev_keep=1; break; }; done
    _hev_in_use_by_slot && _hev_keep=1
    if [ "$_hev_keep" = 1 ]; then
        { [ -z "$_keep" ] && [ -f "$ENODIA_BIN/hev" ] && warn "hev (tun2socks) оставлен: его ещё держит установленный альт или дополнительный выход."; } || true
    else
        _purge_bin "$ENODIA_BIN/hev" "hev (tun2socks)"
    fi
    return 0
}

if [ "${1:-}" = purge-alt ]; then purge_unselected_alt; exit 0; fi




log "Проверяю окружение..."

if [ "$(id -u)" -ne 0 ]; then
    err "Скрипт должен запускаться от root. Текущий пользователь: $(whoami)"
    exit 1
fi

mkdir -p "$ENODIA_DIR" "$ENODIA_STATE" "$ENODIA_BIN"






if [ -f "$ENODIA_DIR/ram-lib.sh" ]; then ( . "$ENODIA_DIR/ram-lib.sh"; ram_migrate ) 2>/dev/null || true; fi
chmod 700 "$ENODIA_STATE" 2>/dev/null || true
chmod 755 "$ENODIA_BIN" 2>/dev/null || true



if [ -z "$INSTALL_FROM_PKG" ]; then rm -f "$ENODIA_DIR/.pkg-sums" 2>/dev/null || true; fi








if command -v harden_perms >/dev/null 2>&1; then
    harden_perms "$ENODIA_DIR" "$ENODIA_STATE" "$ENODIA_BIN"
fi
cd "$ENODIA_DIR"







if [ -f "$ENODIA_DIR/xray-transport.sh" ]; then
    sh "$ENODIA_DIR/xray-transport.sh" access-purge >/dev/null 2>&1 || true
fi








case "$INSTALL_LANG" in
    ru|en)
        if ! grep -q '^lang=' "$ENODIA_STATE/.prefs" 2>/dev/null; then





            if [ -s "$ENODIA_STATE/.prefs" ] && [ -n "$(tail -c 1 "$ENODIA_STATE/.prefs" 2>/dev/null)" ]; then
                printf '\n' >> "$ENODIA_STATE/.prefs"
            fi
            printf 'lang=%s\n' "$INSTALL_LANG" >> "$ENODIA_STATE/.prefs"
        fi
        ;;
esac




HAVE_AWG=0;  [ -f "$AWG_CONF" ] && HAVE_AWG=1
HAVE_XRAY=0; ls "$ENODIA_STATE"/xray-configs/*.json >/dev/null 2>&1 && HAVE_XRAY=1
[ -s "$ENODIA_STATE/xray.json" ] && HAVE_XRAY=1
HAVE_HY2=0;  ls "$ENODIA_STATE"/hy2-configs/*.yaml >/dev/null 2>&1 && HAVE_HY2=1
[ -s "$ENODIA_STATE/hysteria.yaml" ] && HAVE_HY2=1










{ [ -f "$ENODIA_DIR/bin/xray.user" ] || [ -x "$(bin_path xray)" ]; } && HAVE_XRAY=1
{ [ -f "$ENODIA_DIR/bin/hysteria.user" ] || [ -x "$(bin_path hysteria)" ]; } && HAVE_HY2=1



HAVE_BYEDPI=0; { [ -f "$ENODIA_DIR/bin/byedpi.user" ] || [ -x "$(bin_path byedpi)" ]; } && HAVE_BYEDPI=1





PANEL_ONLY=0



if [ "$INSTALL_PROTO" = none ]; then PANEL_ONLY=1; fi









KEEP_TRANSPORT=0
if [ "$PANEL_ONLY" = 1 ] && [ -f "$ENODIA_DIR/transport.sh" ]; then
    sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1 && _kt=0 || _kt=$?
    if [ "$_kt" != 1 ]; then KEEP_TRANSPORT=1; fi
fi
if [ "$PANEL_ONLY" = 0 ] && [ "$HAVE_AWG" = 0 ] && [ "$HAVE_XRAY" = 0 ] && [ "$HAVE_HY2" = 0 ] && [ "$HAVE_BYEDPI" = 0 ]; then
    err "Не найдено ни $AWG_CONF, ни xray-/hy2-конфигов, ни byedpi-бинаря."
    err "Положите awg.conf (AmneziaWG) и/или альт-конфиг (Xray/Hysteria2) либо bin/byedpi.user и запустите снова."
    err "Нужна установка без транспорта (только веб-панель) — запустите с INSTALL_PROTO=none."
    exit 1
fi

if [ "$HAVE_AWG" = 1 ]; then ACTIVE_PROTO=awg; elif [ "$HAVE_XRAY" = 1 ]; then ACTIVE_PROTO=xray; elif [ "$HAVE_HY2" = 1 ]; then ACTIVE_PROTO=hy2; else ACTIVE_PROTO=byedpi; fi
[ -n "$INSTALL_PROTO" ] && ACTIVE_PROTO="$INSTALL_PROTO"
if [ "$PANEL_ONLY" = 1 ] && [ "$KEEP_TRANSPORT" = 1 ]; then
    ok "Режим: ТОЛЬКО ПАНЕЛЬ поверх настроенной системы — транспорт и его правила не трогаю"
elif [ "$PANEL_ONLY" = 1 ]; then
    ok "Режим: ТОЛЬКО ПАНЕЛЬ — транспорт не активируем, протоколы добираются в браузере"
else
    ok "Ставим: AmneziaWG=$HAVE_AWG, Xray=$HAVE_XRAY, Hysteria2=$HAVE_HY2, ByeDPI=$HAVE_BYEDPI; активный транспорт = $ACTIVE_PROTO"
fi


ok "Роутер: $(uname -m), ядро $(uname -r)"

















LEGACY_DIR=/data/usr/app/awg
_legacy=0
if [ -f "$LEGACY_DIR/uninstall.sh" ]; then _legacy=1; fi
if grep -qF "$LEGACY_DIR/" /etc/crontabs/root 2>/dev/null; then _legacy=1; fi
if [ "$LEGACY_DIR" != "$ENODIA_DIR" ] && [ "$_legacy" = 1 ]; then
    err "На роутере стоит ПРЕЖНЯЯ версия — $LEGACY_DIR (каталог переехал при ребрендинге)."
    err "Две копии разом дерутся за iptables и cron, поэтому ставить поверх нельзя."
    err "Снимите прежнюю — панель: «Настройки» → «Удаление» → «Удалить всё»,"
    err "либо по SSH:  sh $LEGACY_DIR/uninstall.sh purge"
    err "После этого запустите установку заново."
    exit 1
fi




















WAN_IF=$(wan_iface)   # владелец имени — ip-lib.sh (шим в шапке)
if curl -fsSk --max-time 5 -o /dev/null https://1.1.1.1 2>/dev/null || \
   curl -fsSk --max-time 5 -o /dev/null https://www.gstatic.com/generate_204 2>/dev/null || \
   ping -c 1 -W 3 1.1.1.1 >/dev/null 2>&1; then
    ok "Интернет на роутере есть"
elif [ -n "$WAN_IF" ] && { curl -fsSk --max-time 5 --interface "$WAN_IF" -o /dev/null https://1.1.1.1 2>/dev/null || \
                           ping -I "$WAN_IF" -c 1 -W 3 1.1.1.1 >/dev/null 2>&1; }; then
    warn "Интернет ЕСТЬ (проверено через $WAN_IF), но трафик роутера заворачивается в неработающий туннель"
    warn "— это следы прошлой установки. Продолжаю: установка их перезапишет."
elif [ -n "$INSTALL_FROM_PKG" ]; then


    warn "Нет интернета на роутере: панель встанет, но протоколы и списки ей качать будет неоткуда, пока не появится связь."
    warn "Кабель на месте, а связи нет? Похоже на правила прошлой установки — снимите её (панель → «Удаление») и повторите."
else
    err "Нет интернета на роутере. Подключите WAN-кабель/проверьте настройки."
    err "Кабель на месте? Тогда снимите прошлую установку (в панели «Удаление» либо enodia-setup.bat) и повторите:"
    err "её правила могли остаться и уводить трафик роутера в туннель, которого больше нет."
    exit 1
fi








if [ "$HAVE_AWG" = 1 ] && grep -qE '^I[1-5]\s*=\s*$' "$AWG_CONF"; then
    log "Чищу пустые поля I1..I5 в awg.conf..."
    sed -i '/^I[1-5]\s*=\s*$/d' "$AWG_CONF"
    ok "Пустые I-поля удалены"
fi








if [ "$HAVE_AWG" = 1 ] && [ ! -f "$ENODIA_STATE/amnezia_for_awg.conf" ]; then
    cp "$AWG_CONF" "$ENODIA_STATE/amnezia_for_awg.conf"
    ok "amnezia_for_awg.conf создан из awg.conf"
fi




















_elf_machine() { dd if="$1" of="$2" bs=1 skip=18 count=2 2>/dev/null; }
bin_arch_matches() {
    _ref=/bin/busybox
    [ -r "$_ref" ] || return 0
    command -v dd >/dev/null 2>&1 || return 0
    command -v cmp >/dev/null 2>&1 || return 0

    _probe=""
    for _f in "$ENODIA_DIR"/bin/*.user; do
        if [ -f "$_f" ]; then _probe="$_f"; break; fi
    done
    [ -n "$_probe" ] || return 0
    _elf_machine "$_ref" /tmp/.enodia-arch-ref.$$ || return 0
    _elf_machine "$_probe" /tmp/.enodia-arch-bin.$$ || return 0
    if cmp -s /tmp/.enodia-arch-ref.$$ /tmp/.enodia-arch-bin.$$; then _rc=0; else _rc=1; fi
    rm -f /tmp/.enodia-arch-ref.$$ /tmp/.enodia-arch-bin.$$
    return $_rc
}
if ! bin_arch_matches; then
    err "Бинари bin/*.user НЕ подходят к архитектуре этого роутера — установка невозможна."
    err "Роутер: $(uname -m); в bin/ лежит набор под ДРУГУЮ арку."
    err "Ядро откажется их запускать (ENOEXEC), busybox напечатает «syntax error» вместо"
    err "версии, и туннель не поднимется. Наборы собраны под arm64 и armv7 — ПК-сторона"
    err "(enodia.py) выбирает нужный сама; сюда, похоже, приехал не тот. Переустановите с ПК."
    err "Пришлите разработчику: uname -a; cat /proc/cpuinfo"
    exit 1
fi




















if [ "$HAVE_AWG" = 1 ] && [ -f "$ENODIA_DIR/bin/amneziawg-go.user" ]; then
    log "Найден пользовательский amneziawg-go.user, ставлю (mv, без удвоения флеша)..."
    mv "$ENODIA_DIR/bin/amneziawg-go.user" "$ENODIA_BIN/amneziawg-go"
    chmod +x "$ENODIA_BIN/amneziawg-go"
    ok "amneziawg-go установлен ($("$ENODIA_BIN/amneziawg-go" --version 2>&1 | head -1))"
fi
if [ "$HAVE_AWG" = 1 ] && [ -f "$ENODIA_DIR/bin/awg.user" ]; then
    log "Найден пользовательский awg.user, ставлю (mv, без удвоения флеша)..."
    mv "$ENODIA_DIR/bin/awg.user" "$ENODIA_BIN/awg"
    chmod +x "$ENODIA_BIN/awg"
    ok "awg установлен ($("$ENODIA_BIN/awg" --version 2>&1 | head -1))"
fi











if [ -f "$ENODIA_DIR/bin/xray.user" ]; then
    log "Найден xray.user, ставлю (mv, без удвоения флеша)..."
    put_bin "$ENODIA_DIR/bin/xray.user" xray
    ok "xray установлен ($("$(bin_path xray)" version 2>&1 | head -1))"
fi
if [ -f "$ENODIA_DIR/bin/hev.user" ]; then
    log "Найден hev.user (tun2socks), ставлю..."
    put_bin "$ENODIA_DIR/bin/hev.user" hev
    ok "hev (tun2socks) установлен"
fi



if [ -f "$ENODIA_DIR/bin/hysteria.user" ]; then
    log "Найден hysteria.user, ставлю (mv, без удвоения флеша)..."
    put_bin "$ENODIA_DIR/bin/hysteria.user" hysteria
    ok "hysteria установлен"
fi


if [ -f "$ENODIA_DIR/bin/byedpi.user" ]; then
    log "Найден byedpi.user (ciadpi, DPI-десинк), ставлю..."
    put_bin "$ENODIA_DIR/bin/byedpi.user" byedpi
    ok "byedpi (ciadpi) установлен"
fi


if [ -f "$ENODIA_DIR/bin/nfqws.user" ]; then
    log "Найден nfqws.user (zapret, DPI-десинк направо), ставлю..."
    put_bin "$ENODIA_DIR/bin/nfqws.user" nfqws
    ok "nfqws (zapret) установлен"
fi


if [ -f "$ENODIA_DIR/bin/https-dns-proxy.user" ]; then
    log "Найден https-dns-proxy.user (DoH-прокси), ставлю..."
    mv "$ENODIA_DIR/bin/https-dns-proxy.user" "$ENODIA_BIN/https-dns-proxy"
    chmod +x "$ENODIA_BIN/https-dns-proxy"
    ok "https-dns-proxy (DoH) установлен"
fi


if [ -f "$ENODIA_DIR/bin/dot-proxy.user" ]; then
    log "Найден dot-proxy.user (DoT-прокси), ставлю..."
    mv "$ENODIA_DIR/bin/dot-proxy.user" "$ENODIA_BIN/dot-proxy"
    chmod +x "$ENODIA_BIN/dot-proxy"
    ok "dot-proxy (DoT) установлен"
fi




if [ -f "$ENODIA_DIR/bin/panel-tls.user" ]; then
    log "Найден panel-tls.user (HTTPS панели), ставлю..."
    mv "$ENODIA_DIR/bin/panel-tls.user" "$ENODIA_BIN/panel-tls"
    chmod +x "$ENODIA_BIN/panel-tls"
    ok "panel-tls (HTTPS панели) установлен"
fi






_have=""; _miss=""
for _b in amneziawg-go awg xray hev hysteria byedpi nfqws https-dns-proxy dot-proxy panel-tls; do
    if [ -x "$(bin_path "$_b")" ]; then _have="$_have $_b"; else _miss="$_miss $_b"; fi
done
ok "Бинари на роутере:${_have:- (ни одного!)}"




if [ -n "$_miss" ]; then
    if [ "$PANEL_ONLY" = 1 ]; then log "Остальное ставится из панели («Компоненты»):$_miss"
    else warn "Не установлены:$_miss"; fi
fi





[ -f "$ENODIA_DIR/xray-transport.sh" ] && chmod +x "$ENODIA_DIR/xray-transport.sh" || true
[ -f "$ENODIA_DIR/transport-hy2.sh" ] && chmod +x "$ENODIA_DIR/transport-hy2.sh" || true
[ -f "$ENODIA_DIR/transport-byedpi.sh" ] && chmod +x "$ENODIA_DIR/transport-byedpi.sh" || true
[ -f "$ENODIA_DIR/byedpi-test.sh" ] && chmod +x "$ENODIA_DIR/byedpi-test.sh" || true
[ -f "$ENODIA_DIR/zapret.sh" ] && chmod +x "$ENODIA_DIR/zapret.sh" || true
mkdir -p "$ENODIA_STATE/xray-configs" "$ENODIA_STATE/hy2-configs"



if [ "$HAVE_AWG" = 1 ] && { grep -qE '^(S3|S4)\s*=' "$AWG_CONF" || grep -qE '^H[1-4]\s*=\s*[0-9]+-[0-9]+' "$AWG_CONF"; }; then
    if [ ! -x "$ENODIA_BIN/amneziawg-go" ] || [ ! -x "$ENODIA_BIN/awg" ]; then
        warn "Конфиг AWG 2.0 (есть S3/S4 или диапазон H), но нет рабочих бинарников"
        warn "AmneziaWG. Вендорный awg_setup.sh их БОЛЬШЕ НЕ качает (старые версии с"
        warn "github ломали S3/S4) — он просто упадёт с exit 1, awg0 не поднимется."
        warn "Соберите бинарники по инструкции (Приложение Г) и положите в"
        warn "$ENODIA_DIR/bin/{amneziawg-go.user,awg.user}, потом перезапустите этот скрипт."
        warn "Альтернатива: добавьте на VPS протокол AmneziaWG Legacy и используйте его конфиг."
    fi
fi
















FW3_WIPED=0     # выставит секция 1, если реально звали awg_setup.sh (он делает fw3 reload)
if [ "$HAVE_AWG" = 1 ] && [ "$PANEL_ONLY" = 0 ] && [ ! -f "$ENODIA_STATE/.vpn-off" ]; then
log "Проверяю установщик AmneziaWG (awg_setup.sh, вендорится с бандлом)..."






if [ ! -f "$ENODIA_DIR/awg_setup.sh" ]; then
    err "awg_setup.sh не найден в $ENODIA_DIR — он поставляется с установщиком (вендорится)."
    err "Перезалейте файлы бандла. Историч. источник: $INSTALL_SCRIPT_URL"
    exit 1
fi
chmod +x "$ENODIA_DIR/awg_setup.sh"
ok "Установщик AWG на месте (вендорится с бандлом, github не нужен)"






log "Запускаю установщик AmneziaWG (может занять 1-2 минуты)..."
if ! ip link show awg0 >/dev/null 2>&1; then







    FW3_WIPED=1
    sh "$ENODIA_DIR/awg_setup.sh" || {
        err "Установщик AWG завершился с ошибкой"
        err "Откройте $ENODIA_DIR/awg_setup.sh глазами, разберитесь с конфигом"
        exit 1
    }
    ok "AmneziaWG установлен"
else
    ok "Интерфейс awg0 уже поднят, переустановку пропускаю"
fi


log "Жду поднятия awg0..."
for i in $(seq 1 30); do
    if ip link show awg0 >/dev/null 2>&1; then
        ok "awg0 поднят"
        break
    fi
    sleep 1
done

if ! ip link show awg0 >/dev/null 2>&1; then
    err "awg0 не появился за 30 секунд. Проверьте awg.conf, ключи и endpoint VPS."
    err "Команда для диагностики: ip a; cat $ENODIA_STATE/awg_setup.log (если есть)"
    exit 1
fi


log "Проверяю handshake с VPS..."
sleep 3
if command -v wg >/dev/null 2>&1; then
    WG_CMD="wg"
elif command -v amnezia-wg >/dev/null 2>&1; then
    WG_CMD="amnezia-wg"
elif [ -x "$ENODIA_BIN/awg" ]; then




    WG_CMD="$ENODIA_BIN/awg"
fi

if [ -n "$WG_CMD" ]; then
    "$WG_CMD" show awg0 2>/dev/null || warn "Не удалось получить wg show, но интерфейс есть"
fi
elif [ "$HAVE_AWG" = 1 ] && [ "$PANEL_ONLY" = 0 ]; then



    log "VPN выключен вручную — awg0 не поднимаю (поднимется при включении VPN)"
elif [ "$HAVE_AWG" = 1 ]; then



    log "Только панель: awg.conf на флеше есть, но awg0 не трогаю — протокол включают в браузере"
fi   # /HAVE_AWG (конец секции 1: установка/подъём awg0)




log "Проверяю наличие ipset..."

if ! command -v ipset >/dev/null 2>&1; then
    warn "ipset не найден, пробую установить через opkg..."
    if command -v opkg >/dev/null 2>&1; then
        opkg update || warn "opkg update не удался, продолжаю"
        opkg install ipset || {
            err "Не удалось установить ipset через opkg."
            err "Ставьте вручную через Entware или ImmortalWrt репо."
            exit 1
        }
    else
        err "opkg недоступен. ipset нужно поставить вручную."
        exit 1
    fi
fi
ok "ipset на месте: $(ipset --version | head -1)"


if ! ipset list -n | grep -q "^${ENODIA_LIST_NAME}$"; then
    ipset create "$ENODIA_LIST_NAME" hash:net family inet hashsize 1024 maxelem 1000000
    ok "ipset $ENODIA_LIST_NAME создан"
else
    ok "ipset $ENODIA_LIST_NAME уже существует"
fi








log "Настраиваю dnsmasq..."

mkdir -p "$DNSMASQ_DIR"


if ! grep -q "^conf-dir=$DNSMASQ_DIR" "$DNSMASQ_CONF" 2>/dev/null; then
    echo "" >> "$DNSMASQ_CONF"
    echo "# Подключение split-tunnel конфигов (добавлено Enodia)" >> "$DNSMASQ_CONF"
    echo "conf-dir=$DNSMASQ_DIR,*.conf" >> "$DNSMASQ_CONF"
    ok "conf-dir добавлен в $DNSMASQ_CONF"
else
    ok "conf-dir уже подключён"
fi







DNS_OVERRIDE="$DNSMASQ_DIR/00-upstream.conf"





DNS_OVERRIDE_LIVE="/tmp/dnsmasq.d/00-upstream.conf"
if [ "$PANEL_ONLY" = 1 ] && [ "$KEEP_TRANSPORT" = 1 ]; then

    ok "DNS upstream: не трогаю — им владеет уже выбранный транспорт"
elif [ "$PANEL_ONLY" = 1 ]; then





    if [ -f "$DNS_OVERRIDE" ] || [ -f "$DNS_OVERRIDE_LIVE" ]; then
        rm -f "$DNS_OVERRIDE" "$DNS_OVERRIDE_LIVE"
        /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null || true
        ok "DNS upstream: вернул стоковый (снял 00-upstream.conf в /etc и /tmp от прошлой установки)"
    else
        ok "DNS upstream: стоковый (транспорта нет — не трогаю)"
    fi
elif [ "$ACTIVE_PROTO" = xray ] || [ "$ACTIVE_PROTO" = hy2 ] || [ "$ACTIVE_PROTO" = byedpi ]; then




    printf 'no-resolv\nserver=1.1.1.1\nserver=8.8.8.8\n' > "$DNS_OVERRIDE"
    ok "DNS upstream: публичный 1.1.1.1/8.8.8.8 (альт-транспорт)"









    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null || true
    ok "dnsmasq перезапущен на публичный upstream (резолв для закачки списков до подъёма транспорта)"
else

    VPN_DNS=$(grep -E '^DNS\s*=' "$AWG_CONF" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | awk -F',' '{print $1}' | tr -d ' ')
    [ -z "$VPN_DNS" ] && VPN_DNS="172.29.172.254"
    cat > "$DNS_OVERRIDE" <<EOF
# DNS-сервер внутри VPN-туннеля (защита от подмен провайдером).
# Адрес взят из awg.conf поля DNS=. Если у вас другой — поправьте здесь
# и убедитесь, что heal.sh использует тот же (переменная VPN_DNS).
no-resolv
server=$VPN_DNS
EOF
    ok "DNS upstream настроен ($DNS_OVERRIDE → $VPN_DNS)"

    if ip link show awg0 >/dev/null 2>&1; then



        ip route replace "$VPN_DNS/32" dev awg0 2>/dev/null || true
        ok "Маршрут к $VPN_DNS прописан через awg0"
    fi
fi












log "Домены: ведёт менеджер источников (панель → «Сайты, домены, IP»)."
log "  IP-пул (CIDR от opencck.org) наполняет iplist-update.sh, он уже настроен."










if [ -f "$ENODIA_DIR/iplist-update.sh" ]; then
    log "Подгружаю CIDR от iplist.opencck.org..."
    chmod +x "$ENODIA_DIR/iplist-update.sh"
    sh "$ENODIA_DIR/iplist-update.sh" || warn "iplist-update вернул ошибку — см. /tmp/enodia-iplist-update.log"
    if ipset list -n 2>/dev/null | grep -qx iplist_set; then

        ipl_count=$(ipset list iplist_set 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)





        case "$ipl_count" in ''|*[!0-9]*) ipl_count=$(ipset list iplist_set 2>/dev/null | grep -cE '^[0-9]' || true) ;; esac
        case "$ipl_count" in ''|*[!0-9]*) ipl_count=0 ;; esac
        ok "iplist_set наполнен: $ipl_count CIDR"
    fi
fi









CARRIER_UP=0
if [ "$PANEL_ONLY" = 1 ] && [ "$KEEP_TRANSPORT" = 1 ]; then






    _kt_name=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_kt_name" ] || _kt_name=awg
    log "Транспорт уже выбран ($_kt_name) — маршрутизацию не трогаю"
    ok "Обновлены скрипты, панель и cron; транспорт и его правила остались как были"
elif [ "$PANEL_ONLY" = 1 ]; then



    rm -f "$ENODIA_STATE/.transport"
    log "Только панель: маршрутизацию не трогаю — роутер работает как сток"
    ok "Транспорт не активирован (выбор за человеком, в панели)"
else
    log "Применяю ядро маршрутизации + активный транспорт ($ACTIVE_PROTO)..."
    echo "$ACTIVE_PROTO" > "$ENODIA_STATE/.transport"
    if [ -f "$ENODIA_DIR/mark-core.sh" ]; then
        sh "$ENODIA_DIR/mark-core.sh"
    else
        err "mark-core.sh отсутствует (payload неполон) — маркировка не применена"
    fi













    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        n=1
        while [ "$n" -le 2 ]; do
            out=$(sh "$ENODIA_DIR/transport.sh" up "$ACTIVE_PROTO" 2>&1) && rc=0 || rc=$?
            [ -n "$out" ] && printf '%s\n' "$out"
            if [ "$rc" = 0 ]; then CARRIER_UP=1; break; fi
            warn "Попытка $n: транспорт $ACTIVE_PROTO не поднялся (код $rc). Повтор через 3с…"
            sleep 3; n=$((n+1))
        done
    else
        warn "transport.sh отсутствует (payload неполон) — несущая не поднята."
    fi
    if [ "$CARRIER_UP" = 1 ]; then
        ok "Маршрутизация + транспорт ($ACTIVE_PROTO) применены"
    else
        err "Несущая ($ACTIVE_PROTO) НЕ поднялась. VPN сейчас в ПРЯМОМ режиме (fail-open: интернет"
        err "работает, трафик идёт МИМО туннеля). Установка продолжается — см. логи демонов ниже."

        for L in /tmp/enodia-hysteria.log /tmp/xray.log /tmp/enodia-hev.log; do
            [ -s "$L" ] && { warn "--- последние строки $L ---"; tail -n 15 "$L"; }
        done
        warn "cron (heal/watchdog) будет зарегистрирован — несущую поднимут после ребута / при"
        warn "восстановлении. Либо проверьте конфиг в меню (Протокол) и повторите установку."
    fi
fi   # /PANEL_ONLY (конец секции 5: ядро маркировки + подъём несущей)








if [ "$FW3_WIPED" = 1 ] && [ -f "$ENODIA_DIR/vpn-toggle.sh" ]; then
    log "awg_setup сделал firewall reload — переигрываю цепочки (vpn-toggle repair)…"
    sh "$ENODIA_DIR/vpn-toggle.sh" repair >/dev/null 2>&1 || true
    ok "Правила переиграны (вырезы, порты, устройства, десинк, доп-выходы, доступ снаружи)"
fi









if [ -f "$ENODIA_DIR/heal.sh" ]; then
    log "переигрываю персист подсистем (группы, гео, списки, десинк, доп-выходы)…"


    if sh "$ENODIA_DIR/heal.sh" replay >/dev/null 2>&1; then
        ok "Персист подсистем переигран (группы, гео, списки, DNS-hosts, десинк, доп-выходы)"
    else
        warn "Персист подсистем НЕ переигран (шла смена транспорта или переигрыш не смог). Повторите: sh $ENODIA_BOOT/boot.sh heal.sh replay"
    fi
fi




log "Настраиваю автозапуск..."







if [ -f "$RC_LOCAL" ]; then
    sed -i '/# AWG-SETUP-BE7000 START/,/# AWG-SETUP-BE7000 END/d' "$RC_LOCAL"
fi



mkdir -p /etc/crontabs
touch /etc/crontabs/root




if [ -f "$ENODIA_DIR/boot.sh" ]; then
    if sh "$ENODIA_DIR/boot.sh" sync "$ENODIA_DIR" >/dev/null 2>&1; then
        ok "Бутстрап собран ($ENODIA_BOOT — его зовёт cron, он же ищет накопитель)"
    else
        warn "не собрался бутстрап в $ENODIA_BOOT — cron-строки будут ссылаться в пустоту"
    fi
else
    warn "нет $ENODIA_DIR/boot.sh — неполный payload; cron-строки ссылаться некуда"
fi






cron_put() {
    _cp_s="$1"; _cp_t="$2"; shift 2
    if [ $# -gt 0 ]; then
        _cp_line="$_cp_s $CRON_RUN $_cp_t $* >/dev/null 2>&1"
    else
        _cp_line="$_cp_s $CRON_RUN $_cp_t >/dev/null 2>&1"
    fi
    if grep -qF "$_cp_line" /etc/crontabs/root 2>/dev/null; then _cp_new=; else _cp_new=1; fi
    sed -i "\|$_cp_t|d" /etc/crontabs/root 2>/dev/null
    echo "$_cp_line" >> /etc/crontabs/root
    [ -n "$_cp_new" ]
}

if [ -f "$ENODIA_DIR/heal.sh" ]; then
    chmod +x "$ENODIA_DIR/heal.sh"
    if cron_put "*/1 * * * *" heal.sh; then
        ok "Cron-задача heal.sh зарегистрирована (каждую минуту, через бутстрап)"
    else
        ok "Cron-задача heal.sh уже на месте"
    fi
else
    warn "$ENODIA_DIR/heal.sh не найден — автоматическое восстановление после ребута"
    warn "работать НЕ будет. Залейте heal.sh через WinSCP и перезапустите скрипт."
fi




if [ -f "$ENODIA_DIR/iplist-update.sh" ]; then
    chmod +x "$ENODIA_DIR/iplist-update.sh"
    if cron_put "0 5 * * *" iplist-update.sh --notify; then
        ok "Cron-задача iplist-update зарегистрирована (5:00 ежедневно, со сводкой на почту)"
    fi





    if [ -f "$ENODIA_DIR/update-sched.sh" ]; then
        chmod +x "$ENODIA_DIR/update-sched.sh"
        [ -f "$ENODIA_DIR/subs-update.sh" ] && chmod +x "$ENODIA_DIR/subs-update.sh"
        sh "$ENODIA_DIR/update-sched.sh" apply 2>/dev/null && ok "Расписание обновления списков: $(sh "$ENODIA_DIR/update-sched.sh" get 2>/dev/null) · подписок: $(sh "$ENODIA_DIR/update-sched.sh" get subs 2>/dev/null)"
    fi
fi




if [ -f "$ENODIA_DIR/watchdog.sh" ]; then
    chmod +x "$ENODIA_DIR/watchdog.sh"
    if cron_put "*/2 * * * *" watchdog.sh; then
        ok "Cron-задача watchdog.sh зарегистрирована (каждые 2 минуты)"
    fi
fi



if [ -f "$ENODIA_DIR/traffic-acct.sh" ]; then
    chmod +x "$ENODIA_DIR/traffic-acct.sh"
    if cron_put "*/5 * * * *" traffic-acct.sh; then
        ok "Cron-задача учёта трафика зарегистрирована (каждые 5 минут)"
    fi
fi








if [ -f "$ENODIA_DIR/web-ui.sh" ]; then
    chmod +x "$ENODIA_DIR/web-ui.sh"
    [ -d "$ENODIA_DIR/web/cgi-bin" ] && chmod +x "$ENODIA_DIR"/web/cgi-bin/* 2>/dev/null

    [ -f "$ENODIA_DIR/web/htmlwrap" ] && chmod +x "$ENODIA_DIR/web/htmlwrap" 2>/dev/null



    [ -f "$ENODIA_DIR/totp.sh" ] && chmod +x "$ENODIA_DIR/totp.sh" 2>/dev/null
    if cron_put "*/5 * * * *" web-ui.sh start; then
        ok "Cron-задача веб-панели зарегистрирована (каждые 5 минут, поднимает uhttpd:8088)"
    fi







    sh "$ENODIA_DIR/web-ui.sh" start >/dev/null 2>&1 || true
fi









for s in gh-update.sh proto-install.sh usb-offload.sh; do
    [ -f "$ENODIA_DIR/$s" ] && chmod +x "$ENODIA_DIR/$s"
done
[ -f "$ENODIA_DIR/VERSION" ] && ok "Версия установки: $(sed -n 's/^VERSION=//p' "$ENODIA_DIR/VERSION" | head -1)"











mkdir -p /etc/crontabs
touch /etc/crontabs/root

if [ -f "$ENODIA_DIR/update-lists.sh" ]; then
    rm -f "$ENODIA_DIR/update-lists.sh"
    ok "Убран легаси update-lists.sh (домены ведёт менеджер источников)"
fi
if grep -qF "$ENODIA_DIR/update-lists.sh" /etc/crontabs/root; then
    sed -i "\|$ENODIA_DIR/update-lists.sh|d" /etc/crontabs/root
    /etc/init.d/cron restart 2>/dev/null || /etc/init.d/crond restart 2>/dev/null || true
    ok "Убрана legacy cron-строка re-filter"
fi









for _lft in /tmp/enodia-uninstall.sh /tmp/awg-uninstall.sh; do   # legacy-name: второе имя — след ДОРЕБРЕНДИНГОВОГО снимальщика, подбираем и забываем
    if [ -f "$_lft" ]; then
        rm -f "$_lft"
        ok "Убран остаток прошлого удаления ($_lft)"
    fi
done






for _lft in /data/usr/enodia-uninstall.log /data/enodia-uninstall.log /data/awg-uninstall.log; do   # legacy-name: текущий путь и оба прежних, см. выше
    if [ -f "$_lft" ]; then
        rm -f "$_lft"
        ok "Убран отчёт прошлого удаления ($_lft)"
    fi
done








log "Устанавливаю helper-скрипты..."
for helper in switch-vpn.sh domain.sh status.sh; do
    if [ -f "$ENODIA_DIR/$helper" ]; then
        chmod +x "$ENODIA_DIR/$helper"
    fi
done










mkdir -p "$ENODIA_STATE/configs"
if [ -f "$AWG_CONF" ] && [ ! -f "$ENODIA_STATE/configs/default.conf" ]; then
    cp "$AWG_CONF" "$ENODIA_STATE/configs/default.conf"
    ok "Текущий конфиг сохранён как 'default' (можно переключаться через 'vpn')"
fi










if [ ! -s "$ENODIA_STATE/.active" ] && [ -s "$ENODIA_STATE/configs/default.conf" ]; then
    echo "default" > "$ENODIA_STATE/.active"
fi









if [ ! -f "$ENODIA_STATE/.failover-home" ] && [ -s "$ENODIA_STATE/.active" ]; then
    act=$(cat "$ENODIA_STATE/.active" 2>/dev/null || true)
    [ -n "$act" ] || act="default"
    echo "$act" > "$ENODIA_STATE/.failover-home"
    ok "Авто-failover: основной конфиг (home) = '$act', режим по умолчанию sticky"
fi















for b in amneziawg-go awg; do
    [ -f "$ENODIA_DIR/bin/$b.user" ] || continue
    if [ -f "$ENODIA_BIN/$b" ] && \
       [ "$(stat -c%s "$ENODIA_DIR/bin/$b.user" 2>/dev/null)" = "$(stat -c%s "$ENODIA_BIN/$b" 2>/dev/null)" ]; then
        rm -f "$ENODIA_DIR/bin/$b.user"
        ok "bin/$b.user удалён (рабочий бинарь на месте, размер совпал; источник — git/payload)"
    else
        warn "bin/$b.user оставлен: рабочего $b нет или размер не совпал с источником"
    fi
done
rmdir "$ENODIA_DIR/bin" 2>/dev/null || true   # уберём каталог, если опустел







echo ""
echo "========================================================================"
ok "Настройка завершена!"
echo "========================================================================"
echo ""
if [ "$PANEL_ONLY" = 1 ]; then



    if [ "$KEEP_TRANSPORT" = 1 ]; then
        echo "Обновлены ВЕБ-ПАНЕЛЬ, скрипты и cron. Транспорт ($_kt_name) остался как был:"
        echo "его флаг, правила и несущую установщик не трогал."
    else
        echo "Установлена ВЕБ-ПАНЕЛЬ и вся обвязка. Транспорт (VPN/десинк) НЕ выбран:"
        echo "роутер сейчас работает ровно как из коробки — наших правил в ядре нет."
    fi
    echo ""
    echo "  1. Панель: http://$(ip -4 addr show "$(lan_if)" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}'):8088 (форма входа: логин admin, пароль — заданный)"
    echo "  2. Что дальше — прямо в браузере:"
    echo "       «Компоненты» — поставить нужные протоколы (качаются с GitHub)"
    echo "       «Серверы»    — добавить сервер (vless://, hy2://, awg-конфиг) и включить"
    echo "  3. Что уже лежит на роутере (без сервера и VPS работают сразу):"
    _pbin=""
    [ -x "$(bin_path byedpi)" ] && _pbin="$_pbin ByeDPI"
    [ -x "$(bin_path nfqws)" ]  && _pbin="$_pbin Zapret"
    echo "       ${_pbin:- (ничего — все протоколы качаются из панели)}"
    echo "  4. Автозапуск, сторож и обновление — уже в cron; после ребута всё встаёт само."
    echo ""
    echo "========================================================================"
    echo "Диагностика: sh $ENODIA_BOOT/boot.sh status.sh · логи: /tmp/enodia-startup.log"
    echo "========================================================================"
else
echo "Что у вас сейчас работает:"
echo ""
if [ "$ACTIVE_PROTO" = xray ] || [ "$ACTIVE_PROTO" = hy2 ] || [ "$ACTIVE_PROTO" = byedpi ]; then
    echo "  1. Активный транспорт: $ACTIVE_PROTO (TUN xtun). AmneziaWG не используется."
    [ "$ACTIVE_PROTO" = byedpi ] && echo "     (ByeDPI — DPI-десинк напрямую, без VPS; десинк-аргументы в .byedpi-args)"
    ip -br a show xtun 2>/dev/null || echo "     (xtun поднят через transport.sh up)"
else
    echo "  1. AmneziaWG-туннель awg0 поднят:"
    ip -br a show awg0 2>/dev/null || warn "awg0 не виден — проверьте конфиг"
fi
echo ""
echo "  2. ipset $ENODIA_LIST_NAME готов принимать IP-адреса:"






enodia_list_n=$(ipset list "$ENODIA_LIST_NAME" 2>/dev/null | grep -c '^[0-9]' || true)
case "$enodia_list_n" in ''|*[!0-9]*) enodia_list_n=0 ;; esac
echo "     Размер сейчас: $enodia_list_n записей"
echo "     (он будет наполняться по мере того, как устройства будут открывать"
echo "      сайты из списка. Откройте YouTube — IP появятся.)"
echo ""
echo "  3. Маршрутизация через VPN работает по iplist_set (CIDR) +"
echo "     ipset enodia_list (домены). Этого хватает для YouTube, OpenAI,"
echo "     Discord, Meta, Cloudflare и т.п."
echo "     Готовые списки доменов подключаются в панели:"
echo "     «Сайты, домены, IP» → источники. Отдельного скрипта больше нет."
echo ""
echo "  4. После ребута роутера всё поднимется само (cron+heal.sh)."
echo "     Если /etc/rc.local выживет — отлично, нет — heal через минуту всё восстановит."
echo ""
echo "  5. Авто-failover: если активный VPS умрёт, watchdog сам переберёт"
echo "     configs/*.conf по алфавиту и встанет на первый рабочий (режим sticky"
echo "     по умолчанию). Сменить режим off/sticky/home — enodia-setup.bat → 21."
echo ""
echo "========================================================================"
echo "ТЕСТ:"
echo "========================================================================"
echo "  - Через подключённое устройство откройте https://2ip.ru — должен показать"
echo "    IP вашего ПРОВАЙДЕРА (это значит, что обычный трафик идёт мимо VPN)."
echo "  - Откройте https://www.youtube.com и зайдите в любое видео — должно играть"
echo "    без тормозов. Чтобы проверить, что YouTube идёт через VPS:"
echo "    в браузере откройте https://www.youtube.com/about — снизу будет ваша"
echo "    \"страна\" — она должна совпадать со страной вашего VPS."
echo ""
echo "  - Из консоли роутера: 'ipset list $ENODIA_LIST_NAME | head' — должны"
echo "    появиться IP-адреса googlevideo.com и подобных."
echo ""
echo "УПРАВЛЕНИЕ: удобнее всего с ПК через enodia-setup.bat (меню)."
echo ""
echo "В консоли роутера коротких команд awg/vpn/domain НЕТ (на стоке / это"
echo "squashfs ro -> симлинки в /usr/bin не создаются). Вызывайте ЧЕРЕЗ ЗАПУСКАТЕЛЬ:"
echo "  sh $CRON_RUN status.sh           — полный статус AWG + ipset + правила"
echo "  sh $CRON_RUN status.sh test      — проверка популярных сайтов (через VPN или нет)"
echo "  sh $CRON_RUN switch-vpn.sh           — список доступных конфигов стран"
echo "  sh $CRON_RUN switch-vpn.sh germany   — переключиться на конфиг germany.conf"
echo "  sh $CRON_RUN switch-vpn.sh status    — текущий активный конфиг + страна"
echo "  sh $CRON_RUN domain.sh add chatgpt.com      — добавить домен в туннель"
echo "  sh $CRON_RUN domain.sh remove instagram.com — убрать домен из своего списка"
echo "  sh $CRON_RUN domain.sh list          — ваши добавления + статистика"
echo "  sh $CRON_RUN domain.sh search openai — поиск по всем спискам"
echo "  (запускатель — единственный, кто экспортирует пути: код и состояние могут жить"
echo "   на накопителе, и прямой путь тогда указывает в пустоту)"
echo ""
echo "ДОПОЛНИТЕЛЬНЫЕ КОНФИГИ (для смены страны):"
echo "  Положите .conf файлы в $ENODIA_STATE/configs/"
echo "  Например: germany.conf, france.conf, netherlands.conf"
echo "  Затем: sh $CRON_RUN switch-vpn.sh germany   (или enodia-setup.bat -> 9)"
echo ""
echo "НИЗКОУРОВНЕВЫЕ КОМАНДЫ (если что-то не работает):"
echo "  $ENODIA_BIN/awg show awg0        — статус туннеля + handshake (wg тут НЕТ, есть awg)"
echo "  ipset list $ENODIA_LIST_NAME | head — что попало в список"
echo "  iptables -t mangle -L -v -n   — правила маркировки"
echo "  ip rule                       — правила роутинга"
echo "  ip route show table $ROUTE_TABLE  — таблица маршрутизации VPN"
echo "  sh $CRON_RUN iplist-update.sh    — обновить CIDR-список вручную"
echo ""
echo "Если что-то не работает — смотрите /tmp/enodia-startup.log после ребута."
echo "========================================================================"
fi   # /PANEL_ONLY (конец секции 8: финальный отчёт)
