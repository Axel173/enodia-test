#!/bin/sh







































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}
export ENODIA_DIR ENODIA_STATE ENODIA_BIN ENODIA_BOOT

MAN=update-manifest.txt


SUMS=.pkg-sums


SNAP_DIR="$ENODIA_STATE/.gh-backup"

LEGACY_SNAP="$ENODIA_DIR/.gh-backup"      # снимки пофайлового апдейтера: по 3 МБ несжатыми, откат к ним не умеем
INST_LOG="$ENODIA_STATE/.gh-update-install.log"   # вывод install.sh последнего обновления/отката (разбор у pi_run_installer)
SWITCH_LOCK=/tmp/enodia-switching.lock
LOCK_WAIT=${PKG_LOCK_WAIT:-60}
MINFREE_KB=${PKG_MINFREE_KB:-1024}
T="/tmp/enodia-pkg-inst.$$"

MODE="$1"
SRC="$2"
FRESH=0
case "$MODE" in rollback) TAG=rollback ;; *) TAG=apply ;; esac
log()  { printf '%s\n' "[$TAG] $*"; }
stop() { printf '%s\n' "[$TAG] СТОП: $*"; }




pi_safe() {
    case "$1" in
        ''|/*|*..*|*[!A-Za-z0-9._/-]*) return 1 ;;
        awg.conf|notify.conf|xray.json|hysteria.yaml) return 1 ;;
        configs/*|xray-configs/*|hy2-configs/*) return 1 ;;
        *.sh|*.conf.example|VERSION|update-manifest.txt|hev.yaml|web/*) return 0 ;;
        geo-*-catalog.txt) return 0 ;;
        *) return 1 ;;
    esac
}

pi_exec() { case "$1" in *.sh|web/cgi-bin/*|web/htmlwrap) return 0 ;; *) return 1 ;; esac; }


pi_list() {
    [ -f "$1" ] || return 0
    tr -d '\r' < "$1" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | grep -v '^#' | grep -v '^$' || true
}
pi_code() { sed -n 's/^CODE=//p' "$1" 2>/dev/null | head -n 1 | tr -cd '0-9'; }
pi_name() { sed -n 's/^VERSION=//p' "$1" 2>/dev/null | head -n 1 | tr -d ' \r"\\'; }
pi_free_kb() { df -k "$1" 2>/dev/null | awk 'NR==2{print $4+0}'; }

LOCK_MINE=0
pi_unlock() { [ "$LOCK_MINE" = 1 ] && rm -f "$SWITCH_LOCK" 2>/dev/null; LOCK_MINE=0; return 0; }
pi_cleanup() { pi_unlock; rm -rf "$T" 2>/dev/null; }
trap 'pi_cleanup' EXIT
trap 'pi_cleanup; exit 1' INT TERM HUP PIPE




pi_lock() {
    _pw=0
    while [ -e "$SWITCH_LOCK" ] && [ "$_pw" -lt "$LOCK_WAIT" ]; do sleep 2; _pw=$((_pw + 2)); done
    if [ -e "$SWITCH_LOCK" ]; then
        log "ВНИМАНИЕ: лок смены транспорта занят дольше ${LOCK_WAIT} с — продолжаю без него"
        return 0
    fi
    : > "$SWITCH_LOCK" 2>/dev/null && LOCK_MINE=1
    return 0
}


pi_check_src() {
    [ -n "$SRC" ] && [ -d "$SRC" ] || { stop "нет каталога источника «$SRC»"; return 1; }
    [ -f "$SRC/$MAN" ] || { stop "в источнике нет $MAN"; return 1; }
    [ -f "$SRC/VERSION" ] || { stop "в источнике нет VERSION"; return 1; }
    [ -n "$(pi_code "$SRC/VERSION")" ] || { stop "в VERSION источника нет кода"; return 1; }
    pi_list "$SRC/$MAN" > "$T/man"
    [ -s "$T/man" ] || { stop "манифест источника пуст"; return 1; }
    : > "$T/new"
    while IFS= read -r _r || [ -n "$_r" ]; do
        pi_safe "$_r" || { stop "путь вне белого списка в манифесте: $_r"; return 1; }
        if [ ! -f "$SRC/$_r" ]; then


            [ "$MODE" = rollback ] || { stop "в пакете нет файла из его же манифеста: $_r"; return 1; }
            log "в снимке нет $_r — оставляю текущий"
            continue
        fi
        if pi_exec "$_r"; then
            sh -n "$SRC/$_r" 2>/dev/null || { stop "синтаксическая ошибка в $_r — ничего не заменено"; return 1; }
        fi
        printf '%s\n' "$_r" >> "$T/new"
    done < "$T/man"
    [ -s "$T/new" ] || { stop "в источнике нет ни одного файла набора"; return 1; }
    return 0
}



pi_have() {
    pi_list "$ENODIA_DIR/$MAN" > "$T/old"
    [ -s "$T/old" ] || cp "$T/new" "$T/old"
    : > "$T/have"
    while IFS= read -r _r || [ -n "$_r" ]; do
        pi_safe "$_r" || continue
        [ -f "$ENODIA_DIR/$_r" ] && printf '%s\n' "$_r" >> "$T/have"
    done < "$T/old"
    return 0
}

pi_snapshot() {    # $1 = куда (файл) · $2 = quiet (провал без строки СТОП — вызывающий попробует ещё раз)
    pi_have
    [ -s "$T/have" ] || { stop "на роутере не нашлось ни одного файла установленного набора — снимать нечего"; return 1; }


    [ -f "$ENODIA_DIR/$SUMS" ] && printf '%s\n' "$SUMS" >> "$T/have"
    mkdir -p "$(dirname "$1")" 2>/dev/null
    if ! tar -czf "$1.part" -C "$ENODIA_DIR" -T "$T/have" 2>/dev/null || [ ! -s "$1.part" ]; then
        rm -f "$1.part"
        [ "$2" = quiet ] || stop "не удалось снять снимок установленного набора (нет места на $(dirname "$1")?) — ничего не заменено"
        return 1
    fi
    mv -f "$1.part" "$1" || { rm -f "$1.part"; stop "снимок не лёг на место — ничего не заменено"; return 1; }
    SNAP="$1"
    return 0
}




pi_rotate() {
    [ -d "$SNAP_DIR" ] || return 0
    ls -1 "$SNAP_DIR" 2>/dev/null | grep '^[0-9]\{8\}-[0-9]\{6\}\.tar\.gz$' > "$T/snaps" || true
    while IFS= read -r _s || [ -n "$_s" ]; do
        [ -n "$_s" ] || continue
        [ "$SNAP_DIR/$_s" = "$1" ] && continue
        rm -f "$SNAP_DIR/$_s" && log "снят прежний снимок: ${_s%.tar.gz}"
    done < "$T/snaps"
    return 0
}



pi_drop_absent() {
    [ -s "$T/absent" ] || return 0
    while IFS= read -r _r || [ -n "$_r" ]; do
        pi_safe "$_r" && rm -f "$ENODIA_DIR/$_r"
    done < "$T/absent"
    return 0
}
pi_restore() {

    [ "$FRESH" = 1 ] && { pi_drop_absent; log "свежая установка не легла — положенное снято, роутер как до установки"; log "итог: заменено 0, удалено 0"; return 0; }
    log "возвращаю снимок ${SNAP##*/} — набор не должен остаться смешанным"
    if tar -xzf "$SNAP" -C "$ENODIA_DIR" 2>/dev/null; then
        pi_drop_absent
        while IFS= read -r _r || [ -n "$_r" ]; do
            pi_exec "$_r" && chmod 755 "$ENODIA_DIR/$_r" 2>/dev/null
        done < "$T/have"
        log "снимок возвращён — работает прежняя версия"
        log "итог: заменено 0, удалено 0"
        return 0
    fi
    stop "снимок вернуть НЕ удалось — набор файлов смешанный; повторите обновление или переустановите с компьютера"
    return 1
}


pi_swap() {
    NREP=0; NDEL=0
    : > "$T/absent"

    grep -vxF 'web/index.html' "$T/new" > "$T/order" || true
    if grep -qxF 'web/index.html' "$T/new"; then printf '%s\n' 'web/index.html' >> "$T/order"; fi
    while IFS= read -r _r || [ -n "$_r" ]; do
        _s="$SRC/$_r"; _d="$ENODIA_DIR/$_r"
        _m=644; pi_exec "$_r" && _m=755
        if [ -f "$_d" ] && cmp -s "$_s" "$_d" 2>/dev/null; then
            chmod "$_m" "$_d" 2>/dev/null
            continue
        fi
        [ -f "$_d" ] || printf '%s\n' "$_r" >> "$T/absent"
        mkdir -p "$(dirname "$_d")" 2>/dev/null
        if cp "$_s" "$_d.new" 2>/dev/null && chmod "$_m" "$_d.new" 2>/dev/null && mv -f "$_d.new" "$_d" 2>/dev/null; then
            NREP=$((NREP + 1))
        else
            rm -f "$_d.new" 2>/dev/null
            stop "не записался $_r (нет места? накопитель пропал?)"
            return 1
        fi
    done < "$T/order"



    if [ -s "$T/old" ]; then
        grep -vxF -f "$T/man" "$T/old" > "$T/gone" || true
        while IFS= read -r _r || [ -n "$_r" ]; do
            [ -n "$_r" ] || continue
            pi_safe "$_r" || continue
            [ -f "$ENODIA_DIR/$_r" ] || continue
            if rm -f "$ENODIA_DIR/$_r" 2>/dev/null; then NDEL=$((NDEL + 1)); log "снят файл прежней версии: $_r"
            else stop "не удалось снять $_r"; return 1; fi
        done < "$T/gone"
    fi
    return 0
}

pi_space_ok() {
    _pf=$(pi_free_kb "$ENODIA_DIR"); case "$_pf" in ''|*[!0-9]*) return 0 ;; esac

    _pb=0
    while IFS= read -r _r || [ -n "$_r" ]; do
        _sz=$(wc -c < "$SRC/$_r" 2>/dev/null | tr -d ' '); case "$_sz" in ''|*[!0-9]*) _sz=0 ;; esac
        [ "$_sz" -gt "$_pb" ] && _pb=$_sz
    done < "$T/new"
    _pneed=$((_pb / 1024 + MINFREE_KB))
    if [ "$_pf" -lt "$_pneed" ]; then
        stop "на томе кода свободно ${_pf} КБ, нужно ≥ ${_pneed} — освободите место («Роутер» → «Место и накопитель») и повторите"
        return 1
    fi
    return 0
}


pi_run_installer() {
    [ -f "$ENODIA_DIR/install.sh" ] || { log "ВНИМАНИЕ: в наборе нет install.sh — cron и бутстрап не пересобраны"; return 1; }
    log "запускаю установщик версии $(pi_name "$ENODIA_DIR/VERSION") (режим «только панель»: транспорт и его правила не трогает)…"
    ( cd "$ENODIA_DIR" && INSTALL_PROTO=none INSTALL_FROM_PKG=1 sh ./install.sh ) > "$T/inst" 2>&1
    _pir=$?



    tr -d '\033' < "$T/inst" | sed 's/\[[0-9;]*m//g' > "$INST_LOG" 2>/dev/null


    if [ -n "$PKG_INSTALL_VERBOSE" ]; then sed 's/^/  | /' "$INST_LOG" 2>/dev/null; fi
    if [ "$_pir" = 0 ]; then
        log "установщик отработал (его журнал: $INST_LOG)"
    elif [ -n "$PKG_INSTALL_VERBOSE" ]; then
        log "установщик кончился ошибкой (его журнал: $INST_LOG)"
    else
        log "последние строки установщика ($INST_LOG):"
        tail -n 8 "$INST_LOG" 2>/dev/null | sed 's/^/  | /'
    fi
    return "$_pir"
}

cmd_install() {
    mkdir -p "$T" || { stop "не создать рабочий каталог в /tmp"; return 1; }
    pi_check_src || return 1
    _nn=$(pi_name "$SRC/VERSION"); _nc=$(pi_code "$SRC/VERSION")
    _on=$(pi_name "$ENODIA_DIR/VERSION"); _oc=$(pi_code "$ENODIA_DIR/VERSION")
    if [ -n "$_oc" ]; then
        log "ставлю ${_nn:-?} (код ${_nc:-?}) поверх ${_on:-?} (код ${_oc:-?})"
    else
        log "ставлю ${_nn:-?} (код ${_nc:-?}) — прежней версии на роутере нет"
    fi
    pi_space_ok || return 1
    if [ "$MODE" = rollback ]; then


        pi_snapshot "$T/cur.tar.gz" || return 1
    else


        if [ -d "$LEGACY_SNAP" ]; then rm -rf "$LEGACY_SNAP" && log "сняты снимки прежнего апдейтера ($LEGACY_SNAP)"; fi
        pi_have
        if [ ! -s "$T/have" ]; then

            FRESH=1
            log "свежая установка: прежнего набора нет — снимать нечего, отката у неё не будет"
        else
            mkdir -p "$SNAP_DIR" 2>/dev/null; chmod 700 "$SNAP_DIR" 2>/dev/null
            _pff=$(pi_free_kb "$SNAP_DIR"); case "$_pff" in ''|*[!0-9]*) _pff="" ;; esac
            if [ -n "$_pff" ] && [ "$_pff" -lt "$MINFREE_KB" ]; then
                stop "на томе настроек свободно ${_pff} КБ — снимок для отката не ляжет; освободите место и повторите"
                return 1
            fi


            _psn="$SNAP_DIR/$(date +%Y%m%d-%H%M%S).tar.gz"
            if ! pi_snapshot "$_psn" quiet; then
                pi_rotate ""
                pi_snapshot "$_psn" || return 1
            fi
            pi_rotate "$_psn"
            log "снимок для отката: ${SNAP##*/}"
        fi
    fi
    pi_lock
    if ! pi_swap; then
        pi_restore
        pi_unlock
        return 1
    fi
    pi_unlock


    if [ -f "$SRC/pkg-sums.txt" ]; then _ps="$SRC/pkg-sums.txt"; elif [ -f "$SRC/$SUMS" ]; then _ps="$SRC/$SUMS"; else _ps=""; fi
    if [ -n "$_ps" ]; then
        cp "$_ps" "$ENODIA_DIR/$SUMS.new" 2>/dev/null && mv -f "$ENODIA_DIR/$SUMS.new" "$ENODIA_DIR/$SUMS" 2>/dev/null \
            || { rm -f "$ENODIA_DIR/$SUMS.new"; log "ВНИМАНИЕ: суммы пакета не легли — «Целостность» будет сверять с GitHub"; }
    else
        rm -f "$ENODIA_DIR/$SUMS"
    fi
    if [ "$MODE" = rollback ]; then
        log "возвращено файлов: $NREP; снято: $NDEL (версия ${_nn:-?}, код ${_nc:-?})"
    fi
    log "итог: заменено $NREP, удалено $NDEL"
    if ! pi_run_installer; then
        if [ "$FRESH" = 1 ]; then
            stop "установщик версии ${_nn:-?} кончился ошибкой — файлы уже на месте; повторите установку"
        else
            stop "установщик версии ${_nn:-?} кончился ошибкой — файлы уже этой версии; повторите или откатитесь к снимку"
        fi
        return 1
    fi
    if [ "$MODE" = rollback ]; then
        log "готово: работает ${_nn:-?} (код ${_nc:-?}). Правила примените: «Починить правила» или перезагрузка"
    elif [ "$FRESH" = 1 ]; then
        log "готово: ${_nn:-?} (код ${_nc:-?}) поставлен с нуля, файлов $NREP"
    else
        log "готово: ${_nn:-?} (код ${_nc:-?}), заменено $NREP, удалено $NDEL, снимок ${SNAP##*/}. Правила примените: «Починить правила» или перезагрузка"
    fi
    return 0
}

case "$MODE" in
    install|rollback) cmd_install ;;
    *) echo "usage: $0 install <распакованный пакет> | rollback <распакованный снимок>" >&2; exit 2 ;;
esac
