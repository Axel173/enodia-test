#!/bin/sh





























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
STORE="$ENODIA_STATE/.dev-names"
TAB=$(printf '\t')
NL='
'

if [ -f "$ENODIA_DIR/lease-lib.sh" ]; then . "$ENODIA_DIR/lease-lib.sh"; fi
command -v mac_norm >/dev/null 2>&1 || mac_norm() { printf '%s' "$1" | tr 'A-Z' 'a-z' | tr -d ' \t\r\n'; }
command -v mac_ok   >/dev/null 2>&1 || mac_ok()   { printf '%s' "$1" | grep -qE '^[0-9a-f]{2}(:[0-9a-f]{2}){5}$'; }


if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' < "/proc/$1/cmdline" 2>/dev/null | grep -qE "$2"; }



NAME_MAX=96
LOCK=/tmp/.enodia-dev-names.lock





lock_take() {
    _li=0
    while ! mkdir "$LOCK" 2>/dev/null; do
        _li=$((_li+1)); [ "$_li" -gt 5 ] && return 1
        _lp=$(cat "$LOCK/pid" 2>/dev/null | tr -d ' \r\n')
        if [ -n "$_lp" ]; then
            pid_runs "$_lp" 'dev-names' || { rm -rf "$LOCK" 2>/dev/null; continue; }
        elif [ "$_li" -ge 3 ]; then
            rm -rf "$LOCK" 2>/dev/null; continue
        fi
        sleep 1
    done
    echo $$ > "$LOCK/pid" 2>/dev/null
    return 0
}
lock_drop() { rm -rf "$LOCK" 2>/dev/null; }



san_name() { printf '%s' "$1" | tr '\t\r\n' '   ' | tr -d '\000-\037"\\' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[[:space:]][[:space:]]*/ /g'; }



cmd_list() {
    [ -f "$STORE" ] || return 0
    tr -d '\000-\010\013-\037"\\' < "$STORE" 2>/dev/null | awk -F"$TAB" '
    {
        m = tolower($1); gsub(/ /, "", m)
        if (m !~ /^[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]$/) next
        if (m in seen) next
        n = $2; for (i = 3; i <= NF; i++) n = n " " $i
        gsub(/  +/, " ", n); sub(/^ /, "", n); sub(/ $/, "", n)
        if (n == "") next
        seen[m] = 1; print m "\t" n
    }'
}

cmd_get() {
    _gm=$(mac_norm "$1"); mac_ok "$_gm" || return 1
    cmd_list | awk -F"$TAB" -v m="$_gm" '$1==m { print $2; exit }'
}





store_write() {   # $1 = mac, $2 = имя (пусто = снять)
    _wb=$(cmd_list | awk -F"$TAB" -v m="$1" '$1!=m')
    [ -n "$2" ] && _wb="${_wb:+$_wb$NL}$1$TAB$2"
    if [ -z "$_wb" ]; then rm -f "$STORE"; return $?; fi
    _wt="$STORE.$$"
    if printf '%s\n' "$_wb" > "$_wt" 2>/dev/null && [ "$(cat "$_wt" 2>/dev/null)" = "$_wb" ]; then
        mv "$_wt" "$STORE" && return 0
    fi
    rm -f "$_wt"; return 1
}

cmd_set() {
    _sm=$(mac_norm "$1")
    mac_ok "$_sm" || { echo "[dev-names] у устройства нет MAC — метку привязать не к чему"; return 1; }
    _sn=$(san_name "$2")


    if [ -z "$_sn" ] && [ -n "$(printf '%s' "$2" | tr -d ' \t\r\n')" ]; then
        echo "[dev-names] в имени нет ни одного допустимого знака — кавычки и обратная косая не сохраняются"; return 1
    fi
    if [ "$(printf '%s' "$_sn" | wc -c)" -gt "$NAME_MAX" ]; then
        echo "[dev-names] имя слишком длинное: до 48 букв кириллицей или 96 латиницей — сократите"; return 1
    fi
    lock_take || { echo "[dev-names] имена сейчас правит другая операция — повторите"; return 1; }
    store_write "$_sm" "$_sn"; _sr=$?
    lock_drop
    [ "$_sr" = 0 ] || { echo "[dev-names] не удалось записать имя (место на разделе?)"; return 1; }

    _su=$(printf '%s' "$_sm" | tr 'a-z' 'A-Z')
    if [ -n "$_sn" ]; then echo "[dev-names] устройство $_su: имя «$_sn»"; else echo "[dev-names] устройство $_su: своё имя снято"; fi
}

case "$1" in
    set)  cmd_set "$2" "$3" ;;
    del)  cmd_set "$2" "" ;;
    get)  cmd_get "$2" ;;
    list) cmd_list; exit 0 ;;
    *) echo "usage: $0 set <mac> <имя> | del <mac> | get <mac> | list"; exit 2 ;;
esac
