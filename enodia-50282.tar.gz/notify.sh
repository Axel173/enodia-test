#!/bin/sh








































ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
CONF="$ENODIA_STATE/notify.conf"
LOG=/tmp/enodia-notify.log

SUBJECT="$1"
BODY="$2"







_rl="$(dirname "$0")/router-lib.sh"
if [ -f "$_rl" ]; then . "$_rl"; fi
command -v router_relabel >/dev/null 2>&1 && SUBJECT=$(router_relabel "$SUBJECT")







case "$SUBJECT" in
	"Enodia · "*) ;;
	*) SUBJECT="Enodia · $SUBJECT" ;;
esac



_dl="$(dirname "$0")/dns-lib.sh"
if [ -f "$_dl" ]; then . "$_dl"; fi
command -v resolve_ipv4 >/dev/null 2>&1 || resolve_ipv4() { nslookup "$1" 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{x=$NF; if(x ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/){print x; exit}}'; }

[ -f "$CONF" ] || { echo "$(date) notify: нет $CONF — почта не настроена, письмо не ушло" >>"$LOG"; exit 3; }
. "$CONF"

if [ -z "$SMTP_HOST" ] || [ -z "$SMTP_USER" ] || [ -z "$SMTP_PASS" ] || [ -z "$MAIL_TO" ]; then
    echo "$(date) notify: notify.conf не заполнен (нет SMTP_PASS?) — письмо не ушло" >>"$LOG"
    exit 3
fi
SMTP_PORT="${SMTP_PORT:-465}"



STARTTLS_ARG=""
case "$(printf '%s' "${SMTP_TLS:-}" | tr 'A-Z' 'a-z')" in
    starttls) STARTTLS_ARG="-starttls smtp" ;;
    implicit) STARTTLS_ARG="" ;;
    *) case "$SMTP_PORT" in 587|25) STARTTLS_ARG="-starttls smtp" ;; *) STARTTLS_ARG="" ;; esac ;;
esac


U_B64=$(printf '%s' "$SMTP_USER" | base64 | tr -d '\n')
P_B64=$(printf '%s' "$SMTP_PASS" | base64 | tr -d '\n')
SUBJ_B64=$(printf '%s' "$SUBJECT" | base64 | tr -d '\n')

DATE_HDR=$(date -R 2>/dev/null || date)




TMO=""
if command -v timeout >/dev/null 2>&1; then
    if timeout 2 true 2>/dev/null; then
        TMO="timeout 25"
    elif timeout -t 2 true 2>/dev/null; then
        TMO="timeout -t 25"
    fi
fi













SMTP_IP=""
case "$SMTP_HOST" in
    *[!0-9.]*)   # это имя, а не IPv4 — резолвим
        SMTP_IP=$(resolve_ipv4 "$SMTP_HOST")
        case "$SMTP_IP" in *.*.*.*) ;; *) SMTP_IP="" ;; esac
        ;;
    *) SMTP_IP="$SMTP_HOST" ;;   # SMTP_HOST уже IP
esac
if [ -n "$SMTP_IP" ]; then
    CONNECT="$SMTP_IP:$SMTP_PORT"
else
    CONNECT="$SMTP_HOST:$SMTP_PORT"   # fallback — как было
fi
echo "$(date) notify: connect=$CONNECT (host=$SMTP_HOST, tls=$([ -n "$STARTTLS_ARG" ] && echo starttls || echo implicit))" >>"$LOG"




RESP=$(
{
    echo "EHLO router";            sleep 1
    echo "AUTH LOGIN";             sleep 1
    echo "$U_B64";                 sleep 1
    echo "$P_B64";                 sleep 1
    echo "MAIL FROM:<$SMTP_USER>"; sleep 1
    echo "RCPT TO:<$MAIL_TO>";     sleep 1
    echo "DATA";                   sleep 1
    echo "From: $SMTP_USER"
    echo "To: $MAIL_TO"
    echo "Subject: =?UTF-8?B?$SUBJ_B64?="
    echo "MIME-Version: 1.0"
    echo "Content-Type: text/plain; charset=UTF-8"
    echo "Content-Transfer-Encoding: 8bit"
    echo "Date: $DATE_HDR"
    echo ""
    printf '%s\n' "$BODY"
    echo ""
    echo "-- "
    echo "Поддержать: https://web.tribute.tg/d/LtA"
    echo "Другие способы: https://github.com/Axel173/xiaomi-be7000-amnezia#donate"
    echo "."
    sleep 1
    echo "QUIT"
    sleep 1
} | $TMO openssl s_client -connect "$CONNECT" -servername "$SMTP_HOST" $STARTTLS_ARG -crlf -quiet 2>&1
)

echo "$(date) notify: subj='$SUBJECT'" >>"$LOG"
echo "$RESP" >>"$LOG"













if printf '%s\n' "$RESP" | grep -qE '^235' && \
   printf '%s\n' "$RESP" | awk '{sub(/\r$/,"")} /^354/{d=1; next} d && /^250([ -]|$)/{ok=1} END{if(ok) exit 0; exit 1}'; then
    exit 0
else
    echo "$(date) notify: ОТПРАВКА НЕ ПОДТВЕРЖДЕНА (детали выше)" >>"$LOG"
    exit 1
fi
