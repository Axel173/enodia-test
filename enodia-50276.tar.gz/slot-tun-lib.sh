#!/bin/sh





































if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }

: "${ENODIA_STATE:=/data/usr/app/enodia-state}"

SLOT_SOCKS_BASE=10830

slot_socks_port() { echo $(( SLOT_SOCKS_BASE + $1 )); }   # id 2 -> 10832 ...
slot_tun()        { echo "xtun$1"; }
slot_table()      { echo "100$1"; }
slot_hev_pid()    { echo "/tmp/enodia-hev-s$1.pid"; }
slot_hev_log()    { echo "/tmp/enodia-hev-s$1.log"; }
slot_hev_yaml()   { echo "$ENODIA_STATE/hev-s$1.yaml"; }



slot_write_hev_yaml() {   # $1 = id
    _id="$1"
    cat > "$(slot_hev_yaml "$_id")" <<YAML
tunnel:
  name: xtun$_id
  mtu: 8500
  ipv4: 198.18.$_id.1
socks5:
  port: $(slot_socks_port "$_id")
  address: 127.0.0.1
  udp: 'udp'
misc:
  log-file: $(slot_hev_log "$_id")
  log-level: warn
YAML
}






slot_wait_socks() {   # $1 = порт ; $2 = пидфайл демона слота ; $3 = имя бинаря ; $4 = срок на флеше (деф. 8)





    case "$2" in
        /*) daemon_wait_port "$2" "$3" "${4:-8}" "$SOCKS_ADDR" "$1"; return $? ;;
    esac
    _p="$1"; _t="${2:-8}"; _i=0


    while [ "$_i" -lt "$_t" ]; do
        netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$_p " && return 0
        sleep 1; _i=$((_i+1))
    done
    netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$_p "
}





slot_free_socks() {   # $1 = id ; $2 = пидфайл СВОЕГО socks-провайдера
    _port=$(slot_socks_port "$1"); _own=$(cat "$2" 2>/dev/null | tr -d ' \r\n')
    _holder=$(netstat -ltnp 2>/dev/null | grep "$SOCKS_ADDR:$_port " | awk '{print $NF}' | cut -d/ -f1 | head -n1)
    case "$_holder" in ''|*[!0-9]*) return 0 ;; esac
    [ "$_holder" = "$_own" ] && return 0
    log "слот №$1: socks $_port держит чужой pid $_holder — освобождаю"
    kill "$_holder" 2>/dev/null
    _i=0; while [ $_i -lt 5 ]; do netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$_port " || break; sleep 1; _i=$((_i+1)); done
}






slot_socks_is_ours() {   # $1 = port ; $2 = свой пидфайл
    _own=$(cat "$2" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_own" ] || return 1
    _holder=$(netstat -ltnp 2>/dev/null | grep "$SOCKS_ADDR:$1 " | awk '{print $NF}' | cut -d/ -f1 | head -n1)
    case "$_holder" in ''|*[!0-9]*) return 0 ;; esac
    [ "$_holder" = "$_own" ]
}



slot_hev_up() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id")
    [ -x "$HEV" ] || { log "слот №$_id: НЕТ бинаря hev ($HEV)"; return 1; }
    slot_write_hev_yaml "$_id"
    if ! proc_alive "$(slot_hev_pid "$_id")"; then
        log "слот №$_id: запускаю hev (tun2socks -> $_tun)…"
        start-stop-daemon -S -b -m -p "$(slot_hev_pid "$_id")" -x "$HEV" -- "$(slot_hev_yaml "$_id")"
    fi
    daemon_wait_dev "$(slot_hev_pid "$_id")" hev 6 "$_tun" || {
        log "слот №$_id: tun $_tun не создан ($DAEMON_WAIT_WHY). Лог hev:"; tail -n 15 "$(slot_hev_log "$_id")" 2>/dev/null; return 1; }
    return 0
}




slot_hev_down() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id")
    start-stop-daemon -K -p "$(slot_hev_pid "$_id")" 2>/dev/null
    _i=0
    while ip link show "$_tun" >/dev/null 2>&1 && [ "$_i" -lt 6 ]; do
        ip link del "$_tun" 2>/dev/null
        ip link show "$_tun" >/dev/null 2>&1 || break
        sleep 1; _i=$((_i+1))
    done
    rm -f "$(slot_hev_pid "$_id")" 2>/dev/null
}



slot_apply_routing() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id"); _tab=$(slot_table "$_id")
    ip link set "$_tun" up 2>/dev/null
    ipt_top FORWARD -o "$_tun" -j ACCEPT
    ipt_top FORWARD -i "$_tun" -j ACCEPT
    ip route replace default dev "$_tun" table "$_tab"
}
slot_remove_routing() {   # $1 = id
    _id="$1"; _tun=$(slot_tun "$_id"); _tab=$(slot_table "$_id")
    ip route flush table "$_tab" 2>/dev/null || true
    iptables -D FORWARD -o "$_tun" -j ACCEPT 2>/dev/null
    iptables -D FORWARD -i "$_tun" -j ACCEPT 2>/dev/null
}














hev_path_check() {   # $1 = функция маршрута плагина
    [ -n "$(probe_ext_ip "--interface $TUN" 8)" ] && return 0
    sleep 2
    [ -n "$(probe_ext_ip "--interface $TUN" 8)" ] && return 0
    log "health: сервер отвечает через socks, а путь клиентов через $TUN — нет (дважды): hev залип → перезапускаю hev на месте"
    _hpp=$(cat "$HEV_PID" 2>/dev/null | tr -d ' \r\n')
    start-stop-daemon -K -p "$HEV_PID" >/dev/null 2>&1      # -K пишет в stdout — health читают и CGI
    command -v daemon_wait_gone >/dev/null 2>&1 && daemon_wait_gone "$_hpp" 5
    ip link del "$TUN" 2>/dev/null; rm -f "$HEV_PID" 2>/dev/null
    if start_daemons && "$1"; then
        ct_flush
        if [ -n "$(probe_ext_ip "--interface $TUN" 8)" ]; then
            log "health: hev перезапущен — путь клиентов через $TUN ожил"
            return 0
        fi
    fi
    log "health: и после перезапуска hev путь клиентов через $TUN мёртв"
    return 1
}
