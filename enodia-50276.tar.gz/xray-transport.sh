#!/bin/sh



























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }



if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }





if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi

command -v carrier_barred >/dev/null 2>&1 || carrier_barred() { return 1; }
command -v carrier_run >/dev/null 2>&1 || carrier_run() { shift; "$@"; }
command -v daemon_wait_port >/dev/null 2>&1 || daemon_wait_port() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0; sleep 1; _dwi=$((_dwi+1)); done
    netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
command -v daemon_wait_dev >/dev/null 2>&1 || daemon_wait_dev() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do ip link show "$4" >/dev/null 2>&1 && return 0; sleep 1; _dwi=$((_dwi+1)); done
    ip link show "$4" >/dev/null 2>&1 && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
TABLE=1000
TUN=xtun
SOCKS_ADDR=127.0.0.1
SOCKS_PORT=10808
XRAY=$(bin_path xray)
HEV=$(bin_path hev)
XRAY_JSON="$ENODIA_STATE/xray.json"
HEV_YAML="$ENODIA_DIR/hev.yaml"
XRAY_PID=/tmp/enodia-xray.pid
HEV_PID=/tmp/enodia-hev.pid
XRAY_LOG=/tmp/xray.log
HEV_LOG=/tmp/enodia-hev.log
TRANSPORT_FLAG="$ENODIA_STATE/.transport"
SWITCH_LOCK=/tmp/enodia-switching.lock       # ручной switch (панель/меню) держит его → авто-failover прерывается (Fix C 2026-07-09)
NOTIFY_EVENT="$ENODIA_DIR/notify-event.sh"
APPLY_BYPASS="$ENODIA_DIR/apply-bypass.sh"
SEED_CONF="/etc/dnsmasq.d/02-altserver.conf" # локальный dnsmasq-ответ server-host->IP (демон резолвит имя сам)
DNS1=1.1.1.1
DNS2=8.8.8.8
FWMARK=0x1

log() { echo "[xray-transport] $*"; }
notify_event() { [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "$1" "$2" "$3" "$4" >/dev/null 2>&1; }




proc_alive() { p=$(cat "$1" 2>/dev/null | tr -d ' \r\n'); [ -n "$p" ] && kill -0 "$p" 2>/dev/null; }






socks_ours() { slot_socks_is_ours "$SOCKS_PORT" "$XRAY_PID"; }











if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; else
    echo "[xray] нет $ENODIA_DIR/dns-lib.sh — обновите установку (панель → «Обновление» или переустановка с компьютера)" >&2; exit 1
fi



command -v seed_host_clear >/dev/null 2>&1 || seed_host_clear() { rm -f "$1" "/tmp/dnsmasq.d/${1##*/}" 2>/dev/null; }


if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi



if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
command -v doh_apply_dns >/dev/null 2>&1 || doh_apply_dns() { return 1; }
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }

if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v carrier_up_mark >/dev/null 2>&1 || carrier_up_mark() { return 0; }










xray_server_host() {
    { tr -d '\r\n' < "${1:-$XRAY_JSON}" 2>/dev/null; } \
        | sed 's/.*"outbounds"/"outbounds"/' \
        | grep -o '"address"[[:space:]]*:[[:space:]]*"[^"]*"' \
        | head -1 \
        | sed 's/.*"\([^"]*\)"[[:space:]]*$/\1/'
}






seed_server_dns() {
    [ -s "$XRAY_JSON" ] || { log "нет $XRAY_JSON"; return 1; }
    _h=$(xray_server_host)
    [ -n "$_h" ] || { log "не нашёл address в $XRAY_JSON"; return 1; }
    seed_host_dns "$_h" "$SEED_CONF"
}





xray_endpoint_ip() {
    _ip=$(sed -n 's%^address=/[^/]*/%%p' "${1:-$SEED_CONF}" 2>/dev/null | head -1)
    [ -n "$_ip" ] && { echo "$_ip"; return 0; }
    _h=$(xray_server_host "${2:-$XRAY_JSON}")
    echo "$_h" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' && echo "$_h"
}


exclude_endpoint() {
    ep=$(xray_endpoint_ip)
    [ -n "$ep" ] || { log "endpoint xray не определён — пропуск анти-петли"; return 0; }
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-set "$ep" >/dev/null 2>&1
    log "endpoint $ep исключён из маркировки (анти-петля)"
}





set_xray_dns() {


    if doh_apply_dns tunnel; then [ -n "${DOH_APPLY_NOTE:-}" ] && log "DoH: $DOH_APPLY_NOTE"; return 0; fi
    mkdir -p /etc/dnsmasq.d
    printf 'no-resolv\nserver=%s\nserver=%s\n' "$DNS1" "$DNS2" > /etc/dnsmasq.d/00-upstream.conf
    for d in "$DNS1" "$DNS2"; do
        iptables -t mangle -C OUTPUT -d "$d" -j MARK --set-mark $FWMARK 2>/dev/null || \
            iptables -t mangle -A OUTPUT -d "$d" -j MARK --set-mark $FWMARK
    done
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}



set_direct_dns() {





    for d in "$DNS1" "$DNS2"; do
        iptables -t mangle -D OUTPUT -d "$d" -j MARK --set-mark $FWMARK 2>/dev/null
    done
    doh_apply_dns direct && return 0    # DoH ВКЛ (или авто-режим прямых) → резолв через локальный прокси; иначе → ниже как было
    mkdir -p /etc/dnsmasq.d
    printf 'no-resolv\nserver=%s\nserver=%s\n' "$DNS1" "$DNS2" > /etc/dnsmasq.d/00-upstream.conf
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}









access_off() {   # $1 = json-конфиг xray; $2 = "keep" — накопленный лог НЕ удалять (демон может быть жив)
    ACCESS_FIXED=0
    [ -f "$1" ] || return 0
    _aold=$(sed -n 's#.*"access"[[:space:]]*:[[:space:]]*"\(/tmp/[^"]*\)".*#\1#p' "$1" 2>/dev/null | head -n1)
    [ -n "$_aold" ] || return 0



    ( umask 077; sed 's#\("access"[[:space:]]*:[[:space:]]*\)"/tmp/[^"]*"#\1"none"#' "$1" > "$1.acc" ) 2>/dev/null
    if [ -s "$1.acc" ] && cat "$1.acc" > "$1" 2>/dev/null; then
        ACCESS_FIXED=1
        log "в конфиге $(basename "$1") погашен access-лог xray ($_aold рос в ОЗУ)"






        [ "$2" = keep ] || rm -f "$_aold" 2>/dev/null
    fi
    rm -f "$1.acc" 2>/dev/null
    return 0
}











cmd_access_purge() {
    _apn=0; _apt=0
    for _apf in "$XRAY_JSON" "$ENODIA_STATE"/xray-configs/*.json; do
        [ -f "$_apf" ] || continue          # пустой каталог ⇒ glob приедет литералом
        _apt=$((_apt+1))
        access_off "$_apf" keep
        if [ "$ACCESS_FIXED" = 1 ]; then _apn=$((_apn+1)); fi
    done
    log "access-purge: просмотрено конфигов $_apt, вычищено $_apn"
    return 0
}









spawn_xray() {
    : > "$XRAY_LOG" 2>/dev/null || true
    access_off "$XRAY_JSON"                # старый конфиг мог нести /tmp/xray-access.log
    seed_server_dns || return 1            # посеять server-host->IP в локальный dnsmasq; 1 = не зарезолвили
    start-stop-daemon -S -b -m -p "$XRAY_PID" -x /bin/sh -- -c "exec '$XRAY' run -c '$XRAY_JSON' >>'$XRAY_LOG' 2>&1"
}








free_foreign_socks() {
    own=$(cat "$XRAY_PID" 2>/dev/null | tr -d ' \r\n')
    holder=$(netstat -ltnp 2>/dev/null | grep "$SOCKS_ADDR:$SOCKS_PORT " | awk '{print $NF}' | cut -d/ -f1 | head -n1)
    case "$holder" in ''|*[!0-9]*) return 0 ;; esac   # никто не слушает / pid не распарсился
    [ "$holder" = "$own" ] && return 0                 # уже наш xray
    log "socks $SOCKS_PORT держит чужой pid $holder — освобождаю (своп альта/рестарт)"
    kill "$holder" 2>/dev/null
    i=0; while [ $i -lt 5 ]; do netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$SOCKS_PORT" || break; sleep 1; i=$((i+1)); done
}
start_daemons() {
    [ -x "$XRAY" ] || { log "НЕТ бинаря $XRAY — поставьте его в панели: «Компоненты»"; return 1; }
    [ -x "$HEV" ]  || { log "НЕТ бинаря $HEV"; return 1; }
    [ -s "$XRAY_JSON" ] || { log "НЕТ конфига $XRAY_JSON — добавьте xray-конфиг (меню)"; return 1; }
    [ -s "$HEV_YAML" ]  || { log "НЕТ $HEV_YAML"; return 1; }

    free_foreign_socks   # выгнать оставшийся hysteria/чужой демон с порта 10808
    if ! proc_alive "$XRAY_PID"; then
        log "запускаю xray…"
        spawn_xray || { log "xray не запущен: не удалось зарезолвить server-host. Лог:"; tail -n 15 "$XRAY_LOG" 2>/dev/null; return 1; }
    fi


    if ! daemon_wait_port "$XRAY_PID" xray 8 "$SOCKS_ADDR" "$SOCKS_PORT"; then
        log "xray не слушает $SOCKS_PORT: $DAEMON_WAIT_WHY. Лог:"; tail -n 15 "$XRAY_LOG" 2>/dev/null
        return 1
    fi
    socks_ours || { log "socks $SOCKS_PORT держит ЧУЖОЙ демон — наш xray не забиндил (несущую поверх чужого socks не поднимаю)"; return 1; }
    if ! proc_alive "$HEV_PID"; then
        log "запускаю hev (tun2socks)…"
        start-stop-daemon -S -b -m -p "$HEV_PID" -x "$HEV" -- "$HEV_YAML"
    fi
    daemon_wait_dev "$HEV_PID" hev 6 "$TUN" || {
        log "tun $TUN не создан: $DAEMON_WAIT_WHY. Лог hev:"; tail -n 15 "$HEV_LOG" 2>/dev/null; return 1; }
    return 0
}
stop_daemons() {
    start-stop-daemon -K -p "$HEV_PID"  2>/dev/null
    start-stop-daemon -K -p "$XRAY_PID" 2>/dev/null
    ip link del "$TUN" 2>/dev/null



    rm -f "$HEV_PID" "$XRAY_PID" 2>/dev/null
}





restart_xray() {





    seed_server_dns || { log "restart_xray: server-host не резолвится — несущую не трогаю"; return 2; }









    start-stop-daemon -K -p "$XRAY_PID" 2>/dev/null
    i=0; while [ $i -lt 6 ] && proc_alive "$XRAY_PID"; do sleep 1; i=$((i+1)); done
    rm -f "$XRAY_PID" 2>/dev/null
    free_foreign_socks
    spawn_xray || { log "restart_xray: резолв server-host не удался"; return 1; }
    daemon_wait_port "$XRAY_PID" xray 8 "$SOCKS_ADDR" "$SOCKS_PORT" || { log "restart_xray: $DAEMON_WAIT_WHY"; return 1; }
    socks_ours
}














XRAY_WARM_TRIES=${XRAY_WARM_TRIES:-3}
health_warm() {
    cmd_health && return 0
    [ "${WARM_LEFT:-0}" -gt 0 ] 2>/dev/null || return 1
    WARM_LEFT=$((WARM_LEFT - 1))
    log "health: первая проба пуста — даю прогревочный повтор (холодный outbound; в бюджете прогона осталось $WARM_LEFT)"
    cmd_health
}






cmd_failover() {
    [ -e "$SWITCH_LOCK" ] && { log "xray-failover: идёт ручной switch (lock) — не перебираю"; return 1; }
    WARM_LEFT=$XRAY_WARM_TRIES   # бюджет прогревочных повторов health на ВЕСЬ прогон (см. health_warm)






    if ! ip link show "$TUN" >/dev/null 2>&1; then
        [ "$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')" = xray ] || {
            log "xray-failover: нет $TUN и транспорт не xray — xray не активен"; return 1; }
        log "xray-failover: нет $TUN, но транспорт=xray — несущая (hev) умерла, иду в ФАЗУ 0"
    fi
    cur=$(cat "$ENODIA_STATE/.xray-active" 2>/dev/null | tr -d ' \r\n')



    if cmd_health; then log "xray-failover: транспорт уже здоров — нечего делать"; return 0; fi








    plumbing_down=0
    proc_alive "$XRAY_PID" || plumbing_down=1
    proc_alive "$HEV_PID"  || plumbing_down=1
    netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$SOCKS_PORT" || plumbing_down=1
    if [ "$plumbing_down" = 1 ]; then
        log "xray-failover: несущая (xray/hev/socks) мертва → ЧИНЮ на месте, серверы НЕ перебираю"
        proc_alive "$HEV_PID" || { start-stop-daemon -K -p "$HEV_PID" 2>/dev/null; ip link del "$TUN" 2>/dev/null; }
        if start_daemons; then
            apply_xray_routing
            ct_flush
            if health_warm; then
                log "xray-failover: несущая восстановлена на текущем сервере ${cur:-?} — перебор серверов не понадобился"
                return 0
            fi
        fi
        log "xray-failover: починка несущей не помогла — перехожу к перебору серверов"
    fi

    tried=""; dns_dead=0; _xfwl=0





    _xfw=0
    command -v wan_probe_ok >/dev/null 2>&1 && command -v wan_recheck >/dev/null 2>&1 && wan_probe_ok && _xfw=1
    for f in "$ENODIA_STATE"/xray-configs/*.json; do
        [ -f "$f" ] || continue
        [ -e "$SWITCH_LOCK" ] && { log "xray-failover: ручной switch (lock) в процессе — прерываю перебор"; return 1; }


        carrier_barred && { log "xray-failover: VPN выключили вручную — прерываю перебор"; break; }
        name=$(basename "$f" .json)
        [ "$name" = "$cur" ] && continue       # текущий (дохлый) пропускаем




        if [ "$dns_dead" = 1 ] && ! is_ipv4 "$(xray_server_host "$f")"; then
            log "xray-failover: пропускаю $name — сервер задан именем, а DNS сейчас мёртв"
            continue
        fi
        log "xray-failover: пробую $name…"


        cp "$f" "$XRAY_JSON" || { log "xray-failover: не удалось положить конфиг $name — пропускаю"; continue; }
        chmod 600 "$XRAY_JSON"
        echo "$name" > "$ENODIA_STATE/.xray-active"
        restart_xray; rc=$?
        [ "$rc" = 2 ] && { dns_dead=1; log "xray-failover: $name не резолвится — DNS мёртв (upstream заперт в несущей)"; }
        if [ "$rc" = 0 ] && health_warm; then
            exclude_endpoint        # анти-петля: endpoint нового резерва мимо маркировки
            ct_flush
            ip=$(probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$SOCKS_PORT" 8)
            log "xray-failover OK: встал на $name (egress ${ip:-?})"
            if [ "$(nf_lang)" = en ]; then
                notify_event "xray-failover-ok" 1800 "BE7000: Xray failover -> $name" \
"Xray server ${cur:-?} stopped responding. The router switched to a backup
xray config: $name — VPN works again. External IP: ${ip:-unknown}.

Change manually: panel :8088 -> the VPN card -> pick the xray server."
            else
                notify_event "xray-failover-ok" 1800 "BE7000: Xray-failover -> $name" \
"Xray-сервер ${cur:-?} перестал отвечать. Роутер переключился на резервный
xray-конфиг: $name — VPN снова работает. Внешний IP: ${ip:-неизвестен}.

Сменить вручную: панель :8088 -> карточка VPN -> выбрать xray-сервер."
            fi
            return 0
        fi
        tried="$tried $name"
        if [ "$_xfw" = 1 ] && ! wan_probe_ok && ! wan_recheck; then
            _xfwl=1; log "xray-failover: интернет через WAN пропал посреди перебора — прерываю (недостижим любой сервер)"; break
        fi
    done



    if [ -n "$tried" ] && [ -n "$cur" ] && [ -f "$ENODIA_STATE/xray-configs/$cur.json" ]; then
        cp "$ENODIA_STATE/xray-configs/$cur.json" "$XRAY_JSON" && chmod 600 "$XRAY_JSON"
        echo "$cur" > "$ENODIA_STATE/.xray-active"
        carrier_barred || restart_xray || true
    fi
    carrier_barred && { log "xray-failover: перебор прерван — VPN выключен вручную, несущую не поднимаю"; return 1; }





    if [ "$_xfwl" = 1 ]; then
        log "xray-failover: перебор прерван — нет интернета от провайдера (пробовал:$tried); несущая на ${cur:-текущем}"
    elif [ -z "$tried" ]; then
        log "xray-failover: резервных конфигов нет — переключаться некуда, несущая осталась на ${cur:-текущем}"
    else
        log "xray-failover FAIL: ни один резерв не поднялся (пробовал:$tried)"
    fi
    return 1
}


apply_xray_routing() {
    ip link set "$TUN" up 2>/dev/null

    ipt_top FORWARD -o "$TUN" -j ACCEPT
    ipt_top FORWARD -i "$TUN" -j ACCEPT

    ip route replace default dev "$TUN" table "$TABLE"
}


cmd_up() {
    if ! start_daemons; then
        log "запуск не удался — остаюсь на awg"
        stop_daemons
        return 1
    fi
    exclude_endpoint        # анти-петля: endpoint мимо маркировки ДО постановки default->xtun
    apply_xray_routing
    set_xray_dns
    echo xray > "$TRANSPORT_FLAG"


    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    carrier_up_mark         # грейс сторожу: демоны стартовали, но egress поднимается ещё секунды (clock-lib.sh)
    ct_flush
    log "транспорт = XRAY (default table $TABLE -> $TUN). Общие правила сохранены."
    cmd_status
}

cmd_down() {





    stop_daemons
    iptables -D FORWARD -o "$TUN" -j ACCEPT 2>/dev/null
    iptables -D FORWARD -i "$TUN" -j ACCEPT 2>/dev/null
    ip route flush table "$TABLE" 2>/dev/null || true
    seed_host_clear "$SEED_CONF"           # снять сид server-host — ОБЕ копии, /etc и живую /tmp (set_direct_dns ниже рестартит dnsmasq)
    set_direct_dns
    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    ct_flush
    log "Xray-несущая снята (релинквиш) -> прямой режим (fail-open). Следующий транспорт ставит оркестратор."
}

cmd_status() {


    t=; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    echo "=== транспорт: ${t:-(флаг пуст — транспорт не выбран)} ==="
    echo "--- default в table $TABLE ---"; ip route show table "$TABLE" 2>/dev/null | grep default   # raw-print: сырой вывод человеку в `status`, вердикта тут нет
    echo "--- демоны ---"
    proc_alive "$XRAY_PID" && echo "xray: pid $(cat $XRAY_PID) жив" || echo "xray: не запущен"
    proc_alive "$HEV_PID"  && echo "hev:  pid $(cat $HEV_PID) жив"  || echo "hev:  не запущен"
    echo "--- tun $TUN ---"; ip -o link show "$TUN" 2>/dev/null || echo "нет"
    echo "--- socks $SOCKS_PORT ---"; netstat -ltn 2>/dev/null | grep "$SOCKS_PORT" || echo "не слушает"
    if [ "$t" = xray ]; then
        echo "--- egress через xray socks ---"
        probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$SOCKS_PORT" 8; echo
    fi
    echo "--- awg0 (тёплый резерв) ---"; ip link show awg0 >/dev/null 2>&1 && echo "поднят" || echo "нет"
}


cmd_health() {
    t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    [ "$t" = xray ] || return 0
    proc_alive "$XRAY_PID" || { log "health: xray не жив"; return 1; }
    proc_alive "$HEV_PID"  || { log "health: hev не жив"; return 1; }
    ip link show "$TUN" >/dev/null 2>&1 || { log "health: нет $TUN"; return 1; }

    ip=$(probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$SOCKS_PORT" 8)
    [ -n "$ip" ] || { log "health: проба egress пуста"; return 1; }


    command -v hev_path_check >/dev/null 2>&1 || return 0
    hev_path_check apply_xray_routing
}

























if [ -f "$ENODIA_DIR/slot-tun-lib.sh" ]; then . "$ENODIA_DIR/slot-tun-lib.sh"; else SLOT_LIB_MISSING=1; fi
slot_lib_ok() { [ -z "$SLOT_LIB_MISSING" ] && return 0
    echo "[xray] слот-слой недоступен: нет $ENODIA_DIR/slot-tun-lib.sh — обновите скрипты" >&2; return 1; }



command -v slot_socks_is_ours >/dev/null 2>&1 || slot_socks_is_ours() { return 0; }
slot_srcconf()  { echo "$ENODIA_STATE/xray-configs/$1.json"; }   # $1 = имя конфига
slot_conf()     { echo "$ENODIA_STATE/xray-s$1.json"; }
slot_xray_pid() { echo "/tmp/enodia-xray-s$1.pid"; }
slot_xray_log() { echo "/tmp/xray-s$1.log"; }
slot_seed()     { echo "/etc/dnsmasq.d/02-altserver-s$1.conf"; }




slot_gen_conf() {   # $1 = id ; $2 = имя конфига ; 0 = готов
    _id="$1"; _src=$(slot_srcconf "$2"); _dst=$(slot_conf "$_id"); _port=$(slot_socks_port "$_id")
    [ -s "$_src" ] || { log "слот №$_id: нет конфига $_src"; return 1; }
    sed -e "s/\"port\"[[:space:]]*:[[:space:]]*10808/\"port\": $_port/" \
        -e "s#/tmp/xray-access.log#none#g" \
        -e "s#/tmp/xray\.log#$(slot_xray_log "$_id")#g" \
        "$_src" > "$_dst" 2>/dev/null
    [ -s "$_dst" ] || { log "слот №$_id: не удалось подготовить конфиг"; return 1; }
    chmod 600 "$_dst" 2>/dev/null


    grep -q "$_port" "$_dst" || { log "слот №$_id: в конфиге не найден socks-инбаунд 10808 — не могу выделить порт слоту"; return 1; }
    return 0
}

slot_start_daemons() {   # $1 = id ; $2 = имя конфига
    [ -x "$XRAY" ] || { log "слот №$1: НЕТ бинаря $XRAY"; return 1; }
    [ -x "$HEV" ]  || { log "слот №$1: НЕТ бинаря hev"; return 1; }
    _id="$1"; _port=$(slot_socks_port "$_id")
    slot_gen_conf "$_id" "$2" || return 1
    _h=$(xray_server_host "$(slot_conf "$_id")")
    [ -n "$_h" ] || { log "слот №$_id: не нашёл address в конфиге"; return 1; }
    seed_host_dns "$_h" "$(slot_seed "$_id")" || return 1     # без резолва демон упал бы dial-ом
    slot_free_socks "$_id" "$(slot_xray_pid "$_id")"
    if ! proc_alive "$(slot_xray_pid "$_id")"; then
        log "слот №$_id: запускаю xray на socks :$_port (конфиг $2)…"
        : > "$(slot_xray_log "$_id")" 2>/dev/null || true
        start-stop-daemon -S -b -m -p "$(slot_xray_pid "$_id")" -x /bin/sh -- -c "exec '$XRAY' run -c '$(slot_conf "$_id")' >>'$(slot_xray_log "$_id")' 2>&1"
    fi
    if ! slot_wait_socks "$_port" "$(slot_xray_pid "$_id")" xray; then
        log "слот №$_id: xray не слушает :$_port ($DAEMON_WAIT_WHY). Лог:"; tail -n 15 "$(slot_xray_log "$_id")" 2>/dev/null
        return 1
    fi
    slot_hev_up "$_id"          # hev + ожидание xtunN (общий слой)
}
slot_stop_daemons() {   # $1 = id
    _id="$1"
    slot_hev_down "$_id"
    start-stop-daemon -K -p "$(slot_xray_pid "$_id")" 2>/dev/null
    rm -f "$(slot_xray_pid "$_id")" 2>/dev/null
}



slot_exclude_endpoint() {   # $1 = id
    _id="$1"
    _ep=$(xray_endpoint_ip "$(slot_seed "$_id")" "$(slot_conf "$_id")")
    [ -n "$_ep" ] || { log "слот №$_id: endpoint не определён — пропуск анти-петли"; return 0; }
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "$_ep" >/dev/null 2>&1
    log "слот №$_id: endpoint $_ep исключён из маркировки (анти-петля)"
}



cmd_slot_up() {   # $1 = id ; $2 = имя конфига
    _id="$1"; _cfg="$2"
    case "$_id" in 2|3|4) ;; *) log "слот: id = 2..4"; return 1 ;; esac
    [ -n "$_cfg" ] && [ "$_cfg" != "-" ] || { log "слот №$_id: не задан конфиг сервера"; return 1; }
    if ! slot_start_daemons "$_id" "$_cfg"; then
        log "слот №$_id: xray-несущая не поднялась -> выход живёт по fallback-политике (mark-core)"
        slot_stop_daemons "$_id"
        return 1
    fi
    slot_exclude_endpoint "$_id"    # ДО постановки default->xtunN
    slot_apply_routing "$_id"
    ct_flush
    log "слот №$_id: xray-несущая $(slot_tun "$_id") в table $(slot_table "$_id") (конфиг $_cfg)"
    return 0
}
cmd_slot_down() {   # $1 = id
    _id="$1"
    case "$_id" in 2|3|4) ;; *) log "слот: id = 2..4"; return 1 ;; esac
    slot_remove_routing "$_id"
    slot_stop_daemons "$_id"
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "" >/dev/null 2>&1   # снять анти-петлю слота
    rm -f "$(slot_hev_yaml "$_id")" "$(slot_conf "$_id")" 2>/dev/null


    if seed_host_clear "$(slot_seed "$_id")"; then
        /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
    fi
    ct_flush
    log "слот №$_id: xray-несущая снята"
    return 0
}


cmd_slot_health() {   # $1 = id
    _id="$1"
    case "$_id" in 2|3|4) ;; *) return 1 ;; esac
    proc_alive "$(slot_xray_pid "$_id")" || { log "слот №$_id health: xray не жив"; return 1; }
    proc_alive "$(slot_hev_pid "$_id")"  || { log "слот №$_id health: hev не жив"; return 1; }
    ip link show "$(slot_tun "$_id")" >/dev/null 2>&1 || { log "слот №$_id health: нет $(slot_tun "$_id")"; return 1; }
    _ip=$(probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$(slot_socks_port "$_id")" 8)
    [ -n "$_ip" ] || { log "слот №$_id health: проба egress пуста"; return 1; }
    return 0
}

case "$1" in


    up)       carrier_run cmd_down cmd_up ;;
    down)     cmd_down ;;
    cold)     : ;;                        # тёплого резерва нет: демонов гасит сам `down` (stop_daemons)
    status)   cmd_status ;;
    health)   carrier_run cmd_down cmd_health ;;   # залипший hev перезапускает на месте (hev_path_check) — берёт несущую
    failover) carrier_run cmd_down cmd_failover ;;

    dns)      if carrier_barred; then set_direct_dns; else set_xray_dns; fi ;;
    access-purge) cmd_access_purge ;;  # разовая чистка ХРАНИЛИЩА конфигов от пути access-лога (зовут install.sh и gh-update.sh)


    slot-up)     slot_lib_ok || exit 2; carrier_run cmd_slot_down cmd_slot_up "$2" "$3" ;;   # доп-выход (Ф3): 2-й xray + hev + xtunN в table 100N
    slot-down)   slot_lib_ok || exit 2; cmd_slot_down "$2" ;;      # доп-выход: снять несущую слота (-> fallback-политика mark-core)
    slot-health) slot_lib_ok || exit 2; cmd_slot_health "$2" ;;    # доп-выход: жив ли выход (watchdog)
    slot-iface)  slot_lib_ok || exit 2; slot_tun "$2" ;;           # имя несущей слота — учёту трафика (владелец имени один: slot-tun-lib.sh)
    *) echo "usage: $0 up|down|cold|status|health|failover|dns|access-purge|slot-up <id> <cfg>|slot-down <id>|slot-health <id>|slot-iface <id>"; exit 2 ;;
esac
