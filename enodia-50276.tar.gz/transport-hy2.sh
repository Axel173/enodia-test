#!/bin/sh


































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }


if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }





if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi

command -v carrier_barred >/dev/null 2>&1 || carrier_barred() { return 1; }
command -v carrier_run >/dev/null 2>&1 || carrier_run() { shift; "$@"; }
command -v daemon_wait_port >/dev/null 2>&1 || daemon_wait_port() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0; sleep 1; _dwi=$((_dwi+1)); done
    netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
command -v daemon_wait_dev >/dev/null 2>&1 || daemon_wait_dev() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do ip link show "$4" >/dev/null 2>&1 && return 0; sleep 1; _dwi=$((_dwi+1)); done
    ip link show "$4" >/dev/null 2>&1 && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
TABLE=1000
TUN=xtun
SOCKS_ADDR=127.0.0.1
SOCKS_PORT=10808                             # ТОТ ЖЕ порт, что у xray → общий hev.yaml несёт оба
HY2=$(bin_path hysteria)
HEV=$(bin_path hev)
HY2_YAML="$ENODIA_STATE/hysteria.yaml"       # активный конфиг (генерит меню; socks5.listen ОБЯЗАН быть 127.0.0.1:10808)
SEED_CONF="/etc/dnsmasq.d/02-altserver.conf" # локальный dnsmasq-ответ server-host->IP (демон резолвит имя сам)
HEV_YAML="$ENODIA_DIR/hev.yaml"
HY2_PID=/tmp/enodia-hysteria.pid
HEV_PID=/tmp/enodia-hev.pid
HY2_LOG=/tmp/enodia-hysteria.log
HEV_LOG=/tmp/enodia-hev.log
TRANSPORT_FLAG="$ENODIA_STATE/.transport"
SWITCH_LOCK=/tmp/enodia-switching.lock       # ручной switch (панель/меню) держит его → авто-failover прерывается (Fix C 2026-07-09)
NOTIFY_EVENT="$ENODIA_DIR/notify-event.sh"
APPLY_BYPASS="$ENODIA_DIR/apply-bypass.sh"
DNS1=1.1.1.1
DNS2=8.8.8.8
FWMARK=0x1

log() { echo "[hy2-transport] $*"; }
notify_event() { [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "$1" "$2" "$3" "$4" >/dev/null 2>&1; }




proc_alive() { p=$(cat "$1" 2>/dev/null | tr -d ' \r\n'); [ -n "$p" ] && kill -0 "$p" 2>/dev/null; }





socks_ours() { slot_socks_is_ours "$SOCKS_PORT" "$HY2_PID"; }












if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; else
    echo "[hy2] нет $ENODIA_DIR/dns-lib.sh — обновите установку (панель → «Обновление» или переустановка с компьютера)" >&2; exit 1
fi



command -v seed_host_clear >/dev/null 2>&1 || seed_host_clear() { rm -f "$1" "/tmp/dnsmasq.d/${1##*/}" 2>/dev/null; }


if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi



if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
command -v doh_apply_dns >/dev/null 2>&1 || doh_apply_dns() { return 1; }
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }

if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v carrier_up_mark >/dev/null 2>&1 || carrier_up_mark() { return 0; }












hy2_server_host() {
    _h=$(grep -E '^[[:space:]]*server:' "${1:-$HY2_YAML}" 2>/dev/null | head -1 | sed 's/^[[:space:]]*server:[[:space:]]*//; s/[[:space:]]*$//; s/^["'\'']//; s/["'\'']$//')
    echo "${_h%:*}"                                      # отрезать :port
}
seed_server_dns() {
    [ -s "$HY2_YAML" ] || { log "нет $HY2_YAML"; return 1; }
    _host=$(hy2_server_host)
    [ -n "$_host" ] || { log "не нашёл server в $HY2_YAML"; return 1; }
    seed_host_dns "$_host" "$SEED_CONF"
}





hy2_endpoint_ip() {
    _ip=$(sed -n 's%^address=/[^/]*/%%p' "${1:-$SEED_CONF}" 2>/dev/null | head -1)
    [ -n "$_ip" ] && { echo "$_ip"; return 0; }
    _h=$(hy2_server_host "${2:-$HY2_YAML}")
    echo "$_h" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' && echo "$_h"
}


exclude_endpoint() {
    ep=$(hy2_endpoint_ip)
    [ -n "$ep" ] || { log "endpoint hy2 не определён — пропуск анти-петли"; return 0; }
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-set "$ep" >/dev/null 2>&1
    log "endpoint $ep исключён из маркировки (анти-петля)"
}





set_hy2_dns() {


    if doh_apply_dns tunnel; then [ -n "${DOH_APPLY_NOTE:-}" ] && log "DoH: $DOH_APPLY_NOTE"; return 0; fi
    mkdir -p /etc/dnsmasq.d
    printf 'no-resolv\nserver=%s\nserver=%s\n' "$DNS1" "$DNS2" > /etc/dnsmasq.d/00-upstream.conf
    for d in "$DNS1" "$DNS2"; do
        iptables -t mangle -C OUTPUT -d "$d" -j MARK --set-mark $FWMARK 2>/dev/null || \
            iptables -t mangle -A OUTPUT -d "$d" -j MARK --set-mark $FWMARK
    done
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}

set_direct_dns() {



    for d in "$DNS1" "$DNS2"; do
        iptables -t mangle -D OUTPUT -d "$d" -j MARK --set-mark $FWMARK 2>/dev/null
    done
    doh_apply_dns direct && return 0    # DoH ВКЛ (или авто-режим прямых) → резолв через локальный прокси; иначе → ниже как было
    mkdir -p /etc/dnsmasq.d
    printf 'no-resolv\nserver=%s\nserver=%s\n' "$DNS1" "$DNS2" > /etc/dnsmasq.d/00-upstream.conf
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}










spawn_hysteria() {
    : > "$HY2_LOG" 2>/dev/null || true
    seed_server_dns || return 1            # посеять server-host->IP в локальный dnsmasq; 1 = не зарезолвили
    start-stop-daemon -S -b -m -p "$HY2_PID" -x /bin/sh -- -c "exec '$HY2' -c '$HY2_YAML' >>'$HY2_LOG' 2>&1"
}








free_foreign_socks() {
    own=$(cat "$HY2_PID" 2>/dev/null | tr -d ' \r\n')
    holder=$(netstat -ltnp 2>/dev/null | grep "$SOCKS_ADDR:$SOCKS_PORT " | awk '{print $NF}' | cut -d/ -f1 | head -n1)
    case "$holder" in ''|*[!0-9]*) return 0 ;; esac   # никто не слушает / pid не распарсился
    [ "$holder" = "$own" ] && return 0                 # уже наша hysteria
    log "socks $SOCKS_PORT держит чужой pid $holder — освобождаю (своп альта/рестарт)"
    kill "$holder" 2>/dev/null
    i=0; while [ $i -lt 5 ]; do netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$SOCKS_PORT" || break; sleep 1; i=$((i+1)); done
}
start_daemons() {
    [ -x "$HY2" ] || { log "НЕТ бинаря $HY2 — поставьте его в панели: «Компоненты»"; return 1; }
    [ -x "$HEV" ] || { log "НЕТ бинаря $HEV"; return 1; }
    [ -s "$HY2_YAML" ] || { log "НЕТ конфига $HY2_YAML — добавьте hy2-конфиг (меню)"; return 1; }
    [ -s "$HEV_YAML" ] || { log "НЕТ $HEV_YAML"; return 1; }

    free_foreign_socks   # выгнать оставшийся xray/чужой демон с порта 10808
    if ! proc_alive "$HY2_PID"; then
        log "запускаю hysteria…"
        spawn_hysteria || { log "hysteria не запущена: не удалось зарезолвить server-host. Лог:"; tail -n 15 "$HY2_LOG" 2>/dev/null; return 1; }
    fi










    if ! daemon_wait_port "$HY2_PID" hysteria 25 "$SOCKS_ADDR" "$SOCKS_PORT"; then
        log "hysteria не слушает $SOCKS_PORT: $DAEMON_WAIT_WHY (socks5.listen в конфиге обязан быть $SOCKS_ADDR:$SOCKS_PORT). Лог:"; tail -n 15 "$HY2_LOG" 2>/dev/null
        return 1
    fi
    socks_ours || { log "socks $SOCKS_PORT держит ЧУЖОЙ демон — наша hysteria не забиндила (несущую поверх чужого socks не поднимаю)"; return 1; }
    if ! proc_alive "$HEV_PID"; then
        log "запускаю hev (tun2socks)…"
        start-stop-daemon -S -b -m -p "$HEV_PID" -x "$HEV" -- "$HEV_YAML"
    fi
    daemon_wait_dev "$HEV_PID" hev 6 "$TUN" || {
        log "tun $TUN не создан: $DAEMON_WAIT_WHY. Лог hev:"; tail -n 15 "$HEV_LOG" 2>/dev/null; return 1; }
    return 0
}
stop_daemons() {
    start-stop-daemon -K -p "$HEV_PID" 2>/dev/null
    start-stop-daemon -K -p "$HY2_PID" 2>/dev/null
    ip link del "$TUN" 2>/dev/null



    rm -f "$HEV_PID" "$HY2_PID" 2>/dev/null
}




restart_hy2() {




    seed_server_dns || { log "restart_hy2: server-host не резолвится — несущую не трогаю"; return 2; }




    start-stop-daemon -K -p "$HY2_PID" 2>/dev/null
    i=0; while [ $i -lt 6 ] && proc_alive "$HY2_PID"; do sleep 1; i=$((i+1)); done
    rm -f "$HY2_PID" 2>/dev/null
    free_foreign_socks
    spawn_hysteria || { log "restart_hy2: резолв server-host не удался"; return 1; }

    daemon_wait_port "$HY2_PID" hysteria 25 "$SOCKS_ADDR" "$SOCKS_PORT" || { log "restart_hy2: $DAEMON_WAIT_WHY"; return 1; }
    socks_ours
}






cmd_failover() {
    [ -e "$SWITCH_LOCK" ] && { log "hy2-failover: идёт ручной switch (lock) — не перебираю"; return 1; }





    if ! ip link show "$TUN" >/dev/null 2>&1; then
        [ "$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')" = hy2 ] || {
            log "hy2-failover: нет $TUN и транспорт не hy2 — hysteria не активна"; return 1; }
        log "hy2-failover: нет $TUN, но транспорт=hy2 — несущая (hev) умерла, иду в ФАЗУ 0"
    fi
    cur=$(cat "$ENODIA_STATE/.hy2-active" 2>/dev/null | tr -d ' \r\n')


    if cmd_health; then log "hy2-failover: транспорт уже здоров — нечего делать"; return 0; fi





    plumbing_down=0
    proc_alive "$HY2_PID" || plumbing_down=1
    proc_alive "$HEV_PID" || plumbing_down=1
    netstat -ltn 2>/dev/null | grep -q "$SOCKS_ADDR:$SOCKS_PORT" || plumbing_down=1
    if [ "$plumbing_down" = 1 ]; then
        log "hy2-failover: несущая (hysteria/hev/socks) мертва → ЧИНЮ на месте, серверы НЕ перебираю"
        proc_alive "$HEV_PID" || { start-stop-daemon -K -p "$HEV_PID" 2>/dev/null; ip link del "$TUN" 2>/dev/null; }
        if start_daemons; then
            apply_hy2_routing
            ct_flush
            if cmd_health; then
                log "hy2-failover: несущая восстановлена на текущем сервере ${cur:-?} — перебор не понадобился"
                return 0
            fi
        fi
        log "hy2-failover: починка несущей не помогла — перехожу к перебору серверов"
    fi

    tried=""; dns_dead=0; _hfwl=0


    _hfw=0
    command -v wan_probe_ok >/dev/null 2>&1 && command -v wan_recheck >/dev/null 2>&1 && wan_probe_ok && _hfw=1
    for f in "$ENODIA_STATE"/hy2-configs/*.yaml; do
        [ -f "$f" ] || continue
        [ -e "$SWITCH_LOCK" ] && { log "hy2-failover: ручной switch (lock) в процессе — прерываю перебор"; return 1; }

        carrier_barred && { log "hy2-failover: VPN выключили вручную — прерываю перебор"; break; }
        name=$(basename "$f" .yaml)
        [ "$name" = "$cur" ] && continue       # текущий (дохлый) пропускаем


        if [ "$dns_dead" = 1 ] && ! is_ipv4 "$(hy2_server_host "$f")"; then
            log "hy2-failover: пропускаю $name — сервер задан именем, а DNS сейчас мёртв"
            continue
        fi
        log "hy2-failover: пробую $name…"


        cp "$f" "$HY2_YAML" || { log "hy2-failover: не удалось положить конфиг $name — пропускаю"; continue; }
        chmod 600 "$HY2_YAML"
        echo "$name" > "$ENODIA_STATE/.hy2-active"
        restart_hy2; rc=$?
        [ "$rc" = 2 ] && { dns_dead=1; log "hy2-failover: $name не резолвится — DNS мёртв (upstream заперт в несущей)"; }
        if [ "$rc" = 0 ] && cmd_health; then
            exclude_endpoint        # анти-петля: endpoint нового резерва мимо маркировки
            ct_flush
            ip=$(probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$SOCKS_PORT" 8)
            log "hy2-failover OK: встал на $name (egress ${ip:-?})"
            if [ "$(nf_lang)" = en ]; then
                notify_event "hy2-failover-ok" 1800 "BE7000: Hysteria2 failover -> $name" \
"Hysteria2 server ${cur:-?} stopped responding. The router switched to a backup
hy2 config: $name — VPN works again. External IP: ${ip:-unknown}.

Change manually: panel :8088 -> the VPN card -> pick the hy2 server."
            else
                notify_event "hy2-failover-ok" 1800 "BE7000: Hysteria2-failover -> $name" \
"Hysteria2-сервер ${cur:-?} перестал отвечать. Роутер переключился на резервный
hy2-конфиг: $name — VPN снова работает. Внешний IP: ${ip:-неизвестен}.

Сменить вручную: панель :8088 -> карточка VPN -> выбрать hy2-сервер."
            fi
            return 0
        fi
        tried="$tried $name"
        if [ "$_hfw" = 1 ] && ! wan_probe_ok && ! wan_recheck; then
            _hfwl=1; log "hy2-failover: интернет через WAN пропал посреди перебора — прерываю (недостижим любой сервер)"; break
        fi
    done

    if [ -n "$tried" ] && [ -n "$cur" ] && [ -f "$ENODIA_STATE/hy2-configs/$cur.yaml" ]; then
        cp "$ENODIA_STATE/hy2-configs/$cur.yaml" "$HY2_YAML" && chmod 600 "$HY2_YAML"
        echo "$cur" > "$ENODIA_STATE/.hy2-active"
        carrier_barred || restart_hy2 || true
    fi
    carrier_barred && { log "hy2-failover: перебор прерван — VPN выключен вручную, несущую не поднимаю"; return 1; }
    if [ "$_hfwl" = 1 ]; then
        log "hy2-failover: перебор прерван — нет интернета от провайдера (пробовал:$tried); несущая на ${cur:-текущем}"
    else
        log "hy2-failover FAIL: ни один резерв не поднялся (пробовал:${tried:- нет})"
    fi
    return 1
}


apply_hy2_routing() {
    ip link set "$TUN" up 2>/dev/null
    ipt_top FORWARD -o "$TUN" -j ACCEPT
    ipt_top FORWARD -i "$TUN" -j ACCEPT
    ip route replace default dev "$TUN" table "$TABLE"
}


cmd_up() {
    if ! start_daemons; then
        log "запуск не удался — несущая не поднята (оркестратор решит, что дальше)"
        stop_daemons
        return 1
    fi
    exclude_endpoint        # анти-петля: endpoint мимо маркировки ДО постановки default->xtun
    apply_hy2_routing
    set_hy2_dns
    echo hy2 > "$TRANSPORT_FLAG"

    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    carrier_up_mark         # грейс сторожу: демоны стартовали, но egress поднимается ещё секунды (clock-lib.sh)
    ct_flush
    log "транспорт = HYSTERIA2 (default table $TABLE -> $TUN). Общие правила сохранены."
    cmd_status
}

cmd_down() {



    stop_daemons
    iptables -D FORWARD -o "$TUN" -j ACCEPT 2>/dev/null
    iptables -D FORWARD -i "$TUN" -j ACCEPT 2>/dev/null
    ip route flush table "$TABLE" 2>/dev/null || true
    seed_host_clear "$SEED_CONF"           # снять сид server-host — ОБЕ копии, /etc и живую /tmp (set_direct_dns ниже рестартит dnsmasq)
    set_direct_dns
    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    ct_flush
    log "Hysteria2-несущая снята (релинквиш) -> прямой режим (fail-open). Следующий транспорт ставит оркестратор."
}

cmd_status() {


    t=; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    echo "=== транспорт: ${t:-(флаг пуст — транспорт не выбран)} ==="
    echo "--- default в table $TABLE ---"; ip route show table "$TABLE" 2>/dev/null | grep default   # raw-print: сырой вывод человеку в `status`, вердикта тут нет
    echo "--- демоны ---"
    proc_alive "$HY2_PID" && echo "hysteria: pid $(cat $HY2_PID) жив" || echo "hysteria: не запущен"
    proc_alive "$HEV_PID" && echo "hev:      pid $(cat $HEV_PID) жив" || echo "hev:      не запущен"
    echo "--- tun $TUN ---"; ip -o link show "$TUN" 2>/dev/null || echo "нет"
    echo "--- socks $SOCKS_PORT ---"; netstat -ltn 2>/dev/null | grep "$SOCKS_PORT" || echo "не слушает"
    if [ "$t" = hy2 ]; then
        echo "--- egress через hysteria socks ---"
        probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$SOCKS_PORT" 8; echo
    fi
    echo "--- awg0 (тёплый резерв) ---"; ip link show awg0 >/dev/null 2>&1 && echo "поднят" || echo "нет"
}


cmd_health() {
    t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG")
    [ "$t" = hy2 ] || return 0
    proc_alive "$HY2_PID" || { log "health: hysteria не жив"; return 1; }
    proc_alive "$HEV_PID" || { log "health: hev не жив"; return 1; }
    ip link show "$TUN" >/dev/null 2>&1 || { log "health: нет $TUN"; return 1; }
    ip=$(probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$SOCKS_PORT" 8)
    [ -n "$ip" ] || { log "health: проба egress пуста"; return 1; }


    command -v hev_path_check >/dev/null 2>&1 || return 0
    hev_path_check apply_hy2_routing
}










if [ -f "$ENODIA_DIR/slot-tun-lib.sh" ]; then . "$ENODIA_DIR/slot-tun-lib.sh"; else SLOT_LIB_MISSING=1; fi
slot_lib_ok() { [ -z "$SLOT_LIB_MISSING" ] && return 0
    echo "[hy2] слот-слой недоступен: нет $ENODIA_DIR/slot-tun-lib.sh — обновите скрипты" >&2; return 1; }



command -v slot_socks_is_ours >/dev/null 2>&1 || slot_socks_is_ours() { return 0; }
slot_srcconf()  { echo "$ENODIA_STATE/hy2-configs/$1.yaml"; }   # $1 = имя конфига
slot_conf()     { echo "$ENODIA_STATE/hysteria-s$1.yaml"; }
slot_hy2_pid()  { echo "/tmp/enodia-hysteria-s$1.pid"; }
slot_hy2_log()  { echo "/tmp/enodia-hysteria-s$1.log"; }
slot_seed()     { echo "/etc/dnsmasq.d/02-altserver-s$1.conf"; }


slot_gen_conf() {   # $1 = id ; $2 = имя конфига
    _id="$1"; _src=$(slot_srcconf "$2"); _dst=$(slot_conf "$_id"); _port=$(slot_socks_port "$_id")
    [ -s "$_src" ] || { log "слот №$_id: нет конфига $_src"; return 1; }
    sed -e "s/127\.0\.0\.1:10808/127.0.0.1:$_port/" "$_src" > "$_dst" 2>/dev/null
    [ -s "$_dst" ] || { log "слот №$_id: не удалось подготовить конфиг"; return 1; }
    chmod 600 "$_dst" 2>/dev/null


    grep -q "127.0.0.1:$_port" "$_dst" || { log "слот №$_id: в конфиге нет socks5.listen 127.0.0.1:10808 — не могу выделить порт слоту"; return 1; }
    return 0
}

slot_start_daemons() {   # $1 = id ; $2 = имя конфига
    [ -x "$HY2" ] || { log "слот №$1: НЕТ бинаря $HY2"; return 1; }
    [ -x "$HEV" ] || { log "слот №$1: НЕТ бинаря hev"; return 1; }
    _id="$1"; _port=$(slot_socks_port "$_id")
    slot_gen_conf "$_id" "$2" || return 1
    _h=$(hy2_server_host "$(slot_conf "$_id")")
    [ -n "$_h" ] || { log "слот №$_id: не нашёл server в конфиге"; return 1; }
    seed_host_dns "$_h" "$(slot_seed "$_id")" || return 1   # без резолва hysteria упала бы FATAL
    slot_free_socks "$_id" "$(slot_hy2_pid "$_id")"
    if ! proc_alive "$(slot_hy2_pid "$_id")"; then
        log "слот №$_id: запускаю hysteria на socks :$_port (конфиг $2)…"
        : > "$(slot_hy2_log "$_id")" 2>/dev/null || true
        start-stop-daemon -S -b -m -p "$(slot_hy2_pid "$_id")" -x /bin/sh -- -c "exec '$HY2' -c '$(slot_conf "$_id")' >>'$(slot_hy2_log "$_id")' 2>&1"
    fi
    if ! slot_wait_socks "$_port" "$(slot_hy2_pid "$_id")" hysteria 25; then
        log "слот №$_id: hysteria не слушает :$_port ($DAEMON_WAIT_WHY). Лог:"; tail -n 15 "$(slot_hy2_log "$_id")" 2>/dev/null
        return 1
    fi
    slot_hev_up "$_id"          # hev + ожидание xtunN (общий слой)
}
slot_stop_daemons() {   # $1 = id
    _id="$1"
    slot_hev_down "$_id"
    start-stop-daemon -K -p "$(slot_hy2_pid "$_id")" 2>/dev/null
    rm -f "$(slot_hy2_pid "$_id")" 2>/dev/null
}


slot_exclude_endpoint() {   # $1 = id
    _id="$1"
    _ep=$(hy2_endpoint_ip "$(slot_seed "$_id")" "$(slot_conf "$_id")")
    [ -n "$_ep" ] || { log "слот №$_id: endpoint не определён — пропуск анти-петли"; return 0; }
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "$_ep" >/dev/null 2>&1
    log "слот №$_id: endpoint $_ep исключён из маркировки (анти-петля)"
}


cmd_slot_up() {   # $1 = id ; $2 = имя конфига
    _id="$1"; _cfg="$2"
    case "$_id" in 2|3|4) ;; *) log "слот: id = 2..4"; return 1 ;; esac
    [ -n "$_cfg" ] && [ "$_cfg" != "-" ] || { log "слот №$_id: не задан конфиг сервера"; return 1; }
    if ! slot_start_daemons "$_id" "$_cfg"; then
        log "слот №$_id: hy2-несущая не поднялась -> выход живёт по fallback-политике (mark-core)"
        slot_stop_daemons "$_id"
        return 1
    fi
    slot_exclude_endpoint "$_id"
    slot_apply_routing "$_id"
    ct_flush
    log "слот №$_id: hy2-несущая $(slot_tun "$_id") в table $(slot_table "$_id") (конфиг $_cfg)"
    return 0
}
cmd_slot_down() {   # $1 = id
    _id="$1"
    case "$_id" in 2|3|4) ;; *) log "слот: id = 2..4"; return 1 ;; esac
    slot_remove_routing "$_id"
    slot_stop_daemons "$_id"
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "" >/dev/null 2>&1
    rm -f "$(slot_hev_yaml "$_id")" "$(slot_conf "$_id")" 2>/dev/null
    if seed_host_clear "$(slot_seed "$_id")"; then  # ОБЕ копии; HUP конфиг НЕ перечитывает — нужен рестарт
        /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
    fi
    ct_flush
    log "слот №$_id: hy2-несущая снята"
    return 0
}

cmd_slot_health() {   # $1 = id
    _id="$1"
    case "$_id" in 2|3|4) ;; *) return 1 ;; esac
    proc_alive "$(slot_hy2_pid "$_id")" || { log "слот №$_id health: hysteria не жива"; return 1; }
    proc_alive "$(slot_hev_pid "$_id")" || { log "слот №$_id health: hev не жив"; return 1; }
    ip link show "$(slot_tun "$_id")" >/dev/null 2>&1 || { log "слот №$_id health: нет $(slot_tun "$_id")"; return 1; }
    _ip=$(probe_ext_ip "--socks5-hostname $SOCKS_ADDR:$(slot_socks_port "$_id")" 8)
    [ -n "$_ip" ] || { log "слот №$_id health: проба egress пуста"; return 1; }
    return 0
}

case "$1" in

    up)       carrier_run cmd_down cmd_up ;;
    down)     cmd_down ;;
    cold)     : ;;                        # тёплого резерва нет: демонов гасит сам `down` (stop_daemons)
    status)   cmd_status ;;
    health)   carrier_run cmd_down cmd_health ;;   # залипший hev перезапускает на месте (hev_path_check) — берёт несущую
    failover) carrier_run cmd_down cmd_failover ;;

    dns)      if carrier_barred; then set_direct_dns; else set_hy2_dns; fi ;;

    slot-up)     slot_lib_ok || exit 2; carrier_run cmd_slot_down cmd_slot_up "$2" "$3" ;;   # доп-выход (Ф3): 2-я hysteria + hev + xtunN в table 100N
    slot-down)   slot_lib_ok || exit 2; cmd_slot_down "$2" ;;      # доп-выход: снять несущую слота (-> fallback-политика mark-core)
    slot-health) slot_lib_ok || exit 2; cmd_slot_health "$2" ;;    # доп-выход: жив ли выход (watchdog)
    slot-iface)  slot_lib_ok || exit 2; slot_tun "$2" ;;           # имя несущей слота — учёту трафика (владелец имени один: slot-tun-lib.sh)
    *) echo "usage: $0 up|down|cold|status|health|failover|dns|slot-up <id> <cfg>|slot-down <id>|slot-health <id>|slot-iface <id>"; exit 2 ;;
esac
