#!/bin/sh




















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
STATE=/tmp/enodia-watchdog.state
LOCK=/tmp/enodia-watchdog.lock




WD_PID=/tmp/enodia-watchdog.pid
SWITCH_LOCK=/tmp/enodia-switching.lock
HEAL_LOCK=/tmp/enodia-heal.lock    # лок heal.sh (1×/boot) — снимаем при мид-дэй смерти awg0, чтобы heal пересоздал






HEAL_REASON=/tmp/enodia-heal.reason
heal_reason() { echo "$1" > "$HEAL_REASON" 2>/dev/null; }




HEAL_SKIPPED=/tmp/enodia-heal.skipped
LOG=/tmp/enodia-watchdog.log
NOTIFY="$ENODIA_DIR/notify.sh"
NOTIFY_OFF="$ENODIA_STATE/.notify-off"



if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }





if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi



command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }





up_secs() { _ups=$(uptime_s); case "$_ups" in ''|*[!0-9]*) _ups=999999999 ;; esac; echo "$_ups"; }
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}



if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
command -v doh_enabled >/dev/null 2>&1 || doh_enabled() { return 1; }
command -v doh_want >/dev/null 2>&1 || doh_want() { return 1; }   # старая lib без авто-режима
command -v doh_rearm_due >/dev/null 2>&1 || doh_rearm_due() { return 0; }   # lib без паузы ручного DoH — прежний путь





if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }
NF_LANG=$(nf_lang)



HS_DEAD=${HS_DEAD:-180}     # handshake старше этого (сек) => VPS не отвечает
HS_ALIVE=${HS_ALIVE:-120}   # handshake свежее этого (сек) => VPS жив (возврат)



SLOT_KA_MAX=25











CARRIER_GRACE=${CARRIER_GRACE:-60}
CARRIER_UP_STAMP="${CARRIER_UP_STAMP:-/tmp/.enodia-carrier-up.stamp}"   # нет свежей clock-lib → stamp_age даст 999999 ⇒ грейса нет, прежнее поведение






BOOT_GRACE=${BOOT_GRACE:-180}


ACTIVE_NAME="$ENODIA_STATE/.active"
CONFIGS_DIR="$ENODIA_STATE/configs"
SWITCH_VPN="$ENODIA_DIR/switch-vpn.sh"
VPN_TOGGLE="$ENODIA_DIR/vpn-toggle.sh"            # repair: полный переигрыш правил сплита (mark-core + несущая + FORWARD/MASQUERADE + DNS)
FAILOVER_MODE_FILE="$ENODIA_STATE/.failover-mode"   # off|sticky|home; нет файла → sticky
FAILOVER_HOME_FILE="$ENODIA_STATE/.failover-home"   # имя «основного» конфига для home
FAILOVER_ESCALATE_FILE="$ENODIA_STATE/.failover-escalate"  # cross|direct; нет файла → cross
FAILOVER_STAMP=/tmp/enodia-failover.stamp         # троттл повторного перебора в FAILOPEN
FO_MODE_SEEN=/tmp/enodia-failover.mode-seen       # режим резервирования, при котором копилась пауза (см. fo_mode_note)
FAILBACK_STAMP=/tmp/enodia-failback.stamp         # троттл попыток возврата на home
FAILOVER_RETRY=${FAILOVER_RETRY:-600}          # БАЗОВАЯ пауза (сек) между переборами в FAILOPEN; дальше — бэкофф (fo_retry)
FAILOVER_BACKOFF=/tmp/enodia-failover.backoff     # текущая пауза бэкоффа (удваивается на каждом безуспешном свипе пула)
FAILOVER_MAX=${FAILOVER_MAX:-7200}             # кап бэкоффа (сек): 10→20→40→80→120 мин







TUNNEL_RETRY_MAX=${TUNNEL_RETRY_MAX:-1800}
FAILBACK_INTERVAL=${FAILBACK_INTERVAL:-900} # как часто (сек) пробовать возврат на home
WANOUT_COUNT=/tmp/enodia-wanout.count       # подряд провалов egress-пробы через WAN (гистерезис)
WANOUT_EVENT=/tmp/enodia-wanout.event       # эпизод «интернета нет вообще» уже объявлен (гейт события/письма)
WANOUT_SWEEP=/tmp/enodia-wanout.sweep       # когда в последний раз пускали КОНТРОЛЬНЫЙ свип вопреки пробе
WAN_PROBE_FAILS=${WAN_PROBE_FAILS:-2}       # со скольких подряд провалов пробы считаем «интернета нет вообще»
WANOUT_MAX=${WANOUT_MAX:-3600}              # не реже раза в N сек всё же пробуем перебор вслепую (предохранитель)
REUP_STAMP=/tmp/enodia-reup.stamp           # троттл переподъёма awg-несущей ПЕРЕД перебором резервов (см. ниже)
REUP_RETRY=${REUP_RETRY:-1800}              # не чаще раза в N сек: reup рвёт awg0, крутить его каждый тик нельзя
RULEHEAL_STAMP=/tmp/enodia-ruleheal.stamp   # троттл письма о rule-heal (fw3-reload снёс правила сплита)
RULEHEAL_NOTIFY=${RULEHEAL_NOTIFY:-1800}    # не чаще раза в N сек слать письмо о восстановлении правил (анти-спам, если repair не помог)
WIPE_SEEN=/tmp/enodia-splitwipe.seen        # первый (ещё не подтверждённый) детект «правила сплита снесены»
ROUTELOST_SEEN=/tmp/enodia-routelost.seen   # то же для «пропал default несущей из table 1000» — счёт СВОЙ: болезни разные, путать их подтверждения нельзя
RULELOST_SEEN=/tmp/enodia-rulelost.seen     # …и для ЗЕРКАЛЬНОЙ болезни: маршрут на месте, а `ip rule fwmark→1000` пропал (см. carrier_rule_lost)
NONVPN_SEEN=/tmp/enodia-nonvpnwipe.seen     # то же для правил НЕ про VPN (блокировки, запрет IPv6, «доступ домой») при выключенном VPN — см. nonvpn_rules_sweep
NONVPN_TRIED=/tmp/enodia-nonvpnwipe.tried   # когда их чинили в последний раз (+ `.what` — что именно): починка не помогла ⇒ не по кругу
NONVPN_RETRY=${NONVPN_RETRY:-1800}          # не чаще раза в N сек чинить ТО ЖЕ САМОЕ, если прошлая починка его не вернула
AWG0_FIRSTUP=/tmp/enodia-awg0.firstup       # «FAILOPEN здесь поставили МЫ, ожидая ПЕРВЫЙ подъём awg0» — чтобы возврат из него не слал письмо «VPN восстановлен» (ставит ветка «awg0 не поднимался»; снимают гард «STATE не FAILOPEN», ветки «VPS мёртв» и «VPS жив»). По ней же вердикт `standing` судит `boot`
AWG0_SEEN=/tmp/enodia-awg0.seen           # «в ЭТУ загрузку awg0 хоть раз был живым» — отличает ПАДЕНИЕ несущей от «её ещё не поднимали» (см. ветку «awg0 ИСЧЕЗ»); в /tmp ⇒ умирает вместе с загрузкой, как и положено вопросу «в эту загрузку»





CARRIER_SEEN_PFX=/tmp/enodia-carrier-          # <транспорт>.seen / <транспорт>.tries
CARRIER_UP_TRIES=${CARRIER_UP_TRIES:-3}        # сколько раз пробуем поднять НИ РАЗУ не поднимавшуюся несущую, прежде чем отдать вопрос обычной лестнице










HEAL_KICK_TRIES=${HEAL_KICK_TRIES:-3}
HEAL_KICK_SLOW=${HEAL_KICK_SLOW:-3600}         # после потолка — не чаще раза в час
HEAL_KICK_CNT=/tmp/enodia-heal-kick.tries
HEAL_KICK_STAMP=/tmp/enodia-heal-kick.stamp
HEAL_KICK_SAID=/tmp/enodia-heal-kick.said      # «про потолок уже сказано» — строка в лог раз за эпизод, а не раз в тик; она же у вердикта `standing` — «потолок ОБЪЯВЛЕН», граница `boot`





NORAISE_THROTTLE=${NORAISE_THROTTLE:-21600}
WANOUT_FRESH=${WANOUT_FRESH:-900}              # «эпизод без интернета ещё свежий» — столько письмо про awg молчит (закрыть эпизод в этой ветке некому)
HEAL_KICK_MAILED=/tmp/enodia-heal-kick.mailed  # «письмо про потолок уже ушло» — свой флаг, потому что письмо уходит ПОСЛЕ лестницы, а строка в лог — до неё
HEAL_KICK_CFG=/tmp/enodia-heal-kick.cfg        # слепок mtime конфигов awg на момент последней попытки: правка ЧЕЛОВЕКОМ возвращает бюджет, наш же перебор — нет
WIPE_CONFIRM=${WIPE_CONFIRM:-420}              # окно (сек) подтверждения вторым тиком; больше периода cron (120) с запасом
DOMWARM_STAMP=/tmp/enodia-domwarm.stamp           # троттл периодического прогрева доменных правил
DOMWARM_INTERVAL=${DOMWARM_INTERVAL:-3600}     # не чаще раза в N сек: прогрев форкает nslookup на каждый домен



FAILOVER_EPISODE=/tmp/enodia-failover-episode
TRANSPORT_HOME_FILE="$ENODIA_STATE/.transport-home"  # awg|xray|hy2 — предпочитаемый транспорт (ручной выбор в меню); пусто → авто-возврат транспорта выключен
XT_AWG="$ENODIA_DIR/transport-awg.sh"              # плагин awg-несущей (возврат awg-роутинга вместо split-route)
MARK_CORE="$ENODIA_DIR/mark-core.sh"               # ядро маркировки (транспорт-агностично; было в split-route)
TRANSPORT_SH="$ENODIA_DIR/transport.sh"            # ОРКЕСТРАТОР: switch/up/down/health/failover/next — ВСЯ работа с tunnel-транспортами идёт через него (имя файла плагина знает только он)
XSTATE=/tmp/enodia-watchdog.xstate                 # состояние мониторинга tunnel-транспорта (xray/hy2/…): HEALTHY/SUSPECT/FAILED
SUPPORT_SH="$ENODIA_DIR/support.sh"                 # «режим поддержки»: reap гасит истёкший туннель (DRY — не плодим отдельный cron-демон)
SLOTS_SH="$ENODIA_DIR/slots.sh"                      # реестр доп-выходов (мульти-транспорт Ф2): health слотов ниже
VPNSRV_SH="$ENODIA_DIR/vpn-server.sh"                # «доступ домой» (роутер как VPN-сервер): keepalive несущей awgs0 ниже
NOTIFY_EVENT="$ENODIA_DIR/notify-event.sh"           # событийные письма (throttle по ключу) — для отказа доп-выхода
TAB=$(printf '\t')





restore_marking() {
    if [ -f "$MARK_CORE" ]; then sh "$MARK_CORE" >>"$LOG" 2>&1
    elif [ -f "$ENODIA_DIR/split-route.sh" ]; then sh "$ENODIA_DIR/split-route.sh" >>"$LOG" 2>&1; fi
}


restore_awg_carrier() {
    restore_marking
    if [ -f "$XT_AWG" ]; then sh "$XT_AWG" up >>"$LOG" 2>&1; fi
    off_bail "возврата несущей AmneziaWG"
}















uses_marking() {
    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        sh "$ENODIA_DIR/transport.sh" marking "$1" >/dev/null 2>&1
        case "$?" in 0) return 0 ;; 1) return 1 ;; esac
    fi
    case "$1" in awg|xray|hy2|byedpi) return 0 ;; *) return 1 ;; esac
}





command -v carrier_iface >/dev/null 2>&1 || carrier_iface() { ip route show table 1000 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}'; }
carrier_route_dev() {   # тело — отдельной строкой: стенд failopen-direct вырезает функцию по `^}`
    carrier_iface
}








ipt_check_t() {   # $1 = таблица, дальше — правило. `-t` ОБЯЗАН стоять ДО `-C`: у `-C` чейн идёт

    _ipt="$1"; shift
    iptables -t "$_ipt" -C "$@" 2>/dev/null; _iprc=$?
    return "$_iprc"
}
ipt_check() { ipt_check_t filter "$@"; }
split_rules_wiped() {



    _cif=""
    case "$1" in
        zapret)






            [ -f "$ENODIA_STATE/.zapret-on" ] || return 1
            _what="mangle PREROUTING -j ENODIA_ZAPRET"
            ipt_check_t mangle PREROUTING -j ENODIA_ZAPRET; _rc=$?
            ;;
        *)


            uses_marking "$1" || return 1
            _cif=$(carrier_route_dev)
            [ -n "$_cif" ] || return 1
            _what="FORWARD -o $_cif -j ACCEPT"
            ipt_check FORWARD -o "$_cif" -j ACCEPT; _rc=$?
            ;;
    esac
    if [ "$_rc" = 0 ]; then rm -f "$WIPE_SEEN" 2>/dev/null; return 1; fi          # правило есть → всё цело
    if [ "$_rc" != 1 ]; then                                                      # 4=лок занят, прочее=сбой вызова
        log "split-check: iptables -C дал код $_rc (лок занят/сбой) — НЕ сужу, жду следующего тика"
        return 1
    fi



    if [ "$(stamp_age "$WIPE_SEEN")" -le "$WIPE_CONFIRM" ]; then
        return 0                                                                  # подтверждено двумя тиками → wiped
    fi
    date +%s > "$WIPE_SEEN"


    if [ -n "$_cif" ]; then
        log "split-check: $_what не найден (строк в FORWARD: $(iptables -S FORWARD 2>/dev/null | wc -l), MASQ несущей: $(iptables -t nat -S POSTROUTING 2>/dev/null | grep -c -- "-o $_cif -j MASQUERADE")) — жду подтверждения на следующем тике"
    else
        log "split-check: $_what не найден (правил в mangle PREROUTING: $(iptables -t mangle -S PREROUTING 2>/dev/null | wc -l), NFQUEUE в POSTROUTING: $(iptables -t mangle -S POSTROUTING 2>/dev/null | grep -c -- '--queue-num')) — жду подтверждения на следующем тике"
    fi
    return 1
}













carrier_rule_present() {
    ip rule show 2>/dev/null | grep -qE 'fwmark 0x1(/\S+)? lookup 1000'
}
carrier_route_lost() {
    uses_marking "$1" || return 1                  # zapret несущей не держит — сторожить нечего





    if [ -n "$(carrier_route_dev)" ]; then rm -f "$ROUTELOST_SEEN" 2>/dev/null; return 1; fi
    carrier_rule_present || { rm -f "$ROUTELOST_SEEN" 2>/dev/null; return 1; }   # VPN выключен/safety_off — прямой режим НАСТОЯЩИЙ



    if [ "$(stamp_age "$ROUTELOST_SEEN")" -le "$WIPE_CONFIRM" ]; then return 0; fi
    date +%s > "$ROUTELOST_SEEN"
    log "route-check: table 1000 ПУСТА при живой несущей ($1) и целом ip rule — жду подтверждения на следующем тике"
    return 1
}








carrier_rule_lost() {
    uses_marking "$1" || return 1                  # zapret метку не ставит — сторожить нечего

    [ -n "$(carrier_route_dev)" ] || { rm -f "$RULELOST_SEEN" 2>/dev/null; return 1; }
    if carrier_rule_present; then rm -f "$RULELOST_SEEN" 2>/dev/null; return 1; fi


    if [ "$(stamp_age "$RULELOST_SEEN")" -le "$WIPE_CONFIRM" ]; then return 0; fi
    date +%s > "$RULELOST_SEEN"
    log "rule-check: несущая ($1) держит маршрут, а ip rule fwmark→1000 пропал — жду подтверждения на следующем тике"
    return 1
}






do_rule_repair() {   # $1=строка в лог  $2=тема письма  $3=тело письма
    log "$1"
    rm -f "$WIPE_SEEN" "$ROUTELOST_SEEN" "$RULELOST_SEEN" 2>/dev/null   # счёт подтверждений — заново: следующий детект снова начнётся с первого тика
    [ -f "$VPN_TOGGLE" ] && sh "$VPN_TOGGLE" repair >>"$LOG" 2>&1
    if [ "$(stamp_age "$RULEHEAL_STAMP")" -ge "$RULEHEAL_NOTIFY" ]; then
        date +%s > "$RULEHEAL_STAMP"


        notify_ev "rule-heal" 0 "$2" "$3"
    fi
}
heal_split_rules() {
    if [ "$NF_LANG" = en ]; then
        do_rule_repair "rule-heal: несущая ($1) жива, но FORWARD/сплит снесён (fw3-reload?) → vpn-toggle.sh repair" \
            "BE7000: VPN rules restored (firewall reset)" \
"Looks like the router firewall reloaded (a change in the Xiaomi web UI or a firewall
restart) and wiped the VPN routing rules, while the tunnel itself stayed up.
The watchdog noticed the carrier FORWARD rule was gone and replayed the rules (vpn-toggle repair):
marking, FORWARD/MASQUERADE and DNS-through-tunnel are back — split tunneling works again."
        return
    fi
    do_rule_repair "rule-heal: несущая ($1) жива, но FORWARD/сплит снесён (fw3-reload?) → vpn-toggle.sh repair" \
        "BE7000: восстановил правила VPN (сброс firewall)" \
"Похоже, firewall роутера перезагрузился (изменение в веб-панели Xiaomi или перезапуск
фаервола) и снёс правила маршрутизации VPN, хотя сам туннель остался жив.
Watchdog заметил пропажу FORWARD-правила несущей и переиграл правила (vpn-toggle repair):
маркировка, FORWARD/MASQUERADE и DNS-через-туннель восстановлены — сплит-туннель снова работает."
}







nonvpn_q() {   # $1 — скрипт, $2 — что это для человека, дальше — верб с аргументами
    _nvf=$1; _nvl=$2; shift 2
    [ -f "$ENODIA_DIR/$_nvf" ] || return 0
    sh "$ENODIA_DIR/$_nvf" "$@" >/dev/null 2>&1
    [ "$?" = 3 ] && _nvw="${_nvw:+$_nvw, }$_nvl"
    return 0
}
nonvpn_rules_sweep() {
    _nvw=
    nonvpn_q lists-update.sh "блокировки по спискам" wired ipblock
    nonvpn_q geo.sh "гео-«Блок»" wired
    nonvpn_q net-tune.sh "запрет IPv6" wired
    nonvpn_q vpn-server.sh "«доступ домой»" wired
    if [ -z "$_nvw" ]; then rm -f "$NONVPN_SEEN" "$NONVPN_TRIED" "$NONVPN_TRIED.what" 2>/dev/null; return 0; fi



    if [ ! -f "$NONVPN_SEEN" ] || [ "$(stamp_age "$NONVPN_SEEN")" -gt "$WIPE_CONFIRM" ]; then
        date +%s > "$NONVPN_SEEN"
        log "nonvpn-check: в ядре нет ($_nvw) — жду подтверждения следующим тиком"
        return 0
    fi
    rm -f "$NONVPN_SEEN" 2>/dev/null



    if [ -f "$NONVPN_TRIED" ] && [ "$(cat "$NONVPN_TRIED.what" 2>/dev/null)" = "$_nvw" ] \
       && [ "$(stamp_age "$NONVPN_TRIED")" -lt "$NONVPN_RETRY" ]; then
        log "nonvpn-check: после починки снова нет ($_nvw) — повтор не раньше чем через ${NONVPN_RETRY} с"
        return 0
    fi
    date +%s > "$NONVPN_TRIED" 2>/dev/null; printf '%s\n' "$_nvw" > "$NONVPN_TRIED.what" 2>/dev/null
    if [ "$NF_LANG" = en ]; then
        do_rule_repair "rule-heal: VPN выключен или не настроен, а снесено: $_nvw (fw3-reload?) → vpn-toggle.sh repair" \
            "BE7000: blocking and access rules restored (firewall reset)" \
"Looks like the router firewall reloaded (a change in the Xiaomi web UI or a firewall restart) and wiped
rules that live even with the VPN off: address blocking, the IPv6 block or home access.
The watchdog noticed and put them back (vpn-toggle repair). The VPN stays off."
        return 0
    fi
    do_rule_repair "rule-heal: VPN выключен или не настроен, а снесено: $_nvw (fw3-reload?) → vpn-toggle.sh repair" \
        "BE7000: восстановил блокировки и доступ (сброс firewall)" \
"Похоже, firewall роутера перезагрузился (изменение в веб-панели Xiaomi или перезапуск фаервола) и снёс
правила, которые живут и при выключенном VPN: $_nvw.
Watchdog заметил это и вернул их (vpn-toggle repair). VPN остаётся выключенным."
}
heal_carrier_route() {
    if [ "$NF_LANG" = en ]; then
        do_rule_repair "route-heal: несущая ($1) жива, но default из table 1000 пропал → vpn-toggle.sh repair" \
            "BE7000: VPN route restored" \
"The tunnel stayed up (the server answers), but the route into it disappeared from the VPN
routing table — all traffic that should go through the VPN went direct, and site names stopped
resolving. The watchdog noticed and replayed the rules (vpn-toggle repair): the route through the
tunnel and DNS are restored."
        return
    fi
    do_rule_repair "route-heal: несущая ($1) жива, но default из table 1000 пропал → vpn-toggle.sh repair" \
        "BE7000: восстановил маршрут VPN" \
"Туннель остался жив (сервер отвечает), но из таблицы маршрутизации VPN пропал сам маршрут в
него — весь трафик, который должен идти через VPN, уходил напрямую, а имена сайтов переставали
резолвиться. Watchdog заметил это и переиграл правила (vpn-toggle repair): маршрут через туннель
и DNS восстановлены."
}
heal_carrier_rule() {
    if [ "$NF_LANG" = en ]; then
        do_rule_repair "rule-heal: несущая ($1) держит маршрут, но ip rule fwmark→1000 пропал → vpn-toggle.sh repair" \
            "BE7000: VPN routing rule restored" \
"The tunnel is up and the route into it is in place, but the rule that sends marked traffic into
the VPN routing table was missing — so everything that should have gone through the VPN was going
direct, while the router still reported the VPN as working. The watchdog replayed the rules
(vpn-toggle repair): split tunneling works again."
        return
    fi
    do_rule_repair "rule-heal: несущая ($1) держит маршрут, но ip rule fwmark→1000 пропал → vpn-toggle.sh repair" \
        "BE7000: восстановил правило маршрутизации VPN" \
"Туннель поднят, маршрут в него на месте, но пропало правило, которое отправляет помеченный
трафик в таблицу маршрутизации VPN. Из-за этого всё, что должно идти через VPN, шло напрямую —
а роутер по-прежнему показывал, что VPN работает. Watchdog заметил расхождение и переиграл
правила (vpn-toggle repair): раздельное туннелирование снова работает."
}










slot_hs_age() {   # $1 = iface (awgN) -> возраст handshake в сек (999999 = нет)
    [ -n "$WG" ] || { echo 999999; return; }
    _hs=$($WG show "$1" latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
    age_since "$_hs"          # не «now - hs»: скачок часов иначе хоронит живой выход (clock-lib.sh)
}






slot_boot_window() { [ "$(up_secs)" -lt "$BOOT_GRACE" ]; }
slot_fail_event() {   # $1=id $2=cfg $3=fallback $4=причина
    [ -f "$NOTIFY_EVENT" ] || return 0
    _fbl=$([ "$3" = direct ] && echo "напрямую" || echo "через основной туннель")
    sh "$NOTIFY_EVENT" "slot-fail-$1" 3600 \
        "BE7000: доп-выход №$1 недоступен" \
"Дополнительный выход №$1 (сервер $2) не отвечает ($4).
Его трафик переключён на запасной путь: $_fbl.
Выход вернётся автоматически после перезагрузки роутера или при включении вручную в панели." >/dev/null 2>&1
}



bp_sweep_fresh() {
    [ -f /tmp/enodia-byedpi-sweep.lock ] || return 1
    _bts=$(cat /tmp/enodia-byedpi-sweep.lock 2>/dev/null | tr -d ' \r\n')
    case "$_bts" in ''|*[!0-9]*) return 1 ;; esac


    [ "$(age_since "$_bts")" -lt 180 ]
}
slot_health_sweep() {


    [ -f "$SLOTS_SH" ] || return 0



    [ -e "$SWITCH_LOCK" ] && return 0






    [ -f "$ENODIA_STATE/.vpn-off" ] && return 0
    sh "$SLOTS_SH" list-enabled 2>/dev/null | while IFS="$TAB" read -r sid st scfg sfb; do
        if [ "$st" = byedpi ]; then
            bp_sweep_fresh && continue          # идёт браузер-свип — рестарты ciadpi штатны




            if [ -f "$ENODIA_STATE/.byedpi-args-s$sid.sweepbak" ]; then
                log "slot-health: браузер-свип выхода №$sid брошен — восстанавливаю исходную стратегию"
                sh "$ENODIA_DIR/transport-byedpi.sh" sweep-end "$sid" >>"$LOG" 2>&1
            fi









            _rc=2
            [ -f "$TRANSPORT_SH" ] && { sh "$TRANSPORT_SH" slot-health "$sid" >/dev/null 2>&1; _rc=$?; }
            if [ "$_rc" = 0 ]; then
                continue                             # плагин: выход жив (демоны + egress) -> не трогаем
            elif [ "$_rc" = 2 ]; then
                _bp=$(cat "/tmp/enodia-byedpi-s$sid.pid" 2>/dev/null | tr -d ' \r\n')
                if [ -n "$_bp" ] && kill -0 "$_bp" 2>/dev/null && ip link show "xtun$sid" >/dev/null 2>&1; then
                    continue                         # старый плагин: ciadpi жив + tun есть -> считаем живым
                fi
            fi
            log "slot-health: byedpi-выход №$sid просел (ciadpi/tun/egress) -> переподнимаю на месте"
            if [ -f "$TRANSPORT_SH" ] && sh "$TRANSPORT_SH" slot-up "$sid" >>"$LOG" 2>&1; then
                log "slot-health: byedpi-выход №$sid переподнят"
            elif slot_boot_window; then
                log "slot-health: byedpi-выход №$sid не поднялся, но идёт бут — вердикт откладываю до тика после грейса"
            else
                [ -f "$TRANSPORT_SH" ] && sh "$TRANSPORT_SH" slot-down "$sid" >>"$LOG" 2>&1
                slot_fail_event "$sid" "$scfg" "$sfb" "десинк не поднялся"
            fi
            continue
        fi
        if [ "$st" = xray ] || [ "$st" = hy2 ]; then







            [ -f "$TRANSPORT_SH" ] || continue
            sh "$TRANSPORT_SH" slot-health "$sid" >/dev/null 2>&1; _rc=$?
            [ "$_rc" = 0 ] && continue                  # выход жив
            [ "$_rc" = 2 ] && continue                  # плагин старой версии (дрейф деплоя) — судить не по чем, не трогаем
            log "slot-health: $st-выход №$sid ($scfg) не отвечает -> переподнимаю на месте"
            if sh "$TRANSPORT_SH" slot-up "$sid" >>"$LOG" 2>&1 && sh "$TRANSPORT_SH" slot-health "$sid" >/dev/null 2>&1; then
                log "slot-health: $st-выход №$sid переподнят"
            elif slot_boot_window; then
                log "slot-health: $st-выход №$sid ещё не отвечает, но идёт бут (outbound холодный) — вердикт откладываю до тика после грейса"
            else
                sh "$TRANSPORT_SH" slot-down "$sid" >>"$LOG" 2>&1
                slot_fail_event "$sid" "$scfg" "$sfb" "сервер выхода не отвечает"
            fi
            continue
        fi
        [ "$st" = awg ] || continue                 # у zapret-слота несущей нет — сторожить нечего


        [ -n "$WG" ] || continue
        sif="awg$sid"
        if ! ip link show "$sif" >/dev/null 2>&1; then




            if [ "$sfb" = main ] && ip rule show 2>/dev/null | grep -qE "fwmark 0x$sid(/\S+)? lookup 100$sid"; then
                log "slot-health: awg-выход №$sid — несущая исчезла, fallback=main → переигрываю (table 1000)"
                restore_marking
                slot_fail_event "$sid" "$scfg" "$sfb" "несущая исчезла"
            fi
            continue
        fi
        _age=$(slot_hs_age "$sif")
        [ "$_age" -lt "$HS_DEAD" ] && continue       # выход жив — не трогаем









        if $WG show "$sif" persistent-keepalive 2>/dev/null | awk -v cap="$SLOT_KA_MAX" '$2=="off" || $2+0>cap {f=1} END {exit !f}'; then
            _ska="/tmp/enodia-slot-ka.$sid"
            if [ ! -f "$_ska" ]; then
                : > "$_ska"
                log "slot-health: awg-выход №$sid ($scfg): рукопожатию ${_age}с, но keepalive нет (или длиннее ${SLOT_KA_MAX}с) — без трафика это норма; переподнимаю на месте (плагин поставит keepalive; если ключ занят — откажет, причина строкой ниже), вердикт — следующим тиком"
                [ -f "$TRANSPORT_SH" ] && sh "$TRANSPORT_SH" slot-up "$sid" >>"$LOG" 2>&1
            fi
            continue
        fi







        log "slot-health: awg-выход №$sid ($scfg) мёртв (handshake ${_age}с) → гашу несущую → fallback=$sfb"
        if slot_boot_window; then
            [ -f "$TRANSPORT_SH" ] && sh "$TRANSPORT_SH" slot-down "$sid" >>"$LOG" 2>&1
            log "slot-health: идёт бут — письмо о выходе №$sid откладываю до тика после грейса"
            continue
        fi
        [ -f "$TRANSPORT_SH" ] && sh "$TRANSPORT_SH" slot-down "$sid" >>"$LOG" 2>&1
        slot_fail_event "$sid" "$scfg" "$sfb" "handshake ${_age}с"
    done
}


























domain_warm_sweep() {
    [ -f "$ENODIA_DIR/domain.sh" ] || return 0



    [ "$(up_secs)" -ge "$BOOT_GRACE" ] || return 0
    [ "$(stamp_age "$DOMWARM_STAMP")" -ge "$DOMWARM_INTERVAL" ] || return 0
    date +%s > "$DOMWARM_STAMP"
    _dw=$(WARM_TRIES=1 sh "$ENODIA_DIR/domain.sh" warm 2>&1)

    case "$_dw" in
        *"не попал"*|*ПЕРЕПОЛНЕН*|*"не ответил"*)
            log "domain-warm: $(printf '%s' "$_dw" | tr '\n' ' ')" ;;
    esac
}












doh_follow_carrier() {   # $1 = suspect|ok
    command -v doh_untunnel >/dev/null 2>&1 || return 0
    if [ "$1" = suspect ]; then
        doh_untunnel && log "DoH: несущая под подозрением — резолвер уведён МИМО неё (шифрование сохранено, DNS дома жив)"
    else


        doh_retunnel; case $? in
            0) log "DoH: несущая снова везёт — резолвер вернулся в туннель" ;;
            2) log "DoH: несущая везёт, а резолвер ЧЕРЕЗ неё не отвечает — остаётся мимо неё (шифрование сохранено), повтор через $(( ${DOH_RETUNNEL_BACKOFF:-1800} / 60 )) мин" ;;
        esac
    fi
    return 0
}

doh_health_sweep() {
    command -v doh_health_tick >/dev/null 2>&1 || return 0


    [ -e "$SWITCH_LOCK" ] && return 0











    if command -v doh_port_tick >/dev/null 2>&1; then
        doh_port_tick wan_probe_ok; case $? in
            3) log "DoH: DoT текущим путём не отдаёт имён, а DoH того же резолвера отдаёт — шифрованный DNS переведён на DoH" ;;
            4) log "DoH: DoT снова отдаёт имена — шифрованный DNS вернулся на выбранный DoT" ;;

            5) log "DoH: DoT текущим путём не отдаёт имён, и DoH того же резолвера тоже — остаюсь на DoT, следующая попытка переезда — через $(( ${DOH_DOT_RETRY:-3600} / 60 )) мин" ;;
        esac
    fi
    doh_health_tick wan_probe_ok; _dhr=$?
    [ "$_dhr" = 0 ] && return 0
    if [ "$_dhr" = 2 ]; then
        log "DoH (авто): карантин истёк — пробую включить шифрованный DNS снова"
        return 0
    fi
    log "DoH (авто): резолвер перестал отвечать — вернул обычный DNS, авто-режим не трогаю час"
    [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "doh-auto-off" 3600 \
        "BE7000: шифрованный DNS не отвечает — вернул обычный" \
"Роутер сам включал шифрованный DNS (DoH), пока туннель не используется. Резолвер перестал
отвечать: имена не резолвились, и из-за этого не открывались даже те сайты, что работают напрямую.
DNS возвращён на обычный ($DOH_PLAIN_DNS1 / $DOH_PLAIN_DNS2), интернет должен заработать сразу.
Через час роутер попробует включить шифрованный DNS снова. Если это повторяется — смените
резолвер в панели (Сеть → Шифрованный DNS) или выключите там авто-режим." >/dev/null 2>&1
    return 0
}





finish() { slot_health_sweep; doh_health_sweep; domain_warm_sweep; exit "${1:-0}"; }

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >>"$LOG"; }






tsw() {
    sh "$TRANSPORT_SH" switch "$1" >>"$LOG" 2>&1; _tswrc=$?
    off_bail "смены на $1"
    return "$_tswrc"
}



off_bail() {
    [ -f "$ENODIA_STATE/.vpn-off" ] || return 0
    log "VPN выключили вручную посреди $1 — тик дальше не ведёт"
    finish
}

notify() {



    if [ -f "$NOTIFY_OFF" ]; then
        log "notify выключен флагом .notify-off — письмо не отправлено: '$1'"
        return
    fi
    [ -f "$NOTIFY" ] && sh "$NOTIFY" "$1" "$2" >>"$LOG" 2>&1
}













notify_ev() {   # $1 ключ, $2 throttle_sec, $3 тема, $4 текст
    if [ -f "$NOTIFY_EVENT" ]; then
        sh "$NOTIFY_EVENT" "$1" "$2" "$3" "$4" >/dev/null 2>&1
    else
        notify "$3" "$4"
    fi
}








failback_event() {   # $1 transport|server, $2 подпись дома (имя протокола либо сервера)
    ip=$(ext_ip)
    if [ "$1" = server ]; then


        if [ "$NF_LANG" = en ]; then
            notify_ev "failback-server" 1800 "BE7000: VPN is back on the main server $2" \
"The main server $2 answers again — the router returned to it from the backup.
External IP now: ${ip:-unknown}."
        else
            notify_ev "failback-server" 1800 "BE7000: VPN вернулся на основной сервер $2" \
"Основной сервер $2 снова отвечает — роутер вернулся на него с резервного.
Внешний IP сейчас: ${ip:-неизвестен}."
        fi
    elif [ "$NF_LANG" = en ]; then
        notify_ev "failback" 0 "BE7000: back on the home protocol $2" \
"The home protocol $2 carries traffic again — the router returned to it from the backup.
External IP now: ${ip:-unknown}."
    else
        notify_ev "failback" 0 "BE7000: вернулись на домашний протокол $2" \
"Домашний протокол $2 снова везёт — роутер вернулся на него с резервного.
Внешний IP сейчас: ${ip:-неизвестен}."
    fi
}







revived_event() {   # $1 — подпись протокола, на который не ушли
    ip=$(ext_ip)
    if [ "$NF_LANG" = en ]; then
        notify_ev "cross-rollback" 1800 "BE7000: $TLABEL carries traffic again — the move to $1 did not happen" \
"$TLABEL failed the health check, and the watchdog tried to move to $1 — it did not come up.
The rollback brought $TLABEL back, and it carries traffic again: its server apparently recovered
during the move. The connection was interrupted for the duration of the move.
External IP now: ${ip:-unknown}."
    else
        notify_ev "cross-rollback" 1800 "BE7000: $TLABEL снова везёт — переход на $1 не удался" \
"$TLABEL не прошёл проверку здоровья, и сторож попробовал перейти на $1 — тот не поднялся.
Откат вернул $TLABEL, и он снова везёт: похоже, его сервер ожил за время перехода. Связь на время
перехода прерывалась.
Внешний IP сейчас: ${ip:-неизвестен}."
    fi
}





transport_missing_event() {   # $1 — человекочитаемое имя транспорта
    if [ "$NF_LANG" = en ]; then
        notify_ev "transport-missing" 86400 \
            "BE7000: a VPN is selected, but its component is not installed" \
"The router settings select transport $1, but the program itself is not on the router — this is
what a move looks like: a settings backup carries the server choice and the rules, but not the
programs (they are two orders of magnitude heavier).
Right now the router works DIRECTLY: the internet is there, listed sites bypass the VPN.
What to do: open the panel at :8088 → «Components» and install $1 — everything comes up by
itself after that, the settings are already in place."
        return
    fi
    notify_ev "transport-missing" 86400 \
        "BE7000: VPN выбран, но компонент не установлен" \
"В настройках роутера выбран транспорт $1, но самой программы на роутере нет — так бывает после
переезда: бэкап настроек переносит выбор сервера и правила, а программы (они на два порядка
тяжелее) не переносит.
Роутер сейчас работает НАПРЯМУЮ: интернет есть, сайты из списка идут мимо VPN.
Что сделать: откройте панель :8088 → «Компоненты» и поставьте $1 — дальше всё поднимется само,
настройки уже на месте."
}

ext_ip() { probe_ext_ip "" 5; }


fo_mode() {
    m=$(cat "$FAILOVER_MODE_FILE" 2>/dev/null | tr -d ' \t\r\n')
    case "$m" in off|sticky|home) printf '%s' "$m" ;; *) printf 'sticky' ;; esac
}




fo_mode_note() {
    _fmn=$(cat "$FO_MODE_SEEN" 2>/dev/null)
    [ "$_fmn" = "$1" ] && return 0
    echo "$1" > "$FO_MODE_SEEN"
    [ -n "$_fmn" ] || return 0
    rm -f "$FAILOVER_STAMP" "$FAILOVER_BACKOFF" 2>/dev/null
    log "режим резервирования сменился ($_fmn → $1) — пауза попыток сброшена"
    return 0
}



fo_escalate() {
    e=$(cat "$FAILOVER_ESCALATE_FILE" 2>/dev/null | tr -d ' \t\r\n')
    case "$e" in cross|direct) printf '%s' "$e" ;; *) printf 'cross' ;; esac
}



episode_has() { [ -f "$FAILOVER_EPISODE" ] && grep -qw "$1" "$FAILOVER_EPISODE" 2>/dev/null; }
episode_add() { episode_has "$1" || echo "$1" >> "$FAILOVER_EPISODE"; }
episode_reset() { : > "$FAILOVER_EPISODE"; }




transport_home() { cat "$TRANSPORT_HOME_FILE" 2>/dev/null | tr -d ' \t\r\n'; }



transport_label() {
    case "$1" in
        awg)  echo "AmneziaWG" ;;
        xray) echo "Xray" ;;
        hy2)  echo "Hysteria2" ;;
        byedpi) echo "ByeDPI" ;;
        zapret) echo "Zapret" ;;
        *)    echo "$1" ;;
    esac
}


transport_ready() { sh "$TRANSPORT_SH" list 2>/dev/null | grep -qw "$1"; }

cross_target_from_awg() { sh "$TRANSPORT_SH" next awg 2>/dev/null; }




have_awg() { [ -f "$ENODIA_STATE/awg.conf" ]; }






failover_home_name() { _fhn=$(cat "$FAILOVER_HOME_FILE" 2>/dev/null); [ -n "$_fhn" ] || _fhn=default; printf '%s' "$_fhn"; }





awg_watchable() { [ -n "$WG" ] && ip link show awg0 >/dev/null 2>&1; }

awg_hs_alive() { case "$1" in ''|*[!0-9]*) return 1 ;; esac; [ "$1" -le "$HS_ALIVE" ]; }

awg_hs_age() {
    _hsa=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
    case "$_hsa" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$_hsa" -gt 0 ] && age_since "$_hsa" || echo 999999
}

















fo_home_transport_back() {
    case "$1" in
        awg) _htb_why=blind; awg_watchable || return 1 ;;
    esac




    _htb_why=no_orc; [ -f "$TRANSPORT_SH" ] || return 1


    _htb_why=mode; [ "$(fo_mode)" = home ] || return 1
    _htb=$(transport_home)
    case "$1" in
        awg) _htb_why=not_ready; [ -n "$_htb" ] && [ "$_htb" != awg ] && transport_ready "$_htb" ;;
        *)   _htb_why=pair; [ "$_htb" = awg ] && { _htb_why=blind; awg_watchable; } ;;
    esac
}





fo_awg_server_off_home() {
    _aoh_h=$(failover_home_name); _aoh_a=$(cat "$ACTIVE_NAME" 2>/dev/null)
    [ -n "$_aoh_a" ] && [ "$_aoh_a" != "$_aoh_h" ] || return 1
    [ -n "$(cat "$FAILOVER_HOME_FILE" 2>/dev/null)" ] || [ -f "$CONFIGS_DIR/$_aoh_h.conf" ]
}







fo_awg_server_away() {
    _asa_h=$(failover_home_name); _asa_a=$(cat "$ACTIVE_NAME" 2>/dev/null)
    _asa_why=""; [ -n "$_asa_a" ] && [ "$_asa_a" != "$_asa_h" ] || return 1
    _asa_why=gone; [ -f "$CONFIGS_DIR/$_asa_h.conf" ] || return 1
    _asa_why=no_switch; [ -f "$SWITCH_VPN" ]
}




















fo_awg_ladder_reachable() {
    if ip link show awg0 >/dev/null 2>&1; then [ -n "$WG" ]; else have_awg; fi
}
fo_back_on_fail() {
    _bof_h=$(transport_home); [ -n "$_bof_h" ] || return 1
    [ -f "$TRANSPORT_SH" ] || return 1


    carrier_installed "$1" || return 1
    [ "$1" != awg ] || fo_awg_ladder_reachable || return 1
    if [ "$(fo_mode)" = off ]; then
        [ "$1" != awg ] && [ "$_bof_h" = awg ] && awg_fallback_ok && { printf 'awg now'; return 0; }
        return 1
    fi
    [ "$(fo_escalate)" = cross ] || return 1
    _bof_n=$(sh "$TRANSPORT_SH" next "$1" 2>/dev/null)
    [ -n "$_bof_n" ] && [ "$_bof_n" = "$_bof_h" ] && { printf '%s pool' "$_bof_n"; return 0; }
    return 1
}


















carrier_installed() {
    [ -f "$TRANSPORT_SH" ] || return 0
    sh "$TRANSPORT_SH" ready "$1" >/dev/null 2>&1
    [ "$?" = 2 ] && return 0
    sh "$TRANSPORT_SH" installed "$1" >/dev/null 2>&1; _circ=$?
    [ "$_circ" != 1 ]
}







awg_fallback_ok() {
    [ -f "$TRANSPORT_SH" ] || { have_awg; return; }
    sh "$TRANSPORT_SH" ready awg >/dev/null 2>&1; _afo=$?
    if [ "$_afo" = 2 ]; then have_awg; return; fi
    [ "$_afo" = 0 ]
}












carrier_seen()       { [ -f "$CARRIER_SEEN_PFX$1.seen" ]; }
carrier_seen_mark()  { : > "$CARRIER_SEEN_PFX$1.seen" 2>/dev/null || true; }


carrier_tries()      { _cts=$(cat "$CARRIER_SEEN_PFX$1.tries" 2>/dev/null | tr -d ' \r\n')
                       case "$_cts" in ''|*[!0-9]*) _cts=0 ;; esac; printf '%s' "$_cts"; }
carrier_tries_add()  { echo $(( $(carrier_tries "$1") + 1 )) > "$CARRIER_SEEN_PFX$1.tries" 2>/dev/null || true; }
carrier_tries_reset(){ rm -f "$CARRIER_SEEN_PFX$1.tries" 2>/dev/null || true; }




























carrier_absent_unraised() {
    carrier_seen "$1" && return 1
    [ -z "$(carrier_route_dev)" ] || return 1
    heal_running && return 1                       # heal ПРЯМО СЕЙЧАС её и поднимает — не наперегонки
    [ "$(carrier_tries "$1")" -lt "$CARRIER_UP_TRIES" ]
}


















HEAL_STALE=${HEAL_STALE:-900}
heal_running() {
    _hr=$(cat "$HEAL_LOCK" 2>/dev/null | tr -d '\r'); _hr=${_hr%% *}
    case "$_hr" in ''|*[!0-9]*) return 1 ;; esac
    [ -d "/proc/$_hr" ] || return 1




    case "$(tr '\000' ' ' < "/proc/$_hr/cmdline" 2>/dev/null)" in
        *heal.sh*) ;;
        *) return 1 ;;
    esac
    [ "$(age_since "$(stat -c %Y "$HEAL_LOCK" 2>/dev/null)")" -lt "$HEAL_STALE" ]
}
heal_done() { case "$(cat "$HEAL_LOCK" 2>/dev/null | tr -d '\r')" in done*) return 0 ;; esac; return 1; }

heal_kick()       { _hkc=$(cat "$HEAL_KICK_CNT" 2>/dev/null | tr -d ' \r\n')
                    case "$_hkc" in ''|*[!0-9]*) _hkc=0 ;; esac; echo "$_hkc"; }
heal_kick_add()   { echo $(( $(heal_kick) + 1 )) > "$HEAL_KICK_CNT" 2>/dev/null || true
                    date +%s > "$HEAL_KICK_STAMP" 2>/dev/null || true; heal_cfg_save; }
heal_kick_reset() { rm -f "$HEAL_KICK_CNT" "$HEAL_KICK_STAMP" "$HEAL_KICK_SAID" "$HEAL_KICK_MAILED" "$HEAL_KICK_CFG" "$HEAL_SKIPPED" 2>/dev/null || true; }




























heal_cfg_fp() { stat -c '%n:%Y' "$ENODIA_STATE/awg.conf" "$ENODIA_STATE/.active" \
                     "$ENODIA_STATE/amnezia_for_awg.conf" "$CONFIGS_DIR" "$CONFIGS_DIR"/*.conf 2>/dev/null \
                | tr '\n' ' '; }
heal_cfg_save() { heal_cfg_fp > "$HEAL_KICK_CFG" 2>/dev/null || true; }
heal_cfg_changed() {
    [ -f "$HEAL_KICK_CFG" ] || return 1        # попыток ещё не было — и сбрасывать нечего
    _hcc=$(heal_cfg_fp)




    [ -n "$_hcc" ] || return 1
    [ "$_hcc" != "$(cat "$HEAL_KICK_CFG" 2>/dev/null)" ]
}
heal_kick_ok() {
    if heal_cfg_changed; then
        log "конфиг awg изменился после последней попытки — счёт пробуждений heal обнуляю"
        heal_kick_reset
        return 0
    fi
    [ "$(heal_kick)" -lt "$HEAL_KICK_TRIES" ] && return 0



    [ "$(stamp_age "$HEAL_KICK_STAMP")" -ge "$HEAL_KICK_SLOW" ]
}
boot_grace_waived() {
    [ -f "$ENODIA_STATE/.vpn-off" ] && return 1   # выключил человек: поднимать не будем — и обещать нечего
    heal_done || return 1
    _bgw_t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_bgw_t" ] || return 1




    carrier_installed "$_bgw_t" || return 1
    if [ "$_bgw_t" = awg ]; then


        [ ! -f "$AWG0_SEEN" ] && ! ip link show awg0 >/dev/null 2>&1 && [ -z "$(carrier_route_dev)" ]
    else carrier_absent_unraised "$_bgw_t"; fi
}










command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }









clock_tick_sync() {
    command -v clock_boot_sync >/dev/null 2>&1 || return 0
    if clock_boot_sync; then log "$CLOCK_MSG"; fi
    return 0
}



command -v wan_up >/dev/null 2>&1 || wan_up() { _wu=$(wan_iface); [ -n "$_wu" ] || return 1; if [ -r "/sys/class/net/$_wu/carrier" ]; then [ "$(cat "/sys/class/net/$_wu/carrier" 2>/dev/null)" = "1" ] || return 1; fi; return 0; }













wan_probe_ok() {
    _wi=$(wan_iface)
    [ -n "$_wi" ] || return 1
    [ -n "$(probe_ext_ip "--interface $_wi" 4)" ] && return 0



    curl -s -k -o /dev/null --interface "$_wi" --max-time 4 https://8.8.8.8/ 2>/dev/null
}




wan_out_event() {
    date +%s > "$WANOUT_SWEEP"
    [ -f "$WANOUT_EVENT" ] && return 0
    date +%s > "$WANOUT_EVENT"
    log "интернета нет ВООБЩЕ ($1) — перебор серверов подавлен, жду возвращения аплинка"
    [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "wan-down" 1800 \
        "BE7000: нет связи с провайдером" \
"Роутер не видит интернета от провайдера ($1) — недоступен НЕ только VPN, а сеть целиком.
Перебор VPN-серверов на это время приостановлен: без аплинка ни один сервер недостижим,
и перебор лишь греет флеш и засоряет журнал.
Роутер сам заметит возвращение связи и восстановит VPN — делать ничего не нужно." >/dev/null 2>&1
    return 0
}
wan_out_clear() {
    rm -f "$WANOUT_COUNT" "$WANOUT_SWEEP" 2>/dev/null
    [ -f "$WANOUT_EVENT" ] || return 0
    rm -f "$WANOUT_EVENT" 2>/dev/null
    log "аплинк вернулся — перебор серверов снова разрешён"   # wan_out_now ниже судит по $WANOUT_SWEEP



    if command -v doh_bail_forget >/dev/null 2>&1; then doh_bail_forget; fi
    [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "wan-up" 1800 \
        "BE7000: связь с провайдером вернулась" \
"Интернет от провайдера снова доступен. Роутер возобновил обычную работу:
если VPN всё ещё не поднят, сторож переберёт серверы на ближайшем тике." >/dev/null 2>&1
    return 0
}







WANOUT_NOW=${WANOUT_NOW:-300}
wan_out_now() { [ "$(stamp_age "$WANOUT_SWEEP")" -lt "$WANOUT_NOW" ]; }





inet_reachable() {
    if ! wan_up; then
        echo "$WAN_PROBE_FAILS" > "$WANOUT_COUNT"
        wan_out_event "нет дефолт-маршрута или линк опущен"
        return 1
    fi
    if wan_probe_ok; then wan_out_clear; return 0; fi
    _n=$(cat "$WANOUT_COUNT" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
    _n=$((_n + 1)); echo "$_n" > "$WANOUT_COUNT"
    if [ "$_n" -lt "$WAN_PROBE_FAILS" ]; then
        log "egress-проба через WAN не прошла ($_n/$WAN_PROBE_FAILS) — единичный промах, перебор НЕ подавляю"
        return 0
    fi






    if [ -f "$WANOUT_SWEEP" ] && [ "$(stamp_age "$WANOUT_SWEEP")" -ge "$WANOUT_MAX" ]; then
        date +%s > "$WANOUT_SWEEP"
        log "интернета нет по пробе, но подавление идёт ≥$((WANOUT_MAX / 60)) мин — пускаю ОДИН контрольный свип"
        return 0
    fi
    wan_out_event "egress-проба через WAN не отвечает"
    return 1
}





fo_retry() {
    _b=$(cat "$FAILOVER_BACKOFF" 2>/dev/null); case "$_b" in ''|*[!0-9]*) _b=0 ;; esac
    [ "$_b" -lt "$FAILOVER_RETRY" ] && _b=$FAILOVER_RETRY
    [ "$_b" -gt "$FAILOVER_MAX" ] && _b=$FAILOVER_MAX
    printf '%d' "$_b"
}
fo_backoff_bump() {   # $1 — кап (сек) для ЭТОГО вызова; без него общий FAILOVER_MAX. Кап передаёт

    _cap=${1:-$FAILOVER_MAX}
    _b=$(( $(fo_retry) * 2 ))
    [ "$_b" -gt "$_cap" ] && _b=$_cap
    echo "$_b" > "$FAILOVER_BACKOFF"
    log "перебор не помог → следующая попытка не раньше чем через $((_b / 60)) мин"
    return 0
}
fo_backoff_reset() {
    [ -f "$FAILOVER_BACKOFF" ] || return 0
    rm -f "$FAILOVER_BACKOFF" 2>/dev/null
    log "бэкофф перебора сброшен (здоровье вернулось)"
    return 0
}


health_back() { fo_backoff_reset; wan_out_clear; }














ensure_direct_mode() {
    _edev=$(carrier_route_dev)
    [ -n "$_edev" ] || return 0    # table 1000 пуста → прямой режим НАСТОЯЩИЙ, тишина
    log "FAILOPEN, но несущая ($_edev) снова держит default в table 1000 → снимаю (fail-open, не блэкхол)"
    sh "$TRANSPORT_SH" down "$1" >>"$LOG" 2>&1
    echo "FAILOPEN" > "$STATE"








    echo FAILED > "$XSTATE"
}






cross_awg_to_other() {
    [ "$(fo_escalate)" = "cross" ] || return 1
    other=$(cross_target_from_awg)
    [ -n "$other" ] || return 1
    episode_has "$other" && return 1
    episode_add "$other"
    olbl=$(transport_label "$other")




    if [ -f "$AWG0_SEEN" ]; then
        _xw="упал"; _xwe="went down"
        _xwl="Все awg-серверы недоступны."; _xwle="All awg servers are unreachable."
    else
        _xw="не поднялся"; _xwe="failed to come up"
        _xwl="Интерфейс awg0 не удалось создать вовсе (конфиг, ключи или бинари)."
        _xwle="awg0 could not be created at all (config, keys or binaries)."
    fi
    log "awg-пул исчерпан → cross: пробую $other"
    _xsc=0; tsw "$other" || _xsc=1   # оркестратор: релинквиш awg + mark-core + подъём $other



    _xaw=1; _xafl=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    [ "$_xafl" = "$other" ] || _xaw=0
    [ "$_xsc" = 0 ] || _xaw=0
    if [ "$_xaw" = 1 ] && { sh "$TRANSPORT_SH" health "$other" >/dev/null 2>&1 || sh "$TRANSPORT_SH" failover "$other" >>"$LOG" 2>&1; }; then
        off_bail "перебора резервов $other"
        echo NORMAL > "$STATE"; echo HEALTHY > "$XSTATE"
        ip=$(ext_ip)



        if [ "$NF_LANG" = en ]; then
            notify_ev "cross-switch" 0 "BE7000: AmneziaWG $_xwe -> switched to $olbl" \
"$_xwle The router switched over to $olbl automatically.
External IP: ${ip:-unknown}.
To go back to AmneziaWG: panel :8088 -> the VPN card."
        else
            notify_ev "cross-switch" 0 "BE7000: AmneziaWG $_xw -> перешли на $olbl" \
"$_xwl Роутер автоматически переключился на $olbl.
Внешний IP: ${ip:-неизвестен}.
Вернуться на AmneziaWG: панель :8088 -> карточка VPN."
        fi
        return 0
    fi
    off_bail "перебора резервов $other"


    [ "$_xafl" != awg ] && sh "$TRANSPORT_SH" down "$other" >>"$LOG" 2>&1
    [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
    echo FAILOPEN > "$STATE"; echo FAILED > "$XSTATE"
    if [ "$_xaw" = 1 ]; then log "cross: $other тоже недоступен → прямой режим"
    else log "cross: $other не поднялся (флаг: ${_xafl:-—}) → прямой режим"; fi
    return 1
}


count_backups() {
    a=$(cat "$ACTIVE_NAME" 2>/dev/null)
    c=0
    for f in "$CONFIGS_DIR"/*.conf; do
        [ -f "$f" ] || continue
        [ "$(basename "$f" .conf)" = "$a" ] && continue
        c=$((c+1))
    done
    printf '%d' "$c"
}





stamp_age() {
    if [ -f "$1" ]; then
        t=$(cat "$1" 2>/dev/null); case "$t" in ''|*[!0-9]*) t=0 ;; esac
        age_since "$t"
    else
        echo 999999
    fi
}



run_failover() {
    date +%s > "$FAILOVER_STAMP"
    if sh "$SWITCH_VPN" failover >>"$LOG" 2>&1; then
        off_bail "перебора серверов AmneziaWG"
        echo "NORMAL" > "$STATE"
        log "failover: встали на резерв ($(cat "$ACTIVE_NAME" 2>/dev/null))"
        return 0
    else
        off_bail "перебора серверов AmneziaWG"
        echo "FAILOPEN" > "$STATE"
        log "failover: резервы недоступны → прямой режим"
        return 1
    fi
}




WG=""
[ -x "$ENODIA_BIN/awg" ] && WG="$ENODIA_BIN/awg"
[ -z "$WG" ] && command -v wg >/dev/null 2>&1 && WG=wg



[ "$1" = slot-sweep ] && { slot_health_sweep; exit 0; }












SWITCH_STALE=${SWITCH_STALE:-1800}      # дольше этого не длится ни одна наша операция (то же число, что у LOCK_STALE)
switch_lock_held() {
    [ -e "$SWITCH_LOCK" ] || return 1
    _slm=$(date -r "$SWITCH_LOCK" +%s 2>/dev/null)
    case "$_slm" in ''|*[!0-9]*) return 0 ;; esac
    [ "$(age_since "$_slm")" -lt "$SWITCH_STALE" ]
}




















LOCK_STALE=${LOCK_STALE:-1800}
TICK_STUCK=${TICK_STUCK:-300}
tick_lock_stuck() {
    [ -e "$LOCK" ] || return 1
    _tla=$(stamp_age "$LOCK")
    [ "$_tla" -lt "$LOCK_STALE" ] || return 1
    _trp=$(cat "$WD_PID" 2>/dev/null | tr -d ' \r\n')
    case "$_trp" in
        ''|*[!0-9]*) [ "$_tla" -ge "$TICK_STUCK" ] ;;
        *) [ ! -d "/proc/$_trp" ] ;;
    esac
}



























































fo_standing() {
    _fs_m=$(fo_mode); _fs_s=home; _fs_b=none; _fs_to=""; _fs_in=-1; _fs_why=""; _fs_of=""; _fs_ofa=""; _fs_hw=""
    _fs_t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n'); [ -n "$_fs_t" ] || _fs_t=awg
    _fs_h=$(transport_home)
    _fs_st=$(cat "$STATE" 2>/dev/null)
    _fs_tc=0; [ -f "$TRANSPORT_SH" ] && { sh "$TRANSPORT_SH" configured >/dev/null 2>&1; _fs_tc=$?; }
    if [ "$_fs_tc" = 1 ]; then
        _fs_s=none
    elif [ -f "$ENODIA_STATE/.vpn-off" ]; then
        _fs_s=off
    elif [ "$_fs_st" = FAILOPEN ]; then
        _fs_s=direct













        [ "$_fs_t" = awg ] && [ -f "$AWG0_FIRSTUP" ] && [ ! -f "$HEAL_KICK_SAID" ] && wan_up && ! wan_out_now && have_awg && carrier_installed awg && _fs_s=boot
    elif [ "$_fs_t" != awg ] && [ "$(cat "$XSTATE" 2>/dev/null)" = FAILED ]; then


        _fs_s=direct
    else




        _fs_away=0
        if [ "$_fs_t" = awg ] && fo_awg_server_off_home; then _fs_away=1; fi
        if [ -n "$_fs_h" ] && [ "$_fs_h" != "$_fs_t" ]; then
            _fs_s=reserve
            if fo_home_transport_back "$_fs_t"; then _fs_b=transport; _fs_to=$_fs_h; else _fs_why=$_htb_why; fi
        elif [ "$_fs_away" = 1 ]; then
            _fs_s=reserve
        elif [ -z "$_fs_h" ]; then
            _fs_s=unset
        fi









        if [ "$_fs_b" = none ] && [ "$_fs_away" = 1 ]; then
            _fs_w2=""
            if ! awg_watchable; then _fs_w2=blind
            elif [ "$_fs_m" != home ]; then _fs_w2=mode
            elif ! fo_awg_server_away; then _fs_w2=$_asa_why





            else _fs_b=server; _fs_to=$(failover_home_name); _fs_hw=$_fs_why; _fs_why=""
            fi
            [ -n "$_fs_why" ] || _fs_why=$_fs_w2
        fi
    fi








    _fs_grace=0
    if [ "$_fs_b" != none ]; then
        _fs_up=$(up_secs)
        if [ "$_fs_up" -lt "$BOOT_GRACE" ] && ! boot_grace_waived; then _fs_grace=1; fi
    fi
    if [ "$_fs_b" != none ]; then








        if switch_lock_held; then _fs_why=switching
        elif tick_lock_stuck; then _fs_why=stuck
        elif [ "$_fs_t" = awg ]; then

            awg_hs_alive "$(awg_hs_age)" || _fs_why=unhealthy
        elif [ "$(cat "$XSTATE" 2>/dev/null)" = SUSPECT ] || { [ "$_fs_grace" = 0 ] && ! carrier_seen "$_fs_t"; }; then




























            if ! wan_up || wan_out_now; then _fs_why=wan
            elif ! carrier_seen "$_fs_t"; then







                if heal_running; then _fs_why=raising





                elif ! carrier_rule_present; then _fs_why=unwired
                elif [ "$(carrier_tries "$_fs_t")" -lt "$CARRIER_UP_TRIES" ]; then _fs_why=raising

                else _fs_why=unhealthy
                fi
            else _fs_why=unhealthy
            fi
        fi
    fi






    if [ "$_fs_s" = direct ] && [ "$_fs_t" != awg ] && [ "$_fs_m" = off ] && ! awg_fallback_ok \
       && { carrier_seen "$_fs_t" || [ "$(carrier_tries "$_fs_t")" -ge "$CARRIER_UP_TRIES" ]; }; then
        _fs_why=mode
    fi






    if [ "$_fs_s" = direct ] && ! carrier_installed "$_fs_t" \
       && { [ "$_fs_t" != awg ] || [ -f "$ENODIA_STATE/awg.conf" ]; }; then
        _fs_why=noprog
    fi




    if [ "$_fs_s" = reserve ] && [ "$_fs_b" != transport ]; then
        _fs_ofr=$(fo_back_on_fail "$_fs_t")
        [ -n "$_fs_ofr" ] && { _fs_of=${_fs_ofr%% *}; _fs_ofa=${_fs_ofr##* }; }
    fi
    if [ "$_fs_b" != none ]; then
        _fs_in=$(( FAILBACK_INTERVAL - $(stamp_age "$FAILBACK_STAMP") )); [ "$_fs_in" -lt 0 ] && _fs_in=0




        if [ "$_fs_grace" = 1 ]; then
            _fs_g=$(( BOOT_GRACE - _fs_up )); [ "$_fs_g" -gt "$_fs_in" ] && _fs_in=$_fs_g
        fi
    fi
    printf 'standing=%s\nback=%s\nback_to=%s\nback_in=%s\nmode=%s\nback_why=%s\nhome_why=%s\nback_on_fail=%s\nback_on_fail_at=%s\n' "$_fs_s" "$_fs_b" "$_fs_to" "$_fs_in" "$_fs_m" "$_fs_why" "$_fs_hw" "$_fs_of" "$_fs_ofa"
}


[ "$1" = standing ] && { fo_standing; exit 0; }










if [ -e "$SWITCH_LOCK" ]; then
    switch_lock_held && exit 0
    log "switching-лок протух (старше ${SWITCH_STALE}с) — держатель завис или убит, снимаю"
    rm -f "$SWITCH_LOCK" 2>/dev/null
fi







if [ -e "$LOCK" ]; then
    if [ "$(stamp_age "$LOCK")" -lt "$LOCK_STALE" ]; then exit 0; fi
    log "лок сторожа протух (возраст $(stamp_age "$LOCK")с ≥ ${LOCK_STALE}с) — прошлый тик завис/убит, перехватываю"
fi
date +%s > "$LOCK"
echo $$ > "$WD_PID"        # «держатель жив?» — вопрос вердикта, см. tick_running

trap 'rm -f "$LOCK" "$WD_PID"' EXIT
trap 'exit 1' INT TERM HUP PIPE





[ -f "$SUPPORT_SH" ] && sh "$SUPPORT_SH" reap >/dev/null 2>&1










if doh_want 2>/dev/null && ! doh_running 2>/dev/null && doh_rearm_due; then
    log "DoH: https_dns_proxy не запущен, а DoH нужен (тумблер/авто-режим) → поднимаю"
    doh_start >>"$LOG" 2>&1
fi















if [ -n "$DOH_ADDR" ] && [ -n "$DOH_PORT" ] && [ ! -e "$SWITCH_LOCK" ] \
   && doh_want 2>/dev/null && doh_running 2>/dev/null && doh_rearm_due \
   && [ -f "$ENODIA_DIR/transport.sh" ] \
   && ! grep -q "server=$DOH_ADDR#$DOH_PORT" /etc/dnsmasq.d/00-upstream.conf 2>/dev/null; then
    log "DoH: резолвер жив, а dnsmasq смотрит мимо него → возвращаю указатель (transport.sh dns)"
    sh "$ENODIA_DIR/transport.sh" dns >>"$LOG" 2>&1
fi



command -v doh_log_rotate >/dev/null 2>&1 && doh_log_rotate




command -v doh_custom_refresh >/dev/null 2>&1 && doh_custom_refresh









[ -f "$ENODIA_DIR/usb-offload.sh" ] && sh "$ENODIA_DIR/usb-offload.sh" mount-ensure >>"$LOG" 2>&1








up=$(up_secs)



clock_tick_sync
if [ "$up" -lt "$BOOT_GRACE" ]; then



    if boot_grace_waived; then
        log "boot-grace: uptime ${up}с < ${BOOT_GRACE}с, но heal уже отработал, а несущей нет вовсе — грейс снимаю (бинарь/накопитель приехали после heal, поднять несущую больше некому)"
    else
        log "boot-grace: uptime ${up}с < ${BOOT_GRACE}с — пропускаю тик (первичный подъём несущей за heal.sh)"
        exit 0
    fi
fi










if ip link show awg0 >/dev/null 2>&1; then date +%s > "$AWG0_SEEN" 2>/dev/null || true; fi








if [ -f "$AWG0_FIRSTUP" ] && [ "$(cat "$STATE" 2>/dev/null)" != "FAILOPEN" ]; then
    rm -f "$AWG0_FIRSTUP" 2>/dev/null
fi







TRANSPORT_OK=1
if [ -f "$TRANSPORT_SH" ]; then
    sh "$TRANSPORT_SH" configured >/dev/null 2>&1; _tc=$?
    [ "$_tc" = 1 ] && TRANSPORT_OK=0
fi








if [ -f "$ENODIA_STATE/.vpn-off" ]; then TRANSPORT_OK=0; fi












mark_above_miwifi_ok() {
    mi=$(iptables -t mangle -nL PREROUTING --line-numbers 2>/dev/null | awk '/miwifi|ipt_compiler|NFQUEUE/{print $1; exit}')
    [ -z "$mi" ] && return 0   # фичи Xiaomi нет — сторожить нечего
    mk=$(iptables -t mangle -nL PREROUTING --line-numbers 2>/dev/null | awk '/match-set iplist_set dst/ && /MARK set/{print $1; exit}')





    [ -z "$mk" ] && [ "$TRANSPORT_OK" = 0 ] && return 0
    [ -n "$mk" ] && [ "$mk" -lt "$mi" ]   # MARK есть И выше первой miwifi-цепочки
}
if ! mark_above_miwifi_ok; then
    log "mipctld-guard: маркировка iplist_set ниже/мимо miwifi — переигрываю mark-core"
    restore_marking
fi










if [ -f "$VPNSRV_SH" ] && [ -f "$ENODIA_STATE/server/.on" ] && ! ip link show awgs0 >/dev/null 2>&1; then
    log "доступ домой: сервер включён, но несущей awgs0 нет (демон умер?) → поднимаю"
    sh "$VPNSRV_SH" up >>"$LOG" 2>&1
fi




















if [ "$TRANSPORT_OK" = 0 ]; then nonvpn_rules_sweep; finish; fi

TRANSPORT=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
if [ -n "$TRANSPORT" ] && [ "$TRANSPORT" != "awg" ] && [ -f "$TRANSPORT_SH" ]; then
    TLABEL=$(transport_label "$TRANSPORT")
    xcur=HEALTHY; [ -f "$XSTATE" ] && xcur=$(cat "$XSTATE")

    if sh "$TRANSPORT_SH" health "$TRANSPORT" >>"$LOG" 2>&1; then





        carrier_seen_mark "$TRANSPORT"; carrier_tries_reset "$TRANSPORT"
        if [ "$xcur" != "HEALTHY" ]; then echo HEALTHY > "$XSTATE"; episode_reset; log "$TRANSPORT health: ок"; fi
        doh_follow_carrier ok       # несущая везёт ⇒ резолвер можно вернуть в туннель
        health_back   # бэкофф перебора и эпизод «интернета нет» закрыты: туннель жив ⇒ аплинк тоже













        if [ "$(cat "$STATE" 2>/dev/null)" != "NORMAL" ]; then




            uses_marking "$TRANSPORT" && restore_marking
            echo NORMAL > "$STATE"
        fi


        split_rules_wiped "$TRANSPORT" && heal_split_rules "$TRANSPORT"


        carrier_route_lost "$TRANSPORT" && heal_carrier_route "$TRANSPORT"


        carrier_rule_lost "$TRANSPORT" && heal_carrier_rule "$TRANSPORT"



        if fo_home_transport_back "$TRANSPORT" \
           && [ "$(stamp_age "$FAILBACK_STAMP")" -ge "$FAILBACK_INTERVAL" ]; then
            ahs=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
            case "$ahs" in ''|*[!0-9]*) ahs=0 ;; esac
            if [ "$ahs" -gt 0 ] && awg_hs_alive "$(age_since "$ahs")"; then
                date +%s > "$FAILBACK_STAMP"
                log "home-transport: awg жив → возврат на AmneziaWG"

                if tsw awg; then
                    failback_event transport "$(transport_label awg)"
                fi
            fi
        fi
        finish
    fi









    if ! carrier_installed "$TRANSPORT"; then
        if [ "$xcur" != FAILED ]; then
            log "transport=$TRANSPORT, но компонент не установлен — лестницу не кручу (ставить в панели: «Компоненты»)"
            [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
            echo "FAILOPEN" > "$STATE"; echo FAILED > "$XSTATE"
            transport_missing_event "$TLABEL"
        fi
        finish
    fi





    _cg=$(stamp_age "$CARRIER_UP_STAMP")
    if [ "$_cg" -lt "$CARRIER_GRACE" ]; then
        log "$TRANSPORT health: осечка, но несущую подняли ${_cg}с назад (грейс ${CARRIER_GRACE}с) — жду прогрева"
        finish
    fi







    if [ "$xcur" = "HEALTHY" ] && ! carrier_absent_unraised "$TRANSPORT"; then
        echo SUSPECT > "$XSTATE"; episode_reset
        log "$TRANSPORT health: осечка (жду подтверждения на следующем тике)"



        doh_follow_carrier suspect
        finish
    fi




    if ! inet_reachable; then
        log "$TRANSPORT health: провал, но интернета нет вообще — не перебираю, жду аплинка"
        exit 0
    fi


    clock_tick_sync




















    if ! carrier_seen "$TRANSPORT"; then




        if heal_running; then log "$TRANSPORT: несущую поднимает heal (лок держит живой прогон) — не мешаю"; finish; fi











        if ! carrier_rule_present && [ "$(cat "$STATE" 2>/dev/null)" != "FAILOPEN" ]; then
            finish
        fi
        _cnt=$(carrier_tries "$TRANSPORT")
        if [ "$_cnt" -lt "$CARRIER_UP_TRIES" ]; then
            carrier_tries_add "$TRANSPORT"
            log "$TRANSPORT: несущую в эту загрузку не поднимали ни разу (heal не смог — бинарь/накопитель приехали позже) → поднимаю, попытка $((_cnt + 1)) из $CARRIER_UP_TRIES"
            sh "$TRANSPORT_SH" up "$TRANSPORT" >>"$LOG" 2>&1
            finish
        fi




        if [ "$_cnt" = "$CARRIER_UP_TRIES" ]; then
            carrier_tries_add "$TRANSPORT"
            log "$TRANSPORT: несущая не поднялась за $CARRIER_UP_TRIES попытки — дальше обычная лестница"
        fi
    fi

    mode=$(fo_mode)
    fo_mode_note "$mode"









    if [ "$xcur" = FAILED ] && [ "$mode" != off ]; then
        ensure_direct_mode "$TRANSPORT"
        _ret=$(fo_retry); [ "$_ret" -gt "$TUNNEL_RETRY_MAX" ] && _ret=$TUNNEL_RETRY_MAX
        _left=$(( _ret - $(stamp_age "$FAILOVER_STAMP") ))
        if [ "$_left" -gt 0 ]; then
            log "$TRANSPORT мёртв, уже FAILOPEN — прямой режим (следующая попытка через $((_left / 60)) мин)"
            finish
        fi
        episode_reset   # свежая попытка ВСЕЙ лестницы: вдруг ожил другой транспорт
        log "$TRANSPORT всё ещё мёртв, FAILOPEN → повторная попытка восстановления"
    fi

    episode_add "$TRANSPORT"
    log "$TRANSPORT health: подтверждённый сбой (режим=$mode)"

    if [ "$mode" = "off" ]; then








        _fb_awg=0; _fb_why=absent
        if awg_fallback_ok; then
            _fb_why=failed
            _ret=$(fo_retry); [ "$_ret" -gt "$TUNNEL_RETRY_MAX" ] && _ret=$TUNNEL_RETRY_MAX
            if [ "$xcur" != FAILED ] || [ "$(stamp_age "$FAILOVER_STAMP")" -ge "$_ret" ]; then
                date +%s > "$FAILOVER_STAMP"
                log "$TRANSPORT режим=off → фолбэк на AmneziaWG"
                _fb_awg=1
                tsw awg || _fb_awg=0   # релинквиш tunnel + подъём awg-несущей + .transport=awg
                [ "$_fb_awg" = 1 ] && [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" = awg ] || _fb_awg=0
                if [ "$_fb_awg" = 0 ]; then





                    if [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" = "$TRANSPORT" ] \
                       && sh "$TRANSPORT_SH" health "$TRANSPORT" >>"$LOG" 2>&1; then
                        log "$TRANSPORT режим=off: AmneziaWG не поднялся, но сам $TRANSPORT снова везёт — остаёмся на нём"
                        revived_event "$(transport_label awg)"
                        finish
                    fi



                    log "$TRANSPORT режим=off: AmneziaWG не поднялся → прямой режим"
                    if [ "$xcur" = FAILED ]; then fo_backoff_bump "$TUNNEL_RETRY_MAX"; fi
                fi
            fi
        fi
        if [ "$_fb_awg" = 1 ]; then
            echo FAILED > "$XSTATE"
            ip=$(ext_ip)
            if [ "$NF_LANG" = en ]; then
                notify_ev "cross-switch" 0 "BE7000: $TLABEL went down -> back to AmneziaWG" \
"$TLABEL failed the health check (daemon/tunnel/egress probe).
Auto-failover is off (mode off) — the router returned to AmneziaWG (awg0).
External IP now: ${ip:-unknown}.
To turn $TLABEL back on: panel :8088 -> the VPN card."
            else
            notify_ev "cross-switch" 0 "BE7000: $TLABEL упал -> вернулись на AmneziaWG" \
"$TLABEL не прошёл проверку здоровья (демон/туннель/проба egress).
Авто-failover выключен (режим off) — роутер вернулся на AmneziaWG (awg0).
Внешний IP сейчас: ${ip:-неизвестен}.
Снова включить $TLABEL: панель :8088 -> карточка VPN."
            fi
        else




            if [ "$xcur" != FAILED ]; then
                if [ "$_fb_why" = failed ]; then
                    _fb_ru="AmneziaWG не поднялся"; _fb_en="AmneziaWG failed to come up"
                    _fb_tru="Сторож повторит переход сам (не чаще раза в 10–30 мин); вернуть $TLABEL сразу: панель :8088 -> карточка VPN."
                    _fb_ten="The watchdog retries by itself (every 10–30 min); to bring $TLABEL back now: panel :8088 -> the VPN card."
                else
                    _fb_ru="AmneziaWG не установлен или не настроен"; _fb_en="AmneziaWG is not installed or not set up"
                    _fb_tru="Снова поднять $TLABEL: панель :8088 -> карточка VPN."
                    _fb_ten="To bring $TLABEL back up: panel :8088 -> the VPN card."
                    log "$TRANSPORT режим=off, AmneziaWG не установлен (нет конфига или программы) → прямой режим (fail-open)"
                fi
                sh "$TRANSPORT_SH" down "$TRANSPORT" >>"$LOG" 2>&1
                echo FAILED > "$XSTATE"
                ip=$(ext_ip)
                if [ "$NF_LANG" = en ]; then
                    notify_ev "vpn-failopen" 0 "BE7000: $TLABEL went down -> direct mode" \
"$TLABEL failed the health check (daemon/tunnel/egress probe).
Auto-failover is off (mode off) and $_fb_en — the router is in DIRECT
mode: traffic and DNS bypass the VPN (if the ISP link is up, the internet works),
listed sites are unavailable.
External IP now: ${ip:-unknown}.
$_fb_ten"
                else
                notify_ev "vpn-failopen" 0 "BE7000: $TLABEL упал -> прямой режим" \
"$TLABEL не прошёл проверку здоровья (демон/туннель/проба egress).
Авто-failover выключен (режим off), $_fb_ru — роутер в ПРЯМОМ
режиме: трафик и DNS идут мимо VPN (если связь с провайдером есть, интернет
работает), сайты из списка недоступны.
Внешний IP сейчас: ${ip:-неизвестен}.
$_fb_tru"
                fi
            else





                ensure_direct_mode "$TRANSPORT"
                echo FAILED > "$XSTATE"
            fi
        fi
        finish
    fi


    log "→ перебор резервов $TRANSPORT"


    date +%s > "$FAILOVER_STAMP"
    if sh "$TRANSPORT_SH" failover "$TRANSPORT" >>"$LOG" 2>&1; then
        off_bail "перебора резервов $TRANSPORT"
        echo HEALTHY > "$XSTATE"
        log "$TRANSPORT-failover: встали на резервный сервер"
        finish
    fi
    off_bail "перебора резервов $TRANSPORT"




    esc=$(fo_escalate)
    other=$(sh "$TRANSPORT_SH" next "$TRANSPORT")
    if [ "$esc" = "cross" ] && [ -n "$other" ] && ! episode_has "$other"; then
        episode_add "$other"
        log "$TRANSPORT-пул исчерпан → cross: переключаюсь на $other"





        _xsw=1; _xsvf=0
        tsw "$other" || _xsw=0   # релинквиш tunnel + подъём несущей $other (switch уже записал .transport)
        _xfl=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
        [ "$_xfl" = "$other" ] || _xsw=0
        if [ "$_xsw" = 0 ] && [ "$_xfl" = "$TRANSPORT" ] && sh "$TRANSPORT_SH" health "$TRANSPORT" >>"$LOG" 2>&1; then


            log "cross: $other не поднялся, но сам $TRANSPORT снова везёт — остаёмся на нём"
            revived_event "$(transport_label "$other")"
        elif [ "$_xsw" = 1 ] && sh "$TRANSPORT_SH" health "$other" >/dev/null 2>&1; then

            echo "NORMAL" > "$STATE"; echo HEALTHY > "$XSTATE"
            log "cross: $other жив — остаёмся на нём"
        elif [ "$_xsw" = 1 ] && [ "$other" = "awg" ] && [ -f "$SWITCH_VPN" ] && { _xsvf=1; sh "$SWITCH_VPN" failover >>"$LOG" 2>&1; }; then


            off_bail "перебора серверов AmneziaWG"
            echo "NORMAL" > "$STATE"; echo HEALTHY > "$XSTATE"
            log "cross: текущий awg мёртв → встали на awg-резерв"
        elif [ "$_xsw" = 1 ] && [ "$other" != "awg" ] && sh "$TRANSPORT_SH" failover "$other" >>"$LOG" 2>&1; then

            off_bail "перебора резервов $other"
            echo "NORMAL" > "$STATE"; echo HEALTHY > "$XSTATE"
            log "cross: перебор резервов $other — встали"
        else
            off_bail "перебора резервов $other"
            echo "FAILOPEN" > "$STATE"; echo FAILED > "$XSTATE"
            if [ "$_xsw" = 1 ]; then log "cross: $other тоже недоступен → прямой режим"
            else log "cross: $other не поднялся (флаг: ${_xfl:-—}) → прямой режим"; fi













            if [ "$_xfl" = awg ]; then
                [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
                fo_backoff_bump
            else
                ensure_direct_mode "$_xfl"
                fo_backoff_bump "$TUNNEL_RETRY_MAX"
            fi







            if [ "$xcur" != FAILED ] && [ "$_xsvf" = 0 ]; then
            _xol=$(transport_label "$other")
            ip=$(ext_ip)
            if [ "$NF_LANG" = en ]; then
                if [ "$_xsw" = 1 ]; then _xwhy="$_xol is unreachable as well"; else _xwhy="$_xol failed to come up"; fi
                notify_ev "vpn-failopen" 0 "BE7000: $TLABEL and its backups are unreachable -> direct mode" \
"$TLABEL went down and none of its backups came up; switching over to $_xol failed too: $_xwhy.
The router is in DIRECT mode (safety_off): traffic and DNS bypass the VPN — if the ISP link is up,
the internet works; listed sites are unavailable.
External IP now: ${ip:-unknown}.
The watchdog keeps retrying by itself; to bring the VPN back now: panel :8088 -> the VPN card."
            else
                if [ "$_xsw" = 1 ]; then _xwhy="$_xol тоже недоступен"; else _xwhy="$_xol не поднялся"; fi
                notify_ev "vpn-failopen" 0 "BE7000: $TLABEL и резервы недоступны -> прямой режим" \
"$TLABEL упал, и ни один его резерв не поднялся; переход на другой протокол тоже не удался: $_xwhy.
Роутер в ПРЯМОМ режиме (safety_off): трафик и DNS идут мимо VPN — если связь с провайдером есть,
интернет работает; сайты из списка недоступны.
Внешний IP сейчас: ${ip:-неизвестен}.
Сторож повторит попытку сам; вернуть VPN сразу: панель :8088 -> карточка VPN."
            fi
            fi
        fi
        finish
    fi




    if [ "$xcur" != FAILED ]; then
        log "$TRANSPORT-пул исчерпан → прямой режим (escalate=$esc)"
        sh "$TRANSPORT_SH" down "$TRANSPORT" >>"$LOG" 2>&1
        [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
        echo "FAILOPEN" > "$STATE"; echo FAILED > "$XSTATE"
        ip=$(ext_ip)
        if [ "$NF_LANG" = en ]; then
            notify_ev "vpn-failopen" 0 "BE7000: $TLABEL and its backups are unreachable -> direct mode" \
"$TLABEL went down and none of its backups came up. The router is in DIRECT mode
(safety_off): traffic and DNS bypass the VPN — if the ISP link is up, the internet
works; listed sites are unavailable.
External IP now: ${ip:-unknown}.
To bring the VPN back by hand: panel :8088 -> the VPN card."
        else
        notify_ev "vpn-failopen" 0 "BE7000: $TLABEL и резервы недоступны -> прямой режим" \
"$TLABEL упал, и ни один его резерв не поднялся. Роутер в ПРЯМОМ режиме
(safety_off): трафик и DNS идут мимо VPN — если связь с провайдером есть,
интернет работает; сайты из списка недоступны.
Внешний IP сейчас: ${ip:-неизвестен}.
Вернуть VPN вручную: панель :8088 -> карточка VPN."
        fi


    else



        fo_backoff_bump "$TUNNEL_RETRY_MAX"
        ensure_direct_mode "$TRANSPORT"
        log "$TRANSPORT-пул исчерпан, остаёмся в прямом режиме (escalate=$esc)"
    fi
    finish
fi















cur="NORMAL"
[ -f "$STATE" ] && cur=$(cat "$STATE")

if ip link show awg0 >/dev/null 2>&1; then








    { [ -e "$HEAL_KICK_CNT" ] || [ -e "$HEAL_SKIPPED" ]; } && heal_kick_reset
else
    if ! wan_up; then exit 0; fi    # WAN опущен: и чинить нечего, и свип выходов дал бы ложные отказы







    if [ -f "$ENODIA_STATE/awg.conf" ] && ! carrier_installed awg; then
        if [ "$cur" != "FAILOPEN" ]; then
            log "transport=awg, но компонент не установлен (бинарей нет) — heal-лок НЕ снимаю, пересоздавать awg0 нечем"
            [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
            echo "FAILOPEN" > "$STATE"
            transport_missing_event AmneziaWG
        fi
        finish
    fi
    if [ -f "$ENODIA_STATE/awg.conf" ]; then








        HEAL_BUSY=0; heal_running && HEAL_BUSY=1




        HEAL_KICK_CAPPED=0


        heal_lock_release() {   # снять лок heal — ТОЛЬКО если он не бежит и попытки не исчерпаны
            [ "$HEAL_BUSY" = 1 ] && { log "heal сейчас работает — лок не трогаю, подъём awg0 за ним"; return 0; }
            if ! heal_kick_ok; then
                HEAL_KICK_CAPPED=1





                [ -f "$HEAL_KICK_SAID" ] || { : > "$HEAL_KICK_SAID" 2>/dev/null
                    log "снятий heal-лока было $(heal_kick), awg0 так и не создан — дальше не чаще раза в $((HEAL_KICK_SLOW / 60)) мин; резервов $(count_backups), эскалация $(fo_escalate), режим $(fo_mode) — причина не в том, что heal не добежал (смотрите конфиг awg, ключи и бинари)"; }
                return 0
            fi
            heal_kick_add


            rm -f "$HEAL_LOCK" "$HEAL_SKIPPED" 2>/dev/null
            heal_reason "$1"
        }
        if [ "$cur" != "FAILOPEN" ]; then







            if [ ! -f "$AWG0_SEEN" ]; then
                log "transport=awg, но awg0 в эту загрузку ещё не поднимался (компонент/конфиг приехали позже) → safety_off + снимаю heal-лок; письма нет — это не падение"
                [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
                echo "FAILOPEN" > "$STATE"





                : > "$AWG0_FIRSTUP" 2>/dev/null || true
                heal_lock_release carrier-not-up   # причина СВОЯ: в логе heal видно, что несущую поднимают ВПЕРВЫЕ, а не чинят падение
                finish
            fi
            log "awg0 ИСЧЕЗ при transport=awg → safety_off (снимаю DNS-SPOF)"
            [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
            echo "FAILOPEN" > "$STATE"


            heal_lock_release carrier-lost
            ip=$(ext_ip)



            if [ "$NF_LANG" = en ]; then
                notify_ev "awg0-down" 3600 "BE7000: awg0 went down — direct mode" \
"The awg0 interface is gone (the amneziawg-go daemon died or was killed). The router is
temporarily in DIRECT mode: traffic and DNS bypass the VPN (with a live ISP link the
internet works), listed sites are unavailable.
Auto-recovery of awg0 is running (heal.sh).
External IP now: ${ip:-unknown}."
            else
            notify_ev "awg0-down" 3600 "BE7000: awg0 упал — прямой режим" \
"Интерфейс awg0 исчез (демон amneziawg-go умер/убит). Роутер временно в ПРЯМОМ
режиме: трафик и DNS идут мимо VPN (при живой связи с провайдером интернет
работает), сайты из списка недоступны.
Идёт авто-восстановление awg0 (heal.sh).
Внешний IP сейчас: ${ip:-неизвестен}."
            fi
        else
            heal_lock_release carrier-lost   # уже FAILOPEN — просто дать heal попробовать поднять awg0
            [ "$HEAL_KICK_CAPPED" = 0 ] && log "awg0 всё ещё отсутствует, уже FAILOPEN — жду heal"
        fi

























        _esc_bk=0; _esc_cr=0; _esc_tgt=
        if [ "$HEAL_KICK_CAPPED" = 1 ]; then
            _esc_bk=$(count_backups)
            [ "$(fo_escalate)" = cross ] && _esc_tgt=$(cross_target_from_awg)
            [ -n "$_esc_tgt" ] && _esc_cr=1
        fi
        if [ "$HEAL_KICK_CAPPED" = 1 ] && [ "$(fo_mode)" != off ] \
           && { [ "$_esc_bk" -ge 1 ] || [ "$_esc_cr" = 1 ]; } \
           && [ "$(stamp_age "$FAILOVER_STAMP")" -ge "$(fo_retry)" ] && inet_reachable; then
            date +%s > "$FAILOVER_STAMP"; episode_reset; episode_add awg


            log "awg0 не создаётся, а heal исчерпан → лестница: резервов $_esc_bk, cross ${_esc_tgt:-нет}"
            if [ "$_esc_bk" -ge 1 ] && [ -f "$SWITCH_VPN" ]; then
                run_failover || cross_awg_to_other || fo_backoff_bump
            else
                cross_awg_to_other || fo_backoff_bump
            fi


            heal_cfg_save


            [ "$(cat "$STATE" 2>/dev/null)" = NORMAL ] && heal_kick_reset
        fi
















        if [ "$HEAL_KICK_CAPPED" = 1 ] && [ ! -f "$HEAL_KICK_MAILED" ] \
           && [ "$(stamp_age "$WANOUT_EVENT")" -ge "$WANOUT_FRESH" ] \
           && [ "$(cat "$STATE" 2>/dev/null)" != NORMAL ]; then
            : > "$HEAL_KICK_MAILED" 2>/dev/null || true










            _nr_heal="и самовосстановление каждый раз отрабатывало."
            _nr_heale="and self-healing did run each time."
            _nr_healok=1





            if [ ! -e "$HEAL_LOCK" ] && [ -e "$HEAL_REASON" ] && [ ! -e "$SWITCH_LOCK" ] \
               && [ ! -e "$HEAL_SKIPPED" ]; then
                _nr_healok=0


                _nr_heal="а самовосстановление после наших попыток так и не запускалось — проверьте строку heal.sh в cron (она есть в архиве «⬇ Скачать диагностику»)."
                _nr_heale="but self-healing never started after our attempts — check the heal.sh cron line (it is in the «Download diagnostics» archive)."
            fi



            if [ "$_nr_healok" = 0 ]; then
                _nr_why="Про сам AmneziaWG судить рано: до него дело не дошло."
                _nr_whye="It is too early to blame AmneziaWG itself — the recovery never got that far."
            elif [ -f "$AWG0_SEEN" ]; then
                _nr_why="awg0 в эту загрузку уже работал, а теперь не пересоздаётся — чаще всего это нехватка ОЗУ (демона унёс OOM) или занятый флеш; конфиг и ключи тут ни при чём."
                _nr_whye="awg0 was up earlier in this boot and now cannot be recreated — usually that means low RAM (the daemon was OOM-killed) or a full flash; the config and keys are not the cause."
            else
                _nr_why="Значит дело в самом AmneziaWG — проверьте конфиг сервера (ключи, Endpoint), бинари в «Компонентах» и место на флеше."
                _nr_whye="So the problem is AmneziaWG itself — check the server config (keys, Endpoint), the binaries in Components and free flash space."
            fi
            _nr_bk=0; [ "$(fo_mode)" != off ] && [ "$_esc_bk" -ge 1 ] && _nr_bk=1
            _nr_cr=0; [ "$(fo_mode)" != off ] && [ "$_esc_cr" = 1 ] && _nr_cr=1
            _nr_next="Дальше пробую редко — раз в $((HEAL_KICK_SLOW / 60)) мин."
            [ "$_nr_bk" = 1 ] && _nr_next="$_nr_next Параллельно перебираю резервные серверы."
            [ "$_nr_cr" = 1 ] && _nr_next="$_nr_next Если не поможет — перейду на другой протокол."
            _nr_nexte="From now on I retry rarely — once every $((HEAL_KICK_SLOW / 60)) min."
            [ "$_nr_bk" = 1 ] && _nr_nexte="$_nr_nexte Backup servers are tried in parallel."
            [ "$_nr_cr" = 1 ] && _nr_nexte="$_nr_nexte If that does not help, I switch to another protocol."
            if [ "$NF_LANG" = en ]; then
                notify_ev "awg-noraise" "$NORAISE_THROTTLE" "BE7000: AmneziaWG does not come up — the watchdog stopped recreating it" \
"awg0 is not being created (attempts in a row: $(heal_kick)), $_nr_heale
$_nr_whye
The router is in DIRECT mode right now: listed sites bypass the VPN, and with a live ISP link
the internet works.
$_nr_nexte A config change is noticed at once; new binaries or freed space — at the next retry.
Panel: :8088 -> the VPN card."
            else
                notify_ev "awg-noraise" "$NORAISE_THROTTLE" "BE7000: AmneziaWG не поднимается — сторож перестал пересоздавать" \
"Интерфейс awg0 не создаётся (попыток подряд: $(heal_kick)), $_nr_heal
$_nr_why
Роутер сейчас в ПРЯМОМ режиме: сайты из списка идут мимо VPN, и при живой связи с провайдером
интернет работает.
$_nr_next Правку конфига сторож заметит СРАЗУ, а новые бинари или освободившееся место — на
ближайшей редкой попытке. Панель: :8088 -> карточка VPN."
            fi
        fi
    fi
    finish            # доп-выходы несут СВОИ несущие — их здоровье от awg0 не зависит
fi
awg_watchable || finish  # без бинаря awg судить об основном туннеле нечем, а выходы сторожим; тот же гейт — у обещаний возврата вердикта





hs=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
case "$hs" in ''|*[!0-9]*) hs=0 ;; esac
age=$(age_since "$hs")

if [ "$age" -ge "$HS_DEAD" ]; then




    doh_follow_carrier suspect




    if ! inet_reachable; then
        log "VPS handshake устарел (${age}с), но интернета нет вообще — не перебираю, жду аплинка"
        exit 0
    fi




    rm -f "$AWG0_FIRSTUP" 2>/dev/null











    if [ "$cur" != "FAILOPEN" ] && [ -f "$ENODIA_STATE/awg.conf" ] && [ -f "$TRANSPORT_SH" ] \
       && [ "$(stamp_age "$REUP_STAMP")" -ge "$REUP_RETRY" ]; then
        date +%s > "$REUP_STAMP"



        log "handshake ${age}с → сперва ОДИН переподъём awg0 (резервы — только если не поможет)"
        ip link del awg0 2>/dev/null
        sh "$TRANSPORT_SH" up awg >>"$LOG" 2>&1
        off_bail "переподъёма awg0"
        i=0
        while [ "$i" -lt 25 ]; do
            sleep 1
            hs2=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
            case "$hs2" in
                ''|0) ;;
                *)  if [ "$(age_since "$hs2")" -lt "$HS_DEAD" ]; then
                        log "reup помог: handshake вернулся на текущем конфиге — резервы не трогаю"
                        finish
                    fi ;;
            esac
            i=$((i + 1))
        done
        log "reup не помог (handshake так и не пришёл) — иду по лестнице failover"
    fi
    mode=$(fo_mode)
    nbk=$(count_backups)
    if [ "$cur" != "FAILOPEN" ]; then

        episode_reset; episode_add awg; date +%s > "$FAILOVER_STAMP"
        if [ "$mode" != "off" ] && [ "$nbk" -ge 1 ] && [ -f "$SWITCH_VPN" ]; then


            log "VPS МЁРТВ (handshake ${age}с) → failover (режим=$mode, резервов=$nbk)"
            run_failover || cross_awg_to_other || fo_backoff_bump
        elif [ "$mode" != "off" ] && [ "$(fo_escalate)" = "cross" ] && [ -n "$(cross_target_from_awg)" ]; then

            log "VPS МЁРТВ (handshake ${age}с), awg-резервов нет → cross на другой транспорт"
            [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
            echo "FAILOPEN" > "$STATE"
            cross_awg_to_other || fo_backoff_bump
        else

            log "VPS МЁРТВ (handshake ${age}с) → прямой режим (режим=$mode, резервов=$nbk)"
            [ -f "$SWITCH_VPN" ] && sh "$SWITCH_VPN" safety-off >>"$LOG" 2>&1
            echo "FAILOPEN" > "$STATE"
            active=$(cat "$ACTIVE_NAME" 2>/dev/null)
            ip=$(ext_ip)


            if [ "$NF_LANG" = en ]; then
                notify_ev "vpn-failopen" 0 "BE7000: the VPN went down, direct mode" \
"The VPS does not answer (last handshake ${age} s ago).
Config: ${active:-?}.

The router switched to DIRECT mode: traffic and DNS bypass the VPN — if the ISP
link is up, the internet works; listed sites are temporarily unavailable.
External IP now: ${ip:-unknown}.

When the VPS comes back, the VPN returns automatically and a second email
arrives. If the VPS stays down for long — check it, or switch the server:
panel :8088 -> the VPN card."
            else
            notify_ev "vpn-failopen" 0 "BE7000: VPN упал, прямой режим" \
"VPS не отвечает (последний handshake ${age} сек назад).
Конфиг: ${active:-?}.

Роутер перешёл в ПРЯМОЙ режим: трафик и DNS идут мимо VPN — если связь
с провайдером есть, интернет работает; сайты из списка временно недоступны.
Внешний IP сейчас: ${ip:-неизвестен}.

Когда VPS снова заработает, VPN вернётся автоматически и придёт
второе письмо. Если VPS долго не оживает — проверьте его или смените
сервер: панель :8088 -> карточка VPN."
            fi
        fi
    else





        if [ "$mode" != "off" ] && [ "$(stamp_age "$FAILOVER_STAMP")" -ge "$(fo_retry)" ]; then
            date +%s > "$FAILOVER_STAMP"; episode_reset; episode_add awg
            log "VPS всё ещё мёртв (${age}с), FAILOPEN → повторная попытка восстановления"
            if [ "$nbk" -ge 1 ] && [ -f "$SWITCH_VPN" ]; then
                run_failover || cross_awg_to_other || fo_backoff_bump
            else
                cross_awg_to_other || fo_backoff_bump
            fi
        else
            log "VPS всё ещё мёртв (${age}с), уже FAILOPEN — без изменений (следующая попытка через $(( ($(fo_retry) - $(stamp_age "$FAILOVER_STAMP")) / 60 )) мин)"
        fi
    fi
elif awg_hs_alive "$age"; then



    rm -f "$REUP_STAMP" 2>/dev/null
    health_back   # бэкофф перебора и эпизод «интернета нет» закрыты: handshake свежий ⇒ аплинк жив
    doh_follow_carrier ok       # awg0 везёт ⇒ резолвер можно вернуть в туннель
    if [ "$cur" = "FAILOPEN" ] && [ -f "$AWG0_FIRSTUP" ]; then












        if [ -z "$(carrier_route_dev)" ] || ! carrier_rule_present; then
            log "awg0 поднят ВПЕРВЫЕ, но ядро не восстановлено (маршрут/ip rule) — возвращаю несущую"
            restore_awg_carrier
        fi
        rm -f "$AWG0_FIRSTUP" 2>/dev/null
        echo "NORMAL" > "$STATE"; episode_reset
        log "awg0 поднят ВПЕРВЫЕ в эту загрузку (handshake ${age}с назад) — прямой режим был нашим ожиданием, а не аварией: NORMAL, письма нет"
    elif [ "$cur" = "FAILOPEN" ]; then
        log "VPS ОЖИЛ (handshake ${age}с назад) → возврат VPN"


        restore_awg_carrier








        if [ ! -f "$XT_AWG" ]; then

            VPN_DNS=$(grep -E '^DNS\s*=' "$ENODIA_STATE/awg.conf" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | awk -F',' '{print $1}' | tr -d ' ')
            [ -z "$VPN_DNS" ] && VPN_DNS=172.29.172.254
            printf 'no-resolv\nserver=%s\n' "$VPN_DNS" > /etc/dnsmasq.d/00-upstream.conf
            ip route replace "$VPN_DNS/32" dev awg0 2>/dev/null
            /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
        fi
        echo "NORMAL" > "$STATE"; episode_reset   # эпизод аварии закрыт
        ip=$(ext_ip)
        if [ "$NF_LANG" = en ]; then
            notify_ev "vpn-restored" 0 "BE7000: the VPN is back" \
"The VPS answers again (last handshake ${age} s ago).
VPN routing and DNS through the tunnel are restored.
External IP: ${ip:-unknown}."
        else
        notify_ev "vpn-restored" 0 "BE7000: VPN восстановлен" \
"VPS снова отвечает (последний handshake ${age} сек назад).
Вернул VPN-роутинг и DNS через туннель.
Внешний IP: ${ip:-неизвестен}."
        fi
    else



        split_rules_wiped awg && heal_split_rules awg


        carrier_route_lost awg && heal_carrier_route awg


        carrier_rule_lost awg && heal_carrier_rule awg








        home_t=$(transport_home)
        if fo_home_transport_back awg \
           && [ "$(stamp_age "$FAILBACK_STAMP")" -ge "$FAILBACK_INTERVAL" ]; then





            home_lbl=$(transport_label "$home_t")
            date +%s > "$FAILBACK_STAMP"
            log "home-transport: проба возврата на домашний $home_lbl (подъём + egress-проба)"




            _fb_ok=1
            tsw "$home_t" || _fb_ok=0   # оркестратор: релинквиш awg + mark-core + подъём $home_t
            [ "$_fb_ok" = 1 ] && [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" = "$home_t" ] || _fb_ok=0
            if [ "$_fb_ok" = 1 ] && sh "$TRANSPORT_SH" health "$home_t" >/dev/null 2>&1; then
                echo HEALTHY > "$XSTATE"; log "home-transport: вернулись на $home_lbl"
                failback_event transport "$home_lbl"
            else



                [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" = awg ] || tsw awg
                log "home-transport: $home_lbl ещё мёртв — остаёмся на awg"
            fi
        elif [ "$(fo_mode)" = "home" ]; then
            home=$(failover_home_name)
            active=$(cat "$ACTIVE_NAME" 2>/dev/null)
            if fo_awg_server_away \
               && [ "$(stamp_age "$FAILBACK_STAMP")" -ge "$FAILBACK_INTERVAL" ]; then
                date +%s > "$FAILBACK_STAMP"
                ep=$(grep -E '^Endpoint' "$CONFIGS_DIR/$home.conf" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | sed 's/:[0-9]*$//' | tr -d ' ')
                if [ -n "$ep" ] && ping -c 1 -W 2 "$ep" >/dev/null 2>&1; then
                    log "home-failback: основной '$home' (endpoint $ep) ожил → возврат"


                    if sh "$SWITCH_VPN" "$home" >>"$LOG" 2>&1 && [ "$(cat "$ACTIVE_NAME" 2>/dev/null)" = "$home" ]; then
                        failback_event server "$home"
                    fi
                else
                    log "home-failback: основной '$home' ещё недоступен — остаёмся на '$active'"
                fi
            fi
        fi
    fi
fi










finish
