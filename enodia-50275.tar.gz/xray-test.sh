#!/bin/sh














ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}


if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }




if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v daemon_wait_port >/dev/null 2>&1 || daemon_wait_port() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0; sleep 1; _dwi=$((_dwi+1)); done
    netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
XRAY=$(bin_path xray)




if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
IP_PROBE_TRACE="${IP_PROBE_TRACE:-https://1.1.1.1/cdn-cgi/trace}"








MODE=egress
case "$1" in speed) MODE=speed; shift ;; egress) shift ;; esac
name="$1"





TPORT="$2"; case "$TPORT" in 1081[2-9]) : ;; *) TPORT=10812 ;; esac



STREAMS="$3"; case "$STREAMS" in ''|*[!0-9]*) STREAMS=4 ;; esac
[ "$STREAMS" -lt 1 ] 2>/dev/null && STREAMS=1; [ "$STREAMS" -gt 8 ] 2>/dev/null && STREAMS=8
DUR="$4"; case "$DUR" in ''|*[!0-9]*) DUR=12 ;; esac
[ "$DUR" -lt 5 ] 2>/dev/null && DUR=5; [ "$DUR" -gt 30 ] 2>/dev/null && DUR=30
TCONF=/tmp/enodia-xray-test.$TPORT.json
TPID=/tmp/enodia-xray-test.$TPORT.pid
TLOG=/tmp/xray-test.$TPORT.log
TOUT=/tmp/enodia-xray-test.$TPORT.out
TACC=/tmp/xray-test.$TPORT.access.log

TLOCK=/tmp/enodia-xray-test.$TPORT.lock

emit() { printf '%s\n' "$1"; }




_lk=0




command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' < "/proc/$1/cmdline" 2>/dev/null | grep -qE "$2"; }
lock_take() {
	mkdir "$TLOCK" 2>/dev/null && { echo $$ > "$TLOCK/pid"; _lk=1; return 0; }
	_lp=$(cat "$TLOCK/pid" 2>/dev/null | tr -cd '0-9')
	[ -n "$_lp" ] || { sleep 1; _lp=$(cat "$TLOCK/pid" 2>/dev/null | tr -cd '0-9'); }
	if [ -n "$_lp" ] && pid_runs "$_lp" 'xray-test'; then return 1; fi
	mv "$TLOCK" "$TLOCK.stale.$$" 2>/dev/null && rm -rf "$TLOCK.stale.$$" 2>/dev/null
	mkdir "$TLOCK" 2>/dev/null && { echo $$ > "$TLOCK/pid"; _lk=1; return 0; }
	return 1
}
cleanup() {
	[ "$_lk" = 1 ] || return 0
	[ -f "$TPID" ] && kill "$(cat "$TPID" 2>/dev/null)" 2>/dev/null
	rm -f "$TPID" "$TCONF" "$TOUT" "$TOUT".* "$TACC" 2>/dev/null
}


xt_done() { cleanup; [ "$_lk" = 1 ] && rm -rf "$TLOCK" 2>/dev/null; _lk=0; return 0; }
trap xt_done EXIT
trap 'exit 1' INT TERM HUP PIPE

[ -n "$name" ] || { emit '{"ok":false,"msg":"не задано имя конфига"}'; exit 0; }
src="$ENODIA_STATE/xray-configs/$name.json"
[ -x "$XRAY" ] || { emit '{"ok":false,"msg":"xray не установлен на роутере"}'; exit 0; }
[ -s "$src" ]  || { emit '{"ok":false,"msg":"конфиг не найден"}'; exit 0; }

lock_take || { emit "{\"ok\":false,\"busy\":true,\"msg\":\"на временном порту $TPORT идёт другая проверка — повторите, когда она кончится\"}"; exit 0; }
cleanup   # снять возможный прошлый тест (замок наш — значит, прежний держатель мёртв)







sed -e "s/\"port\"[[:space:]]*:[[:space:]]*10808/\"port\": $TPORT/" \
    -e "s#/tmp/xray-access.log#none#g" \
    -e "s#/tmp/xray\.log#$TLOG#g" \
    "$src" > "$TCONF" 2>/dev/null
[ -s "$TCONF" ] || { emit '{"ok":false,"msg":"не удалось подготовить тест-конфиг"}'; exit 0; }

: > "$TLOG" 2>/dev/null
start-stop-daemon -S -b -m -p "$TPID" -x /bin/sh -- -c "exec '$XRAY' run -c '$TCONF' >>'$TLOG' 2>&1"





if ! daemon_wait_port "$TPID" xray 8 127.0.0.1 "$TPORT"; then
	err=$(tail -n 4 "$TLOG" 2>/dev/null | tr -d '\r\033' | sed 's/\[[0-9;]*m//g' | tr '\n' ' ' | sed 's/\\/\\\\/g; s/"/\\"/g' | cut -c1-300)
	emit "{\"ok\":false,\"msg\":\"xray не поднялся с этим конфигом: ${err:-$DAEMON_WAIT_WHY}\"}"
	exit 0
fi





if [ "$MODE" = speed ]; then




	CHUNK=$((75*1024*1024))
	rm -f "$TOUT".* 2>/dev/null
	t0=$(date +%s); deadline=$((t0+DUR)); k=0
	while [ "$k" -lt "$STREAMS" ]; do
		( tot=0
		  while now=$(date +%s); [ "$now" -lt "$deadline" ]; do
			rem=$((deadline-now)); [ "$rem" -lt 1 ] && break
			got=$(curl -s --max-time "$rem" -o /dev/null --socks5-hostname "127.0.0.1:$TPORT" \
			      -w '%{size_download}' "https://speed.cloudflare.com/__down?bytes=$CHUNK" 2>/dev/null)
			got=${got%.*}; case "$got" in ''|*[!0-9]*) got=0 ;; esac
			tot=$((tot+got))
		  done
		  echo "$tot" > "$TOUT.$k" ) &
		k=$((k+1))
	done
	wait


	t1=$(date +%s); el=$((t1-t0)); [ "$el" -lt 1 ] && el=1
	total=$(cat "$TOUT".* 2>/dev/null | awk '{s=s+$1} END{printf "%.0f", s+0}')
	rm -f "$TOUT".* 2>/dev/null
	if [ "${total:-0}" -gt 0 ] 2>/dev/null; then
		mbps=$(awk -v b="$total" -v t="$el" 'BEGIN{ if(t>0) printf "%.1f", b*8/t/1000000 }')
		emit "{\"ok\":true,\"mbps\":${mbps:-0},\"bytes\":$total,\"streams\":$STREAMS,\"secs\":$el}"
	else
		emit '{"ok":false,"msg":"скачивание через этот сервер не пошло"}'
	fi
	exit 0
fi




out=$(curl -s -k --max-time 12 --socks5-hostname "127.0.0.1:$TPORT" -w '|%{time_total}' "$IP_PROBE_TRACE" 2>/dev/null)
tt=${out##*|}; body=${out%|*}
ip=$(printf '%s\n' "$body" | sed -n 's/^ip=\([0-9.]*\).*/\1/p' | head -1)
if echo "$ip" | grep -Eq '^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$'; then
	ms=$(awk -v t="$tt" 'BEGIN{ if(t+0>0) printf "%.0f", t*1000 }')
	emit "{\"ok\":true,\"ip\":\"$ip\",\"ms\":${ms:-0}}"
else
	emit '{"ok":false,"msg":"нет реального выхода через этот сервер (пинг не значит рабочий)"}'
fi
exit 0
