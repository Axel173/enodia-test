#!/bin/sh





























































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
LIVE=/tmp/dnsmasq.d          # второй conf-dir (RAM); сток копирует сюда /etc при рестарте
ETC=/etc/dnsmasq.d           # ПЕРВЫЙ conf-dir по порядку чтения (см. шапку) — здесь и живёт агрегат
OUT_BASE=00-ipset-merge.conf
OUT="$ETC/$OUT_BASE"
OUT_COPY="$LIVE/$OUT_BASE"   # копия, которую сделает стоковый init: снимаем вместе с оригиналом




DRAFT=/tmp/.enodia-dns-merge.draft.$$ # ВНЕ conf-dir: там читается всё подряд, а не только *.conf
PAIRS=/tmp/.enodia-dns-merge.pairs.$$
STAMP=/tmp/.enodia-dns-merge.stamp    # RAM ⇒ после ребута штамп пуст и агрегат пересобирается заново
LOCK=/tmp/.enodia-dns-merge.lock      # КАТАЛОГ (mkdir атомарен), внутри pid — как do_update в lists-lib
DIRTY=/tmp/.enodia-dns-merge.dirty    # «пока ты собирал, состав изменился» — держатель лока идёт на второй круг
TAB=$(printf '\t')






src_files() {


	for _f in "$ETC"/*.conf; do
		[ -f "$_f" ] || continue
		[ "$(basename "$_f")" = "$OUT_BASE" ] && continue   # свой же файл (иначе агрегат самозаклинится)
		echo "$_f"
	done
	for _f in "$LIVE"/*; do
		[ -f "$_f" ] || continue
		_b=$(basename "$_f")
		[ "$_b" = "$OUT_BASE" ] && continue          # копия нашего файла, сделанная init'ом
		case "$_b" in *.new|*.tmp) continue ;; esac  # чужие черновики


		[ -f "$ETC/$_b" ] && continue
		echo "$_f"
	done
}






extract_pairs() {
	: > "$PAIRS"


	_args=$(src_files | tr '\n' ' ')
	[ -n "$_args" ] || return 0




	_args=$(grep -l '^ipset=/' $_args 2>/dev/null | tr '\n' ' ')
	[ -n "$_args" ] || return 0

	awk -F/ -v OFS="$TAB" '
		/^ipset=\// {
			ln++
			s = $NF
			while (1) {
				p = s; sub(/,.*/, "", p)
				if (p != "") for (i = 2; i < NF; i++) if ($i != "") print tolower($i), p, ln
				if (s ~ /,/) sub(/^[^,]*,/, "", s); else break
			}
		}' $_args 2>/dev/null > "$PAIRS"
	sort -u "$PAIRS" > "$PAIRS.s" 2>/dev/null && mv "$PAIRS.s" "$PAIRS"
}














aggregate() {
	awk -F"$TAB" '
		$1 == "#" { next }
		{
			d = $1; t = $2; n = $3 + 0
			if (!(d in first) || n < first[d]) first[d] = n
			if (!((d SUBSEP t) in have)) { have[d SUBSEP t] = 1; nset[d]++; sets[d] = sets[d] "," t }
			# сколько наборов несёт КОНКРЕТНАЯ строка n (дедуп не нужен: тройки уже sort -u)
			lcnt[d SUBSEP n]++
		}
		END {
			for (d in first) {
				# наборы предков, которых нет у самого домена
				extra = ""; nex = 0; p = d
				while (sub(/^[^.]+\./, "", p)) {
					if (p in first) {
						s = sets[p]
						while (sub(/^,/, "", s)) {
							t = s; sub(/,.*/, "", t)
							if (!((d SUBSEP t) in have)) { have[d SUBSEP t] = 1; extra = extra "," t; nex++ }
							if (s ~ /,/) sub(/^[^,]*/, "", s); else s = ""
						}
					}
				}
				# победитель применит lcnt[d,first] наборов, а действовать должны nset+nex
				if (nset[d] + nex > lcnt[d SUBSEP first[d]]) {
					out = ""; s = sets[d] extra
					while (sub(/^,/, "", s)) {
						t = s; sub(/,.*/, "", t)
						out = (out == "" ? t : out "," t)
						if (s ~ /,/) sub(/^[^,]*/, "", s); else s = ""
					}
					if (out != "") print "ipset=/" d "/" out
				}
			}
		}' "$PAIRS" 2>/dev/null | sort
}







lock_take() {
	_i=0; _empty=0
	while [ "$_i" -lt 15 ]; do
		if mkdir "$LOCK" 2>/dev/null; then printf '%s' "$$" > "$LOCK/pid" 2>/dev/null; return 0; fi
		_p=$(cat "$LOCK/pid" 2>/dev/null)
		case "$_p" in



			''|*[!0-9]*) _empty=$((_empty + 1)); [ "$_empty" -ge 3 ] && rm -rf "$LOCK" 2>/dev/null ;;
			*) _empty=0; [ -d "/proc/$_p" ] || rm -rf "$LOCK" 2>/dev/null ;;
		esac
		_i=$((_i + 1)); sleep 1
	done
	return 1
}
lock_drop() { rm -rf "$LOCK" 2>/dev/null; }





sync_pass() {
	mkdir -p "$ETC" "$LIVE" 2>/dev/null
	extract_pairs
	_new=$(md5sum "$PAIRS" 2>/dev/null | cut -d' ' -f1)

	_old=$(cat "$STAMP" 2>/dev/null)


	[ "$1" != "-f" ] && [ -n "$_new" ] && [ "$_new" = "$_old" ] && return 0
	aggregate > "$DRAFT"




	rm -f "$OUT_COPY" 2>/dev/null
	if [ -s "$DRAFT" ]; then





		if cp "$DRAFT" "$OUT.tmp" 2>/dev/null && mv "$OUT.tmp" "$OUT" 2>/dev/null; then _ok=0; else _ok=1; fi
		rm -f "$DRAFT" "$OUT.tmp" 2>/dev/null
	else

		rm -f "$DRAFT" "$OUT" 2>/dev/null
		_ok=0
	fi




	[ "$_ok" = 0 ] || { echo "[dns-merge] не удалось выложить $OUT (нет места в /etc?) — штамп не пишу, повторю на следующем вызове" >&2; return 1; }
	printf '%s' "$_new" > "$STAMP" 2>/dev/null
	return 0
}




do_sync() {
	: > "$DIRTY" 2>/dev/null
	lock_take || return 0
	trap 'rm -f "$PAIRS" "$DRAFT" 2>/dev/null; lock_drop' EXIT
	trap 'exit 1' INT TERM HUP PIPE
	while :; do
		rm -f "$DIRTY" 2>/dev/null
		sync_pass "$1"
		[ -f "$DIRTY" ] || break
	done
	trap - EXIT INT TERM HUP PIPE
	rm -f "$PAIRS" "$DRAFT" 2>/dev/null
	lock_drop
}
out_count() { _c=$(grep -c '^ipset=/' "$OUT" 2>/dev/null); case "$_c" in ''|*[!0-9]*) _c=0 ;; esac; printf '%s' "$_c"; }




dns_cfg_real() {
	for _dp in /proc/[0-9]*; do
		case "$(tr '\0' ' ' < "$_dp/cmdline" 2>/dev/null)" in
			*dnsmasq*-C\ *)
				_dc=$(tr '\0' '\n' < "$_dp/cmdline" 2>/dev/null | awk '$0=="-C"{f=1;next} f{print;exit}')
				[ -f "$_dc" ] && { printf '%s' "$_dc"; return 0; } ;;
		esac
	done
	printf '/etc/dnsmasq.conf'
}




dns_cfg_ok() {
	[ -x /usr/sbin/dnsmasq ] || return 0
	_dt=$(/usr/sbin/dnsmasq --test -C "$(dns_cfg_real)" 2>&1)
	case "$_dt" in
		*"syntax check OK"*) return 0 ;;
		"") return 0 ;;
	esac
	printf '%s' "$_dt" | tail -2 >&2
	return 1
}



dns_resolves() {
	pidof dnsmasq >/dev/null 2>&1 || return 1
	nslookup localhost 2>/dev/null | grep -q '^Address'
}


















dns_restart() {
	_dwas=0; pidof dnsmasq >/dev/null 2>&1 && _dwas=1
	if ! dns_cfg_ok; then
		echo "[dns-merge] dnsmasq забраковал итоговый конфиг — рестарт ПРОПУЩЕН (живой демон важнее свежих правил)" >&2
		return 0
	fi
	/etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
	[ "$_dwas" = 1 ] || return 0
	_dwk=0
	while [ "$_dwk" -lt 8 ]; do
		dns_resolves && return 0
		_dwk=$((_dwk + 1)); sleep 1
	done
	echo "[dns-merge] после рестарта DNS не резолвит — снимаю свой агрегат и поднимаю демона обратно" >&2
	rm -f "$OUT" "$OUT_COPY" 2>/dev/null
	/etc/init.d/dnsmasq restart >/dev/null 2>&1
	return 0
}

case "$1" in
	sync)
		do_sync "$2"
		printf '[dns-merge] склеено доменов: %s\n' "$(out_count)"
		;;
	reload)


		do_sync "$2"
		dns_restart
		;;
	status)
		_n=$(out_count)
		printf 'агрегат: %s (доменов: %s)\n' "$OUT" "$_n"
		[ "$_n" = 0 ] || head -20 "$OUT"
		printf 'источники:\n'
		src_files | while read -r _f; do
			_c=$(grep -c '^ipset=/' "$_f" 2>/dev/null); case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
			[ "$_c" = 0 ] || printf '  %s\t%s\n' "$_c" "$_f"
		done
		;;
	clear)

		rm -f "$OUT" "$OUT_COPY" "$STAMP" /tmp/.enodia-dns-merge.pairs.* /tmp/.enodia-dns-merge.draft.* "$DIRTY" 2>/dev/null
		rm -rf "$LOCK" 2>/dev/null
		printf '[dns-merge] агрегат снят\n'
		;;
	*)
		cat <<EOF
dns-merge.sh — склейка ipset=-правил доменов из всех подсистем.

  dns-merge.sh sync [-f]    пересобрать агрегат ($OUT)
  dns-merge.sh reload [-f]  пересобрать + перечитать dnsmasq
  dns-merge.sh status       что сейчас склеено и из каких файлов
  dns-merge.sh clear        снять агрегат
EOF
		;;
esac
