#!/bin/sh

















ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
LISTS_DIR="$ENODIA_STATE/lists"             # ПЕРСИСТ на флеше: РЕЕСТР источников + мелкий персист.



LISTS_RAM="${LISTS_RAM:-/tmp/enodia-lists}"



MAX_FLASH_CIDR="${MAX_FLASH_CIDR:-40000}"
TAB=$(printf '\t')






if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi




if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
	case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
	[ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}




if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
command -v wan_gateway >/dev/null 2>&1 || wan_gateway() { ip route show default 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}'; }
command -v doh_ips >/dev/null 2>&1 || doh_ips() { _r=$(curl -s --connect-timeout 3 --max-time 15 $2 "https://1.1.1.1/dns-query?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null); [ -n "$_r" ] || _r=$(curl -sk --connect-timeout 3 --max-time 15 $2 "https://1.1.1.1/dns-query?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null); printf '%s' "$_r" | grep -o '"data":"[0-9.]*"' | cut -d'"' -f4; }














ls_dir() {  # ls_dir <cat> → каталог ПЕРСИСТА категории на флеше (реестр + blob пользователя)
	_d="$LISTS_DIR/$1"
	mkdir -p "$_d/blob" 2>/dev/null
	printf '%s' "$_d"
}
ram_dir() {  # ram_dir <cat> → каталог ОЗУ категории (закачки/кэш/рабочие файлы; стирается на ребуте)
	_d="$LISTS_RAM/$1"
	mkdir -p "$_d/cache" 2>/dev/null
	printf '%s' "$_d"
}
reg_path()   { printf '%s/sources.tsv' "$(ls_dir "$1")"; }   # флеш: реестр (переживает ребут)




reg_nen() {
	_rgp=$(reg_path "$1"); [ -f "$_rgp" ] || return 0
	awk -F"$TAB" '$1 != "" && $3 == "1" { n++ } END { print n + 0 }' "$_rgp"
}
blob_path()  { printf '%s/blob/%s'  "$(ls_dir "$1")" "$2"; }  # флеш: контент file/text-источника (нет URL для перекачки)
cache_path() { printf '%s/cache/%s' "$(ram_dir "$1")" "$2"; } # ОЗУ: фолбэк последней удачной закачки URL
allow_path() { printf '%s/allow' "$(ls_dir "$1")"; }       # флеш: исключения категории (adblock — домены, ipblock — IPv4/CIDR)
enable_path(){ printf '%s/.enabled' "$(ls_dir "$1")"; }    # флеш: мастер-флаг (adblock/ipblock off по умолч.)





snap_path()  {
	case "$1" in
		tunnel-cidr|zapret-cidr|zapret-dom) printf '%s/.snapshot' "$(ls_dir "$1")" ;;
		*)                       printf '%s/.snapshot' "$(ram_dir "$1")" ;;
	esac
}





snap_write() {
	_c="$1"; _sf="$2"; _dst=$(snap_path "$_c")
	case "$_dst" in
		"$LISTS_DIR"/*)
			_ln=$(grep -c '' "$_sf" 2>/dev/null); case "$_ln" in ''|*[!0-9]*) _ln=0 ;; esac
			if [ "$_ln" -gt "$MAX_FLASH_CIDR" ]; then


				case "$_c" in
					*-dom|*domains) _hint="возьмите список поменьше" ;;
					*)              _hint="используйте агрегированный CIDR (data=cidr4)" ;;
				esac
				echo "снимок на флеш ПРОПУЩЕН: $_ln строк > лимита $MAX_FLASH_CIDR — $_hint. В RAM список работает, но не переживёт офлайн-ребут"
				return 0
			fi ;;
	esac
	cp "$_sf" "$_dst" 2>/dev/null
}

















_lock_stale() {
	_lp=$(cat "$1/pid" 2>/dev/null)
	if [ -n "$_lp" ]; then
		[ -d "/proc/$_lp" ] && return 1
		return 0
	fi
	_la=$(date -r "$1" +%s 2>/dev/null)
	case "$_la" in ''|*[!0-9]*) return 1 ;; esac   # busybox без `date -r` → не гадаем, считаем живым
	[ "$(age_since "$_la")" -gt "${2:-120}" ]
}
ls_lock_take() {
	_ld="$1"; _df="$2"; _dp="$3"
	if ! mkdir "$_ld" 2>/dev/null; then
		if ! _lock_stale "$_ld"; then
			printf '%s' "$_dp" > "$_df" 2>/dev/null; return 1   # держатель жив → он переиграет
		fi
		rm -rf "$_ld" 2>/dev/null
		mkdir "$_ld" 2>/dev/null || { printf '%s' "$_dp" > "$_df" 2>/dev/null; return 1; }
	fi
	echo $$ > "$_ld/pid"
	return 0
}
ls_lock_drop() { rm -f "$1/pid" 2>/dev/null; rmdir "$1" 2>/dev/null; }

_san() { printf '%s' "$1" | tr -d "$TAB\r\n"; }










_reg_lock_dir() { printf '/tmp/.enodia-lists-reg.%s.lock' "$1"; }   # /tmp: ребут снимает лок сам
reg_lock_take() {  # reg_lock_take <cat> → 0 = взят (обязателен reg_lock_drop) | 1 = не удалось
	_rl=$(_reg_lock_dir "$1"); _ri=0
	while [ "$_ri" -lt 15 ]; do
		mkdir "$_rl" 2>/dev/null && { echo $$ > "$_rl/pid"; return 0; }
		_ri=$((_ri + 1))


		if _lock_stale "$_rl" 30; then rm -rf "$_rl" 2>/dev/null; continue; fi
		sleep 1
	done
	return 1
}
reg_lock_drop() { rm -rf "$(_reg_lock_dir "$1")" 2>/dev/null; }



_reg_rewrite() {
	_rc="$1"; shift
	_rf=$(reg_path "$_rc"); [ -f "$_rf" ] || return 1
	reg_lock_take "$_rc"; _rlk=$?
	_rt="$_rf.new.$$"
	if awk -F"$TAB" -v OFS="$TAB" "$@" "$_rf" > "$_rt" 2>/dev/null; then
		mv "$_rt" "$_rf"; _rr=0
	else
		rm -f "$_rt" 2>/dev/null; _rr=1   # awk упал (нет места/битый файл) — реестр НЕ трогаем
	fi
	[ "$_rlk" = 0 ] && reg_lock_drop "$_rc"
	return $_rr
}











ls_opt_cats() { echo "adblock ipblock zapret-cidr zapret-dom"; }



cat_enabled() {
	case " $(ls_opt_cats) " in
		*" $1 "*) [ -f "$(enable_path "$1")" ] ;;
		*) return 0 ;;
	esac
}

reg_next_id() {  # следующий свободный sN (детерминированно, max+1)
	_f=$(reg_path "$1"); _max=0
	if [ -f "$_f" ]; then
		_max=$(awk -F"$TAB" '$1 ~ /^s[0-9]+$/{n=substr($1,2)+0; if(n>m)m=n} END{print m+0}' "$_f")
		case "$_max" in ''|*[!0-9]*) _max=0 ;; esac
	fi
	printf 's%s' "$((_max + 1))"
}

reg_add() {  # reg_add <cat> <type> <enabled> <format> <label> <value> → печатает новый id
	_cat="$1"; _type="$2"; _en="$3"; _fmt="$4"; _lbl="$5"; _val="$6"


	reg_lock_take "$_cat"; _alk=$?
	_id=$(reg_next_id "$_cat"); _f=$(reg_path "$_cat")
	printf '%s\t%s\t%s\t%s\t0\t0\t%s\t%s\n' \
		"$_id" "$_type" "$_en" "$_fmt" "$(_san "$_lbl")" "$(_san "$_val")" >> "$_f"
	[ "$_alk" = 0 ] && reg_lock_drop "$_cat"
	printf '%s' "$_id"
}
reg_del() {  # reg_del <cat> <id> — убрать строку + blob/cache
	_f=$(reg_path "$1"); [ -f "$_f" ] || return 0
	_reg_rewrite "$1" -v id="$2" '$1!=id'
	rm -f "$(blob_path "$1" "$2")" "$(cache_path "$1" "$2")" 2>/dev/null
}
reg_toggle() {  # reg_toggle <cat> <id> <0|1>
	_reg_rewrite "$1" -v id="$2" -v v="$3" '$1==id{$3=v} {print}'
}
reg_set_format() {  # reg_set_format <cat> <id> <fmt>
	_reg_rewrite "$1" -v id="$2" -v v="$3" '$1==id{$4=v} {print}'
}
reg_set_meta() {  # reg_set_meta <cat> <id> <count> <ts>
	_reg_rewrite "$1" -v id="$2" -v c="$3" -v t="$4" '$1==id{$5=c;$6=t} {print}'
}






fetch_url() {  # fetch_url <url> <outfile> → 0 + непустой outfile при успехе






	_u="$1"; _o="$2"
	_fetch_try '' && return 0
	_fetch_try '-k' && return 0
	return 1
}

_fetch_try() {  # $1 = '' | '-k' (сверка/без); берёт _u/_o из fetch_url; 0 + непустой _o при успехе






	_k="$1"
	if curl $_k -sfL --max-time 120 "$_u" -o "$_o" && [ -s "$_o" ]; then return 0; fi
	_host=$(printf '%s' "$_u" | sed -e 's|^[a-zA-Z][a-zA-Z0-9+.-]*://||' -e 's|[/?#].*$||' -e 's|^[^@]*@||' -e 's|:.*$||')
	[ -n "$_host" ] || return 1
	case "$_u" in http://*) _port=80 ;; *) _port=443 ;; esac



	_ips=$(doh_ips "$_host" "$_k --max-time 15")
	[ -n "$_ips" ] || return 1
	for _ip in $_ips; do
		case "$_ip" in *.*.*.*) ;; *) continue ;; esac
		if curl $_k -sfL --max-time 120 --resolve "$_host:$_port:$_ip" "$_u" -o "$_o" && [ -s "$_o" ]; then
			return 0
		fi
	done
	return 1
}


detect_format() {  # stdin → echo cidr|hosts|dnsmasq|adblock|domain
	_s=$(grep -vE '^[[:space:]]*([#!].*)?$' 2>/dev/null | head -50)
	if   printf '%s' "$_s" | grep -qE '^\|\|';                                   then echo adblock
	elif printf '%s' "$_s" | grep -qE '^(address|server|ipset|local)=/';         then echo dnsmasq
	elif printf '%s' "$_s" | grep -qE '^[0-9]{1,3}(\.[0-9]{1,3}){3}[[:space:]]+[A-Za-z0-9]'; then echo hosts
	elif printf '%s' "$_s" | grep -qE '^[0-9]{1,3}(\.[0-9]{1,3}){3}(/[0-9]{1,2})?[[:space:]]*$'; then echo cidr
	else echo domain
	fi
}

















strip_bogon() {  # strip_bogon [мин_маска] ; stdin (CIDR по строке) → stdout БЕЗ приватных/богонов
	awk -F'[./]' -v minm="${1:-8}" '
	{
		o1=$1+0; o2=$2+0
		mask = ($5=="") ? 32 : $5+0        # "a.b.c.d/m" → $5=m; "a.b.c.d" → нет $5 (=/32)
		if (mask < minm) next              # слишком широкая маска для этой цели (см. шапку функции)
		if (o1==0 || o1==10 || o1==127) next            # this-net / 10-я приватка / loopback
		if (o1>=224) next                               # multicast+reserved 224.0.0.0/3
		if (o1==169 && o2==254) next                    # link-local 169.254/16
		if (o1==172 && o2>=16 && o2<=31) next           # 172.16/12 приватка
		if (o1==192 && o2==168) next                    # 192.168/16 приватка (наш LAN)
		if (o1==100 && o2>=64 && o2<=127) next          # CGNAT 100.64/10 — подсеть awg0!
		if (o1==198 && (o2==18 || o2==19)) next         # 198.18/15 benchmark
		print
	}'
}



strip_bogon6() {
	awk -F/ -v minm="${1:-16}" '{ m = ($2 == "") ? 128 : $2 + 0; if (m < minm || m > 128) next; if ($1 !~ /^[23][0-9a-f][0-9a-f][0-9a-f]:/) next; print }'
}


















collect_critical() {  # stdout: «IP/CIDR<TAB>причина[<TAB>уточнение]» по строке — НИКОГДА не блокировать/не дропать

	[ -s "$ENODIA_STATE/.endpoint-bypass" ] && grep -E '^[0-9]' "$ENODIA_STATE/.endpoint-bypass" 2>/dev/null | sed "s/\$/${TAB}vps/"

	for _cs in 2 3 4 5 6 7; do
		[ -s "$ENODIA_STATE/.endpoint-bypass-s$_cs" ] && grep -E '^[0-9]' "$ENODIA_STATE/.endpoint-bypass-s$_cs" 2>/dev/null | sed "s/\$/${TAB}exit${TAB}$_cs/"
	done


	_wif=$(wan_iface)
	if [ -n "$_wif" ]; then

		wan_gateway | grep -E '^[0-9]' | sed "s/\$/${TAB}gw/"
		ip -4 addr show dev "$_wif" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | sed "s/\$/${TAB}wan/"
	fi






	for _ccd in /etc/dnsmasq.d /tmp/dnsmasq.d; do
		for _ccf in "$_ccd"/*.conf; do
			case "${_ccf##*/}" in 06-adblock.conf|07-zapret-dom.conf|1[0-9]-geo*.conf) continue ;; esac
			[ -f "$_ccf" ] && grep -hE '^[[:space:]]*server=' "$_ccf" 2>/dev/null
		done
	done \
		| sed 's/^[[:space:]]*server=//; s/[[:space:]]//g; s#.*/##; s/#.*$//' \
		| grep -E '^[0-9]{1,3}(\.[0-9]{1,3}){3}$' | grep -v '^127\.' | sed "s/\$/${TAB}dns/"



	if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then
		( . "$ENODIA_DIR/doh-lib.sh" 2>/dev/null
		  if command -v dns_now >/dev/null 2>&1; then
			  _ccn=$(dns_now 2>/dev/null)
			  printf '%s\n' "$_ccn" | sed -n 's/^addr=//p' | tr ' ,' '\n\n' | sed 's/#.*$//'
			  printf '%s\n' "$_ccn" | grep -q '^src=doh' && doh_resolver_ips 2>/dev/null
		  fi ) \
			| tr ' ' '\n' | grep -E '^[0-9]{1,3}(\.[0-9]{1,3}){3}$' | grep -v '^127\.' | sed "s/\$/${TAB}dns/"
	fi


	ip -4 route show 2>/dev/null | awk -v t="$TAB" '/proto kernel/ && $1 ~ /\//{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); print $1 t "net" t d}'   # not-wan: подсети НАШИХ мостов для allowlist, а не WAN

	[ -s "$(allow_path ipblock)" ] && grep -E '^[0-9]' "$(allow_path ipblock)" 2>/dev/null | sed "s/\$/${TAB}user/"
	return 0
}








ALLOW_LOCK=/tmp/enodia-allowset.lock
_nap() { if command -v usleep >/dev/null 2>&1; then usleep 100000; else sleep 1; fi; }
ensure_allow_set() {  # создать/наполнить ipset blocklist_allow критичными IP (idемпотентно, атомарный swap)
	_ea_got=0; _ea_n=0
	while [ "$_ea_n" -lt 50 ]; do
		if ls_lock_take "$ALLOW_LOCK" /dev/null; then _ea_got=1; break; fi
		_nap; _ea_n=$((_ea_n + 1))
	done
	ipset list -n 2>/dev/null | grep -qx blocklist_allow || \
		ipset create blocklist_allow hash:net hashsize 1024 maxelem 65536 2>/dev/null

	for _ea_o in $(ipset list -n 2>/dev/null | grep '^blocklist_allow_[0-9][0-9]*$'); do
		[ -d "/proc/${_ea_o#blocklist_allow_}" ] || ipset destroy "$_ea_o" 2>/dev/null
	done
	_ea_t="blocklist_allow_$$"
	ipset destroy "$_ea_t" 2>/dev/null
	ipset create "$_ea_t" hash:net hashsize 1024 maxelem 65536 2>/dev/null
	collect_critical | cut -f1 | while IFS= read -r _ip; do
		case "$_ip" in ''|'#'*) continue ;; esac
		ipset add "$_ea_t" "$_ip" 2>/dev/null
	done

	ipset swap "$_ea_t" blocklist_allow 2>/dev/null
	ipset destroy "$_ea_t" 2>/dev/null
	[ "$_ea_got" = 1 ] && ls_lock_drop "$ALLOW_LOCK"
	return 0
}





addr_block_live() {
	iptables -C INPUT -j ENODIA_BLK 2>/dev/null || iptables -C INPUT -j ENODIA_GEOBLK 2>/dev/null
}





norm_cidr() {  # stdin → stdout (по IP/CIDR на строку)

	_nc="${TMPDIR:-/tmp}/.normcidr.$$"
	tr -d '\r' | sed 's/[#;].*$//' > "$_nc"


	_out=$(sed 's/[[:space:]]//g' "$_nc" | grep -E '^[0-9]{1,3}(\.[0-9]{1,3}){3}(/[0-9]{1,2})?$')
	if [ -n "$_out" ]; then printf '%s\n' "$_out"; rm -f "$_nc"; return 0; fi






	grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}' "$_nc"
	rm -f "$_nc"
}



norm_cidr6() {
	tr -d '\r' | sed 's/[#;].*$//; s/[[:space:]]//g' | tr 'A-F' 'a-f' | grep -E '^[0-9a-f]{0,4}(:[0-9a-f]{0,4}){2,7}(/[0-9]{1,3})?$'
}











norm_domains() {  # stdin → stdout (по домену на строку, дедуп снаружи)
	tr 'A-Z' 'a-z' | tr -d '\r' | awk '
		/^[[:space:]]*[#!]/ { next }
		/^[[:space:]]*(include|keyword|regexp|ext):/ { next }
		{
			line=$0; d=""
			if (line ~ /^\|\|/) {                       # adblock: ||domain^
				sub(/^\|\|/,"",line); sub(/[\^\/].*$/,"",line); d=line
			} else if ($1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && NF>=2) {  # hosts: IP domain
				d=$2
			} else if (line ~ /^(address|server|ipset|local)=\//) {         # dnsmasq
				sub(/^[a-z]*=\//,"",line); sub(/\/.*$/,"",line); d=line
			} else {                                     # plain domain / geosite (первое слово)
				d=$1
				sub(/^(domain|full):/,"",d)              # v2fly/geosite: `domain:x` `full:www.x` = домен
			}
			# пользователь мог вставить URL целиком — тянем голый хост:
			sub(/^[a-z][a-z0-9+.-]*:\/\//,"",d)          # схема http:// https:// ftp:// …
			sub(/[\/?#].*$/,"",d)                         # хвост /path ?query #frag
			sub(/:[0-9]+$/,"",d)                          # :port
			gsub(/^\.+/,"",d); gsub(/\.+$/,"",d)
			if (d=="" || d=="localhost" || d=="local" || d=="localhost.localdomain") next
			if (d ~ /^[0-9.]+$/) next                     # голый IP — не домен
			# {0,61} — это метка ≤63 символов, и это НЕ косметика: dnsmasq отвергает ВЕСЬ конфиг
			# из-за одной такой строки (замер — в шапке dns-lib.sh::dom_ok), а сюда домены едут из
			# ЧУЖИХ списков на сотни тысяч строк. Один мусорный хост в источнике = сеть без DNS.
			if (d ~ /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/) print d
		}'
}

normalize() {  # normalize <kind cidr|domains> <format> < infile > outfile
	case "$1" in
		cidr)    norm_cidr ;;
		domains) norm_domains ;;
		*)       cat ;;
	esac
}














ipset_count() {  # ipset_count <setname> → число членов (0 если пусто/нет набора)







	_c=$(ipset list -t "$1" 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)
	case "$_c" in ''|*[!0-9]*) _c=$(ipset list "$1" 2>/dev/null | grep -cE '^[0-9]') ;; esac
	case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
	printf '%s' "$_c"
}

apply_ipset() {  # apply_ipset <setname> <file...> → печатает count | код 1
	_set="$1"; shift
	ipset list -n 2>/dev/null | grep -qx "$_set" || \
		ipset create "$_set" hash:net hashsize 4096 maxelem 1000000 2>/dev/null
	ipset destroy "${_set}_new" 2>/dev/null
	ipset create "${_set}_new" hash:net hashsize 4096 maxelem 1000000 2>/dev/null
	_rf="${TMPDIR:-/tmp}/.ipset-restore.$$"; : > "$_rf"
	for _f in "$@"; do
		[ -f "$_f" ] || continue
		awk -v s="${_set}_new" '/^[0-9]/{print "add " s " " $1}' "$_f" >> "$_rf"
	done
	ipset restore -exist < "$_rf" 2>/dev/null
	rm -f "$_rf"
	_n=$(ipset_count "${_set}_new")
	if [ "$_n" -eq 0 ]; then ipset destroy "${_set}_new" 2>/dev/null; return 1; fi
	ipset swap "${_set}_new" "$_set"; ipset destroy "${_set}_new" 2>/dev/null
	printf '%s' "$_n"; return 0
}





dnsmasq_reload() { sh "$ENODIA_DIR/dns-merge.sh" reload 2>/dev/null \
	|| /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null; }














apply_dnsmasq_block() {  # apply_dnsmasq_block <conf> <domainsfile> <allowfile|''> → печатает count доменов
	_conf="$1"; _dom="$2"; _allow="$3"
	mkdir -p "$(dirname "$_conf")" 2>/dev/null
	_eff="$_dom"; _dpar=''
	if [ -n "$_allow" ] && [ -s "$_allow" ]; then
		awk 'FNR==NR { if ($0!="") a[$0]=1; next }
		     { x=$0; while (1) { if (x in a) next; if (sub(/^[^.]*\./, "", x)==0) break } print }' "$_allow" "$_dom" > "$_dom.eff.$$"
		_eff="$_dom.eff.$$"

		_dpar="$_dom.par.$$"
		awk 'FNR==NR { x=$0; while (sub(/^[^.]*\./, "", x)) { if (x ~ /\./) p[x]=p[x] " " $0 }; next }
		     ($0 in p) { print p[$0] }' "$_allow" "$_eff" | tr ' ' '\n' | grep . | sort -u > "$_dpar"


		if [ -s "$_dpar" ]; then
			for _dof in "$(dirname "$_conf")"/*; do
				[ "$_dof" = "$_conf" ] && continue; [ -f "$_dof" ] || continue
				sed -n 's#^address=/\([^/]*\)/.*#\1#p' "$_dof" 2>/dev/null
			done > "$_dom.oth.$$"
			if [ -s "$_dom.oth.$$" ]; then
				awk 'FNR==NR { o[$0]=1; next } { x=$0; k=1; while (sub(/^[^.]*\./, "", x)) if (x in o) { k=0; break }; if (k) print }' \
					"$_dom.oth.$$" "$_dpar" > "$_dpar.k" && mv "$_dpar.k" "$_dpar"
			fi
			rm -f "$_dom.oth.$$"
		fi
	fi







	_cnew="$(dirname "$_conf")/.$(basename "$_conf").new.$$"
	{ sed 's|.*|address=/&/0.0.0.0|' "$_eff"; sed 's|.*|address=/&/::|' "$_eff"
	  [ -n "$_dpar" ] && [ -s "$_dpar" ] && sed 's|.*|server=/&/#|' "$_dpar"; } > "$_cnew"
	mv "$_cnew" "$_conf"
	rm -f "$_dom.eff.$$" "$_dpar" 2>/dev/null

	_n=$(grep -c '/0\.0\.0\.0$' "$_conf" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac

	[ -n "$LISTS_NO_RELOAD" ] || dnsmasq_reload
	printf '%s' "$_n"
}








apply_dnsmasq_ipset() {  # apply_dnsmasq_ipset <conf> <domainsfile> <setname> [allowfile] → печатает count
	_conf="$1"; _dom="$2"; _dset="$3"; _allow="$4"
	mkdir -p "$(dirname "$_conf")" 2>/dev/null
	_eff="$_dom"
	if [ -n "$_allow" ] && [ -s "$_allow" ]; then
		grep -vxF -f "$_allow" "$_dom" 2>/dev/null > "$_dom.eff"; _eff="$_dom.eff"
	fi
	_cnew="$(dirname "$_conf")/.$(basename "$_conf").new.$$"   # черновик вне поля зрения dnsmasq (разбор у apply_dnsmasq_block)
	sed "s|.*|ipset=/&/$_dset|" "$_eff" > "$_cnew"
	mv "$_cnew" "$_conf"
	rm -f "$_dom.eff" 2>/dev/null
	_n=$(grep -c '^ipset=/' "$_conf" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
	dnsmasq_reload
	printf '%s' "$_n"
}
