#!/bin/sh




























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}






ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}
if [ ! -f "$ENODIA_DIR/VERSION" ] && [ -f "$ENODIA_BOOT/boot.sh" ]; then
    _bp=$(sh "$ENODIA_BOOT/boot.sh" paths 2>/dev/null)
    _bd=$(printf '%s\n' "$_bp" | sed -n 's/^dir=//p' | tail -1)
    _bs=$(printf '%s\n' "$_bp" | sed -n 's/^state=//p' | tail -1)
    _bb=$(printf '%s\n' "$_bp" | sed -n 's/^bin=//p' | tail -1)
    case "$_bd" in /*) ENODIA_DIR="$_bd" ;; esac
    case "$_bs" in /*) ENODIA_STATE="$_bs" ;; esac
    case "$_bb" in /*) ENODIA_BIN="$_bb" ;; esac
    unset _bp _bd _bs _bb
fi



export ENODIA_DIR ENODIA_STATE ENODIA_BIN ENODIA_BOOT



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi



if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
command -v wan_gateway >/dev/null 2>&1 || wan_gateway() { ip route show default 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}'; }


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}
command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }



dmp_uptime() { _du=$(uptime_s); [ "$_du" = 999999999 ] && _du="не прочитан"; echo "$_du"; }

















ENV_SED=/tmp/.enodia-diag-env.$$.sed
build_env_sed() {
    : > "$ENV_SED" 2>/dev/null || return 0

    _esc() { printf '%s' "$1" | sed 's|[]\\.*^$&#[]|\\&|g'; }





    _n=0
    uci -q show wireless 2>/dev/null | sed -n "s/.*\.ssid='\(.*\)'\$/\1/p" | sort -u |
    awk '{print length($0) "\t" $0}' | sort -nr | cut -f2- |
    while read -r _s; do
        [ -n "$_s" ] && [ "${#_s}" -ge 4 ] || continue
        _n=$((_n+1))
        printf 's#%s#[SSID-%s]#g\n' "$(_esc "$_s")" "$_n" >> "$ENV_SED"
    done

    if [ -f /tmp/dhcp.leases ]; then
        _n=0
        awk '{print $4}' /tmp/dhcp.leases 2>/dev/null | sort -u |
        awk '{print length($0) "\t" $0}' | sort -nr | cut -f2- |
        while read -r _h; do
            [ -n "$_h" ] && [ "$_h" != "*" ] && [ "${#_h}" -ge 4 ] || continue
            _n=$((_n+1))
            printf 's#%s#[HOST-%s]#g\n' "$(_esc "$_h")" "$_n" >> "$ENV_SED"
        done
    fi
    [ -s "$ENV_SED" ] || rm -f "$ENV_SED"
    return 0
}







redact() {
    [ -f "$ENV_SED" ] || build_env_sed
    sed -e 's#[A-Za-z0-9+/]\{43\}=#[KEY-REDACTED]#g' \
        -e 's#PrivateKey *=.*#PrivateKey = [KEY-REDACTED]#g' \
        -e 's#PublicKey *=.*#PublicKey = [KEY-REDACTED]#g' \
        -e 's#PresharedKey *=.*#PresharedKey = [KEY-REDACTED]#g' \
        -e 's#endpoint: .*#endpoint: [REDACTED]#g' \
        -e 's#Endpoint *=.*#Endpoint = [REDACTED]#g' \
        -e 's#\([0-9A-Fa-f]\{2\}:[0-9A-Fa-f]\{2\}:[0-9A-Fa-f]\{2\}:\)[0-9A-Fa-f]\{2\}:[0-9A-Fa-f]\{2\}:[0-9A-Fa-f]\{2\}#\1xx:xx:xx#g' \
    | { [ -s "$ENV_SED" ] && sed -f "$ENV_SED" || cat; } \
    | awk '
    {
        line = $0; out = ""
        while (match(line, /[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/)) {
            ip   = substr(line, RSTART, RLENGTH)
            out  = out substr(line, 1, RSTART - 1)
            line = substr(line, RSTART + RLENGTH)
            split(ip, o, ".")
            if (o[1]=="10" || o[1]=="127" || o[1]=="0" || \
                (o[1]=="192" && o[2]=="168") || \
                (o[1]=="169" && o[2]=="254") || \
                (o[1]=="172" && o[2]>=16 && o[2]<=31)) {
                out = out ip                     # приватный/служебный — оставляем
            } else {
                out = out o[1] "." o[2] ".x.x"   # публичный — маскируем хвост
            }
        }
        print out line
    }'
}

sec() { echo ""; echo "==================================================================="; echo "## $1"; echo "==================================================================="; }
sub() { echo ""; echo "----- $1 -----"; }


showf() {
    if [ -f "$1" ]; then echo "[$1]"; cat "$1" 2>/dev/null; echo "[/$1]"
    else echo "[$1] — нет"; fi
}

showmeta() {
    if [ -e "$1" ]; then ls -ld "$1" 2>/dev/null | awk '{print $1, $3, $5, $NF}'
    else echo "$1 — нет"; fi
}



xqver() { grep -E "^[[:space:]]*option $1 " /usr/share/xiaoqiang/xiaoqiang_version 2>/dev/null | head -1 | sed "s/.*'\(.*\)'.*/\1/"; }









DUMP_LOGS="enodia-startup enodia-watchdog enodia-switch-vpn-setup enodia-transport-awg-setup
enodia-iplist-update enodia-subs-update enodia-notify enodia-notify-event enodia-hev
enodia-hysteria enodia-byedpi enodia-byedpi-test-run enodia-byedpi-fetch enodia-zapret-nfqws
enodia-doh enodia-panel-tls enodia-support enodia-xiaomi-bypass enodia-dnsq enodia-restore
enodia-store-mode xray xray-access hytest ussl-dbg
switch-vpn-setup transport-awg-setup iplist-update subs-update notify notify-event hev hysteria
byedpi byedpi-test-run zapret-nfqws doh panel-tls support xiaomi-bypass"













our_ramlogs() {
    if [ -f "$ENODIA_DIR/clean.sh" ]; then
        sh "$ENODIA_DIR/clean.sh" ramlogs-list 2>/dev/null
    else
        for _lg in $DUMP_LOGS; do [ -s "/tmp/$_lg.log" ] && echo "/tmp/$_lg.log"; done
    fi
    return 0
}

main() {

sec "ОБЗОР РОУТЕРА (железо / прошивка / нагрузка)"
rom=$(xqver ROM); ch=$(xqver CHANNEL); hw=$(xqver HARDWARE); bt=$(xqver BUILDTIME)
echo "Прошивка (ROM):  ${rom:-?} (${ch:-?})   сборка: ${bt:-?}"
echo "Модель:          Xiaomi ${hw:-?}  /  $(cat /proc/device-tree/model 2>/dev/null | tr -d '\000')"
echo "Ядро:            $(uname -s 2>/dev/null) $(uname -r 2>/dev/null) $(uname -m 2>/dev/null)"
echo "BusyBox:         $(busybox 2>&1 | head -1)"
ncpu=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null)
la=$(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)





if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi
pct=$(command -v cpu_busy_pct >/dev/null 2>&1 && cpu_busy_pct)
echo "CPU:             ${ncpu:-?} ядра · загрузка ~${pct:-?}% (load average: ${la:-?})"
awk '/^MemTotal:/{t=$2}/^MemFree:/{f=$2}/^MemAvailable:/{a=$2}END{printf "RAM:             %d МБ свободно из %d МБ (доступно %s)\n", f/1024, t/1024, (a==""?"?":sprintf("%d МБ", a/1024))}' /proc/meminfo 2>/dev/null


























DUMP_FLASH="$ENODIA_BOOT"; [ -d "$DUMP_FLASH" ] || DUMP_FLASH="$ENODIA_DIR"
df -k "$DUMP_FLASH" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{printf "%-19s %.1fM свободно из %.1fM (занято %.0f%%)\n", "ПЗУ (" $NF "):", $(NF-2)/1024,$(NF-4)/1024,($(NF-4)-$(NF-2))*100/$(NF-4)}'


DUMP_CODE_MP=$(df -k "$ENODIA_DIR" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{print $NF}')
DUMP_FLASH_MP=$(df -k "$DUMP_FLASH" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{print $NF}')
if [ -n "$DUMP_CODE_MP" ] && [ "$DUMP_CODE_MP" != "$DUMP_FLASH_MP" ]; then
    df -k "$ENODIA_DIR" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{printf "%-19s %.1fM свободно из %.1fM (занято %.0f%%)\n", "Накопитель (" $NF "):", $(NF-2)/1024,$(NF-4)/1024,($(NF-4)-$(NF-2))*100/$(NF-4)}'
fi
echo "Uptime:          $(uptime 2>/dev/null)"   # raw-uptime: busybox-апплет, печать человеку — вердикта по строке нет
echo "Дата (роутер):   $(date 2>/dev/null)"



echo "Часы на буте:    $(cat "${CLOCK_SYNC_MARK:-/tmp/enodia-clock.synced}" 2>/dev/null || echo 'сверки не было (нет отметки)') · сток ntp: $(cat /tmp/ntp.status 2>/dev/null || echo '—')"
echo "Hostname:        $(cat /proc/sys/kernel/hostname 2>/dev/null)"
echo "ENODIA_DIR:      $ENODIA_DIR"





_ver=$(sed -n 's/^VERSION=//p' "$ENODIA_DIR/VERSION" 2>/dev/null | head -1)
_code=$(sed -n 's/^CODE=//p'   "$ENODIA_DIR/VERSION" 2>/dev/null | head -1)
if [ -n "$_ver" ]; then
    echo "Версия скриптов: $_ver (CODE ${_code:-?})"
else
    echo "Версия скриптов: (нет $ENODIA_DIR/VERSION — установка старее апдейтера)"
fi






_ghrepo=$(cat "$ENODIA_STATE/.gh-repo" 2>/dev/null | tr -d ' \r\n')
_ghref=$(cat "$ENODIA_STATE/.gh-ref" 2>/dev/null | tr -d ' \r\n')
_ghbin=$(cat "$ENODIA_STATE/.gh-bin-tag" 2>/dev/null | tr -d ' \r\n')
echo "Источник обновлений: репо ${_ghrepo:-(по умолчанию)} · ветка/тег ${_ghref:-(по умолчанию)} · тег бинарей ${_ghbin:-(по умолчанию)}"

sec "ИНТЕРФЕЙС awg0"
ip addr show awg0 2>/dev/null || echo "(awg0 не поднят)"
sub "ip link"
ip link show awg0 2>/dev/null || echo "(нет)"

sec "СОСТОЯНИЕ AWG (awg show — ключи/endpoint замаскированы)"
if [ -x "$ENODIA_BIN/awg" ]; then
    "$ENODIA_BIN/awg" show awg0 2>/dev/null || echo "(awg show awg0 не отработал)"
    sub "возраст handshake"
    hs=$("$ENODIA_BIN/awg" show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
    case "$hs" in
        ''|*[!0-9]*) echo "handshake: нет / никогда — VPS не отвечает?" ;;
        0)           echo "handshake: 0 — никогда" ;;
        *)           # Печатаем ОБА числа, когда они разошлись: расхождение = часы шагнули после


                     _dmp_raw=$(( $(date +%s) - hs ))   # clock-raw: сырая разность нужна как раз для сравнения с age_since
                     _dmp_age=$(age_since "$hs")
                     if [ "$_dmp_raw" != "$_dmp_age" ]; then
                         echo "handshake: $_dmp_age сек назад (ЧАСЫ ШАГНУЛИ: сырая разность $_dmp_raw с при аптайме $(dmp_uptime) с)"
                     else
                         echo "handshake: $_dmp_age сек назад"
                     fi ;;
    esac
else
    echo "(бинарь $ENODIA_BIN/awg не найден)"
fi

sec "АКТИВНЫЙ ТРАНСПОРТ (что реально несёт трафик)"






_dmp_t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
if [ -n "$_dmp_t" ]; then
    echo "Файл .transport:  $_dmp_t"
elif [ -f "$ENODIA_DIR/transport.sh" ]; then
    sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1
    case "$?" in
        1) echo "Файл .transport:  (пуст — установка «только панель»: транспорт не выбран НИ РАЗУ, правил в роутере нет)" ;;
        2) echo "Файл .transport:  (пуст — старая копия transport.sh, судить о транспорте нечем)" ;;
        *) echo "Файл .transport:  (пуст, но транспорт НАСТРОЕН — роутер старше флага, несущая awg)" ;;
    esac
else
    echo "Файл .transport:  (пуст — transport.sh нет, установка до рефактора плагинов)"
fi



_dp_act=$(cat "$ENODIA_STATE/.active" 2>/dev/null | tr -d '\r')
echo "Файл .active:     ${_dp_act:-?}"


echo "Прочее: .vpn-off=$( [ -f "$ENODIA_STATE/.vpn-off" ] && echo "ДА — VPN выключен человеком" || echo нет )  .zapret-on=$( [ -f "$ENODIA_STATE/.zapret-on" ] && echo да || echo нет )  .full-tunnel=$( [ -f "$ENODIA_STATE/.full-tunnel" ] && echo да || echo нет )"
if [ -f "$ENODIA_DIR/transport.sh" ]; then
    sub "transport.sh active"
    sh "$ENODIA_DIR/transport.sh" active 2>/dev/null || echo "(active не отработал)"
    sub "transport.sh list (готовность транспортов)"
    sh "$ENODIA_DIR/transport.sh" list 2>/dev/null || echo "(list не отработал)"





    sub "transport.sh health (жива ли несущая активного транспорта)"


    _rc=0
    if [ -f "$ENODIA_STATE/.vpn-off" ]; then _rc=off
    else sh "$ENODIA_DIR/transport.sh" health >/dev/null 2>&1 || _rc=$?; fi
    if [ "$_rc" = off ]; then
        echo "health: не проверялась — VPN выключен человеком, несущей нет по его воле"
    elif [ "$_rc" = 0 ]; then
        echo "health: OK — несущая активного транспорта жива"
    else
        echo "health: НЕ ОК (код $_rc) — несущая просела ЛИБО активного транспорта нет (fail-open); причина в логе транспорта ниже"
    fi
else
    echo "(transport.sh нет — установка до рефактора плагинов)"
fi





sec "ДОП-ВЫХОДЫ (слоты 2..4 — свой транспорт и свой сервер у каждого)"
if [ -f "$ENODIA_DIR/slots.sh" ]; then
    sh "$ENODIA_DIR/slots.sh" state 2>/dev/null || echo "(state не отработал)"
    sub "несущие выходов (carriers)"
    sh "$ENODIA_DIR/slots.sh" carriers 2>/dev/null || echo "(нет)"
    sub "слот-марки и таблицы (ip rule)"
    ip rule 2>/dev/null | grep -E 'fwmark 0x[2-4]' || echo "(слот-правил в ip rule нет)"






    sub "учёт трафика по выходам (сырой замер + сегодня)"
    if [ -f "$ENODIA_STATE/.traffic-last" ]; then cat "$ENODIA_STATE/.traffic-last"
    else echo "(.traffic-last нет — учёт ещё не тикал)"; fi
    awk -v d="$(date +%F 2>/dev/null)" '$2==d{print "сегодня: "$0; f=1} END{if(!f)print "(сегодняшней строки в .traffic-daily ещё нет)"}' \
        "$ENODIA_STATE/.traffic-daily" 2>/dev/null || echo "(.traffic-daily нет)"
else
    echo "(slots.sh нет — установка до мульти-транспорта)"
fi

sec "ZAPRET / ДЕСИНК (nfqws, NFQUEUE, пулы)"
if [ -f "$ENODIA_DIR/zapret.sh" ]; then



    sh "$ENODIA_DIR/zapret.sh" status 2>/dev/null || echo "(status не отработал)"
    sub "проводка: jump ENODIA_ZAPRET + NFQUEUE (по нему сторож судит, жив ли десинк)"
    iptables -t mangle -S PREROUTING 2>/dev/null | grep -i zapret || echo "(jump ENODIA_ZAPRET в mangle PREROUTING НЕТ)"
    iptables -t mangle -S POSTROUTING 2>/dev/null | grep -i NFQUEUE || echo "(правил NFQUEUE нет)"
    sub "устройства целиком в десинк (NFQUEUE по источнику)"
    sh "$ENODIA_DIR/zapret.sh" src-list 2>/dev/null || echo "(нет)"
else
    echo "(zapret.sh нет)"
fi

sec "ДОСТУП ДОМОЙ (роутер как VPN-сервер; ключи пиров НЕ читаем)"
if [ -f "$ENODIA_DIR/vpn-server.sh" ]; then
    sh "$ENODIA_DIR/vpn-server.sh" status 2>/dev/null || echo "(status не отработал)"
    sub "цепочки VPNSRV_* (порт наружу / вход из туннеля / форвард)"
    for c in VPNSRV_WAN VPNSRV_IN VPNSRV_FWD; do
        iptables -S "$c" 2>/dev/null || echo "(цепочки $c нет)"
    done
else
    echo "(vpn-server.sh нет)"
fi

sec "ШИФРОВАННЫЙ DNS (DoH/DoT — прокси на 127.0.0.1:5053)"


echo "Тумблер (.doh-on): $( [ "$(cat "$ENODIA_STATE/.doh-on" 2>/dev/null)" = on ] && echo вкл || echo выкл )   авто в прямых режимах: $( [ "$(cat "$ENODIA_STATE/.doh-auto" 2>/dev/null)" = off ] && echo запрещён || echo разрешён )$( [ -f /tmp/.enodia-doh-auto-on ] && echo ' (СЕЙЧАС активен)' )"
echo "Протокол: $(cat "$ENODIA_STATE/.doh-proto" 2>/dev/null || echo doh)   резолвер: $(cat "$ENODIA_STATE/.doh-resolver" 2>/dev/null || echo '(деф. cloudflare)')"


[ -f /tmp/.enodia-doh-untunneled.stamp ] && echo "Резолвер УВЕДЁН МИМО несущей (RETURN вместо марки), уведён $(age_since "$(cat /tmp/.enodia-doh-untunneled.stamp 2>/dev/null | tr -cd '0-9')") с назад"
_drs=$(cat /tmp/enodia-doh-retunnel.stamp 2>/dev/null | tr -cd '0-9')
[ -n "$_drs" ] && echo "Возврат в несущую ПРОВАЛИЛСЯ (резолвер через неё не отвечает) $(age_since "$_drs") с назад — пауза до повтора"



_dhs=$( [ -f "$ENODIA_DIR/doh-lib.sh" ] && . "$ENODIA_DIR/doh-lib.sh" && command -v doh_health_state >/dev/null 2>&1 && doh_health_state )
case "$_dhs" in *dotfb=1*)
    echo "Выбран DoT, а шифрует DoH: порт 853 текущим путём не проходил — переехал $(printf '%s\n' "$_dhs" | sed -n 's/^dotfb_age=//p') с назад, повтор DoT через $(printf '%s\n' "$_dhs" | sed -n 's/^dotfb_retry=//p') с (-1 = неизвестно)" ;;
esac
ps 2>/dev/null | grep -E '[h]ttps_dns_proxy|[d]ot-proxy' | head -4 || echo "(прокси шифрованного DNS не запущен)"




_dhc=$(cat /tmp/.enodia-doh-auto-cooldown 2>/dev/null | tr -cd '0-9')
_dhl=$(( ${_dhc:-0} - $(date +%s) ))
[ "$_dhl" -gt 0 ] && echo "Авто-режим В КАРАНТИНЕ после отката: ещё $(( _dhl / 60 )) мин (резолвер не отвечал)"
[ -s /tmp/enodia-doh.log ] && echo "Лог прокси: $(wc -c < /tmp/enodia-doh.log) Б, провалов резолва: $(grep -c 'curl request failed' /tmp/enodia-doh.log 2>/dev/null || true)"

sec "МАРШРУТИЗАЦИЯ (fwmark / таблицы / прямой путь)"
sub "ip rule"
ip rule 2>/dev/null
sub "ip route show table 1000 (VPN-таблица — несущая)"
ip route show table 1000 2>/dev/null || echo "(таблица 1000 пуста)"
sub "default route (main) + WAN-интерфейс"
ip route show default 2>/dev/null


WANDEV=$(wan_iface)
WANGW=$(wan_gateway)
echo "WAN dev: ${WANDEV:-'(дефолта в main НЕТ либо он смотрит в туннель — прямой egress мёртв!)'}   шлюз: ${WANGW:-?}"
sub "ip route get 8.8.8.8 (обычно маркируется в туннель)"
ip route get 8.8.8.8 2>/dev/null
sub "ip route get 77.88.55.242 (ya.ru — РУНЕТ, должен идти ПРЯМО через main/WAN)"
ip route get 77.88.55.242 2>/dev/null
sub "ip route get 1.1.1.1"
ip route get 1.1.1.1 2>/dev/null
sub "ip route get 8.8.8.8 mark 0x1 (МАРКИРОВАННЫЙ — должен уходить в table 1000/несущую)"


ip route get 8.8.8.8 mark 0x1 2>/dev/null || echo "(mark-роут не разобран)"

sec "IPTABLES mangle (метки в туннель)"


_iptwait=$(command -v ipt_wait_mode >/dev/null 2>&1 && ipt_wait_mode)
case "$_iptwait" in
    [1-9]*) echo "xtables-лок: ждём до ${_iptwait} с (ipt-lib.sh)" ;;
    no)     echo "xtables-лок: ЖДАТЬ НЕ УМЕЕМ — сборка iptables без \`-w <сек>\`; при занятом локе правило молча не встанет" ;;
    *)      echo "xtables-лок: ipt-lib.sh не загружен (старая установка) — ожидания нет" ;;
esac
iptables -t mangle -S 2>/dev/null || echo "(mangle недоступен)"



sub "PREROUTING со счётчиками (первые 30 — видно, бьют ли правила трафик)"
iptables -t mangle -L PREROUTING -v -n 2>/dev/null | head -30
sub "VPN_EXCLUDE / VPN_FORCE со счётчиками"
iptables -t mangle -L VPN_EXCLUDE -v -n 2>/dev/null || echo "(цепочки VPN_EXCLUDE нет)"
iptables -t mangle -L VPN_FORCE   -v -n 2>/dev/null || echo "(цепочки VPN_FORCE нет)"

sec "IPTABLES nat (MASQUERADE — прямой И туннельный egress)"
sub "POSTROUTING полностью (masq нужен и на WAN для рунета, и на awg0/xtun)"
iptables -t nat -S POSTROUTING 2>/dev/null || echo "(nat недоступен)"
sub "PREROUTING (nat, первые 20)"
iptables -t nat -S PREROUTING 2>/dev/null | head -20

sec "IPTABLES filter FORWARD (у fw3 policy DROP — без ACCEPT форвард мёртв)"
sub "FORWARD -S полностью (policy + все правила)"
iptables -S FORWARD 2>/dev/null || echo "(filter недоступен)"
sub "FORWARD со счётчиками (первые 25 — видно, кто дропает пакеты)"
iptables -L FORWARD -v -n 2>/dev/null | head -25

sec "IPSET (наполнение списков)"
echo "Наборы: $(ipset list -n 2>/dev/null | tr '\n' ' ')"
for s in enodia_list iplist_set; do
    if ipset list -n 2>/dev/null | grep -qx "$s"; then


        n=$(ipset list "$s" 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)
        case "$n" in ''|*[!0-9]*) n=$(ipset list "$s" 2>/dev/null | grep -cE '^[0-9]') ;; esac
        echo "  $s: ${n:-0}"
    else
        echo "  $s: нет набора"
    fi
done

sec "CONNTRACK"



if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi
if command -v ct_tool >/dev/null 2>&1; then
    case "$(ct_tool)" in
        conntrack) echo "Сброс соединений: утилита conntrack" ;;
        ecm)       echo "Сброс соединений: ручка ускорителя ($CT_ECM_DEFUNCT) — утилиты conntrack в прошивке НЕТ" ;;
        *)         echo "Сброс соединений: НЕЧЕМ (ни утилиты conntrack, ни ручки ускорителя) — правила применятся только к НОВЫМ соединениям" ;;
    esac
fi
echo "Ускоренных потоков (NSS/ECM): $(cat /sys/kernel/debug/ecm/ecm_db/connection_count 2>/dev/null || echo 'н/д')"
echo "Активных соединений: $(cat /proc/sys/net/netfilter/nf_conntrack_count 2>/dev/null || conntrack -C 2>/dev/null || echo '?')"
sub "срез TCP:443 (видно, доходит ли SYN-ACK / держится ли ESTABLISHED)"
{ conntrack -L -p tcp --dport 443 2>/dev/null || grep -E 'dport=443' /proc/net/nf_conntrack 2>/dev/null; } | head -12 || echo "(conntrack-срез недоступен)"
sub "TCP-строгость conntrack (ключ к 'SYN-ACK дошёл до роутера, но дропнут')"




echo "nf_conntrack_tcp_be_liberal = $(cat /proc/sys/net/netfilter/nf_conntrack_tcp_be_liberal 2>/dev/null || echo '?')  (0 = строго, дропает out-of-window как INVALID)"
echo "FORWARD 'ctstate INVALID -j DROP' бьёт: $(iptables -L FORWARD -v -n 2>/dev/null | awk '/ctstate INVALID/{print $1" пакетов / "$2" байт"; exit}')"

sec "ПРЯМОЙ ПУТЬ — ПРОБА С РОУТЕРА (жив ли egress мимо туннеля)"


printf 'Рунет напрямую (ya.ru 77.88.55.242, мимо DNS): '
c=$(curl -s -k --max-time 6 -o /dev/null -w '%{http_code}' -H 'Host: ya.ru' https://77.88.55.242/ 2>/dev/null); echo "HTTP ${c:-000}"


printf 'Инет напрямую (IPv4-выход роутера, IP-литерал trace): '
_di=$(curl -s -k ${WANDEV:+--interface $WANDEV} --max-time 6 https://1.1.1.1/cdn-cgi/trace 2>/dev/null | sed -n 's/^ip=\([0-9.]*\).*/\1/p'); echo "${_di:-(нет ответа)}"
if [ -n "$WANGW" ]; then
    printf 'Пинг WAN-шлюза: '
    ping -c2 -W2 "$WANGW" 2>/dev/null | tail -2 || echo "(шлюз не пингуется)"
fi

sec "АЛЬТ-НЕСУЩАЯ (xray / hev / tun2socks / socks 10808)"
sub "процессы транспортов"
ps 2>/dev/null | grep -E '[x]ray|[h]ev|tun2socks|[h]ysteria|[b]yedpi|[c]iadpi|[a]mneziawg-go' | head -12 || echo "(процессов альт-несущих нет)"
sub "интерфейс xtun (tun2socks)"
ip addr show xtun 2>/dev/null | grep -E 'inet|state' || echo "(xtun нет — не xray/hy2)"
sub "socks 10808 — живая проба (curl --socks5 к 1.1.1.1 по IP)"
c=$(curl -s --max-time 6 --socks5 127.0.0.1:10808 -o /dev/null -w '%{http_code}' http://1.1.1.1/ 2>/dev/null); echo "socks5 127.0.0.1:10808 -> HTTP ${c:-000}  (000 = socks не отвечает / curl без socks)"





_np=0
for _p in "$ENODIA_DIR"/transport-*.sh "$ENODIA_DIR"/xray-transport.sh; do
    [ -f "$_p" ] || continue
    _np=1
    sub "$(basename "$_p") status"



    sh "$_p" status 2>/dev/null || echo "(status не отработал)"
done
[ "$_np" = 0 ] && echo "(плагинов несущих нет — установка до рефактора транспортов)"

sec "OFFLOAD (Qualcomm NSS / SFE / ECM — влияет на conntrack и десинк)"
found=0
for k in /sys/kernel/debug/ecm /sys/module/shortcut_fe /sys/module/qca_nss_drv /proc/sys/dev/nss; do
    [ -e "$k" ] && { echo "есть: $k"; found=1; }
done
for f in /sys/kernel/debug/ecm/front_end_ipv4_stop /sys/kernel/debug/ecm/front_end_ipv6_stop; do
    [ -e "$f" ] && echo "$f = $(cat "$f" 2>/dev/null)"
done
[ "$found" = 0 ] && echo "(маркеров NSS/SFE/ECM не найдено — офлоад иной или выключен)"

sec "IPv6 В LAN (раздаётся ли клиентам / утечка мимо IPv4-сплита)"
_lanif=$(command -v lan_if >/dev/null 2>&1 && lan_if || echo br-lan)   # lan-lit: шим без router-lib.sh
sub "адреса $_lanif (глобальный 2…/3… = роутер раздаёт клиентам рабочий v6)"
ip -6 addr show "$_lanif" 2>/dev/null | grep -E 'inet6' || echo "(v6 на $_lanif нет)"
sub "v6 default (есть ли у ISP рабочий v6-upstream)"
ip -6 route show default 2>/dev/null || echo "(v6-дефолта нет — v6-утечки быть не может)"
sub "uci dhcp.lan (ra/dhcpv6 — анонсирует ли роутер v6 в LAN)"
uci show dhcp.lan 2>/dev/null | grep -E '\.ra=|\.dhcpv6=|\.ra_' || echo "(ra/dhcpv6 в uci не задано)"

sec "КЛИЕНТЫ ЛОКАЛЬНОЙ СЕТИ (аренды + кто реально в сети)"




sub "аренды dnsmasq (/tmp/dhcp.leases)"
if [ -f /tmp/dhcp.leases ]; then
    printf 'строк: %s\n' "$(grep -c . /tmp/dhcp.leases 2>/dev/null || echo 0)"
    awk '{print $3"\t"$2"\t"$4}' /tmp/dhcp.leases 2>/dev/null | sort -n
else
    echo "(файла нет — dnsmasq ещё не выдавал адресов в эту загрузку)"
fi
sub "кто в сети СЕЙЧАС (ARP на клиентских мостах)"
if [ -f "$ENODIA_DIR/lease-lib.sh" ]; then . "$ENODIA_DIR/lease-lib.sh"; fi
if command -v neigh_pairs >/dev/null 2>&1; then
    neigh_pairs | sort -n
    sub "в сети, но БЕЗ АРЕНДЫ (адрес задан на самом устройстве)"


    _dnb=$(neigh_pairs | while IFS='	' read -r _ni _nm; do
        awk -v w="$_ni" '$3==w{f=1} END{exit f?0:1}' /tmp/dhcp.leases 2>/dev/null || printf '%s\t%s\n' "$_ni" "$_nm"
    done)
    [ -n "$_dnb" ] && printf '%s\n' "$_dnb" || echo "(таких нет — у всех клиентов есть аренда)"
else
    echo "(нет lease-lib.sh — обновите установку)"
fi

sec "DNS (dnsmasq)"



for _dd in /etc/dnsmasq.d /tmp/dnsmasq.d; do
    sub "$_dd/ (наши файлы)"
    ls -la "$_dd/" 2>/dev/null | grep -E "awg|upstream|^-.*[0-9][0-9]-" || echo "(наших файлов нет)"
done
sub "00-upstream.conf (форвард upstream в туннель)"
showf /etc/dnsmasq.d/00-upstream.conf



sub "сид server-host в /etc/hosts"
grep -F "# awg-seed" /etc/hosts 2>/dev/null || echo "(наших строк нет)"
sub "счётчики доменов"




dom_count() {   # число строк ipset= в файле; нет файла = 0
    [ -f "$1" ] || { echo 0; return 0; }
    _dc=$(grep -c '^ipset=' "$1" 2>/dev/null); case "$_dc" in ''|*[!0-9]*) _dc=0 ;; esac
    echo "$_dc"
}
echo "awg-domains: $(dom_count /etc/dnsmasq.d/enodia-domains.conf)"
echo "awg-custom:  $(dom_count /etc/dnsmasq.d/enodia-custom.conf)"
sub "dnsmasq запущен? (процесс + аргументы)"






_dmq=""
for _p in /proc/[0-9]*; do
    [ -r "$_p/cmdline" ] || continue
    _cl=$(tr '\0' ' ' < "$_p/cmdline" 2>/dev/null)
    case "${_cl%% *}" in
        */dnsmasq|dnsmasq) echo "pid ${_p#/proc/}: $_cl"; _dmq="$_cl" ;;
    esac
done
[ -n "$_dmq" ] || echo "(демон dnsmasq НЕ найден среди процессов?!)"
sub "какие каталоги dnsmasq РЕАЛЬНО читает (conf-dir из его -C файла)"



_dmc=""
case "$_dmq" in *" -C "*) _dmc=${_dmq#*" -C "}; _dmc=${_dmc%% *} ;; esac
if [ -n "$_dmc" ] && [ -f "$_dmc" ]; then
    echo "конфиг демона: $_dmc"
    grep -E '^(conf-dir|conf-file|addn-hosts)' "$_dmc" 2>/dev/null || echo "(conf-dir в нём не задан — каталоги не подключены!)"




    if grep -q '^conf-dir=.*etc/dnsmasq\.d' "$_dmc" 2>/dev/null; then
        echo "⇒ /etc/dnsmasq.d демон читает НАПРЯМУЮ"
    else
        echo "⇒ /etc/dnsmasq.d демон НЕ читает: это персист, в живой /tmp его копирует init на буте"
        echo "  (правка только в /etc без рестарта dnsmasq = правила в ядре НЕТ)"
    fi
else
    grep -hE '^(conf-dir|conf-file)' /var/etc/dnsmasq.conf.* 2>/dev/null || echo "(конфиг демона не найден)"
fi
sub "ДОМЕННЫЕ ПРАВИЛА: заявлено в dnsmasq → лежит ли в ядре"












_dtmp=/tmp/enodia-dump-dom.$$
: > "$_dtmp"
for _dmf in /etc/dnsmasq.d/enodia-custom.conf /etc/dnsmasq.d/enodia-domains.conf \
            /etc/dnsmasq.d/[0-9][0-9]-*.conf /tmp/dnsmasq.d/[0-9][0-9]-*.conf; do
    [ -f "$_dmf" ] || continue
    grep '^ipset=' "$_dmf" 2>/dev/null >> "$_dtmp"
done
if [ -s "$_dtmp" ]; then
    echo "всего строк ipset=: $(grep -c . "$_dtmp" 2>/dev/null || echo 0)   (проверяем первые 6)"
    _i=0
    while [ "$_i" -lt 6 ]; do
        _i=$((_i+1))
        _ln=$(awk -v n="$_i" 'NR==n{print; exit}' "$_dtmp")
        [ -n "$_ln" ] || break

        _rest=${_ln#ipset=/}
        _sets=${_rest##*/}; _doms=${_rest%/*}
        _d1=${_doms%%/*}; _s1=${_sets%%,*}
        _was=$(ipset list -t "$_s1" 2>/dev/null | grep 'Number of entries' | awk '{print $NF}')
        [ -n "$_was" ] || _was="нет набора"

        _ip=$(nslookup "$_d1" 2>/dev/null | awk '/^Name:/{f=1} f&&/^Address /{print $3; exit}')
        _now=$(ipset list -t "$_s1" 2>/dev/null | grep 'Number of entries' | awk '{print $NF}')
        [ -n "$_now" ] || _now="-"
        if [ -n "$_ip" ] && ipset test "$_s1" "$_ip" >/dev/null 2>&1; then _v="В НАБОРЕ ✔"
        elif [ -z "$_ip" ]; then _v="НЕ РЕЗОЛВИТСЯ (нет A-записи или DNS мёртв)"
        else _v="НЕ В НАБОРЕ ✘ — правило по этому домену НЕ РАБОТАЕТ"; fi
        echo "$_d1 → $_s1: было $_was, стало $_now, резолв ${_ip:-—} ⇒ $_v"
    done
else
    echo "(строк ipset= нет вовсе — доменных правил не заявлено)"
fi
rm -f "$_dtmp"
sub "ЖИВАЯ проба dnsmasq: nslookup ya.ru (busybox шлёт на систему = dnsmasq)"

nslookup ya.ru 2>&1 | head -8
sub "upstream МИМО dnsmasq: DoH к 1.1.1.1 по IP (жив ли путь до резолвера)"






curl -sk --max-time 6 'https://1.1.1.1/dns-query?name=ya.ru&type=A' -H 'accept: application/dns-json' 2>/dev/null | head -c 400; echo
sub "тот же DoH, но ПРИНУДИТЕЛЬНО через WAN (так ходит фолбэк резолва — dns-lib doh_ips)"



if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then
    . "$ENODIA_DIR/dns-lib.sh"
    echo "WAN-dev: $(_dnslib_wan 2>/dev/null || echo '?')  →  $(doh_ips ya.ru '' 2>/dev/null | tr '\n' ' ')"
else
    echo "(нет dns-lib.sh — старая установка)"
fi
sub "/etc/resolv.conf"
cat /etc/resolv.conf 2>/dev/null

sec "СОСТОЯНИЕ (persist-файлы в ENODIA_STATE — несекретные)"
_dp_act2=$(cat "$ENODIA_STATE/.active" 2>/dev/null | tr -d '\r')   # пустой файл = «неизвестно», см. выше
echo "Активный конфиг (.active): ${_dp_act2:-?}"
for f in .vpn-off .failover-mode .failover-home .full-tunnel .bypass-ips .bypass-dst \
         .bypass-ifaces .bypass-guest .fullvpn-ips .fullvpn-ifaces \
         .fullvpn-guest .iplist.count; do
    showf "$ENODIA_STATE/$f"
done
sub "Wi-Fi: какая сеть на каком интерфейсе (правила .bypass-ifaces/.fullvpn-ifaces ставятся по wlN)"



if [ -f "$ENODIA_DIR/wifi-lib.sh" ]; then
    . "$ENODIA_DIR/wifi-lib.sh"
    for _di in $(wifi_iface_list); do
        echo "  $_di  ->  $(wifi_ssid_of "$_di" 2>/dev/null || echo '?')"
    done
else
    echo "(нет wifi-lib.sh — старая установка)"
fi
sub "Wi-Fi: клиенты в эфире (скорость линка / стандарт / ширина / RSSI)"





if [ -f "$ENODIA_DIR/wifi-stats.sh" ]; then
    sh "$ENODIA_DIR/wifi-stats.sh" tsv 2>&1 | head -40
else
    echo "(нет wifi-stats.sh — старая установка)"
fi
sub "iplist.conf (источник списка IP — несекретно)"
showf "$ENODIA_STATE/iplist.conf"

sec "ВХОД В ПАНЕЛЬ (форма входа, сессии, пауза после неудач)"





if [ -f "$ENODIA_DIR/totp.sh" ]; then
    echo "totp.sh status: $(sh "$ENODIA_DIR/totp.sh" status 2>&1 | grep '^{' | tail -1)"
else
    echo "(нет totp.sh — установка старее формы входа)"
fi




_dmp_sch=$(cut -d'$' -f2 "$ENODIA_STATE/.panel-pass" 2>/dev/null | head -1)
if [ -n "$_dmp_sch" ]; then _dmp_sch="\$$_dmp_sch\$"; else _dmp_sch="(пароля нет — панель не поднимется)"; fi
echo "Схема хэша пароля: $_dmp_sch  (openssl прошивки: $(openssl version 2>/dev/null | cut -d' ' -f1-2))"




sub "Входы в панель (сколько осталось жить)"




if [ -s "$ENODIA_STATE/.totp-sessions" ]; then





	awk -F'\t' -v n="$(date +%s)" '{ lv=$6+0; if(lv<1) lv=2; d=$2-n; if (d <= 0) printf "уровень %s · ИСТЕКЛА · %s\n", lv, substr($4,1,40); else if (d < 172800) printf "уровень %s · осталось %s ч · %s\n", lv, int(d/3600), substr($4,1,40); else printf "уровень %s · осталось %s суток · %s\n", lv, int(d/86400), substr($4,1,40) }' "$ENODIA_STATE/.totp-sessions" 2>/dev/null
else echo "(входов нет)"; fi
echo "Отметка часов (/tmp/.enodia-clock-base): $(cat /tmp/.enodia-clock-base 2>/dev/null || echo "нет — ещё не бежал web-ui.sh start")  сейчас=$(date +%s) аптайм=$(dmp_uptime)"



sub "Пауза после неудач (/tmp/.enodia-totp-fail: адрес · неудач · разблокировка · отметка)"
if [ -s /tmp/.enodia-totp-fail ]; then cat /tmp/.enodia-totp-fail 2>/dev/null; else echo "(пусто — счётчик чист)"; fi
echo "Флаги: .panel-tls=$( [ -f "$ENODIA_STATE/.panel-tls" ] && echo да || echo нет )  .panel-wan=$( [ -f "$ENODIA_STATE/.panel-wan" ] && echo да || echo нет )"
sub "Строка запуска uhttpd панели"



_dmp_wpid=$(cat /tmp/enodia-uhttpd-web.pid 2>/dev/null)
if [ -n "$_dmp_wpid" ] && [ -d "/proc/$_dmp_wpid" ]; then
    tr '\0' ' ' < "/proc/$_dmp_wpid/cmdline" 2>/dev/null; echo
else
    echo "(uhttpd панели не запущен — pid-файл /tmp/enodia-uhttpd-web.pid пуст или процесса нет)"
fi

sec "СЕКРЕТНЫЕ ФАЙЛЫ — ТОЛЬКО НАЛИЧИЕ / ПРАВА (содержимое НЕ читаем)"
echo "(режим / владелец / размер / имя)"
showmeta "$ENODIA_STATE/awg.conf"
showmeta "$ENODIA_STATE/awg0.conf"
showmeta "$ENODIA_STATE/amnezia_for_awg.conf"
showmeta "$ENODIA_STATE/notify.conf"
showmeta "$ENODIA_STATE/.subs"
showmeta "$ENODIA_STATE/.sub-names"
showmeta "$ENODIA_STATE/.sub-picks"



showmeta "$ENODIA_STATE/.panel-pass"
showmeta "$ENODIA_STATE/.totp"
showmeta "$ENODIA_STATE/.totp-recovery"
showmeta "$ENODIA_STATE/.totp-sessions"
if [ -d "$ENODIA_STATE/configs" ]; then
    for c in "$ENODIA_STATE"/configs/*.conf; do [ -e "$c" ] && showmeta "$c"; done
fi

sec "ПИСЬМА: ВЫКЛЮЧАТЕЛЬ И ПОВОДЫ"



if [ -f "$ENODIA_STATE/.notify-off" ]; then echo "письма: выключены целиком (.notify-off)"; else echo "письма: включены"; fi
_dmp_cls=$( [ -f "$ENODIA_DIR/events.sh" ] && sh "$ENODIA_DIR/events.sh" classes 2>/dev/null | tr '\n' ' ')
echo "поводы: ${_dmp_cls:-(events.sh не ответил вербом classes — установка старше шага 7b)}"

sec "ЛОКИ / СТЕЙТ В /tmp"






















for l in enodia-heal.lock enodia-heal.reason enodia-heal.skipped enodia-heal-kick.tries enodia-heal-kick.stamp \
         enodia-heal-kick.said enodia-heal-kick.mailed enodia-heal-kick.cfg enodia-switching.lock enodia-watchdog.lock enodia-watchdog.pid \
         enodia-watchdog.state enodia-watchdog.xstate enodia-failover.stamp enodia-failover.backoff \
         enodia-failover-episode enodia-awg0.seen enodia-awg0.firstup \
         enodia-domwarm.stamp enodia-proto-install.lock enodia-byedpi-sweep.lock \
         enodia-subs-update.lock enodia-gh-update.lock enodia-pkg-install.lock enodia-uninstall.mode \
         enodia-wanout.count enodia-wanout.event enodia-wanout.sweep \
         .enodia-carrier-up.stamp .enodia-support-active; do
    if [ -e "/tmp/$l" ]; then



        if [ -d "/tmp/$l" ]; then
            echo "/tmp/$l: есть (каталог-лок)$( [ -s "/tmp/$l/pid" ] && echo " -> держит pid $(cat "/tmp/$l/pid" 2>/dev/null)" )"
        else
            echo "/tmp/$l: есть$( [ -s "/tmp/$l" ] && echo " -> $(cat "/tmp/$l" 2>/dev/null)" )"
        fi
    else
        echo "/tmp/$l: нет"
    fi
done



if [ -f "$ENODIA_DIR/watchdog.sh" ] && grep -q '^\[ "\$1" = standing \]' "$ENODIA_DIR/watchdog.sh"; then
    echo "вердикт сторожа (watchdog.sh standing): $(sh "$ENODIA_DIR/watchdog.sh" standing 2>/dev/null | tr '\n' ' ')"
else
    echo "вердикт сторожа: верба standing нет (старая копия watchdog.sh)"
fi

sec "CRON (автозапуск — без него после ребута не поднимется)"
cat /etc/crontabs/root 2>/dev/null || echo "(crontab пуст?!)"

sec "РАСКЛАДКА (в каком режиме стоит система и откуда идёт cron)"








if [ -f "$ENODIA_BOOT/boot.sh" ]; then
    sh "$ENODIA_BOOT/boot.sh" status 2>&1


    [ -f /etc/hotplug.d/block/99-enodia-usb ] && echo "hotplug-хук: на месте" || echo "hotplug-хук: нет (до первого тика cron это норма)"
else
    echo "(бутстрапа нет — установка старее фичи режимов; код на флеше роутера)"
fi






if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
if command -v store_state >/dev/null 2>&1; then
    case "$(store_state)" in
        ok)   echo "Хранилище: включено и доступно ($(store_root))" ;;
        lost) echo "Хранилище: ВКЛЮЧЕНО, НО НЕ НАЙДЕНО — бинари протоколов с него не запустятся" ;;
        *)    echo "Хранилище: не используется" ;;
    esac
else
    echo "Хранилище: (store-lib.sh старее фичи — состояние неизвестно)"
fi






sub "права на каталоги (0777 = приехало с exFAT, лечится переустановкой скриптов)"
for _pd in "$ENODIA_DIR" "$ENODIA_DIR/web" "$ENODIA_DIR/web/cgi-bin" "$ENODIA_STATE" "$ENODIA_BIN"; do
    showmeta "$_pd"
done

sec "БИНАРНИКИ + ВЕРСИИ (что реально установлено и ГДЕ лежит)"










if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path  >/dev/null 2>&1 || bin_path()  { printf '%s' "$ENODIA_BIN/$1"; }
command -v bin_where >/dev/null 2>&1 || bin_where() { [ -x "$ENODIA_BIN/$1" ] && printf 'router'; }



command -v bin_on_store >/dev/null 2>&1 || bin_on_store() { return 1; }



command -v bin_pinned >/dev/null 2>&1 || bin_pinned() { return 1; }
DMP_BINS="amneziawg-go awg xray hysteria hev byedpi nfqws https-dns-proxy dot-proxy panel-tls"



_dmp_bst=""; [ -f "$ENODIA_DIR/gh-update.sh" ] && _dmp_bst=$(sh "$ENODIA_DIR/gh-update.sh" bin-status $DMP_BINS 2>/dev/null)
_dmp_any=0
for _b in $DMP_BINS; do
    _w=$(bin_where "$_b")
    [ -n "$_w" ] || continue
    if bin_on_store "$_b"; then _w=store; fi
    _dmp_any=1
    _p=$(bin_path "$_b")







    _bst=$(printf '%s\n' "$_dmp_bst" | awk -F'\t' -v n="$_b" '$1 == n {
        s = ($2 == "current") ? "свежая " $3 : ($2 == "outdated") ? "УСТАРЕЛА " ($3 == "" ? "?" : $3) " → " $4 : ($2 == "unknown") ? "сборка не сверена" : ""
        if ($5 == "old") s = s " · РАБОТАЕТ ПРЕЖНЯЯ до перезапуска"
        if (s != "") print " · " s; exit }')
    printf '%-16s %s  %s\n' "$_b" \
        "$(ls -l "$_p" 2>/dev/null | awk '{printf "%10s байт  %s %s %s", $5, $6, $7, $8}')" \
        "$( [ "$_w" = store ] && echo '· накопитель' || echo '· роутер' )$( bin_pinned "$_b" && echo ' · закреплён' )$_bst"
done
[ "$_dmp_any" = 1 ] || echo "(бинарников нет — установка «только панель» без бутстрапа либо payload не доехал)"




if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
if command -v daemon_wait_secs >/dev/null 2>&1; then
    printf 'ждём старта: xray %s с · hysteria %s с · byedpi %s с · hev %s с (daemon-lib.sh; потолок по носителю, за трупом не ждём вовсе)\n' \
        "$(daemon_wait_secs xray 8)" "$(daemon_wait_secs hysteria 25)" "$(daemon_wait_secs byedpi 8)" "$(daemon_wait_secs hev 6)"
else
    echo "ждём старта: daemon-lib.sh не загружен (старая установка) — фиксированные 8 с независимо от носителя"
fi





if [ -d /tmp/enodia-usb.lock ]; then
    _dlp=$(cat /tmp/enodia-usb.lock/pid 2>/dev/null)
    echo "лок расстановки бинарей ЗАНЯТ: pid ${_dlp:-?} ($([ -n "$_dlp" ] && [ -d "/proc/$_dlp" ] && echo 'держатель жив' || echo 'ДЕРЖАТЕЛЬ МЁРТВ — снимется на следующем заходе'))"
fi



for _b in amneziawg-go awg; do
    _p=$(bin_path "$_b")
    if [ -x "$_p" ]; then printf '%s: ' "$_b"; "$_p" --version 2>&1 | head -1; fi
done

sec "РЕСУРСЫ (RAM / диск / размер логов)"
awk '/^MemTotal:/{t=$2}/^MemFree:/{f=$2}/^MemAvailable:/{a=$2}END{printf "RAM: %d МБ свободно из %d МБ (доступно %s)\n", f/1024, t/1024, (a==""?"?":sprintf("%d МБ", a/1024))}' /proc/meminfo 2>/dev/null






_ourdf=$(df -k "$ENODIA_DIR" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{print $NF" "$1}')
_ourmp=${_ourdf% *}; _ourdev=${_ourdf#* }
for m in "${_ourmp:-/data}" /tmp; do

    df "$m" 2>/dev/null | tail -1 | awk -v mp="$m" 'NF>=5 && $(NF-4)+0>0{printf "Диск %s: %.1fM своб из %.1fM (занято %.0f%%)\n", mp, $(NF-2)/1024, $(NF-4)/1024, ($(NF-4)-$(NF-2))*100/$(NF-4)}'
done




sub "тома флеша (* — тот, на котором живём мы)"
df -k 2>/dev/null | awk -v od="${_ourdev:-none}" 'NR>1 && NF>=5 && $(NF-4)+0>0 && $(NF-2)+0>0 && $1!="tmpfs" && $1!="devtmpfs" && $1!="none" { if (seen[$1]++) next; printf "%s %s: %.1fM своб из %.1fM (%s)\n", ($1==od?"*":" "), $NF, $(NF-2)/1024, $(NF-4)/1024, $1 }'
our_ramlogs | while read -r _lp; do ls -l "$_lp" 2>/dev/null; done \
  | awk '{s+=$5}END{if(NR>0)printf "Логи /tmp (НАШИ): %d КБ в %d файлах\n",(s+1023)/1024,NR; else print "Логи /tmp (НАШИ): нет"}'
echo "NB: /tmp — это ОЗУ (tmpfs), занятое там вычитается из свободной памяти. Считаем ТОЛЬКО свои"
echo "    логи: рядом лежат стоковые логи Xiaomi, и они к нашему расходу ОЗУ отношения не имеют."










sub "чем занят наш том флеша (clean.sh dryrun — только показывает, не удаляет)"
if [ -f "$ENODIA_DIR/clean.sh" ]; then
    sh "$ENODIA_DIR/clean.sh" dryrun 2>/dev/null || echo "(clean.sh dryrun не отработал)"
else
    echo "(clean.sh нет — установка до разбивки места)"
fi


echo "NB: du (разбивка выше) — ЛОГИЧЕСКИЙ размер, df — реально занятые блоки; UBIFS жмёт, разница штатна."





sub "кто занимает ОЗУ (ram-usage.sh)"
if [ -f "$ENODIA_DIR/ram-usage.sh" ]; then
    sh "$ENODIA_DIR/ram-usage.sh" 2>/dev/null | head -40 || echo "(ram-usage.sh не отработал)"
else
    echo "(ram-usage.sh нет — установка до разбивки ОЗУ)"
fi
sub "OOM: убивало ли ядро процессы из-за нехватки памяти"


_oom=$(dmesg 2>/dev/null | grep -iE 'out of memory|oom-kill|killed process|lowmemorykiller' | tail -8)
if [ -n "$_oom" ]; then
    echo "$_oom"
else
    echo "следов OOM нет (буфер dmesg живёт с последнего ребута — после перезагрузки он пуст в любом случае)"
fi

sec "ЛОГИ /tmp (хвосты по 40 строк)"









for lg in $DUMP_LOGS; do
    [ -s "/tmp/$lg.log" ] || continue
    sub "$lg.log"
    tail -40 "/tmp/$lg.log" 2>/dev/null
done

for i in 2 3 4; do
    for lg in xray hev hysteria byedpi; do
        [ -s "/tmp/$lg-s$i.log" ] || continue
        sub "$lg-s$i.log (доп-выход №$i)"
        tail -25 "/tmp/$lg-s$i.log" 2>/dev/null
    done
done

sec "ВНЕШНИЙ IP (тест маршрута — IP замаскированы redact)"


printf 'Прямой IP:  '; _d=$(curl -s -k ${WANDEV:+--interface $WANDEV} --max-time 6 https://1.1.1.1/cdn-cgi/trace 2>/dev/null | sed -n 's/^ip=\([0-9.]*\).*/\1/p'); echo "${_d:-(нет ответа)}"
if ip link show awg0 >/dev/null 2>&1; then
    printf 'Через awg0: '; _v=$(curl -s -k --interface awg0 --max-time 6 https://1.1.1.1/cdn-cgi/trace 2>/dev/null | sed -n 's/^ip=\([0-9.]*\).*/\1/p'); echo "${_v:-(нет ответа через туннель)}"
fi

echo ""
echo "==================================================================="
echo "## КОНЕЦ ДАМПА"
echo "==================================================================="
}


























sys_budget() {
    _a=$(awk '/^MemAvailable:/{print $2}' "${MEMINFO:-/proc/meminfo}" 2>/dev/null)
    case "$_a" in ''|*[!0-9]*) _a=0 ;; esac



    if   [ "$_a" -gt 131072 ]; then SYS_TAIL=20000; SYS_OLD=1   # >128 МБ: всё, включая .gz
    elif [ "$_a" -gt  32768 ]; then SYS_TAIL=10000; SYS_OLD=0   # >32 МБ: часы истории, ~2 МБ пик
    else                            SYS_TAIL=3000;  SYS_OLD=0   # тесно: только хвосты
    fi
}
OUR_TAIL=3000           # строк из каждого нашего лога (они мелкие, десятки КБ)

cmd_archive() {
    ts=$(date +%Y%m%d-%H%M%S 2>/dev/null); case "$ts" in ''|*[!0-9-]*) ts=diag ;; esac
    base="enodia-diag-$ts"
    td="/tmp/.enodia-diag-$$"

    trap 'rm -rf "$td" "$ENV_SED"' EXIT
    rm -rf "$td"; mkdir -p "$td/$base/logs" "$td/$base/system" 2>/dev/null || return 1

    sys_budget; st=$SYS_TAIL; olds=$SYS_OLD

    build_env_sed
    main 2>&1 | redact > "$td/$base/dump.txt"



    our_ramlogs | while read -r p; do
        [ -s "$p" ] || continue
        tail -$OUR_TAIL "$p" 2>/dev/null | redact > "$td/$base/logs/$(basename "$p")"
    done


    [ -s /tmp/messages ] && tail -$st /tmp/messages 2>/dev/null | redact > "$td/$base/system/messages"
    [ -s /data/usr/log/messages.0 ] && tail -$st /data/usr/log/messages.0 2>/dev/null | redact > "$td/$base/system/messages.0"
    if [ "$olds" = 1 ]; then
        for g in /data/usr/log/messages.*.gz; do
            [ -s "$g" ] || continue
            n=$(basename "$g" .gz)
            zcat "$g" 2>/dev/null | tail -$st | redact > "$td/$base/system/$n"
        done
    fi



    [ -s /tmp/panic.message ] && redact < /tmp/panic.message > "$td/$base/system/panic.message"

    {
        echo "Диагностический архив роутера, собран: $(date 2>/dev/null)"
        echo ""
        echo "dump.txt        — состояние роутера на момент сборки (то же, что «текстовая диагностика»)"
        echo "logs/           — логи подсистем проекта (/tmp, живут до перезагрузки), хвост $OUR_TAIL строк"
        echo "system/messages — системный лог роутера, живой (/tmp, до перезагрузки)"
        echo "system/messages.0…N — он же, ротированный на флеш: ПЕРЕЖИВАЕТ перезагрузку"
        echo "system/panic.message — kernel panic из mtd-раздела, если стоковая утилита его выложила"
        echo ""
        echo "Хвост системных логов: $st строк на файл (объём выбран по свободной ОЗУ роутера)."
        echo "Старые ротированные архивы .gz: $( [ "$olds" = 1 ] && echo "включены" || echo "пропущены — на этом роутере мало свободной памяти" )."
        echo ""
        echo "ЧТО ЗАМАСКИРОВАНО во всех файлах: ключи и endpoint VPN, публичные IPv4 (первые два"
        echo "октета), последние три октета MAC-адресов, имена Wi-Fi-сетей, имена клиентов из аренд"
        echo "DHCP. Имена заменены на [SSID-N] / [HOST-N]: одно и то же имя — один и тот же номер,"
        echo "так что по архиву видно, какое правило на какой сети, но не как сеть называется."
        echo "Маскировка эвристическая — просмотрите архив перед публикацией."
        echo ""
        echo "Где искать причину перезагрузки: в system/messages* по словам"
        echo "  «Linux version»            — старт ядра (сама загрузка)"
        echo "  «procd: - shutdown -»      — штатное выключение/перезагрузка"
        echo "  «Out of memory» / «oom-kill» — нехватка памяти, ядро убило процесс"
        echo "  «kernel panic»             — падение ядра"
    } > "$td/$base/README.txt"

    tar -cz -C "$td" "$base" 2>/dev/null
    rm -rf "$td" "$ENV_SED"; trap 'rm -f "$ENV_SED"' EXIT
    return 0
}






trap 'rm -f "$ENV_SED"; exit 141' HUP INT TERM PIPE
trap 'rm -f "$ENV_SED"' EXIT

case "${1:-}" in
    ''|text) main 2>&1 | redact ;;
    archive) cmd_archive ;;



    redact)  build_env_sed; redact ;;
    *) echo "usage: $0 [text|archive|redact]" >&2; exit 2 ;;
esac
