#!/bin/sh






























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}

if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -d "/proc/$1" ]; }
command -v bin_path  >/dev/null 2>&1 || bin_path()  { printf '%s' "$ENODIA_BIN/$1"; }
command -v bin_dest  >/dev/null 2>&1 || bin_dest()  { printf '%s' "$ENODIA_BIN/$1"; }
command -v bin_prune >/dev/null 2>&1 || bin_prune() { return 0; }
GH="$ENODIA_DIR/gh-update.sh"
SETUP="$ENODIA_DIR/install.sh"
TRANSPORT="$ENODIA_DIR/transport.sh"
STATE="$ENODIA_STATE/.proto-install.state"
LOG="$ENODIA_STATE/.proto-install.log"
LOCK="/tmp/enodia-proto-install.lock"


set_state() { echo "$1" > "$STATE.new" && mv -f "$STATE.new" "$STATE"; }
log() { printf '[%s] %s\n' "$(date '+%H:%M:%S')" "$*" >> "$LOG"; }

parse_combo() {
    case "$1" in
        awg)        WANT_AWG=1; WANT_ALT=none ;;
        xray)       WANT_AWG=0; WANT_ALT=xray ;;
        hy2)        WANT_AWG=0; WANT_ALT=hy2 ;;
        byedpi)     WANT_AWG=0; WANT_ALT=byedpi ;;
        awg-xray)   WANT_AWG=1; WANT_ALT=xray ;;
        awg-hy2)    WANT_AWG=1; WANT_ALT=hy2 ;;
        awg-byedpi) WANT_AWG=1; WANT_ALT=byedpi ;;
        *) return 1 ;;
    esac
}







have_awg()    { [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -x "$ENODIA_BIN/awg" ]; }
have_xray()   { [ -x "$(bin_path xray)" ]; }
have_hy2()    { [ -x "$(bin_path hysteria)" ]; }
have_byedpi() { [ -x "$(bin_path byedpi)" ]; }



cur_alts()    { _l=""; have_xray && _l="$_l xray"; have_hy2 && _l="$_l hy2"; have_byedpi && _l="$_l byedpi"; echo "${_l# }"; }

df_free_mb(){ df -k "$ENODIA_DIR" 2>/dev/null | tail -1 | awk 'NF>=5 && $(NF-4)+0>0{printf "%d",$(NF-2)/1024}'; }

apply() {
    combo="$1"


    rm -f "$ENODIA_STATE/.proto-install.plan" 2>/dev/null
    if ! parse_combo "$combo"; then : > "$LOG"; set_state FAIL; log "неизвестный набор: $combo"; return 1; fi
    : > "$LOG"; set_state RUNNING
    free=$(df_free_mb)
    log "Цель: awg=$WANT_AWG, альт=$WANT_ALT (свободно ${free:-?} МБ)"

    active=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    cura=$(cur_alts)
    log "Сейчас: активный=$active, альты=[${cura:-нет}], awg-бинарь=$(have_awg && echo да || echo нет)"









    need_dl=0
    { [ "$WANT_AWG" = 1 ] && ! have_awg; }           && need_dl=1
    { [ "$WANT_ALT" = xray ]   && ! have_xray; }      && need_dl=1
    { [ "$WANT_ALT" = hy2 ]    && ! have_hy2; }       && need_dl=1
    { [ "$WANT_ALT" = byedpi ] && ! have_byedpi; }    && need_dl=1
    { [ "$WANT_ALT" != none ]  && [ ! -x "$(bin_path hev)" ]; } && need_dl=1



    if [ "$need_dl" = 1 ] && [ -f "$GH" ]; then
        log "Пре-чек доступности GitHub (нужны закачки)…"


        _why=$(sh "$GH" reachable 2>/dev/null)
        if [ "$?" = 0 ]; then
            log "GitHub доступен — продолжаю."
        else
            [ -n "$_why" ] || _why="GitHub недоступен — проверьте VPN и интернет"
            set_state FAIL
            log "$_why. НЕ трогаю текущий набор (ничего не удалено)."
            return 1
        fi
    fi


    drop_active=0
    case "$active" in
        awg)    [ "$WANT_AWG" = 1 ]      || drop_active=1 ;;
        xray)   [ "$WANT_ALT" = xray ]   || drop_active=1 ;;
        hy2)    [ "$WANT_ALT" = hy2 ]    || drop_active=1 ;;
        byedpi) [ "$WANT_ALT" = byedpi ] || drop_active=1 ;;
    esac
    if [ "$drop_active" = 1 ] && [ -n "$active" ]; then
        log "Активная несущая ($active) уходит из набора — релинквиш (прямой режим до подъёма новой)"
        sh "$TRANSPORT" down "$active" >/dev/null 2>&1
    fi









    purge_needed=0
    if [ "$need_dl" = 1 ] && [ -f "$SETUP" ]; then
        purge_needed=1
        want_pkgs=""
        [ "$WANT_AWG" = 1 ] && want_pkgs="awg"
        [ "$WANT_ALT" != none ] && want_pkgs="${want_pkgs:+$want_pkgs,}$WANT_ALT"
        if [ -f "$ENODIA_DIR/packages.sh" ] && sh "$ENODIA_DIR/packages.sh" plan-ok "${want_pkgs:--}" - >/dev/null 2>&1; then
            purge_needed=0
            log "Места хватает — прочие альты ОСТАВЛЯЮ на флеше (установлен ≠ активен)."
        fi
    fi
    if [ "$purge_needed" = 1 ]; then
        log "Освобождаю флеш: снимаю альты, кроме нужного ($WANT_ALT), через purge-alt…"
        INSTALL_ALT="$WANT_ALT" sh "$SETUP" purge-alt >> "$LOG" 2>&1
    fi






    awg_carries_slot=0
    if [ -f "$ENODIA_DIR/slots.sh" ] && sh "$ENODIA_DIR/slots.sh" carriers 2>/dev/null | grep -qx awg; then
        awg_carries_slot=1
    fi
    if [ "$WANT_AWG" = 0 ] && have_awg && [ "$awg_carries_slot" = 1 ]; then
        log "AmneziaWG-бинари ОСТАВЛЕНЫ: на них висит дополнительный выход (см. «Соединение → Дополнительные выходы»)."
    elif [ "$WANT_AWG" = 0 ] && have_awg; then





        if [ -f "$ENODIA_STATE/server/.on" ]; then
            log "AmneziaWG-бинари ОСТАВЛЕНЫ: включён «доступ домой» (сервер awgs0 — тот же демон). Выключите его на экране «Доступ домой», если нужно освободить ~1.1 МБ."
        else
            log "Снимаю AmneziaWG (база) — целевой набор без awg"
            [ "$active" = awg ] && sh "$TRANSPORT" down awg >/dev/null 2>&1
            rm -f "$ENODIA_BIN/amneziawg-go" "$ENODIA_BIN/awg"
        fi
    fi






    need_b=0; need_unknown=0
    add_need() {
        _n=$(sh "$GH" bin-size "$1" 2>/dev/null | tr -d ' \r')
        case "$_n" in ''|*[!0-9]*|0) need_unknown=1; return 0 ;; esac
        need_b=$((need_b+_n))
    }
    { [ "$WANT_AWG" = 1 ] && ! have_awg; } && { add_need amneziawg-go; add_need awg; }
    { [ "$WANT_ALT" = xray ]   && ! have_xray; }   && add_need xray
    { [ "$WANT_ALT" = hy2 ]    && ! have_hy2; }    && add_need hysteria
    { [ "$WANT_ALT" = byedpi ] && ! have_byedpi; } && add_need byedpi
    { [ "$WANT_ALT" != none ] && [ ! -x "$(bin_path hev)" ]; } && add_need hev   # bin_path: hev может лежать на накопителе (иначе лишняя перекачка и завышенный план места)
    need=$(( (need_b + 1048575) / 1048576 ))   # байты → МБ ВВЕРХ
    [ "$need_unknown" = 0 ] || log "Размеры части бинарей неизвестны (нет bin-manifest.txt) — гард места неполный"
    sync 2>/dev/null   # отразить недавние rm (purge-alt): UBIFS пишет лениво, иначе df завышает «занято»
    free=$(df_free_mb)
    if [ "$need" -gt 0 ]; then
        log "Нужно скачать ~${need} МБ, свободно ${free:-0} МБ"




        if [ "${free:-0}" -lt $((need+1)) ]; then
            set_state FAIL; log "Мало места на /data (нужно ~${need} МБ, свободно ${free:-0} МБ) — освободите флеш или перезагрузите роутер и повторите."; return 1
        fi
    fi


    if [ "$WANT_AWG" = 1 ] && ! have_awg; then
        log "Скачиваю AmneziaWG-бинари…"
        sh "$GH" fetch-bin amneziawg-go "$ENODIA_BIN/amneziawg-go" >> "$LOG" 2>&1 || { set_state FAIL; log "не скачал amneziawg-go"; return 1; }
        sh "$GH" fetch-bin awg "$ENODIA_BIN/awg" >> "$LOG" 2>&1 || { set_state FAIL; log "не скачал awg"; return 1; }
    fi




    dl_bin() {   # $1 = имя бинаря, $2 = человеческая метка
        log "Скачиваю $2…"
        _d=$(bin_dest "$1"); mkdir -p "${_d%/*}" 2>/dev/null
        sh "$GH" fetch-bin "$1" "$_d" >> "$LOG" 2>&1 || { set_state FAIL; log "не скачал $1"; return 1; }
        bin_prune "$1"
        return 0
    }
    case "$WANT_ALT" in
        xray)
            have_xray || dl_bin xray "Xray" || return 1
            [ -x "$(bin_path hev)" ] || dl_bin hev "hev (tun2socks)" || return 1
            ;;
        hy2)
            have_hy2 || dl_bin hysteria "Hysteria2" || return 1
            [ -x "$(bin_path hev)" ] || dl_bin hev "hev (tun2socks)" || return 1
            ;;
        byedpi)


            have_byedpi || dl_bin byedpi "ByeDPI (ciadpi)" || return 1
            [ -x "$(bin_path hev)" ] || dl_bin hev "hev (tun2socks)" || return 1
            ;;
    esac


    [ -f "$ENODIA_DIR/xray-transport.sh" ] && chmod +x "$ENODIA_DIR/xray-transport.sh" 2>/dev/null
    [ -f "$ENODIA_DIR/transport-hy2.sh" ] && chmod +x "$ENODIA_DIR/transport-hy2.sh" 2>/dev/null
    [ -f "$ENODIA_DIR/transport-byedpi.sh" ] && chmod +x "$ENODIA_DIR/transport-byedpi.sh" 2>/dev/null


    fw3_wiped=0
    if [ "$WANT_AWG" = 1 ] && ! ip link show awg0 >/dev/null 2>&1; then



        if [ -f "$ENODIA_STATE/awg.conf" ] && [ ! -f "$ENODIA_STATE/amnezia_for_awg.conf" ]; then
            cp "$ENODIA_STATE/awg.conf" "$ENODIA_STATE/amnezia_for_awg.conf"
        fi



        if [ -f "$ENODIA_STATE/.vpn-off" ]; then
            log "VPN выключен вручную — AmneziaWG не поднимаю (поднимется при включении VPN)"
        elif [ -f "$ENODIA_STATE/awg.conf" ] && [ -f "$ENODIA_DIR/awg_setup.sh" ]; then


            log "Поднимаю AmneziaWG с нуля (awg_setup.sh)…"



            fw3_wiped=1
            ( cd "$ENODIA_DIR" && sh ./awg_setup.sh ) >> "$LOG" 2>&1 || log "awg_setup завершился с ошибкой (см. лог выше)"
        else
            log "Нет awg.conf или awg_setup.sh — добавьте сервер AmneziaWG в «Соединение → Серверы и конфиги»"
        fi
    fi


    [ -f "$ENODIA_DIR/mark-core.sh" ] && sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1
    target=""
    case "$active" in
        awg)    [ "$WANT_AWG" = 1 ]      && target=awg ;;
        xray)   [ "$WANT_ALT" = xray ]   && target=xray ;;
        hy2)    [ "$WANT_ALT" = hy2 ]    && target=hy2 ;;
        byedpi) [ "$WANT_ALT" = byedpi ] && target=byedpi ;;
    esac
    if [ -z "$target" ]; then
        if [ "$WANT_AWG" = 1 ]; then target=awg; else target="$WANT_ALT"; fi
    fi
    if [ -n "$target" ] && [ "$target" != none ] && [ -f "$ENODIA_STATE/.vpn-off" ]; then



        echo "$target" > "$ENODIA_STATE/.transport"; rm -f "$ENODIA_STATE/.zapret-on" 2>/dev/null
        log "VPN выключен вручную — несущую не поднимаю; при включении поднимется $target"
    elif [ -n "$target" ] && [ "$target" != none ]; then
        log "Активирую несущую: $target…"
        if sh "$TRANSPORT" switch "$target" >> "$LOG" 2>&1; then
            log "Активная несущая: $target"
        else
            log "Несущую '$target' поднять не вышло (нет активного конфига?) — добавьте конфиг в «Соединение → Серверы и конфиги». Пока прямой режим (интернет работает)."
        fi
    fi





    if [ "$fw3_wiped" = 1 ] && [ -f "$ENODIA_DIR/vpn-toggle.sh" ]; then
        log "awg_setup сделал firewall reload — переигрываю правила (vpn-toggle repair)…"
        sh "$ENODIA_DIR/vpn-toggle.sh" repair >> "$LOG" 2>&1 || true
    fi

    set_state OK
    log "Готово. Установлено/готово: $(sh "$TRANSPORT" list 2>/dev/null | tr '\n' ' ')"
}

case "$1" in
    apply)



        if ! mkdir "$LOCK" 2>/dev/null; then







            _pl=$(cat "$LOCK/pid" 2>/dev/null | tr -cd '0-9')
            [ -n "$_pl" ] || { sleep 1; _pl=$(cat "$LOCK/pid" 2>/dev/null | tr -cd '0-9'); }

            if pid_runs "$_pl" 'packages\.sh|proto-install\.sh'; then echo "уже выполняется"; exit 1; fi
            rm -rf "$LOCK" 2>/dev/null
            mkdir "$LOCK" 2>/dev/null || { echo "уже выполняется"; exit 1; }
        fi
        echo $$ > "$LOCK/pid" 2>/dev/null






        SWLOCK=/tmp/enodia-switching.lock; SWMINE=0
        [ -e "$SWLOCK" ] || { : > "$SWLOCK" 2>/dev/null && SWMINE=1; }
        trap 'rm -rf "$LOCK" 2>/dev/null; [ "$SWMINE" = 1 ] && rm -f "$SWLOCK" 2>/dev/null' EXIT
        trap 'exit 1' INT TERM HUP PIPE
        apply "$2"
        ;;
    state) cat "$STATE" 2>/dev/null || echo IDLE ;;
    *) echo "usage: $0 apply <awg|xray|hy2|byedpi|awg-xray|awg-hy2|awg-byedpi> | state"; exit 2 ;;
esac
