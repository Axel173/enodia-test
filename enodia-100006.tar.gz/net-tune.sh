#!/bin/sh







































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi





memlimit_value() {
	v=$(cat "$ENODIA_STATE/.go-memlimit" 2>/dev/null | tr -cd 'a-z0-9')
	case "$v" in
		off) return 0 ;;
		[0-9]*)


			{ [ "$v" -ge 16 ] && [ "$v" -le 512 ]; } 2>/dev/null && echo "$v"
			return 0 ;;
	esac






	t=$(awk '/^MemTotal:/{print $2+0}' /proc/meminfo 2>/dev/null)
	case "$t" in ''|*[!0-9]*) return 0 ;; esac
	[ "$t" -lt 262144 ] 2>/dev/null && echo 64
	return 0
}


memlimit_env() {
	m=$(memlimit_value)
	[ -n "$m" ] && echo "GOMEMLIMIT=${m}MiB"
	return 0
}



memlimit_info() {
	v=$(cat "$ENODIA_STATE/.go-memlimit" 2>/dev/null | tr -cd 'a-z0-9')
	case "$v" in
		off)    mode=off ;;
		[0-9]*) mode=manual ;;
		*)      mode=auto ;;
	esac
	t=$(awk '/^MemTotal:/{print int($2/1024)}' /proc/meminfo 2>/dev/null)
	echo "mode=$mode"
	echo "value=$(memlimit_value)"
	echo "total=${t:-0}"
}



mtu_flag() {
	m=$(cat "$ENODIA_STATE/.tun-mtu" 2>/dev/null | tr -cd '0-9')
	[ -n "$m" ] || return 0
	[ "$m" -ge 1280 ] 2>/dev/null && [ "$m" -le 1500 ] 2>/dev/null || return 0
	printf '%s\n' "$m"
}
apply_mtu() {
	m=$(mtu_flag)
	[ -n "$m" ] || return 0
	ip link show awg0 >/dev/null 2>&1 && ip link set awg0 mtu "$m" 2>/dev/null
}

apply_ipv6() {


	while ip6tables -t filter -D FORWARD -d 2000::/3 -j DROP 2>/dev/null; do :; done
	while ip6tables -t filter -D FORWARD -d 2000::/3 -j REJECT 2>/dev/null; do :; done
	if [ -f "$ENODIA_STATE/.ipv6-block" ]; then
		ip6tables -t filter -I FORWARD 1 -d 2000::/3 -j DROP 2>/dev/null \
			&& echo "[net-tune] IPv6-block: FORWARD → 2000::/3 DROP (вкл)"
	fi
}






detect_v6uplink() {
	up=0
	if ip -6 route show 2>/dev/null | grep -q '^default'; then   # not-wan: IPv6-аплинк, а не WAN-интерфейс/несущая — вопрос другой
		up=1
	elif ip addr show 2>/dev/null | grep -qE 'inet6 [23][0-9a-f]{3}:'; then
		up=1
	fi
	echo "uplink=$up"
}

case "$1" in
	apply)  apply_mtu; apply_ipv6 ;;
	mtu)    apply_mtu ;;
	mtu-flag) mtu_flag ;;
	ipv6)   apply_ipv6 ;;


	wired)
		[ -f "$ENODIA_STATE/.ipv6-block" ] || exit 0
		ip6tables -t filter -C FORWARD -d 2000::/3 -j DROP 2>/dev/null; _nwr=$?
		case "$_nwr" in 0) exit 0 ;; 1) exit 3 ;; *) exit 2 ;; esac ;;
	detect) detect_v6uplink ;;

	memlimit-env)  memlimit_env ;;
	memlimit-info) memlimit_info ;;
	*)      echo "usage: net-tune.sh apply|mtu|mtu-flag|ipv6|detect|memlimit-env|memlimit-info" ;;
esac
