#!/bin/sh























































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi


if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
if ! command -v ct_flush_dst >/dev/null 2>&1; then
    ct_flush_dst()  { [ -n "$1" ] && conntrack -D -p tcp -d "$1" --dport "$2" >/dev/null 2>&1; return 0; }
fi
RELAY_CONF="$ENODIA_STATE/.support-relay" # "IP PORT [USER]" — координаты релея (НЕ секрет)
KEY="$ENODIA_STATE/.support-key"          # стоячий приватный ключ (0600), фолбэк для голого CLI `up`
CODEKEY=/tmp/.enodia-support-code-key     # приватный ключ, доставленный «кодом поддержки» (RAM, 0600, транзитный)
PIDFILE=/tmp/enodia-support-tunnel.pid
LOG=/tmp/enodia-support.log
ACTIVE=/tmp/.enodia-support-active        # рантайм: "PORT EXPIRE_EPOCH RELAY_IP RELAY_PORT" (RAM)
FWMARK=0x1
TABLE=1000
TTL_DEF=1800                              # 30 мин по умолчанию
TTL_CAP=7200                              # жёсткий потолок 2 ч
PORT_LO=20000
PORT_HI=39999

log() { echo "[$(date '+%H:%M:%S' 2>/dev/null)] $*" >> "$LOG" 2>/dev/null; }




proc_alive() { _ap=$(cat "$1" 2>/dev/null | tr -d ' \r\n'); [ -n "$_ap" ] && kill -0 "$_ap" 2>/dev/null; }





command -v wan_up >/dev/null 2>&1 || wan_up() { _wu=$(wan_iface); [ -n "$_wu" ] || return 1; if [ -r "/sys/class/net/$_wu/carrier" ]; then [ "$(cat "/sys/class/net/$_wu/carrier" 2>/dev/null)" = "1" ] || return 1; fi; return 0; }


load_relay() {
    [ -s "$RELAY_CONF" ] || { log "релей не настроен ($RELAY_CONF нет) — see set-relay"; return 1; }
    read -r RELAY_IP RELAY_PORT RELAY_USER _rest < "$RELAY_CONF"
    [ -n "$RELAY_USER" ] || RELAY_USER=support
    echo "$RELAY_IP"   | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { log "релей: IP '$RELAY_IP' не литерал (нужен IPv4, не имя — dnsmasq-SPOF)"; return 1; }
    case "$RELAY_PORT" in ''|*[!0-9]*) log "релей: порт '$RELAY_PORT' не число"; return 1 ;; esac
    return 0
}










guard_on() {
    while iptables -t mangle -D OUTPUT -d "$RELAY_IP" -p tcp --dport "$RELAY_PORT" -j ACCEPT 2>/dev/null; do :; done
    iptables -t mangle -I OUTPUT 1 -d "$RELAY_IP" -p tcp --dport "$RELAY_PORT" -j ACCEPT 2>/dev/null
    ct_flush_dst "$RELAY_IP" "$RELAY_PORT"
    log "guard: трафик к релею $RELAY_IP:$RELAY_PORT мимо VPN (прямой путь)"
}
guard_off() {
    _ip="$1"; _pt="$2"
    [ -n "$_ip" ] && [ -n "$_pt" ] || return 0
    while iptables -t mangle -D OUTPUT -d "$_ip" -p tcp --dport "$_pt" -j ACCEPT 2>/dev/null; do :; done
    ct_flush_dst "$_ip" "$_pt"
}




guard_check() {
    [ -n "$1" ] && [ -n "$2" ] || return 1
    iptables -t mangle -C OUTPUT -d "$1" -p tcp --dport "$2" -j ACCEPT 2>/dev/null
}


rand_port() { awk "BEGIN{srand(); print $PORT_LO+int(rand()*($PORT_HI-$PORT_LO+1))}"; }




eof_opt() {
    if dbclient 2>&1 | grep -q -- '-o '; then echo '-o ExitOnForwardFailure=yes'; fi
}





auth_opt() {
    AUTH=""
    if [ -n "$SUPPORT_KEY_FILE" ] && [ -r "$SUPPORT_KEY_FILE" ]; then AUTH="-i $SUPPORT_KEY_FILE"; return 0; fi
    if [ -r "$CODEKEY" ]; then AUTH="-i $CODEKEY"; return 0; fi
    if [ -r "$KEY" ]; then AUTH="-i $KEY"; return 0; fi
    return 1
}







tunnel_spawn() {
    _tsp="$1"; _tse="$2"; _tsn="$3"; case "$_tsn" in ''|*[!0-9]*) _tsn=1 ;; esac
    _eo=$(eof_opt)
    port=""; _tsi=0
    while [ "$_tsi" -lt "$_tsn" ]; do
        _tsi=$((_tsi+1))

        if [ "$_tsi" = 1 ] && [ -n "$_tsp" ]; then pt="$_tsp"; else pt=$(rand_port); fi
        log "попытка $_tsi: порт $pt → dbclient -R 127.0.0.1:$pt:127.0.0.1:22 к $RELAY_USER@$RELAY_IP:$RELAY_PORT"





        _tsl=$(( _tse - $(date +%s) )); _tst=""
        [ "$_tsl" -gt 0 ] && timeout -t 1 true >/dev/null 2>&1 && _tst="timeout -t $_tsl "
        start-stop-daemon -S -b -m -p "$PIDFILE" -x /bin/sh -- -c \
            "exec ${_tst}dbclient -N -y -y -K 30 $_eo $AUTH -R 127.0.0.1:$pt:127.0.0.1:22 -p $RELAY_PORT $RELAY_USER@$RELAY_IP >>'$LOG' 2>&1"
        sleep 3
        if proc_alive "$PIDFILE"; then
            port="$pt"
            printf '%s %s %s %s\n' "$port" "$_tse" "$RELAY_IP" "$RELAY_PORT" > "$ACTIVE"
            return 0
        fi
        log "попытка $_tsi: dbclient умер за 3с (порт занят / кред / сеть)"
        start-stop-daemon -K -p "$PIDFILE" >/dev/null 2>&1; rm -f "$PIDFILE" 2>/dev/null
    done
    return 1
}


teardown() {
    start-stop-daemon -K -p "$PIDFILE" >/dev/null 2>&1
    if [ -s "$ACTIVE" ]; then
        read -r _p _e _gip _gpt _r < "$ACTIVE"
        guard_off "$_gip" "$_gpt"
    fi
    rm -f "$PIDFILE" "$ACTIVE" 2>/dev/null
}

cmd_up() {
    ttl="$1"; case "$ttl" in ''|*[!0-9]*) ttl=$TTL_DEF ;; esac
    [ "$ttl" -gt "$TTL_CAP" ] && ttl=$TTL_CAP
    [ "$ttl" -lt 60 ] && ttl=60

    load_relay || { echo '{"active":0,"error":"relay-unset"}'; return 1; }


    auth_opt || {
        log "нет ключа из кода и нет $KEY — открыть доступ нечем"
        echo '{"active":0,"error":"no-credential"}'; return 1
    }


    wan_up || { log "WAN мёртв — туннелю некуда идти"; rm -f "$CODEKEY" 2>/dev/null; echo '{"active":0,"error":"wan-down"}'; return 1; }

    : > "$LOG" 2>/dev/null || true
    teardown                          # снять прошлый экземпляр (идемпотентно)
    guard_on                          # прямой путь к релею ДО подъёма туннеля

    expire=$(( $(date +%s) + ttl ))






    if ! tunnel_spawn "" "$expire" 3; then
        guard_off "$RELAY_IP" "$RELAY_PORT"


        rm -f "$CODEKEY" 2>/dev/null
        log "туннель не поднялся за 3 попытки — см. лог выше"
        echo '{"active":0,"error":"tunnel-failed"}'; return 1
    fi

    log "ДОСТУП ОТКРЫТ: порт $port, истекает через ${ttl}с. Заходить: ssh -J $RELAY_USER@$RELAY_IP -p $port root@127.0.0.1"
    cmd_status
}













cmd_reup() {
    [ -s "$ACTIVE" ] || return 0          # доступ не открыт — не наше дело (штатный no-op после ребута)
    read -r _rp _re _rip _rpt _rr < "$ACTIVE"
    case "$_re" in ''|*[!0-9]*) _re=0 ;; esac
    _rnow=$(date +%s)
    [ "$_rnow" -ge "$_re" ] && return 1   # TTL истёк — поднимать нечего, закрытие за reap


    load_relay >/dev/null 2>&1 || true    # ради RELAY_USER (и координат, если в записи их нет)
    [ -n "$RELAY_USER" ] || RELAY_USER=support
    if [ -n "$_rip" ] && [ -n "$_rpt" ]; then RELAY_IP="$_rip"; RELAY_PORT="$_rpt"; fi
    [ -n "$RELAY_IP" ] && [ -n "$RELAY_PORT" ] || { log "reup: координат релея нет ни в записи, ни в конфиге"; return 1; }
    if proc_alive "$PIDFILE"; then


        guard_check "$RELAY_IP" "$RELAY_PORT" || { log "гард к релею пропал (пересборка mangle) — ставлю заново"; guard_on; }
        return 0
    fi
    wan_up || { log "reup: туннель мёртв, но и WAN мёртв — жду следующего тика"; return 1; }
    auth_opt || { log "reup: туннель мёртв, а ключа для переподъёма нет (сессия открыта старым кодом?) — закрываю"; return 1; }
    guard_on
    if tunnel_spawn "$_rp" "$_re" 2; then
        [ "$port" = "$_rp" ] && log "reup: доступ восстановлен на ТОМ ЖЕ порту $port" \
                             || log "reup: прежний порт $_rp занят — доступ восстановлен на порту $port (человеку нужен новый)"
        return 0
    fi
    log "reup: поднять не удалось — попробую на следующем тике (осталось $(( _re - _rnow ))с)"
    return 1
}

cmd_down() {
    gip=""; gpt=""
    [ -s "$ACTIVE" ] && { read -r _p _e gip gpt _r < "$ACTIVE"; }
    [ -z "$gip" ] && load_relay >/dev/null 2>&1 && { gip="$RELAY_IP"; gpt="$RELAY_PORT"; }
    start-stop-daemon -K -p "$PIDFILE" >/dev/null 2>&1
    guard_off "$gip" "$gpt"
    rm -f "$PIDFILE" "$ACTIVE" "$CODEKEY" 2>/dev/null
    log "доступ закрыт (туннель снят, guard убран)"
    echo '{"active":0}'
}

cmd_status() {



    if [ -s "$ACTIVE" ]; then
        read -r _sp _se _sr < "$ACTIVE"
        case "$_se" in ''|*[!0-9]*) _se=0 ;; esac
        if [ "$(date +%s)" -ge "$_se" ]; then cmd_reap >/dev/null 2>&1; fi
    fi


    rset=0;  [ -s "$RELAY_CONF" ] && rset=1
    ncred=1; [ -r "$KEY" ] && ncred=0
    if [ -s "$ACTIVE" ] && proc_alive "$PIDFILE"; then
        read -r port expire _gip _gpt _r < "$ACTIVE"
        now=$(date +%s); left=$(( expire - now )); [ "$left" -lt 0 ] && left=0
        printf '{"active":1,"port":%s,"expires_in":%s,"relay_set":%s,"need_cred":%s}\n' "$port" "$left" "$rset" "$ncred"
    elif [ -s "$ACTIVE" ] && auth_opt; then





        read -r port expire _gip _gpt _r < "$ACTIVE"
        case "$expire" in ''|*[!0-9]*) expire=0 ;; esac
        case "$port" in ''|*[!0-9]*) port=0 ;; esac
        now=$(date +%s); left=$(( expire - now ))
        if [ "$left" -gt 0 ]; then
            printf '{"active":0,"pending":1,"port":%s,"expires_in":%s,"relay_set":%s,"need_cred":%s}\n' "$port" "$left" "$rset" "$ncred"
        else
            printf '{"active":0,"relay_set":%s,"need_cred":%s}\n' "$rset" "$ncred"
        fi
    else
        printf '{"active":0,"relay_set":%s,"need_cred":%s}\n' "$rset" "$ncred"
    fi
}



cmd_reap() {
    [ -s "$ACTIVE" ] || return 0
    read -r port expire _gip _gpt _r < "$ACTIVE"
    now=$(date +%s)
    case "$expire" in ''|*[!0-9]*) expire=0 ;; esac



    if [ "$now" -ge "$expire" ]; then
        log "reap: TTL истёк (порт $port) — закрываю доступ"
        cmd_down >/dev/null; return 0
    fi
    if ! proc_alive "$PIDFILE"; then


        if cmd_reup; then return 0; fi
        if ! auth_opt; then
            log "reap: демон мёртв, переподнять нечем (ключа нет) — чищу"
            cmd_down >/dev/null
        fi
        return 0
    fi

    cmd_reup >/dev/null 2>&1
    return 0
}

cmd_set_relay() {
    _ip="$1"; _pt="$2"; _u="$3"
    echo "$_ip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { echo "IP должен быть литералом IPv4"; return 2; }
    case "$_pt" in ''|*[!0-9]*) echo "порт должен быть числом"; return 2 ;; esac
    mkdir -p "$ENODIA_STATE"
    printf '%s %s %s\n' "$_ip" "$_pt" "${_u:-support}" > "$RELAY_CONF"
    chmod 600 "$RELAY_CONF" 2>/dev/null
    echo "релей записан: $_ip:$_pt (${_u:-support})"
}











cmd_open_code() {
    ttl="$1"
    _b64=$(cat 2>/dev/null | tr -d ' \t\r\n')
    [ -n "$_b64" ] || { echo '{"active":0,"error":"empty-code"}'; return 1; }
    _dec=$(printf '%s' "$_b64" | base64 -d 2>/dev/null | tr -d '\r')
    [ -n "$_dec" ] || { log "open-code: base64 не декодируется"; echo '{"active":0,"error":"bad-code"}'; return 1; }
    read -r _magic _ip _port _user _keyb64 <<EOF
$_dec
EOF
    [ "$_magic" = "BE7SUP2" ] || { log "open-code: неверная магия кода"; echo '{"active":0,"error":"bad-code"}'; return 1; }
    echo "$_ip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { log "open-code: IP '$_ip' не литерал"; echo '{"active":0,"error":"bad-code"}'; return 1; }
    case "$_port" in ''|*[!0-9]*) log "open-code: порт '$_port' не число"; echo '{"active":0,"error":"bad-code"}'; return 1 ;; esac
    [ -n "$_user" ] || _user=support
    [ -n "$_keyb64" ] || { log "open-code: нет ключа в коде"; echo '{"active":0,"error":"bad-code"}'; return 1; }

    ( umask 077; printf '%s' "$_keyb64" | base64 -d > "$CODEKEY" 2>/dev/null )
    [ -s "$CODEKEY" ] || { rm -f "$CODEKEY" 2>/dev/null; log "open-code: ключ из кода не декодируется"; echo '{"active":0,"error":"bad-code"}'; return 1; }
    chmod 600 "$CODEKEY" 2>/dev/null
    cmd_set_relay "$_ip" "$_port" "$_user" >/dev/null 2>&1 || { rm -f "$CODEKEY" 2>/dev/null; echo '{"active":0,"error":"bad-relay"}'; return 1; }
    SUPPORT_KEY_FILE="$CODEKEY"   # локальная — cmd_up возьмёт ключ из кода приоритетно
    cmd_up "$ttl"
}

case "$1" in
    up)        cmd_up "$2" ;;
    down)      cmd_down ;;
    status)    cmd_status ;;
    reap)      cmd_reap ;;
    reup)      cmd_reup ;;   # переподнять упавший туннель, пока сессия не истекла (зовёт reap из сторожа)
    set-relay) cmd_set_relay "$2" "$3" "$4" ;;
    open-code) cmd_open_code "$2" ;;   # base64-код поддержки на STDIN
    *) echo "usage: $0 up [ttl]|down|status|reap|reup|set-relay IP PORT [USER]|open-code [ttl] (base64<stdin)"; exit 2 ;;
esac
