#!/bin/sh

































SET_SNAP=${SET_SNAP:-/tmp/.enodia-set-snap}







if command -v cmp >/dev/null 2>&1; then _SL_EQ=cmp
elif command -v md5sum >/dev/null 2>&1; then _SL_EQ=md5
else _SL_EQ=cat; fi
_sl_same() {  # _sl_same <файл> <файл> — «содержимое одинаково»
	case "$_SL_EQ" in
		cmp) cmp -s "$1" "$2" ;;
		md5) [ "$(md5sum < "$1" 2>/dev/null)" = "$(md5sum < "$2" 2>/dev/null)" ] ;;
		*)   [ "$(cat "$1" 2>/dev/null)" = "$(cat "$2" 2>/dev/null)" ] ;;
	esac
}

set_ensure() {  # set_ensure <набор> — создать, если его ещё нет
	ipset list -n 2>/dev/null | grep -qx "$1" && return 0
	ipset create "$1" hash:net hashsize "${SET_HASHSIZE:-1024}" maxelem "${SET_MAXELEM:-65536}" 2>/dev/null
}







set_fill() {

	_sl_s="$1"; _sl_f="$2"; _sl_x="${3:-}"
	set_ensure "$_sl_s"
	ipset destroy "${_sl_s}_new" 2>/dev/null
	ipset create "${_sl_s}_new" hash:net hashsize "${SET_HASHSIZE:-1024}" maxelem "${SET_MAXELEM:-65536}" 2>/dev/null || return 1
	if [ -s "$_sl_f" ]; then
		awk -v s="${_sl_s}_new" '/^[0-9]/{print "add " s " " $1}' "$_sl_f" | ipset restore -exist 2>/dev/null
	fi
	if [ -n "$_sl_x" ] && [ -s "$_sl_x" ]; then
		awk -v s="${_sl_s}_new" '/^[0-9]/{print "add " s " " $1}' "$_sl_x" | ipset restore -exist 2>/dev/null
	fi




	if ! ipset swap "${_sl_s}_new" "$_sl_s" 2>/dev/null; then
		ipset destroy "${_sl_s}_new" 2>/dev/null
		return 1
	fi
	ipset destroy "${_sl_s}_new" 2>/dev/null
	return 0
}




set_sync() {
	_sl_ss="$1"; _sl_sf="$2"; _sl_sd="${3:-}"
	_sl_pc="$SET_SNAP-$_sl_ss.cidr"; _sl_pd="$SET_SNAP-$_sl_ss.dom"


	_sl_nc="/tmp/.enodia-set-sync.$$.cidr"; _sl_nd="/tmp/.enodia-set-sync.$$.dom"
	_sl_dy="/tmp/.enodia-set-sync.$$.dyn"; _sl_cur="/tmp/.enodia-set-sync.$$.cur"
	sort "$_sl_sf" 2>/dev/null > "$_sl_nc" || : > "$_sl_nc"
	if [ -n "$_sl_sd" ] && [ -f "$_sl_sd" ]; then sort "$_sl_sd" 2>/dev/null > "$_sl_nd" || : > "$_sl_nd"
	else : > "$_sl_nd"; fi
	: > "$_sl_dy"

	if [ -f "$_sl_pc" ] && [ -f "$_sl_pd" ] && ipset list -n 2>/dev/null | grep -qx "$_sl_ss" \
	   && _sl_same "$_sl_pc" "$_sl_nc" && _sl_same "$_sl_pd" "$_sl_nd"; then
		rm -f "$_sl_nc" "$_sl_nd" "$_sl_dy" "$_sl_cur" 2>/dev/null
		return 0
	fi



	if [ -s "$_sl_nd" ] && [ -f "$_sl_pc" ] && [ -f "$_sl_pd" ] && _sl_same "$_sl_pd" "$_sl_nd"; then




		ipset save "$_sl_ss" 2>/dev/null | awk -v s="$_sl_ss" '$1=="add" && $2==s{print $3}' > "$_sl_cur"
		if [ -s "$_sl_pc" ]; then grep -Fxv -f "$_sl_pc" "$_sl_cur" > "$_sl_dy" 2>/dev/null || : > "$_sl_dy"
		else cat "$_sl_cur" > "$_sl_dy"; fi
	fi



	if set_fill "$_sl_ss" "$_sl_sf" "$_sl_dy"; then
		cp "$_sl_nc" "$_sl_pc" 2>/dev/null; cp "$_sl_nd" "$_sl_pd" 2>/dev/null
		_sl_rc=0
	else
		rm -f "$_sl_pc" "$_sl_pd" 2>/dev/null   # снимка нет = следующий вызов пересоберёт честно
		_sl_rc=1
	fi
	rm -f "$_sl_nc" "$_sl_nd" "$_sl_dy" "$_sl_cur" 2>/dev/null



	return $_sl_rc
}
