#!/bin/sh


























































RAM_MIG_OLD='.bin-manifest.* .carrier-up.stamp .cpu-stat .curl-cafile .dns-merge.* .doh-*
.grp-apply.* .grp-pairs .ip6t-wait .ipt-wait .lists-reg.* .set-snap .set-snap-* .slots.lock
.support-* .totp-* .vpnsrv-* .zapret-* .05-dhcp-static.conf.stage
awg0.seen awgs0.conf byedpi.pid byedpi-fetch.pid byedpi-fetch.users byedpi-s*.pid
byedpi-sweep.lock byedpi-test-cand.lst byedpi-test-ciadpi.pid byedpi-test-pool.lst
byedpi-test-res byedpi-test.owneradded byedpi-test.pid devwatch-stop.*.pid doh.pid
geo geo.pid geo-fresh.pid geo-update.pid gh-update.lock gh-update.pid hev.pid hev-s*.pid
hysteria.pid hysteria-s*.pid iplist.txt iplist-restore.pid lists lists-*.pid
notify-event.*.stamp panel-pass.pid panel-reboot.pid panel-tls.pid ping-active-dead
proto-install.lock proto-install.pid subs-update.lock subs-update-cgi.pid support-tunnel.pid
traffic-acct.lock uhttpd-web.pid uninstall.pid xray.pid xray-s*.pid
xray-test.*.json xray-test.*.out xray-test.*.pid
zapret-migrate.pid zapret-nfqws.pid zapret-sweep.lock'




ram_migrate() {
    for _rm_p in $RAM_MIG_OLD; do
        for _rm_f in /tmp/$_rm_p; do

            [ -e "$_rm_f" ] || continue
            _rm_n=${_rm_f#/tmp/}
            case "$_rm_n" in
                .*) _rm_t="/tmp/.enodia-${_rm_n#.}" ;;
                *)  _rm_t="/tmp/enodia-$_rm_n" ;;
            esac


            if [ -e "$_rm_t" ]; then continue; fi
            mv "$_rm_f" "$_rm_t" 2>/dev/null || :
        done
    done
    return 0
}
