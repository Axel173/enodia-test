#!/bin/sh

























if ! command -v store_is_ours >/dev/null 2>&1 || [ -z "$STORE_SUB" ] || [ -z "$STORE_MNT" ]; then
    echo "mount-lib.sh: нет store-lib.sh (или он старый) — обновите скрипты" >&2
    return 1 2>/dev/null || exit 1
fi

MNT="$STORE_MNT"                        # СВОЯ точка монтирования (если сток не смонтировал сам)




MOUNTS=${ENODIA_MOUNTS:-/proc/mounts}
PARTS=${ENODIA_PARTS:-/proc/partitions}





















unesc_mount() {         # $1 = поле из /proc/mounts; ответ — в $MNT_UNESC
    MNT_UNESC="$1"
    case "$MNT_UNESC" in *'\'*) ;; *) return 0 ;; esac
    while [ "${MNT_UNESC#*'\040'}" != "$MNT_UNESC" ]; do
        MNT_UNESC="${MNT_UNESC%%'\040'*} ${MNT_UNESC#*'\040'}"
    done
    while [ "${MNT_UNESC#*'\134'}" != "$MNT_UNESC" ]; do
        MNT_UNESC="${MNT_UNESC%%'\134'*}\\${MNT_UNESC#*'\134'}"
    done
}



fs_of_mount() {
    while read -r _d _m _t _rest; do
        unesc_mount "$_m"
        [ "$MNT_UNESC" = "$1" ] && { printf '%s' "$_t"; return 0; }
    done < "$MOUNTS"
    return 1
}









store_mp() { [ -n "$1" ] || return 1; _smp=${1%/*}; printf '%s' "${_smp:-/}"; }











store_of_mount() {
    store_is_ours "$1/$STORE_SUB" && { printf '%s' "$1/$STORE_SUB"; return 0; }
    [ -n "$STORE_SUB_OLD" ] && store_is_ours "$1/$STORE_SUB_OLD" && { printf '%s' "$1/$STORE_SUB_OLD"; return 0; }
    return 1
}



find_mounted_store() {
    while read -r _d _m _t _rest; do
        case "$_d" in /dev/sd*) ;; *) continue ;; esac
        unesc_mount "$_m"
        _s=$(store_of_mount "$MNT_UNESC")
        [ -n "$_s" ] && { printf '%s' "$_s"; return 0; }
    done < "$MOUNTS"
    return 1
}






mount_candidates() {
    while read -r _maj _min _blk _name; do
        case "$_name" in sd[a-z][0-9]*) ;; *) continue ;; esac
        [ -z "$ENODIA_ONLY_DEV" ] || [ "$_name" = "$ENODIA_ONLY_DEV" ] || continue
        [ -b "/dev/$_name" ] || continue
        grep -q "^/dev/$_name " "$MOUNTS" && continue
        printf '/dev/%s\n' "$_name"
    done < "$PARTS"
    while read -r _maj _min _blk _name; do
        case "$_name" in sd[a-z]) ;; *) continue ;; esac
        [ -z "$ENODIA_ONLY_DEV" ] || [ "$_name" = "$ENODIA_ONLY_DEV" ] || continue
        [ -b "/dev/$_name" ] || continue
        grep -q "^/dev/$_name " "$MOUNTS" && continue
        printf '/dev/%s\n' "$_name"
    done < "$PARTS"
}



dev_has_parts() {
    while read -r _dhp_maj _dhp_min _dhp_blk _dhp_name; do
        case "$_dhp_name" in "$1"[0-9]*) return 0 ;; esac
    done < "$PARTS"
    return 1
}




















fs_keeps_perms() {
    case "$1" in
        ext2|ext3|ext4) return 0 ;;
        *) return 1 ;;
    esac
}





try_mount() {
    for _t in auto exfat ext4 vfat ntfs3 ntfs ext3 ext2; do
        case "$_t" in
            ext*) _o="rw,noatime" ;;
            *)    _o="rw,noatime,fmask=0000,dmask=0000" ;;
        esac
        mount -t "$_t" -o "$_o" "$1" "$2" 2>/dev/null && return 0
        mount -t "$_t" "$1" "$2" 2>/dev/null && return 0
    done
    return 1
}









try_mount_ro() {
    for _t in auto exfat ext4 vfat ntfs3 ntfs ext3 ext2; do
        mount -t "$_t" -o ro "$1" "$2" 2>/dev/null && return 0
    done
    return 1
}












store_locate() {
    STORE_FOUND=; STORE_FOUND_HOW=; STORE_FOUND_WARN=
    STORE_FOUND=$(find_mounted_store)
    if [ -n "$STORE_FOUND" ]; then
        STORE_FOUND_HOW=system






        if ! : > "$STORE_FOUND/.enodia-write-probe" 2>/dev/null; then
            STORE_FOUND_WARN="хранилище $STORE_FOUND смонтировано ТОЛЬКО НА ЧТЕНИЕ — настройки не сохранятся"
        fi
        rm -f "$STORE_FOUND/.enodia-write-probe" 2>/dev/null
        return 0
    fi
    mkdir -p "$MNT" 2>/dev/null
    for _ml_dev in $(mount_candidates); do
        try_mount_ro "$_ml_dev" "$MNT" || continue
        _ml_s=$(store_of_mount "$MNT")
        umount "$MNT" 2>/dev/null        # проба окончена: чужое не держим, своё поднимем на запись
        [ -n "$_ml_s" ] || continue
        if ! try_mount "$_ml_dev" "$MNT"; then
            STORE_FOUND_WARN="хранилище на $_ml_dev есть, но накопитель не монтируется на запись — пропускаю"
            continue
        fi
        _ml_s=$(store_of_mount "$MNT")
        if [ -n "$_ml_s" ]; then
            STORE_FOUND="$_ml_s"; STORE_FOUND_HOW="$_ml_dev"
            unset _ml_dev _ml_s
            return 0
        fi
        umount "$MNT" 2>/dev/null        # чужой накопитель — не держим его смонтированным
    done
    unset _ml_dev _ml_s
    return 1
}
