#!/bin/sh























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}
CRON_RUN="$ENODIA_BOOT/boot.sh"    # единственная цель cron-строк: код может уехать на накопитель
CRON=/etc/crontabs/root





job_valid() { case "$1" in lists|subs) return 0 ;; *) return 1 ;; esac; }
job_mark()  { case "$1" in subs) echo "$ENODIA_STATE/.subs-interval" ;; *) echo "$ENODIA_STATE/.update-interval" ;; esac; }



job_script() { case "$1" in subs) echo "subs-update.sh" ;; *) echo "iplist-update.sh" ;; esac; }
job_def()   { case "$1" in subs) echo off ;; *) echo daily ;; esac; }


sched_for() {
	if [ "$1" = subs ]; then
		case "$2" in
			off)    echo "" ;;
			6h)     echo "20 */6 * * *" ;;
			12h)    echo "20 */12 * * *" ;;
			weekly) echo "40 4 * * 1" ;;
			*)      echo "40 4 * * *" ;;
		esac
		return 0
	fi
	case "$2" in
		off)    echo "" ;;
		6h)     echo "0 */6 * * *" ;;
		12h)    echo "0 */12 * * *" ;;
		weekly) echo "0 5 * * 1" ;;   # понедельник 05:00
		*)      echo "0 5 * * *" ;;   # daily (дефолт)
	esac
}

args_for() {
	if [ "$1" = subs ]; then echo "update"; return 0; fi
	case "$2" in daily|weekly) echo "--notify --lists" ;; *) echo "--lists" ;; esac
}

norm_iv() { case "$2" in off|6h|12h|daily|weekly) echo "$2" ;; *) job_def "$1" ;; esac; }

restart_cron() {
	/etc/init.d/cron restart >/dev/null 2>&1 || /etc/init.d/crond restart >/dev/null 2>&1 \
		|| killall -HUP crond 2>/dev/null || true
}


write_cron() {
	_j="$1"; _iv=$(norm_iv "$_j" "$2"); _bin=$(job_script "$_j")
	mkdir -p /etc/crontabs 2>/dev/null; touch "$CRON" 2>/dev/null

	sed -i "\|$_bin|d" "$CRON" 2>/dev/null
	_s=$(sched_for "$_j" "$_iv")
	if [ -n "$_s" ]; then
		echo "$_s $CRON_RUN $_bin $(args_for "$_j" "$_iv") >/dev/null 2>&1" >> "$CRON"
	fi
	restart_cron
}


read_iv() {
	_j="$1"; _m=$(job_mark "$_j")
	if [ -f "$_m" ]; then
		norm_iv "$_j" "$(tr -cd 'a-z0-9' < "$_m" 2>/dev/null)"
		return 0
	fi
	_l=$(grep "$(job_script "$_j")" "$CRON" 2>/dev/null | head -1)
	case "$_l" in
		'')                        job_def "$_j" ;;   # строки нет вовсе → дефолт задачи
		"0 */6 "*|"20 */6 "*)      echo 6h ;;
		"0 */12 "*|"20 */12 "*)    echo 12h ;;
		"0 5 * * 1 "*|"40 4 * * 1 "*) echo weekly ;;
		*)                         echo daily ;;
	esac
}



cmd="$1"; shift 2>/dev/null
job=lists; job_explicit=0
if job_valid "$1"; then job="$1"; job_explicit=1; shift 2>/dev/null; fi

case "$cmd" in
	set)
		iv=$(norm_iv "$job" "$1")
		printf '%s\n' "$iv" > "$(job_mark "$job")"
		write_cron "$job" "$iv"
		echo "$iv" ;;
	get)
		read_iv "$job" ;;
	apply)   # установщик/heal: применить cron по маркерам. Без имени задачи — ОБЕ (иначе после

		if [ "$job_explicit" = 1 ]; then
			write_cron "$job" "$(read_iv "$job")"
		else
			write_cron lists "$(read_iv lists)"
			write_cron subs  "$(read_iv subs)"
		fi ;;
	*)
		echo "usage: update-sched.sh set [lists|subs] <off|6h|12h|daily|weekly> | get [job] | apply [job]" >&2
		exit 1 ;;
esac
