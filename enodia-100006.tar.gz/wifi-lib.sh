#!/bin/sh
















































wifi_uci_show() { if [ -n "${WIFI_UCI+x}" ]; then printf '%s\n' "$WIFI_UCI"; else uci show wireless 2>/dev/null; fi; }


wifi_uci_sec_of() {
    case "$1" in
        wl[0-9]*) : ;;
        *) return 1 ;;
    esac
    _wus=$(wifi_uci_show | sed -n "s/\.ifname='$1'\$//p" | head -1)
    [ -n "$_wus" ] || return 1
    printf '%s\n' "$_wus"
}


wifi_ssid_of() {
    case "$1" in
        wl[0-9]*) : ;;
        *) return 1 ;;
    esac
    if [ -f "/var/run/hostapd-$1.conf" ]; then


        _wS=$(grep -i -E '^[[:space:]]*ssid=' "/var/run/hostapd-$1.conf" 2>/dev/null | \
              head -1 | cut -d= -f2- | tr -d '"\\')
        [ -n "$_wS" ] && { printf '%s\n' "$_wS"; return 0; }
    fi



    _wsec=$(wifi_uci_sec_of "$1") || return 1


    _wS=$(uci -q get "$_wsec.ssid" 2>/dev/null | tr -d '"\\')
    [ -n "$_wS" ] || return 1
    printf '%s\n' "$_wS"
}


wifi_iface_list() {
    _wl=""
    for _wf in /var/run/hostapd-*.conf; do
        [ -f "$_wf" ] || continue
        _wi=$(basename "$_wf" .conf); _wi=${_wi#hostapd-}
        case "$_wi" in wl[0-9]*) : ;; *) continue ;; esac
        case " $_wl " in *" $_wi "*) continue ;; esac
        _wl="$_wl${_wl:+ }$_wi"
    done
    for _wi in $(wifi_uci_show | sed -n "s/^wireless\..*\.ifname='\(wl[0-9A-Za-z_-]*\)'\$/\1/p"); do
        case " $_wl " in *" $_wi "*) continue ;; esac
        _wl="$_wl${_wl:+ }$_wi"
    done
    printf '%s\n' "$_wl"
}


wifi_ifaces_of() {
    [ -n "$1" ] || return 1
    _wout=""
    for _wc in $(wifi_iface_list); do
        [ "$(wifi_ssid_of "$_wc")" = "$1" ] || continue
        _wout="$_wout${_wout:+ }$_wc"
    done
    [ -n "$_wout" ] || return 1
    printf '%s\n' "$_wout"
}




wifi_resolve() {
    [ -n "$1" ] || return 1
    _wr=$(wifi_ifaces_of "$1") && { printf '%s\n' "$_wr"; return 0; }
    case "$1" in
        wl[0-9]*) printf '%s\n' "$1"; return 0 ;;
    esac
    return 1
}







wifi_live_ifaces() {
    for _wv in $(wifi_iface_list); do
        [ -d "/sys/class/net/$_wv" ] && printf '%s\n' "$_wv"
    done
    return 0
}


wifi_bridge_of() {
    for _wb in /sys/class/net/br-*; do
        [ -d "$_wb/brif/$1" ] || continue
        printf '%s\n' "${_wb##*/}"
        return 0
    done
    return 1
}



wifi_bridge_net() {
    _wn=$(ip -4 route show dev "$1" proto kernel scope link 2>/dev/null | awk 'NR==1{print $1}')   # not-wan: подсеть МОСТА локальной сети, а не WAN
    case "$_wn" in */*) printf '%s\n' "$_wn"; return 0 ;; esac
    _wa=$(ip -4 addr show dev "$1" 2>/dev/null | sed -n 's/.*inet \([0-9.]*\)\/\([0-9]*\).*/\1 \2/p' | head -1)
    [ -n "$_wa" ] || return 1
    _wq=${_wa#* }; _wa=${_wa% *}; _wo=""; _wk=0
    for _wx in $(printf '%s' "$_wa" | tr . ' '); do
        _wm=$((_wq - _wk*8)); [ "$_wm" -gt 8 ] && _wm=8; [ "$_wm" -lt 0 ] && _wm=0
        _wo="$_wo${_wo:+.}$((_wx & (256 - (1 << (8 - _wm)))))"
        _wk=$((_wk + 1))
    done
    printf '%s/%s\n' "$_wo" "$_wq"
}


wifi_mhz_band() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    if   [ "$1" -ge 2400 ] && [ "$1" -lt 2500 ]; then printf '2.4 %s\n' $(( ($1 - 2407) / 5 ))
    elif [ "$1" -ge 4900 ] && [ "$1" -lt 5900 ]; then printf '5 %s\n' $(( ($1 - 5000) / 5 ))
    elif [ "$1" -ge 5925 ]; then printf '6 %s\n' $(( ($1 - 5950) / 5 ))
    else return 1; fi
}


wifi_band_of() {
    _wg=$(iwconfig "$1" 2>/dev/null | sed -n 's/.*Frequency:\([0-9.]*\) GHz.*/\1/p' | head -1)
    [ -n "$_wg" ] || return 1
    _wg=$(awk -v f="$_wg" 'BEGIN{printf "%d", f*1000+0.5}')
    _wg=$(wifi_mhz_band "$_wg") || return 1
    printf '%s\n' "${_wg%% *}"
}


wifi_hidden_of() {
    grep -qE '^[[:space:]]*ignore_broadcast_ssid=[12]' "/var/run/hostapd-$1.conf" 2>/dev/null
}






wifi_table() {
    for _wt in $(wifi_iface_list); do
        _wtl=0; [ -d "/sys/class/net/$_wt" ] && _wtl=1
        printf '%s\t%s\t%s\n' "$_wt" "$_wtl" "$(wifi_ssid_of "$_wt" | tr '\t' ' ')"
    done
}





wifi_key_state() {
    _wkt=${WIFI_TAB-$(wifi_table)}


    _wks=$(printf '%s\n' "$_wkt" | WK="$1" awk -F'\t' 'BEGIN{k=ENVIRON["WK"]} ($3"")==(k""){m=1; if($2==1) l=1} END{if(m) print (l ? "live" : "off")}')
    [ -n "$_wks" ] && { printf '%s\n' "$_wks"; return 0; }
    case "$1" in
        wl[0-9]*)
            [ -d "/sys/class/net/$1" ] && { echo live; return 0; }
            printf '%s\n' "$_wkt" | cut -f1 | grep -qxF "$1" && { echo off; return 0; } ;;
    esac
    echo gone
}
