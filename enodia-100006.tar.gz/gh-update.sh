#!/bin/sh
























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}


ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}







REPO=$(cat "$ENODIA_STATE/.gh-repo" 2>/dev/null | tr -d '\r\n' | sed 's/^[ 	]*//; s/[ 	]*$//')



case "$REPO" in ''|*[!A-Za-z0-9._/-]*|/*|*/|*/*/*|*..*) REPO= ;; */*) : ;; *) REPO= ;; esac




[ -n "$REPO" ] || REPO="Axel173/enodia"

GH_REF=$(cat "$ENODIA_STATE/.gh-ref" 2>/dev/null | tr -d ' \r\n'); [ -n "$GH_REF" ] || GH_REF=main
RAW="https://raw.githubusercontent.com/$REPO/$GH_REF"




















GH_BIN_TAG=$(cat "$ENODIA_STATE/.gh-bin-tag" 2>/dev/null | tr -d ' \r\n'); [ -n "$GH_BIN_TAG" ] || GH_BIN_TAG=bin
GH_REL="https://github.com/$REPO/releases/download/$GH_BIN_TAG"








CURL_TIMEOUT=150




CURL_OPTS="--connect-timeout 8 --speed-limit 4096 --speed-time 8 --max-time $CURL_TIMEOUT"
GH_RAW_HOST=raw.githubusercontent.com
GH_RAW_IPS="185.199.108.133 185.199.109.133 185.199.110.133 185.199.111.133"




GH_ASSET_HOSTS="release-assets.githubusercontent.com objects.githubusercontent.com"
















GH_TMP=$(mktemp -d /tmp/enodia-gh.XXXXXX 2>/dev/null) || GH_TMP=""
[ -n "$GH_TMP" ] || GH_TMP=/dev/null/enodia-gh
GH_CODE_FILE="$GH_TMP/code"
gh_code_reset() { : > "$GH_CODE_FILE" 2>/dev/null; }
gh_code_note() {
    case "$1" in ''|000) return 0 ;; esac   # 000 = не соединились, это не ответ сервера




    case "$1" in [123]??) return 0 ;; esac


    case "$(cat "$GH_CODE_FILE" 2>/dev/null)" in 429|403) return 0 ;; esac
    printf '%s' "$1" > "$GH_CODE_FILE" 2>/dev/null
}
gh_code_get() { cat "$GH_CODE_FILE" 2>/dev/null; }

gh_code_reason() {
    case "$1" in
        429) echo "GitHub ограничил скачивание с вашего внешнего адреса (HTTP 429, слишком много обращений) — подождите 10-15 минут и повторите" ;;
        403) echo "GitHub отказал в выдаче файла (HTTP 403) — как правило, то же ограничение по частоте; подождите и повторите" ;;
        404) echo "на GitHub нет файла по этому пути (HTTP 404)" ;;
        5??) echo "GitHub отвечает ошибкой $1 — это на его стороне, повторите позже" ;;
        ''|000) echo "" ;;
        *)   echo "GitHub ответил HTTP $1" ;;
    esac
}


gh_code_refused() { case "$(gh_code_get)" in 429|403) return 0 ;; *) return 1 ;; esac; }









if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
command -v curl_ca_opt >/dev/null 2>&1 || curl_ca_opt() { return 0; }


gh_ca_opt() { curl_ca_opt; }







gh_ca_probe() {   # $1 = URL, на котором споткнулись
    case "$1" in
        https://$GH_RAW_HOST/*) _capr="--resolve $GH_RAW_HOST:443:${GH_RAW_IPS%% *}" ;;
        *) _capr="" ;;
    esac
    _cap=$(curl_ca_opt "$1" $_capr)
    [ -n "$_cap" ] || return 1
    log "TLS: системное хранилище curl пусто — доверяю системному бандлу"
    return 0
}

log() { printf '%s\n' "$*"; }

















gh_pin_hosts() {
    case "$1" in
        https://$GH_RAW_HOST/*) echo "$GH_RAW_HOST" ;;
        https://github.com/*)   echo "$GH_ASSET_HOSTS" ;;
        *)                      echo "" ;;
    esac
}
gh_get_round() {   # $1=url $2=out $3=опция доверия («» = системная)
    _gr=1; _g60=0
    _pin=$(gh_pin_hosts "$1")
    if [ -n "$_pin" ]; then
        for _ipx in $GH_RAW_IPS __dns__; do
            _res=""
            if [ "$_ipx" != __dns__ ]; then
                for _ph in $_pin; do _res="$_res --resolve $_ph:443:$_ipx"; done
            fi
            _c=$(curl -fsSL $CURL_OPTS $3 $_res -w '%{http_code}' -o "$2" "$1" 2>/dev/null); _gr=$?
            gh_code_note "$_c"
            [ "$_gr" = 0 ] && return 0
            [ "$_gr" = 60 ] && _g60=1


            gh_code_refused && break
            rm -f "$2"
        done
    else
        _c=$(curl -fsSL $CURL_OPTS $3 -w '%{http_code}' -o "$2" "$1" 2>/dev/null); _gr=$?
        gh_code_note "$_c"
        [ "$_gr" = 0 ] && return 0
        [ "$_gr" = 60 ] && _g60=1
    fi
    rm -f "$2"
    [ "$_g60" = 1 ] && return 60
    return "$_gr"
}
gh_get() {
    _ghu="$1"; _gho="$2"
    gh_code_reset          # вердикт — про ЭТОТ URL, а не про предыдущий
    _cao=$(gh_ca_opt)
    gh_get_round "$_ghu" "$_gho" "$_cao" && return 0
    _grc=$?



    if [ "$_grc" = 60 ] && [ -z "$_cao" ] && gh_ca_probe "$_ghu"; then
        _cao=$(gh_ca_opt)
        gh_get_round "$_ghu" "$_gho" "$_cao" && return 0



        _grc=$?
    fi





    [ "$_grc" = 22 ] && return 1


    gh_code_refused && return 1
    gh_socks_round "$_ghu" "$_gho" "$_cao"
}












GH_SOCKS=""        # "" = ещё не пробовали · "-" = не вышло (второй раз не дёргаем) · адрес = есть
GH_SOCKS_MINE=0    # 1 = демон подняли МЫ и обязаны погасить
BYEDPI_SH="$ENODIA_DIR/transport-byedpi.sh"
gh_socks_try() {
    [ "$GH_SOCKS" = "-" ] && return 1
    [ -n "$GH_SOCKS" ] && return 0
    GH_SOCKS="-"
    [ -f "$BYEDPI_SH" ] || return 1





    _sa=$(sh "$BYEDPI_SH" socks-up "$$" 2>/dev/null | tail -n1 | tr -d ' \r')
    case "$_sa" in
        [0-9]*.[0-9]*.[0-9]*.[0-9]*:[0-9]*) : ;;
        *) return 1 ;;
    esac
    GH_SOCKS="$_sa"; GH_SOCKS_MINE=1
    log "GitHub напрямую не отвечает — пробую через локальный десинк ($GH_SOCKS)"
    return 0
}











gh_socks_release() {
    [ -f "$BYEDPI_SH" ] && sh "$BYEDPI_SH" socks-down "$$" >/dev/null 2>&1
    GH_SOCKS_MINE=0
}








gh_bg_stop() {
    if [ -n "$GH_BGPID" ]; then
        _gbk="$GH_BGPID"; _gbq="$GH_BGPID"
        while [ -n "$_gbq" ]; do
            _gbn=""
            for _gbp in $_gbq; do
                for _gbf in /proc/[0-9]*/status; do
                    grep -q "^PPid:[[:space:]]*$_gbp\$" "$_gbf" 2>/dev/null || continue
                    _gbc=${_gbf#/proc/}; _gbn="$_gbn ${_gbc%/status}"
                done
            done
            _gbk="$_gbk$_gbn"; _gbq=$_gbn
        done
        kill $_gbk 2>/dev/null
    fi
    [ -n "$GH_BGDL" ] && rm -f "$GH_BGDL" 2>/dev/null
    GH_BGPID=; GH_BGDL=
    return 0
}
gh_exit() { gh_bg_stop; gh_socks_release; }
trap 'gh_exit' EXIT
trap 'exit 1' INT TERM HUP PIPE


gh_socks_round() {   # $1=url $2=out $3=опция доверия
    gh_socks_try || return 1
    curl -fsSL $CURL_OPTS $3 --socks5-hostname "$GH_SOCKS" -o "$2" "$1" 2>/dev/null && return 0
    rm -f "$2"
    return 1
}



















gh_reach_round() {   # $1 = путь, $2 = опция доверия
    for _ipx in $GH_RAW_IPS __dns__; do
        if [ "$_ipx" = __dns__ ]; then _res=""; else _res="--resolve $GH_RAW_HOST:443:$_ipx"; fi
        _c=$(curl -s -o /dev/null -w '%{http_code}' $2 --connect-timeout 8 --max-time 12 $_res "$RAW/$1" 2>/dev/null)
        gh_code_note "$_c"
        case "$_c" in
            ''|000)  : ;;             # не соединились — пробуем следующий узел
            429|403) return 1 ;;      # лимит навешен на КЛИЕНТСКИЙ адрес ⇒ соседние узлы ответят тем же
            *)       return 0 ;;
        esac
    done
    return 1
}


gh_reachable() {
    _p="$1"
    _pgiven="$1"      # спрашивали КОНКРЕТНЫЙ путь? ниже `_p` уже подменён дефолтом VERSION
    gh_code_reset




    [ -n "$_p" ] || _p=VERSION
    gh_reach_round "$_p" "$(gh_ca_opt)" && return 0




    if gh_code_refused; then









        _ru=$(rel_flat_url "$SUMS_REL")
        if [ -z "$_pgiven" ] && [ -n "$_ru" ]; then
            _rc=$(gh_code_get)
            _rt="$GH_TMP/reach"
            gh_get "$_ru" "$_rt"; _rr=$?
            rm -f "$_rt"
            [ "$_rr" = 0 ] && return 0
            gh_code_note "$_rc"
        fi
    else

        if [ -z "$(gh_ca_opt)" ] && gh_ca_probe "$RAW/$_p"; then
            gh_reach_round "$_p" "$(gh_ca_opt)" && return 0
        fi




        if gh_socks_try; then
            _c=$(curl -s -o /dev/null -w '%{http_code}' $(gh_ca_opt) --connect-timeout 8 --max-time 12 \
                 --socks5-hostname "$GH_SOCKS" "$RAW/$_p" 2>/dev/null)
            gh_code_note "$_c"
            case "$_c" in ''|000) : ;; 429|403) : ;; *) return 0 ;; esac
        fi
    fi
    _why=$(gh_code_reason "$(gh_code_get)")
    [ -n "$_why" ] || _why="GitHub недоступен — ни один канал не ответил"
    printf '%s\n' "$_why"
    return 1
}




elf_ok() {
    f="$1"
    command -v cmp >/dev/null 2>&1 || return 0
    m="$GH_TMP/elfmagic"; t="$GH_TMP/elfhead"
    printf '\177ELF' > "$m" 2>/dev/null || { rm -f "$m" "$t"; return 0; }
    head -c 4 "$f" > "$t" 2>/dev/null
    cmp -s "$m" "$t"; rc=$?
    rm -f "$m" "$t"
    return $rc
}










SUMS_REL=SHA256SUMS
SUMS_CACHE="$GH_TMP/sums"
SUMS_STATE=            # ''=ещё не пробовали · ok=скачали · no=в репо нет



file_sha256() {
    _fh=""
    if command -v sha256sum >/dev/null 2>&1; then _fh=$(sha256sum "$1" 2>/dev/null | awk '{print $1; exit}'); fi
    if [ "${#_fh}" != 64 ]; then _fh=$(openssl dgst -sha256 "$1" 2>/dev/null | sed 's/.*= *//' | awk '{print $1; exit}'); fi
    case "$_fh" in *[!0-9a-f]*) _fh="" ;; esac
    [ "${#_fh}" = 64 ] || _fh=""
    printf '%s\n' "$_fh"
}





sums_load() {
    [ -z "$SUMS_STATE" ] || return 0
    SUMS_STATE=no
    for _su in "$RAW/$SUMS_REL" "$(rel_flat_url "$SUMS_REL")"; do
        [ -n "$_su" ] || continue
        if gh_get "$_su" "$SUMS_CACHE" && [ -s "$SUMS_CACHE" ]; then SUMS_STATE=ok; return 0; fi
        rm -f "$SUMS_CACHE"
    done
    return 0
}









bin_arch() {
    [ -r /bin/busybox ] || return 0
    command -v dd >/dev/null 2>&1 || return 0
    command -v cmp >/dev/null 2>&1 || return 0
    _m="$GH_TMP/arch"
    dd if=/bin/busybox of="$_m" bs=1 skip=18 count=2 2>/dev/null || { rm -f "$_m"; return 0; }
    printf '\267\000' > "$_m.a64" 2>/dev/null   # 0xB7 0x00 = EM_AARCH64
    printf '\050\000' > "$_m.a32" 2>/dev/null   # 0x28 0x00 = EM_ARM
    _r=""
    if cmp -s "$_m" "$_m.a64"; then _r=arm64
    elif cmp -s "$_m" "$_m.a32"; then _r=armv7
    fi
    rm -f "$_m" "$_m.a64" "$_m.a32"
    echo "$_r"
}

















BM_REL=bin-manifest.txt
BM_FILE="$ENODIA_DIR/$BM_REL"






bm_field() {
    [ -s "$BM_FILE" ] || return 0


    if [ "$BA_DONE" = 1 ]; then _bf_a=$BA_VAL; else _bf_a=$(bin_arch); fi
    awk -F'\t' -v n="$1" -v c="$2" -v a="$_bf_a" -v m="${3:-max}" '
        $1 != n { next }
        a != "" && $2 == a { print $c; found=1; exit }
        a == "" { s=$3+0
                  if (best=="" || (m=="max" && s>best) || (m=="min" && s<best)) { best=s; val=$c } }
        END { if (!found && best!="") print val }
    ' "$BM_FILE"
}


bin_size() { _bs=$(bm_field "$1" 3 "${2:-max}"); case "$_bs" in ''|*[!0-9]*) _bs=0 ;; esac; echo "$_bs"; }
bin_ver()  { bm_field "$1" 4 max; }


local_tag() {


    _lt=$(sed -n 's/^TAG=//p' "$ENODIA_DIR/VERSION" 2>/dev/null | head -n 1 | tr -d '\r')
    case "$_lt" in ''|.*|*[!A-Za-z0-9._-]*) : ;; *) echo "$_lt" ;; esac
}






















BS_CACHE="$ENODIA_STATE/.bin-sha"

bs_key() { stat -c '%s %Y' "$1" 2>/dev/null; }

bs_put() {
    _bpt="$BS_CACHE.$$.new"   # хвост .new — под маской мусора clean.sh (оборванная запись не копится)
    if { [ -f "$BS_CACHE" ] && awk -F'\t' -v n="$1" '$1 != n' "$BS_CACHE"; printf '%s\t%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" "$5"; } > "$_bpt" 2>/dev/null; then
        mv -f "$_bpt" "$BS_CACHE" 2>/dev/null || rm -f "$_bpt" 2>/dev/null
    else rm -f "$_bpt" 2>/dev/null; fi
    return 0
}


bs_sha() {   # $1 = имя, $2 = путь
    _bk=$(bs_key "$2"); [ -n "$_bk" ] || return 0
    _bh=$(awk -F'\t' -v n="$1" -v p="$2" -v k="$_bk" '$1 == n && $2 == p && $3 == k && length($4) == 64 { print $4; exit }' "$BS_CACHE" 2>/dev/null)
    if [ -z "$_bh" ]; then
        _bh=$(file_sha256 "$2"); [ -n "$_bh" ] || return 0
        bs_put "$1" "$2" "$_bk" "$_bh" "$(bs_ver_known "$1" "$_bh")"
    fi
    printf '%s\n' "$_bh"
}

bs_ver_known() { awk -F'\t' -v n="$1" -v h="$2" '$1 == n && $4 == h { print $5; exit }' "$BS_CACHE" 2>/dev/null; }

bs_ver_note() {   # $1 = имя, $2 = путь, $3 = sha, $4 = версия
    [ "$(bs_ver_known "$1" "$3")" = "$4" ] && return 0
    bs_put "$1" "$2" "$(bs_key "$2")" "$3" "$4"
}

bm_ver_of() {   # $1 = имя, $2 = sha
    [ -s "$BM_FILE" ] || return 0
    awk -F'\t' -v n="$1" -v h="$2" -v a="$BA_VAL" '$1 == n && $5 == h && $4 != "" && (a == "" || $2 == a) { print $4; exit }' "$BM_FILE"
}

bs_paths() {
    if [ -f "$ENODIA_DIR/store-lib.sh" ]; then
        ( . "$ENODIA_DIR/store-lib.sh" >/dev/null 2>&1; for _n in "$@"; do printf '%s %s\n' "$_n" "$(bin_path "$_n")"; done )
    else for _n in "$@"; do printf '%s %s\n' "$_n" "$ENODIA_BIN/$_n"; done; fi
}




BS_RUN_SAME=/tmp/enodia-bin-run.same


bs_stale_pids() {   # $1 = имя, $2 = путь стоящего, $3 = его sha
    [ -n "$BS_DEL" ] || return 0
    _brs=$(stat -c %s "$2" 2>/dev/null)
    printf '%s\n' "$BS_DEL" | while read -r _bpid _bpath; do
        [ "${_bpath##*/}" = "$1" ] || continue
        _bps=$(stat -L -c '%s %Y' "/proc/$_bpid/exe" 2>/dev/null) || continue
        [ "${_bps% *}" = "$_brs" ] || { echo "$_bpid"; continue; }
        _brk="$_bpid $_bps $3"
        grep -qxF "$_brk" "$BS_RUN_SAME" 2>/dev/null && continue
        if [ "$(file_sha256 "/proc/$_bpid/exe")" = "$3" ]; then echo "$_brk" >> "$BS_RUN_SAME" 2>/dev/null; else echo "$_bpid"; fi
    done
    return 0
}
bs_run_old() { [ -n "$(bs_stale_pids "$1" "$2" "$3" | head -n 1)" ]; }






bm_names() { [ -s "$BM_FILE" ] && awk -F'\t' '$1 !~ /^#/ && NF >= 4 { print $1 }' "$BM_FILE" | sort -u; }
bs_pick() { printf '%s\n' "$_bsp" | awk -v n="$1" '$1 == n { sub(/^[^ ]* /, ""); print; exit }'; }   # из bs_paths — путь имени $1
bin_status() {
    BA_VAL=$(bin_arch); BA_DONE=1
    BS_DEL=$(exe_deleted)   # процессы, исполняющие удалённый файл, — у владельца (daemon-lib.sh; сорсится ниже, до разбора вербов)
    _bsn="$*"
    [ -n "$_bsn" ] || _bsn=$(bm_names)
    _bsp=$(bs_paths $_bsn)
    for _n in $_bsn; do
        _p=$(bs_pick "$_n")
        _av=$(bm_field "$_n" 4 max)
        if [ -z "$_p" ] || [ ! -f "$_p" ]; then printf '%s\tabsent\t\t%s\t\n' "$_n" "$_av"; continue; fi
        _h=$(bs_sha "$_n" "$_p"); _st=unknown; _cv=""; _run=""
        if [ -n "$_h" ]; then
            _cv=$(bm_ver_of "$_n" "$_h")
            if [ -n "$_cv" ]; then
                _st=current; bs_ver_note "$_n" "$_p" "$_h" "$_cv"
            else
                _cv=$(bs_ver_known "$_n" "$_h")
                _bx=$(bm_field "$_n" 5 max); [ "${#_bx}" = 64 ] && _st=outdated
            fi
            bs_run_old "$_n" "$_p" "$_h" && _run=old
        fi
        printf '%s\t%s\t%s\t%s\t%s\n' "$_n" "$_st" "$_cv" "$_av" "$_run"
    done
    return 0
}


bin_stale() {
    BS_DEL=$(exe_deleted)
    [ -n "$BS_DEL" ] || return 0
    _bsn="$*"
    [ -n "$_bsn" ] || _bsn=$(bm_names)
    _bsp=$(bs_paths $_bsn)
    for _n in $_bsn; do
        _p=$(bs_pick "$_n")
        [ -n "$_p" ] && [ -f "$_p" ] || continue
        _h=$(bs_sha "$_n" "$_p"); [ -n "$_h" ] || continue
        bs_stale_pids "$_n" "$_p" "$_h" | while read -r _sp; do printf '%s\t%s\n' "$_sp" "$_n"; done
    done
    return 0
}


bs_seed() {   # $1 = имя, $2 = куда легло, $3 = путь по репо (bin/<арка>/<имя>.user), [$4 = хеш, уже посчитанный сверкой]
    _bsh=$4; [ -n "$_bsh" ] || _bsh=$(file_sha256 "$2"); [ -n "$_bsh" ] || return 0
    _bsa=""; case "$3" in bin/*/*) _bsa=${3#bin/}; _bsa=${_bsa%%/*} ;; esac
    _bsv=""; [ -s "$BM_FILE" ] && _bsv=$(awk -F'\t' -v n="$1" -v h="$_bsh" -v a="$_bsa" '$1 == n && $5 == h && $4 != "" && (a == "" || $2 == a) { print $4; exit }' "$BM_FILE")
    bs_put "$1" "$2" "$(bs_key "$2")" "$_bsh" "$_bsv"
}









bin_srcs() {
    _bst=$(local_tag)
    { [ -n "$_bst" ] && echo "https://raw.githubusercontent.com/$REPO/$_bst/$1"
      echo "$RAW/$1"
      bin_asset_url "$1"; } | awk 'NF && !s[$0]++'
}
fetch_bin() {
    name="$1"; dst="$2"; minsz="$3"
    case "$minsz" in ''|*[!0-9]*|0) minsz="" ;; esac



    if [ "$FB_NOLOCAL" != 1 ]; then
        if bstage_ok && [ -f "$BIN_STAGE/$name" ] && fetch_bin_staged "$name" "$dst"; then return 0; fi
        if bstage_ok "$BIN_PREFETCH" && [ -f "$BIN_PREFETCH/$name" ] && fetch_bin_staged "$name" "$dst" "$BIN_PREFETCH"; then return 0; fi
    fi
    BA_VAL=$(bin_arch); BA_DONE=1
    if [ -z "$BA_VAL" ]; then log "[fetch-bin] FAIL: архитектуру роутера опознать не вышло — какую сборку $name ставить, неизвестно"; return 1; fi
    _fbl=$(bm_line "$name"); FB_WANT=${_fbl#* }; FB_SIZE=${_fbl%% *}
    if [ "${#FB_WANT}" != 64 ]; then
        if [ -s "$BM_FILE" ]; then log "[fetch-bin] FAIL: «$name» ($BA_VAL) нет в манифесте бинарей установленной версии — ставить нечего"
        else log "[fetch-bin] FAIL: в установленном коде нет манифеста бинарей ($BM_REL) — сверить сборку не с чем; обновите систему"; fi
        return 1
    fi
    case "$FB_SIZE" in ''|*[!0-9]*) FB_SIZE="" ;; esac
    _rel="bin/$BA_VAL/$name.user"




    _fbw=""; _fbo=0; _bref=0; _brc=
    for _bsrc in $(bin_srcs "$_rel"); do
        if fetch_bin_one "$_bsrc" "$_rel" "$name" "$dst" "$minsz"; then return 0; fi
        [ "$FB_OTHER" = 1 ] && _fbo=1
        [ "$_fbo" = 1 ] && continue
        [ "$FB_404" = 1 ] || [ -n "$_fbw" ] || _fbw=$FB_WHY
        gh_code_refused && { _bref=1; _brc=$(gh_code_get); }
    done



    if [ "$_bref" = 1 ]; then [ -n "$_brc" ] && gh_code_note "$_brc"; log "[fetch-bin] FAIL: не скачался $name — $(gh_code_reason "$_brc")"; return 1; fi
    if [ -n "$_fbw" ]; then log "[fetch-bin] FAIL: $_fbw"


    elif [ "$_fbo" = 1 ]; then _fbv=$(local_name); log "[fetch-bin] FAIL: на GitHub лежит другая сборка $name, чем та, что знает установленная версия — обновите систему или загрузите bin/$BA_VAL/$name.user из архива установщика${_fbv:+ $_fbv} («Файлы с компьютера»)"
    else log "[fetch-bin] FAIL: на GitHub нет $_rel ни на теге релиза, ни в ветке $GH_REF"; fi
    return 1
}










BIN_STAGE=/tmp/enodia-bin-stage





BIN_PREFETCH=/tmp/enodia-bin-prefetch



bstage_ok() {   # [$1 = каталог; по умолчанию — хранилище загрузок с компьютера]
    _bsd=${1:-$BIN_STAGE}; _bsd_me="$(id -u 2>/dev/null) 700"
    [ -d "$_bsd" ] && [ ! -L "$_bsd" ] && [ "$(stat -c '%u %a' "$_bsd" 2>/dev/null)" = "$_bsd_me" ]
}






bstage_dir() {   # [$1 = каталог]
    _bdd=${1:-$BIN_STAGE}
    bstage_ok "$_bdd" && return 0
    if [ -e "$_bdd" ] || [ -L "$_bdd" ]; then
        _bdq=$(mktemp -d /tmp/enodia-foreign.XXXXXX 2>/dev/null) || return 1
        mv -f "$_bdd" "$_bdq/" 2>/dev/null || return 1
    fi
    mkdir -m 700 "$_bdd" 2>/dev/null
    bstage_ok "$_bdd"
}


bm_line() {
    [ -s "$BM_FILE" ] || return 0
    if [ "$BA_DONE" = 1 ]; then _bla=$BA_VAL; else _bla=$(bin_arch); fi
    [ -n "$_bla" ] || return 0
    awk -F'\t' -v n="$1" -v a="$_bla" '$1 == n && $2 == a { print $3 " " $5; exit }' "$BM_FILE"
}



cmd_bin_stage() {
    _sn="$1"; _sf="$2"
    case "$_sn" in ''|*[!a-z0-9-]*) rm -f "$_sf"; echo "FAIL: имя компонента не по форме"; return 1 ;; esac
    [ -f "$_sf" ] || { echo "FAIL: файл не получен"; return 1; }
    bstage_dir || { rm -f "$_sf"; echo "FAIL: не завести своё хранилище в /tmp (место в ОЗУ?)"; return 1; }
    _sl=$(bm_line "$_sn")
    if [ -z "$_sl" ]; then
        rm -f "$_sf"; echo "FAIL: «$_sn» нет в манифесте бинарей для этого роутера — это не файл проекта (или архитектура роутера не опознана)"; return 1
    fi
    _ssz=${_sl%% *}; _ssh=${_sl#* }
    if [ "${#_ssh}" != 64 ]; then
        rm -f "$_sf"; echo "FAIL: в манифесте нет суммы «$_sn» — проверить файл нечем (обновите систему)"; return 1
    fi
    _sgot=$(stat -c %s "$_sf" 2>/dev/null)
    _sh=$(file_sha256 "$_sf")
    if [ -z "$_sh" ]; then rm -f "$_sf"; echo "FAIL: нечем посчитать sha256 (нет openssl)"; return 1; fi
    if [ "$_sh" != "$_ssh" ]; then
        _soa=$(awk -F'\t' -v n="$_sn" -v h="$_sh" '$1 == n && $5 == h { print $2; exit }' "$BM_FILE" 2>/dev/null)
        rm -f "$_sf"


        if [ -n "$_soa" ]; then echo "FAIL: это «$_sn» для другой архитектуры ($_soa), а роутеру нужна $(bin_arch) — возьмите bin/$(bin_arch)/$_sn.user"
        else _slv=$(local_name); echo "FAIL: это не та сборка «$_sn», что знает установленная версия${_slv:+ $_slv} — файл из архива другой версии или оборван (у своей $_ssz байт, у этого $_sgot); возьмите bin/$(bin_arch)/$_sn.user из архива${_slv:+ $_slv}"; fi
        return 1
    fi


    _sp=$(bs_paths "$_sn" | cut -d' ' -f2-)
    if [ -f "$_sp" ] && [ "$(bs_sha "$_sn" "$_sp")" = "$_ssh" ]; then
        rm -f "$_sf"; echo "FAIL: «$_sn» $(bm_field "$_sn" 4 max) уже стоит — загружать не нужно"; return 1
    fi


    { printf '%s\n' "$_sh" > "$BIN_STAGE/$_sn.sha" && mv -f "$_sf" "$BIN_STAGE/$_sn"; } 2>/dev/null || {
        rm -f "$_sf" "$BIN_STAGE/$_sn.sha"; echo "FAIL: не положить файл в хранилище"; return 1; }
    echo "OK: $_sn $(bm_field "$_sn" 4 max) принят — его поставит установка компонента"
}





cmd_bin_staged() {
    bstage_ok || return 0
    BA_VAL=$(bin_arch); BA_DONE=1
    for _bf in "$BIN_STAGE"/*; do
        [ -f "$_bf" ] || continue
        _bn=${_bf##*/}
        case "$_bn" in ''|*[!a-z0-9-]*) continue ;; esac
        _bl=$(bm_line "$_bn"); _bm=${_bl#* }
        if [ "${#_bm}" != 64 ] || [ "$(cat "$_bf.sha" 2>/dev/null)" != "$_bm" ]; then rm -f "$_bf" "$_bf.sha"; continue; fi
        _bp=$(bs_paths "$_bn" | cut -d' ' -f2-)
        if [ -f "$_bp" ] && [ "$(bs_sha "$_bn" "$_bp")" = "$_bm" ]; then rm -f "$_bf" "$_bf.sha"; continue; fi
        echo "$_bn"
    done
    return 0
}



cmd_bin_unstage() {   # [$1 = каталог]
    _bud=${1:-$BIN_STAGE}
    bstage_ok "$_bud" || return 0
    for _bf in "$_bud"/*; do if [ -f "$_bf" ]; then rm -f "$_bf"; fi; done
    return 0
}




cmd_bin_prefetch() {
    case "$1" in ''|*[!a-z0-9-]*) log "[fetch-bin] FAIL: имя компонента не по форме"; return 1 ;; esac
    bstage_dir "$BIN_PREFETCH" || { log "[fetch-bin] FAIL: не завести каталог для закачки заранее в /tmp (место в ОЗУ?)"; return 1; }
    rm -f "$BIN_PREFETCH/$1"
    FB_NOLOCAL=1; FB_NOSEED=1
    fetch_bin "$1" "$BIN_PREFETCH/$1" ""
}



fetch_bin_staged() {   # $1 = имя, $2 = куда, [$3 = каталог-источник: по умолчанию — загрузки с компьютера; BIN_PREFETCH — скачанное заранее]
    _fsn="$1"; _fsd="$2"; _fsc=${3:-$BIN_STAGE}
    if [ "$_fsc" = "$BIN_PREFETCH" ]; then _fsw="скачанный заранее"; log "[fetch-bin] $_fsn <- скачан заранее (ОЗУ)"
    else _fsw="загруженный"; log "[fetch-bin] $_fsn <- файл, загруженный с компьютера"; fi
    _fsl=$(bm_line "$_fsn"); _fss=${_fsl#* }
    [ "${#_fss}" = 64 ] || { rm -f "$_fsc/$_fsn" "$_fsc/$_fsn.sha"; fb_fail "$_fsn: в манифесте нет суммы — $_fsw файл не проверить"; return 1; }
    GH_BGDL="$_fsd.dl"   # уборка выхода (gh_bg_stop) снимает копию, не доехавшую до `mv`
    cp "$_fsc/$_fsn" "$_fsd.dl" 2>/dev/null || { rm -f "$_fsd.dl"; fb_fail "не скопировать $_fsw $_fsn (место?)"; return 1; }
    _fsh=$(file_sha256 "$_fsd.dl")
    if [ "$_fsh" != "$_fss" ]; then rm -f "$_fsd.dl" "$_fsc/$_fsn" "$_fsc/$_fsn.sha"; fb_fail "$_fsw $_fsn не совпал с манифестом"; return 1; fi
    if ! elf_ok "$_fsd.dl"; then rm -f "$_fsd.dl" "$_fsc/$_fsn" "$_fsc/$_fsn.sha"; fb_fail "$_fsw $_fsn не ELF (не бинарь)"; return 1; fi
    chmod +x "$_fsd.dl"
    mv "$_fsd.dl" "$_fsd" || { rm -f "$_fsd.dl"; fb_fail "не смог поставить $_fsn"; return 1; }
    GH_BGDL=
    if [ ! -x "$_fsd" ]; then
        chmod +x "$_fsd" 2>/dev/null
        [ -x "$_fsd" ] || { rm -f "$_fsd"; fb_fail "$_fsn лёг без права на исполнение ($_fsd) — накопитель смонтирован без exec?"; return 1; }
    fi
    rm -f "$_fsc/$_fsn" "$_fsc/$_fsn.sha"
    bs_seed "$_fsn" "$_fsd" "bin/$(bin_arch)/$_fsn.user" "$_fsh"
    if [ "$_fsc" = "$BIN_PREFETCH" ]; then log "[fetch-bin] OK: $_fsn (скачан заранее) -> $_fsd"
    else log "[fetch-bin] OK: $_fsn (загружен с компьютера) -> $_fsd"; fi
}





bin_asset_url() {
    case "$1" in
        bin/*/*) _ba=${1#bin/}; _bn=${_ba#*/}; _ba=${_ba%%/*}; rel_flat_url "$_ba-$_bn" ;;
        *) : ;;
    esac
}



rel_flat_url() { [ "$GH_REF" = main ] || return 0; echo "$GH_REL/$1"; }





fb_fail() { FB_WHY="$1"; if [ "$2" = 404 ]; then FB_404=1; else FB_404=0; fi; log "[fetch-bin] мимо: $1"; }
fetch_bin_one() {
    url="$1"; rel="$2"; name="$3"; dst="$4"; minsz="$5"; FB_OTHER=0
    log "[fetch-bin] $name <- $url"




    t0=$(date +%s)
    gh_code_reset          # чтобы ответ прошлого канала не выдали за причину этого
    gh_get "$url" "$dst.dl" &
    cpid=$!; GH_BGPID=$cpid; GH_BGDL="$dst.dl"
    while kill -0 "$cpid" 2>/dev/null; do
        sleep 2
        cur=$(stat -c%s "$dst.dl" 2>/dev/null || echo 0); case "$cur" in ''|*[!0-9]*) cur=0;; esac


    el=$(( $(date +%s) - t0 )); [ "$el" -gt 0 ] || el=1
        log "[fetch-bin] $name: $((cur/1024)) КБ ($((cur/1024/el)) КБ/с)"
    done
    wait "$cpid" 2>/dev/null; rc=$?; GH_BGPID=


    if [ "$rc" != 0 ]; then
        rm -f "$dst.dl"
        _fbc=$(gh_code_get); _why=$(gh_code_reason "$_fbc")
        [ -n "$_why" ] || _why="нет связи с GitHub (или кончилось место)"
        fb_fail "не скачался $name — $_why" "$_fbc"
        return 1
    fi
    sz=$(stat -c%s "$dst.dl" 2>/dev/null || echo 0)
    if [ -n "$minsz" ] && [ "${sz:-0}" -lt "$minsz" ]; then rm -f "$dst.dl"; fb_fail "$name мал ($sz < $minsz) — обрыв закачки"; return 1; fi
    if ! elf_ok "$dst.dl"; then rm -f "$dst.dl"; fb_fail "$name не ELF (не бинарь)"; return 1; fi


    if [ -n "$FB_SIZE" ] && [ "$sz" != "$FB_SIZE" ]; then
        rm -f "$dst.dl"; fb_fail "$name по этому адресу — другая сборка ($sz байт, а у своей $FB_SIZE)"; FB_OTHER=1; return 1
    fi


    _fbh=$(file_sha256 "$dst.dl")
    if [ -z "$_fbh" ]; then rm -f "$dst.dl"; fb_fail "нечем посчитать sha256 $name (нет openssl) — сверить сборку нечем"; return 1; fi
    if [ "$_fbh" != "$FB_WANT" ]; then
        rm -f "$dst.dl"; fb_fail "$name по этому адресу — другая сборка, не та, что знает установленная версия"; FB_OTHER=1; return 1
    fi
    chmod +x "$dst.dl"
    mv "$dst.dl" "$dst" || { rm -f "$dst.dl"; fb_fail "не смог поставить $name"; return 1; }
    GH_BGDL=




    if [ ! -x "$dst" ]; then
        chmod +x "$dst" 2>/dev/null
        [ -x "$dst" ] || { rm -f "$dst"; fb_fail "$name лёг без права на исполнение ($dst) — накопитель смонтирован без exec?"; return 1; }
    fi
    [ "$FB_NOSEED" = 1 ] || bs_seed "$name" "$dst" "$rel" "$_fbh"
    log "[fetch-bin] OK: $name ($sz байт) -> $dst"
}


local_code() { c=$(sed -n 's/^CODE=//p' "$ENODIA_DIR/VERSION" 2>/dev/null | head -1 | tr -d ' \r'); case "$c" in ''|*[!0-9]*) echo 0;; *) echo "$c";; esac; }
local_name() { sed -n 's/^VERSION=//p' "$ENODIA_DIR/VERSION" 2>/dev/null | head -1 | tr -d ' \r"\\'; }
















REL_REL=release.txt
REL_KEYS="1 2"
SNAP_DIR="$ENODIA_STATE/.gh-backup"



PKG_TMP=""
rel_key() {
    case "$1" in
        1) cat <<'EOF'
-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEYMy2nkBwcDrbrYINLqB++poqqwSj
5uwJDict7DbZ/MlZvfx3X5/BWyhXiKCIqDzclOMkfJS5lQKyGoG4n0XyDw==
-----END PUBLIC KEY-----
EOF
        ;;
        2) cat <<'EOF'
-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEVajsejkbpxbm9fFpMaITwkTpbhxv
yIwwQgUmGMWzDiCqqLNE6r1IXmjEgvr1nCk2WWwQyL9O1oymwC8zlkrUDw==
-----END PUBLIC KEY-----
EOF
        ;;
    esac
}

rel_sig_ok() {
    _rk="${2%/*}/key"; _rok=1          # рядом с подписью: это личный каталог rel_load
    for _ki in $REL_KEYS; do
        rel_key "$_ki" > "$_rk" 2>/dev/null || continue
        if openssl dgst -sha256 -verify "$_rk" -signature "$2" "$1" >/dev/null 2>&1; then _rok=0; break; fi
    done
    rm -f "$_rk"
    return "$_rok"
}






rel_load() {
    REL_STATE=fail; REL_WHY=""; REL_VERSION=""; REL_CODE=""; REL_TAG=""; REL_PKG=""; REL_SIZE=""; REL_SHA=""
    _rd=$(mktemp -d /tmp/enodia-pkg.XXXXXX 2>/dev/null) || _rd=""
    [ -n "$_rd" ] || { REL_WHY="не создать рабочий каталог в /tmp"; return 1; }
    _rt="$_rd/rel"
    if ! gh_get "$RAW/$REL_REL" "$_rt" || [ ! -s "$_rt" ]; then
        rm -rf "$_rd"
        _rc=$(gh_code_get)
        case "$_rc" in
            404)     REL_STATE=none ;;
            429|403) REL_STATE=refused; REL_WHY=$(gh_code_reason "$_rc") ;;
            *)       REL_STATE=fail; REL_WHY=$(gh_code_reason "$_rc") ;;
        esac
        return 1
    fi
    if ! command -v openssl >/dev/null 2>&1; then
        rm -rf "$_rd"; REL_STATE=nossl
        REL_WHY="на роутере нет openssl — подпись релиза проверить нечем, а без проверки не ставим; обновите с компьютера"
        return 1
    fi

    grep -v '^SIG=' "$_rt" > "$_rt.body" 2>/dev/null
    sed -n 's/^SIG=//p' "$_rt" | head -n 1 | tr -d ' \r\n' > "$_rt.b64"
    openssl base64 -d -A -in "$_rt.b64" -out "$_rt.sig" 2>/dev/null
    if [ ! -s "$_rt.sig" ] || ! rel_sig_ok "$_rt.body" "$_rt.sig"; then
        rm -rf "$_rd"; REL_STATE=badsig
        REL_WHY="подпись релиза на GitHub не сошлась — такой релиз не ставим (подмена или ошибка публикации)"
        return 1
    fi
    _rf() { sed -n "s/^$1=//p" "$_rt.body" | head -n 1; }
    _rfm=$(_rf FORMAT); REL_VERSION=$(_rf VERSION); REL_CODE=$(_rf CODE); REL_TAG=$(_rf TAG)
    REL_PKG=$(_rf PKG); REL_SIZE=$(_rf SIZE); REL_SHA=$(_rf SHA256)
    rm -rf "$_rd"
    if [ "$_rfm" != 1 ]; then
        REL_STATE=newfmt
        REL_WHY="релиз опубликован в формате «$_rfm», а этот апдейтер знает формат 1 — обновите с компьютера"
        return 1
    fi
    _rbad=""
    case "$REL_CODE" in ''|*[!0-9]*) _rbad=" CODE" ;; esac
    case "$REL_SIZE" in ''|*[!0-9]*) _rbad="$_rbad SIZE" ;; esac
    case "$REL_TAG" in ''|*[!A-Za-z0-9._-]*|.*) _rbad="$_rbad TAG" ;; esac
    case "$REL_VERSION" in ''|*[!A-Za-z0-9._+-]*) _rbad="$_rbad VERSION" ;; esac
    [ "${#REL_SHA}" = 64 ] || _rbad="$_rbad SHA256"
    case "$REL_SHA" in *[!0-9a-f]*) _rbad="$_rbad SHA256" ;; esac
    [ "$REL_PKG" = "enodia-$REL_CODE.tar.gz" ] || _rbad="$_rbad PKG"
    if [ -n "$_rbad" ]; then
        REL_STATE=bad; REL_WHY="описание релиза на GitHub вне правил (поле:$_rbad) — не ставим"
        return 1
    fi
    REL_STATE=ok
    return 0
}

cmd_check() {
    lc=$(local_code); ln=$(local_name); [ -n "$ln" ] || ln="?"
    rel_load
    case "$REL_STATE" in
        ok)
            if [ "$REL_CODE" -gt "$lc" ]; then
                log "локально: $ln (код $lc); на GitHub: $REL_VERSION (код $REL_CODE, подпись сошлась) → ЕСТЬ ОБНОВЛЕНИЕ"
            else
                log "локально: $ln (код $lc); на GitHub: $REL_VERSION (код $REL_CODE) → у вас актуальная версия"
            fi ;;
        none) log "локально: $ln (код $lc); на GitHub нет описания релиза ($GH_REF) → обновление НЕ предлагается" ;;
        *)    log "локально: $ln (код $lc); ${REL_WHY:-GitHub не ответил — нет связи}" ;;
    esac
}





pkg_cleanup() { if [ -n "$PKG_TMP" ]; then rm -rf "$PKG_TMP" 2>/dev/null; fi; PKG_TMP=""; }
pkg_mkdir() {   # свой рабочий каталог (см. PKG_TMP); 1 — не создан
    PKG_TMP=$(mktemp -d /tmp/enodia-pkg.XXXXXX 2>/dev/null) || PKG_TMP=""
    [ -n "$PKG_TMP" ] && mkdir "$PKG_TMP/root" 2>/dev/null && return 0
    pkg_cleanup; return 1
}





upd_store_busy() {
    if command -v store_mode_alive >/dev/null 2>&1 && store_mode_alive; then
        log "[$1] СТОП: идёт смена раскладки (перенос на накопитель или обратно) — отменено; дождитесь её конца и повторите"
        return 0
    fi
    if command -v uninstall_alive >/dev/null 2>&1 && uninstall_alive; then
        log "[$1] СТОП: идёт снятие системы (отключение или полное удаление) — отменено"
        return 0
    fi
    return 1
}
cmd_apply() {
    _force="$1"
    upd_store_busy apply && return 1
    lc=$(local_code)
    if ! rel_load; then
        case "$REL_STATE" in
            none) log "[apply] на GitHub нет описания релиза ($REL_REL, ветка $GH_REF) — обновление отменено" ;;
            *)    log "[apply] СТОП: ${REL_WHY:-не удалось получить описание релиза с GitHub (нет связи)} — обновление отменено" ;;
        esac
        return 1
    fi
    if [ "$_force" != "--force" ] && [ "$REL_CODE" -le "$lc" ]; then
        log "[apply] на GitHub код $REL_CODE <= локального $lc — это даунгрейд, отмена (--force чтобы всё равно)"; return 1
    fi

    _tf=$(df -k /tmp 2>/dev/null | awk 'NR==2{print $4+0}'); case "$_tf" in ''|*[!0-9]*) _tf=0 ;; esac
    _tneed=$((REL_SIZE * 6 / 1024 + 2048))
    if [ "$_tf" -lt "$_tneed" ]; then
        log "[apply] СТОП: под распаковку пакета в /tmp свободно ${_tf} КБ, нужно ≥ ${_tneed} — обновление отменено"; return 1
    fi
    pkg_cleanup
    pkg_mkdir || { log "[apply] СТОП: не создать рабочий каталог в /tmp — обновление отменено"; return 1; }
    trap 'gh_exit; pkg_cleanup' EXIT
    trap 'exit 1' INT TERM HUP
    _pu="https://github.com/$REPO/releases/download/$REL_TAG/$REL_PKG"
    log "[apply] релиз $REL_VERSION (код $REL_CODE): подпись сошлась, качаю $REL_PKG ($REL_SIZE байт)"
    if ! gh_get "$_pu" "$PKG_TMP/pkg.tar.gz"; then
        _pr=$(gh_code_reason "$(gh_code_get)")
        log "[apply] СТОП: пакет не скачался: ${_pr:-нет связи с GitHub} — ничего не заменено"; pkg_cleanup; return 1
    fi
    _psz=$(wc -c < "$PKG_TMP/pkg.tar.gz" 2>/dev/null | tr -d ' ')
    if [ "$_psz" != "$REL_SIZE" ]; then
        log "[apply] СТОП: пакет пришёл не того размера (${_psz:-0} байт вместо $REL_SIZE) — ничего не заменено"; pkg_cleanup; return 1
    fi
    _ph=$(file_sha256 "$PKG_TMP/pkg.tar.gz")
    if [ -z "$_ph" ] || [ "$_ph" != "$REL_SHA" ]; then
        log "[apply] СТОП: sha256 пакета не совпал с подписанным описанием — ничего не заменено"; pkg_cleanup; return 1
    fi


    if ! tar -tvzf "$PKG_TMP/pkg.tar.gz" > "$PKG_TMP/lsv" 2>/dev/null || ! tar -tzf "$PKG_TMP/pkg.tar.gz" > "$PKG_TMP/ls" 2>/dev/null; then
        log "[apply] СТОП: архив пакета не читается — ничего не заменено"; pkg_cleanup; return 1
    fi



    if grep -qv '^-' "$PKG_TMP/lsv" || grep -q ' -> ' "$PKG_TMP/lsv"; then
        log "[apply] СТОП: в пакете есть не только обычные файлы — не ставим"; pkg_cleanup; return 1
    fi
    while IFS= read -r _pe || [ -n "$_pe" ]; do
        case "$_pe" in ''|/*|*..*|*[!A-Za-z0-9._/-]*) log "[apply] СТОП: в пакете путь вне правил: $_pe"; pkg_cleanup; return 1 ;; esac
    done < "$PKG_TMP/ls"
    if ! tar -xzf "$PKG_TMP/pkg.tar.gz" -C "$PKG_TMP/root" 2>/dev/null; then
        log "[apply] СТОП: пакет не распаковался (мало памяти?) — ничего не заменено"; pkg_cleanup; return 1
    fi
    rm -f "$PKG_TMP/pkg.tar.gz"
    _pvc=$(sed -n 's/^CODE=//p' "$PKG_TMP/root/VERSION" 2>/dev/null | head -n 1 | tr -cd '0-9')
    if [ "$_pvc" != "$REL_CODE" ]; then
        log "[apply] СТОП: версия внутри пакета (${_pvc:-нет}) не та, что в описании ($REL_CODE) — не ставим"; pkg_cleanup; return 1
    fi
    if [ ! -f "$PKG_TMP/root/pkg-install.sh" ]; then
        log "[apply] СТОП: в пакете нет установщика pkg-install.sh — не ставим"; pkg_cleanup; return 1
    fi
    log "[apply] пакет проверен (подпись, sha256, состав, версия) — передаю установщику из пакета"



    ENODIA_DIR="$ENODIA_DIR" ENODIA_STATE="$ENODIA_STATE" ENODIA_BIN="$ENODIA_BIN" ENODIA_BOOT="$ENODIA_BOOT" PKG_NEED_PRIOR=1 \
        sh "$PKG_TMP/root/pkg-install.sh" install "$PKG_TMP/root"
    _prc=$?
    pkg_cleanup
    return "$_prc"
}


rb_guard() {                     # 0 = откатывать можно; 1 = снимок СТАРЕЕ формы входа












    _rg="$1/totp.sh"
    if [ -f "$_rg" ]; then
        grep -qE "^pw_verify *\(\)" "$_rg" && return 0
        log "[rollback] снимок СТАРЕЕ формы входа: в его totp.sh нет pw_verify."
    else


        _rs=""
        for _c in status action data list ip ping sysinfo traffic backup diag; do
            [ -f "$1/web/cgi-bin/$_c" ] && { _rs="$1/web/cgi-bin/$_c"; break; }
        done
        [ -n "$_rs" ] || return 0            # ни totp.sh, ни CGI — это частичный бэкап, откат безопасен
        grep -q "403 Forbidden" "$_rs" && return 0
        log "[rollback] снимок СТАРЕЕ формы входа: totp.sh в нём нет, а гейт в CGI — прежний, без отказа."
    fi
    log "[rollback] откат туда оставил бы панель открытой всей локалке до ребута, а после ребута"
    log "[rollback] она не поднялась бы вовсе (прежний start требует web/uhttpd.conf, а миграция"
    log "[rollback] его удалила). Отказываюсь. Нужен именно этот снимок — сначала верните файл"



    log '[rollback] Basic руками:  printf "/:admin:%s\n" "$(uhttpd -m ВАШПАРОЛЬ)" > <каталог кода>/web/uhttpd.conf'   # c38-text: это ТЕКСТ совета, а не запись файла


    log '[rollback] и СРАЗУ откатывайтесь: cron-овский web-ui.sh start снова снесёт этот файл (раз в 5 мин).'
    log '[rollback] setpass его НЕ создаёт — он пишет .panel-pass.'
    return 1
}

snap_list() { ls -1 "$SNAP_DIR" 2>/dev/null | grep '^[0-9]\{8\}-[0-9]\{6\}\.tar\.gz$' | sort; }



cmd_rollback() {
    upd_store_busy rollback && return 1
    last=$(snap_list | tail -n 1)
    [ -n "$last" ] || { log "[rollback] нет снимков в $SNAP_DIR"; return 1; }
    [ -f "$ENODIA_DIR/pkg-install.sh" ] || { log "[rollback] нет $ENODIA_DIR/pkg-install.sh — откатывать нечем; переустановите с компьютера"; return 1; }
    pkg_cleanup
    pkg_mkdir || { log "[rollback] СТОП: не создать рабочий каталог в /tmp"; return 1; }
    trap 'gh_exit; pkg_cleanup' EXIT
    trap 'exit 1' INT TERM HUP
    if ! tar -xzf "$SNAP_DIR/$last" -C "$PKG_TMP/root" 2>/dev/null; then
        pkg_cleanup; log "[rollback] не открыть снимок ${last%.tar.gz} (повреждён?)"; return 1
    fi
    rb_guard "$PKG_TMP/root" || { pkg_cleanup; return 1; }
    log "[rollback] откат к снимку ${last%.tar.gz}"
    ENODIA_DIR="$ENODIA_DIR" ENODIA_STATE="$ENODIA_STATE" ENODIA_BIN="$ENODIA_BIN" ENODIA_BOOT="$ENODIA_BOOT" \
        sh "$ENODIA_DIR/pkg-install.sh" rollback "$PKG_TMP/root"
    _prc=$?
    pkg_cleanup

    if [ "$_prc" = 0 ]; then rm -f "$SNAP_DIR/$last" && log "[rollback] снимок ${last%.tar.gz} использован — снят"; fi
    return "$_prc"
}












bin_file_at() {
    if [ -f "$ENODIA_DIR/store-lib.sh" ]; then ( . "$ENODIA_DIR/store-lib.sh" >/dev/null 2>&1; bin_path "$1" )
    else printf '%s' "$ENODIA_BIN/$1"; fi
}




PKG_SUMS="$ENODIA_DIR/.pkg-sums"
vs_reset() { : > "$1.diff"; : > "$1.miss"; : > "$1.old"; nsame=0; ndiff=0; nmiss=0; nold=0; }
verify_scan() {   # $1 = префикс файлов-списков · $2 = подстрока пути (пусто = всё) · $3 = файл сумм · $4 = all|bin (только бинари)
    only="$2"; _vo="$1"; _vw="${4:-all}"
    _arch=$(bin_arch)
    while read -r _h _p; do
        case "$_h" in ''|\#*) continue ;; esac
        [ "${#_h}" = 64 ] || continue
        _p=${_p#\*}
        if [ "$_vw" = bin ]; then case "$_p" in bin/*) : ;; *) continue ;; esac; fi
        if [ -n "$only" ]; then case "$_p" in *"$only"*) : ;; *) continue ;; esac; fi




        case "$_p" in
            bin/*/*.user)
                _pa=${_p#bin/}; _pa=${_pa%%/*}
                [ -z "$_arch" ] || [ "$_pa" = "$_arch" ] || continue
                _n=${_p##*/}; _l=$(bin_file_at "${_n%.user}"); [ -f "$_l" ] || continue ;;
            bin/*.user)
                [ -z "$_arch" ] || continue
                _n=${_p##*/}; _l=$(bin_file_at "${_n%.user}"); [ -f "$_l" ] || continue ;;
            *) _l="$ENODIA_DIR/$_p" ;;
        esac
        if [ ! -f "$_l" ]; then printf '%s\n' "$_p" >> "$_vo.miss"; nmiss=$((nmiss+1)); continue; fi
        _g=$(file_sha256 "$_l")
        if [ "$_g" = "$_h" ]; then nsame=$((nsame+1)); continue; fi




        if [ "$_vw" = bin ]; then
            _vv=$(bs_ver_known "${_n%.user}" "$_g")
            if [ -n "$_vv" ]; then printf '%s %s\n' "$_p" "$_vv" >> "$_vo.old"; nold=$((nold+1)); continue; fi
        fi
        printf '%s\n' "$_p" >> "$_vo.diff"; ndiff=$((ndiff+1))
    done < "$3"
    return 0
}


VS_BINS=1         # 0 — бинари не сверяли (нет манифеста или арка не опознана): итог обязан это сказать
verify_bins() {   # $1 = префикс · $2 = подстрока пути
    VS_BINS=0
    [ -s "$BM_FILE" ] || return 0
    _vba=$(bin_arch); [ -n "$_vba" ] || return 0
    VS_BINS=1
    awk -F'\t' -v a="$_vba" '$1 !~ /^#/ && $2 == a && length($5) == 64 { print $5 "  bin/" a "/" $1 ".user" }' "$BM_FILE" > "$1.bm" 2>/dev/null
    verify_scan "$1" "$2" "$1.bm" bin
    rm -f "$1.bm"
}

verify_all() {   # $1 = префикс · $2 = подстрока пути
    vs_reset "$1"; VS_SRC=none
    if [ -s "$PKG_SUMS" ]; then
        VS_SRC=pkg
        verify_scan "$1" "$2" "$PKG_SUMS" all
        verify_bins "$1" "$2"
        return 0
    fi
    sums_load >/dev/null 2>&1
    [ "$SUMS_STATE" = ok ] || return 1
    VS_SRC=github
    verify_scan "$1" "$2" "$SUMS_CACHE" all
}
cmd_verify() {
    _vt="$GH_TMP/vf"
    verify_all "$_vt" "$1" || { rm -f "$_vt.diff" "$_vt.miss" "$_vt.old"; log "[verify] сумм установленного пакета нет, а в репо ($GH_REF) нет $SUMS_REL — сверять не с чем"; return 1; }
    while IFS= read -r _x || [ -n "$_x" ]; do [ -n "$_x" ] && log "[verify] нет на роутере: $_x"; done < "$_vt.miss"
    while IFS= read -r _x || [ -n "$_x" ]; do [ -n "$_x" ] && log "[verify] устарела (стоит прежняя подписанная сборка ${_x##* }, новая — в «Компонентах»): ${_x% *}"; done < "$_vt.old"
    while IFS= read -r _x || [ -n "$_x" ]; do [ -n "$_x" ] && log "[verify] РАСХОЖДЕНИЕ: $_x"; done < "$_vt.diff"
    rm -f "$_vt.diff" "$_vt.miss" "$_vt.old"
    case "$VS_SRC" in
        pkg) if [ "$VS_BINS" = 1 ]; then _vsw="код и бинари — по суммам установленного пакета"
             else _vsw="код — по суммам установленного пакета; бинари НЕ сверены (нет манифеста или арка не опознана)"; fi ;;
        *)   _vsw="по суммам репо $GH_REF" ;;
    esac
    _vso=""; [ "$nold" -gt 0 ] && _vso=", устарело $nold"
    log "[verify] совпало $nsame$_vso, расходится $ndiff, нет на роутере $nmiss ($_vsw, локально $(local_name))"
    [ "$ndiff" = 0 ]
}






if [ -f "$ENODIA_DIR/json-lib.sh" ]; then . "$ENODIA_DIR/json-lib.sh"; fi
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -d "/proc/$1" ]; }
command -v exe_deleted >/dev/null 2>&1 || exe_deleted() { ls -l /proc/[0-9]*/exe 2>/dev/null | sed -n 's#^.* /proc/\([0-9][0-9]*\)/exe -> \(.*\) (deleted)$#\1 \2#p'; }
command -v jesc  >/dev/null 2>&1 || jesc()   { tr -d '\000-\037"\\' | cut -c1-"$1"; }   # диапазон первым — C111
command -v jlines >/dev/null 2>&1 || jlines() { cat >/dev/null; }



GH_UPD_STATE="$ENODIA_STATE/.gh-update.state"
GH_UPD_LOG="$ENODIA_STATE/.gh-update.log"
GH_UPD_PID=/tmp/enodia-gh-update.pid
upd_running() {


    case "$(cat "$GH_UPD_STATE" 2>/dev/null | tr -cd 'A-Z')" in RUNNING|RBRUN) : ;; *) return 1 ;; esac



    _up=$(cat "$GH_UPD_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_up" 'gh-update\.sh|cgi-bin/action' 
}




cmd_check_json() {
    lc=$(local_code); ln=$(local_name)
    rel_load
    _why="$REL_WHY"; _rem=null
    case "$REL_STATE" in
        ok)
            if [ "$REL_CODE" -gt "$lc" ]; then _v=newer; else _v=current; fi
            _rem="{\"name\":\"$(printf '%s' "$REL_VERSION" | jesc 60)\",\"code\":$REL_CODE}" ;;
        none)    _v=none ;;
        refused) _v=refused ;;
        *)       _v=fail ;;
    esac
    printf '{"local":{"name":"%s","code":%s},"remote":%s,"verdict":"%s","why":"%s","repo":"%s","ref":"%s"}\n' \
        "$(printf '%s' "$ln" | jesc 60)" "$lc" "$_rem" "$_v" "$(printf '%s' "$_why" | jesc 300)" \
        "$(printf '%s' "$REPO" | jesc 120)" "$(printf '%s' "$GH_REF" | jesc 60)"
}





cmd_verify_json() {



    _vt="$GH_TMP/vf"
    if ! verify_all "$_vt" ""; then
        rm -f "$_vt.diff" "$_vt.miss" "$_vt.old"
        printf '{"state":"nosums","src":"none","bins":false,"same":0,"diff":[],"miss":[],"old":[],"ref":"%s"}\n' "$(printf '%s' "$GH_REF" | jesc 60)"; return 0
    fi
    _vjb=false; [ "$VS_SRC" = pkg ] && [ "$VS_BINS" = 1 ] && _vjb=true
    printf '{"state":"ok","src":"%s","bins":%s,"same":%s,"diff":[' "$VS_SRC" "$_vjb" "$nsame"; jlines 200 < "$_vt.diff"
    printf '],"miss":['; jlines 200 < "$_vt.miss"
    printf '],"old":['; jlines 200 < "$_vt.old"
    printf '],"ref":"%s"}\n' "$(printf '%s' "$GH_REF" | jesc 60)"
    rm -f "$_vt.diff" "$_vt.miss" "$_vt.old"
}



upd_why() {
    [ -f "$GH_UPD_LOG" ] || return 0
    grep -E '^\[(apply|rollback)\] (СТОП:|FAIL |на GitHub нет|на GitHub код|нет снимков|нет .*pkg-install\.sh|не открыть|не создать|снимок СТАРЕЕ)' "$GH_UPD_LOG" 2>/dev/null \
        | head -n 1 | sed 's/^\[[a-z]*\] //'
}





cmd_status_json() {
    _sn=""; _last=""
    for _d in $(snap_list); do
        _sn="$_sn${_sn:+,}\"$(printf '%s' "${_d%.tar.gz}" | jesc 40)\""; _last="$_d"
    done
    _rb=null; [ -n "$_last" ] && _rb=true
    _st=$(cat "$GH_UPD_STATE" 2>/dev/null | tr -cd 'A-Z'); [ -n "$_st" ] || _st=IDLE
    _run=false; upd_running && _run=true
    _at=$(stat -c %Y "$GH_UPD_LOG" 2>/dev/null); case "$_at" in ''|*[!0-9]*) _at=0 ;; esac



    _rp=$(grep '^\[\(apply\|rollback\)\] итог: заменено [0-9]' "$GH_UPD_LOG" 2>/dev/null | tail -n 1 | sed 's/.*заменено \([0-9]*\).*/\1/')
    case "$_rp" in ''|*[!0-9]*) _rp=0 ;; esac
    printf '{"name":"%s","code":%s,"repo":"%s","ref":"%s","snaps":[%s],"rb":%s,"apply":{"state":"%s","running":%s,"at":%s,"now":%s,"replaced":%s,"why":"%s","log":[' \
        "$(printf '%s' "$(local_name)" | jesc 60)" "$(local_code)" "$(printf '%s' "$REPO" | jesc 120)" "$(printf '%s' "$GH_REF" | jesc 60)" \
        "$_sn" "$_rb" "$_st" "$_run" "$_at" "$(date +%s)" "$_rp" "$(printf '%s' "$(upd_why)" | jesc 600)"

    [ -f "$GH_UPD_LOG" ] && tail -n 60 "$GH_UPD_LOG" 2>/dev/null | jlines 600
    printf ']}}\n'
}

case "$1" in
    fetch-bin)     fetch_bin "$2" "$3" "$4" ;;

    bin-stage)     cmd_bin_stage "$2" "$3" ;;
    bin-staged)    cmd_bin_staged ;;
    bin-unstage)   cmd_bin_unstage ;;
    bin-arch)      bin_arch ;;
    check)         cmd_check ;;
    apply)         cmd_apply "$2" ;;
    rollback)      cmd_rollback ;;
    verify)        cmd_verify "$2" ;;
    check-json)    cmd_check_json ;;
    verify-json)   cmd_verify_json ;;
    status-json)   cmd_status_json ;;
    upd-busy)      upd_running ;;
    why)           upd_why ;;       # причина отказа последнего обновления/отката одной строкой (итог кнопки «Откатить» в CGI)   # 0 = обновление идёт прямо сейчас (гард кнопки в cgi-bin/action)
    reachable)     gh_reachable "$2" ;;


    bin-manifest)  cat "$BM_FILE" 2>/dev/null ;;
    bin-size)      bin_size "$2" "$3" ;;
    bin-ver)       bin_ver "$2" ;;

    bin-status)    shift; bin_status "$@" ;;
    bin-stale)     shift; bin_stale "$@" ;;

    bin-prefetch)  cmd_bin_prefetch "$2" ;;
    bin-unprefetch) cmd_bin_unstage "$BIN_PREFETCH" ;;
    *) echo "usage: $0 fetch-bin <name> <dst> [minsz] | check | apply [--force] | rollback | verify [путь] | check-json | verify-json | status-json | upd-busy | reachable [path] | bin-manifest | bin-size <имя> [min|max] | bin-ver <имя> | bin-status [имя…] | bin-stale [имя…] | bin-stage <имя> <файл> | bin-staged | bin-unstage | bin-prefetch <имя> | bin-unprefetch | bin-arch"; exit 2 ;;
esac
_rc=$?




case "$GH_TMP" in /tmp/enodia-gh.*) rm -rf "$GH_TMP" 2>/dev/null ;; esac
exit $_rc
