#!/bin/sh



















EXCLUDE_CHAIN="VPN_EXCLUDE"
BYPASS_SET="xiaomi_bypass"
LOG=/tmp/enodia-xiaomi-bypass.log
ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}


if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v ct_flush_dst >/dev/null 2>&1 || ct_flush_dst() { [ -n "$1" ] && conntrack -D -d "$1" >/dev/null 2>&1; return 0; }


DOMAINS="
api.io.mi.com
ru.api.io.mi.com
de.api.io.mi.com
i2.api.io.mi.com
business.smartcamera.api.io.mi.com
tracker.api.xiaomi.com
api.miwifi.com
router.miwifi.com
api.io.miwifi.com
ott.io.mi.com
resolver.msg.xiaomi.net
"

exec >>"$LOG" 2>&1
echo "===== $(date) ====="


ipset list -n 2>/dev/null | grep -qx "$BYPASS_SET" || \
    ipset create "$BYPASS_SET" hash:net hashsize 256 maxelem 1024


ipset destroy "${BYPASS_SET}_new" 2>/dev/null
ipset create "${BYPASS_SET}_new" hash:net hashsize 256 maxelem 1024

ADDED=0
for d in $DOMAINS; do
    nslookup "$d" 2>/dev/null | awk '/^Address.*: [0-9]/{print $NF}' | grep -v '^127\.' | while read ip; do
        ipset add "${BYPASS_SET}_new" "$ip" 2>/dev/null && echo "  $d -> $ip"
    done
done


ipset swap "${BYPASS_SET}_new" "$BYPASS_SET" 2>/dev/null
ipset destroy "${BYPASS_SET}_new" 2>/dev/null


COUNT=$(ipset list "$BYPASS_SET" 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)
case "$COUNT" in ''|*[!0-9]*) COUNT=$(ipset list "$BYPASS_SET" 2>/dev/null | grep -cE '^[0-9]') ;; esac
case "$COUNT" in ''|*[!0-9]*) COUNT=0 ;; esac
echo "ipset $BYPASS_SET: $COUNT entries"


iptables -t mangle -L "$EXCLUDE_CHAIN" -n >/dev/null 2>&1 || \
    iptables -t mangle -N "$EXCLUDE_CHAIN"
for hook in PREROUTING OUTPUT; do
    iptables -t mangle -C "$hook" -j "$EXCLUDE_CHAIN" 2>/dev/null || {
        iptables -t mangle -I "$hook" 1 -j "$EXCLUDE_CHAIN"
        echo "hooked $EXCLUDE_CHAIN in $hook"
    }
done


iptables -t mangle -C "$EXCLUDE_CHAIN" -m set --match-set "$BYPASS_SET" dst -j ACCEPT 2>/dev/null || {
    iptables -t mangle -A "$EXCLUDE_CHAIN" -m set --match-set "$BYPASS_SET" dst -j ACCEPT
    echo "bypass rule added"
}




N=0
ipset list "$BYPASS_SET" | awk '/^[0-9]+\./{print $1}' | while read ip; do
    ct_flush_dst "$ip"
done >/dev/null 2>&1

echo "done"
