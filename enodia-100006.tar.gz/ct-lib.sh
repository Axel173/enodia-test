#!/bin/sh





























CT_ECM_DEFUNCT=/sys/kernel/debug/ecm/ecm_db/defunct_all   # ручка ускорителя (debugfs, root, 0644)
CT_PROC=/proc/net/nf_conntrack                            # таблица соединений — читается и без утилиты

_ct_have_tool() { command -v conntrack >/dev/null 2>&1; }



_ct_ecm_defunct() {
	[ -w "$CT_ECM_DEFUNCT" ] || return 1
	echo 1 > "$CT_ECM_DEFUNCT" 2>/dev/null || return 1
}


ct_flush() {
	if _ct_have_tool; then conntrack -F >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}



ct_flush_src() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --src "$1" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}





ct_flush_src_n() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --src "$1" 2>/dev/null | wc -l; return 0; fi
	_ct_ecm_defunct || true
	return 0
}



ct_flush_dst() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then
		if [ -n "$2" ]; then conntrack -D -p tcp -d "$1" --dport "$2" >/dev/null 2>&1 || true
		else                 conntrack -D -d "$1" >/dev/null 2>&1 || true; fi
		return 0
	fi
	_ct_ecm_defunct || true
	return 0
}



ct_flush_dport() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D -p tcp --dport "$1" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}









ct_list_src() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -L -s "$1" 2>/dev/null; return 0; fi
	[ -r "$CT_PROC" ] || return 0
	awk -v ip="$1" '{ for(i=1;i<=NF;i++) if (substr($i,1,4)=="src=") { if (substr($i,5)==ip) print; break } }' \
		"$CT_PROC" 2>/dev/null
	return 0
}





ct_list_all() {
	if _ct_have_tool; then conntrack -L 2>/dev/null; return 0; fi
	[ -r "$CT_PROC" ] || return 0
	cat "$CT_PROC" 2>/dev/null
	return 0
}




ct_tool() {
	if _ct_have_tool; then echo conntrack
	elif [ -w "$CT_ECM_DEFUNCT" ]; then echo ecm
	else echo none; fi
}
