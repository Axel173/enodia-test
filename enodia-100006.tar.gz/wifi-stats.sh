#!/bin/sh






















































ENODIA_DIR="${ENODIA_DIR:-/data/usr/app/enodia}"
if [ -f "$ENODIA_DIR/wifi-lib.sh" ]; then . "$ENODIA_DIR/wifi-lib.sh"; fi


if [ -f "$ENODIA_DIR/lease-lib.sh" ]; then . "$ENODIA_DIR/lease-lib.sh"; fi


command -v wifi_iface_list >/dev/null 2>&1 || wifi_iface_list() { ls -1 /sys/class/net 2>/dev/null | grep '^wl[0-9]'; }
command -v wifi_ssid_of >/dev/null 2>&1 || wifi_ssid_of() { return 1; }
command -v wifi_live_ifaces >/dev/null 2>&1 || wifi_live_ifaces() { ls -1 /sys/class/net 2>/dev/null | grep '^wl[0-9]'; }
command -v wifi_bridge_of >/dev/null 2>&1 || wifi_bridge_of() { return 1; }

LEASES=/tmp/dhcp.leases




ws_collect() {
    for _sc in $(wifi_live_ifaces); do







        WS_IFC="$_sc"; WS_SSID=$(wifi_ssid_of "$_sc" 2>/dev/null | tr '\t' ' '); WS_NET=$(wifi_bridge_of "$_sc")
        export WS_IFC WS_SSID WS_NET
        wlanconfig "$_sc" list sta 2>/dev/null | awk '
        BEGIN { ifc = ENVIRON["WS_IFC"]; ssid = ENVIRON["WS_SSID"]; net = ENVIRON["WS_NET"]; n = 0 }
        /^ADDR/ { next }                                            # ловушка 1: шапок несколько
        $1 ~ /^[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:/ {
            n++;
            mac[n] = tolower($1); chan[n] = $3 + 0;
            t = $4; sub(/M$/, "", t); tx[n] = t + 0;
            t = $5; sub(/M$/, "", t); rx[n] = t + 0;
            rssi[n] = $6 + 0; idle[n] = $9 + 0;
            snr[n] = ""; band[n] = ""; mx[n] = 0; asc[n] = 0; mode[n] = ""; nrx[n] = 0; ntx[n] = 0;
            at = 0;
            for (i = 10; i <= NF; i++) if ($i ~ /^[0-9]+:[0-9][0-9]:[0-9][0-9]$/) { at = i; break }
            if (at) {
                # ASSOCTIME = ДЛИТЕЛЬНОСТЬ «Ч:ММ:СС», часов бывает и больше суток. Разбираем
                # substr-ом от КОНЦА строки: минуты и секунды всегда двузначны, часы — нет.
                s = $at; L = length(s);
                asc[n] = substr(s, 1, L - 6) * 3600 + substr(s, L - 4, 2) * 60 + substr(s, L - 1, 2);
                for (j = at - 1; j >= 10; j--) if ($j ~ /^[0-9]+$/) { mx[n] = $j + 0; break }   # ловушка 4
                for (k = at + 1; k <= NF; k++) if ($k ~ /^IEEE80211_MODE_/) {
                    mode[n] = $k; nrx[n] = $(k + 1) + 0; ntx[n] = $(k + 2) + 0; break
                }
            }
            next
        }
        /^[ \t]*SNR[ \t]*:/            { if (n) snr[n]  = $NF + 0; next }   # ловушка 2: блок ПОД строкой
        /^[ \t]*Operating band[ \t]*:/ { if (n) band[n] = $NF;     next }
        END {
            for (i = 1; i <= n; i++) {
                m = mode[i];
                # Ловушка 6: порядок проверок обязателен, «HT» есть внутри VHT и EHT.
                if (m ~ /EHT/)      std = 7;
                else if (m ~ /HE/)  std = 6;
                else if (m ~ /VHT/) std = 5;
                else if (m ~ /HT/)  std = 4;
                else                std = 0;
                # Ширина канала = хвостовые цифры MODE (HT20/VHT80/HE160/EHT320). У легаси-режима
                # (11B/11G) их нет вовсе — тогда честный ноль, а не выдуманные 20.
                w = ""; L = length(m); p = L;
                while (p > 0 && substr(m, p, 1) >= "0" && substr(m, p, 1) <= "9") { w = substr(m, p, 1) w; p-- }
                if (w == "") w = 0;
                # Диапазон: строка блока, а если её не было — по номеру канала (1..14 = 2.4 ГГц).
                b = band[i];
                if (b == "") b = (chan[i] > 0 && chan[i] <= 14) ? "2.4GHz" : (chan[i] > 0 ? "5GHz" : "");
                printf "%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\n", \
                    mac[i], ifc, net, b, chan[i], tx[i], rx[i], int(mx[i] / 1000), rssi[i], \
                    (snr[i] == "" ? "" : snr[i]), nrx[i], ntx[i], asc[i], idle[i], std, w + 0, m, ssid
            }
        }' 2>/dev/null
    done
}










ws_emit() {
    WS_FMT="$1"; export WS_FMT
    awk -v FS='\t' '
    BEGIN { fmt = ENVIRON["WS_FMT"]; first = 1; n = 0; part = 0 }
    $0 == "###STA###" { part = 1; next }
    $0 == "###NAMES###" { part = 2; next }
    # Свои имена (dev-names.sh, `mac⇥имя`) — метка панели: список устройств и список станций обязаны звать устройство ОДНИМ
    # именем, иначе в одном месте «Алиса», а в другом голый MAC.
    part == 2 { if ($1 != "") al[tolower($1)] = $2; next }
    part == 0 {
        # /tmp/dhcp.leases: <expiry> <mac> <ip> <host> <clientid>. Имя «*» = аренда без имени.
        if (NF >= 4) { lip[tolower($2)] = $3; lho[tolower($2)] = ($4 == "*" ? "" : $4) }
        next
    }
    {
        n++;
        mac = $1; ifc = $2; net = $3; band = $4; chan = $5; tx = $6; rx = $7; mx = $8;
        rssi = $9; snr = $10; nrx = $11; ntx = $12; asc = $13; idle = $14; std = $15;
        width = $16; mode = $17; ssid = $18;
        ip = lip[mac]; host = lho[mac]; alias = al[mac];
        if (fmt == "tsv") {
            printf "%s\t%s\t%s\t%s\t%s\t%s\t%s/%s Mbps\tmax %s\t%s dBm\tSNR %s\t%sx%s\tstd %s\tw %s\tup %ss\tidle %ss\n", \
                mac, (ip == "" ? "-" : ip), (host == "" ? "-" : host), ifc, (ssid == "" ? "-" : ssid), \
                band, tx, rx, mx, rssi, snr, nrx, ntx, std, width, asc, idle;
            next
        }
        # Экранируем ТОЛЬКО поля со свободным текстом: имя сети и имя устройства. Порядок
        # обязателен — сперва обратный слеш, иначе экранируем собственные вставки.
        gsub(/\\/, "\\\\", ssid); gsub(/"/, "\\\"", ssid);
        gsub(/\\/, "\\\\", host); gsub(/"/, "\\\"", host);
        printf "%s{\"mac\":\"%s\",\"ip\":\"%s\",\"host\":\"%s\",\"alias\":\"%s\",\"ifc\":\"%s\",\"ssid\":\"%s\",\"net\":\"%s\",\"band\":\"%s\",\"chan\":%s,\"tx\":%s,\"rx\":%s,\"max\":%s,\"rssi\":%s,\"snr\":%s,\"nrx\":%s,\"ntx\":%s,\"assoc\":%s,\"idle\":%s,\"std\":%s,\"width\":%s,\"mode\":\"%s\"}", \
            (first ? "" : ","), mac, ip, host, alias, ifc, ssid, net, band, chan, tx, rx, mx, rssi, \
            (snr == "" ? "null" : snr), nrx, ntx, asc, idle, std, width, mode;
        first = 0
    }
    END { if (fmt != "tsv") printf "\n" }
    '
}





ws_stream() {







    if command -v neigh_pairs >/dev/null 2>&1; then
        neigh_pairs 2>/dev/null | awk -v FS='\t' -v OFS='\t' '{print 0, $2, $1, "*", "-"}'
    fi
    [ -f "$LEASES" ] && sed 's/[ 	][ 	]*/\t/g' "$LEASES" 2>/dev/null




    if [ -f "$ENODIA_DIR/dev-names.sh" ]; then printf '###NAMES###\n'; sh "$ENODIA_DIR/dev-names.sh" list 2>/dev/null; fi
    printf '###STA###\n'
    printf '%s\n' "$1"
}

cmd_json() {
    if ! command -v wlanconfig >/dev/null 2>&1; then


        printf '{"ok":0,"err":"no-wlanconfig","n":0,"sta":[]}\n'
        return 0
    fi
    _raw=$(ws_collect)
    _cnt=$(printf '%s\n' "$_raw" | grep -c . 2>/dev/null || true)
    [ -n "$_cnt" ] || _cnt=0
    _body=$(ws_stream "$_raw" | ws_emit json)
    printf '{"ok":1,"n":%s,"sta":[%s]}\n' "$_cnt" "$_body"
}

cmd_tsv() {
    command -v wlanconfig >/dev/null 2>&1 || { echo "wlanconfig не найден — статистики Wi-Fi нет"; return 1; }
    ws_stream "$(ws_collect)" | ws_emit tsv
}

case "${1:-json}" in
    json) cmd_json ;;
    tsv)  cmd_tsv ;;
    *)    echo "использование: $0 [json|tsv]" >&2; exit 1 ;;
esac
