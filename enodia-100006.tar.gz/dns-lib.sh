#!/bin/sh



























































dom_ok() {

    case "$1" in ''|.*|*.|*..*|*[!A-Za-z0-9._-]*) return 1 ;; esac
    [ "${#1}" -le 253 ] || return 1
    _do_rest="$1"
    while : ; do
        case "$_do_rest" in
            *.*) _do_lab=${_do_rest%%.*}; _do_rest=${_do_rest#*.} ;;
            *)   _do_lab=$_do_rest;       _do_rest='' ;;
        esac
        [ "${#_do_lab}" -le 63 ] || return 1     # длина ≥1 гарантирована отсевом пустых меток выше
        [ -n "$_do_rest" ] || return 0
    done
}



















resolve_ipv4() {
    _h="$1"









    _ip=$(timeout -t "${RESOLVE_NS_TIMEOUT:-2}" nslookup "$_h" 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{x=$NF; if(x ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/){print x; exit}}')
    [ -n "$_ip" ] && { echo "$_ip"; return 0; }

    _ip=$(doh_ips "$_h" "" | head -1)
    [ -n "$_ip" ] && { echo "$_ip"; return 0; }
    return 1
}
















ns_ips() {
    if [ -n "${2:-}" ]; then timeout -t "$2" nslookup "$1" 2>/dev/null
    else nslookup "$1" 2>/dev/null; fi | awk '/^Name:/{f=1}
        f{for(i=1;i<=NF;i++) if ($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) print $i}'
}























doh_ips() {
    _dq_h="$1"; _dq_a="$2"
    _dq_w=$(_dnslib_wan)
    if [ -n "$_dq_w" ]; then
        _dq_r=$(_dnslib_doh_all "$_dq_h" "$_dq_a --interface $_dq_w"); _dq_c=$?
        if [ -n "$_dq_r" ]; then echo "$_dq_r"; return 0; fi
        if [ "$_dq_c" = 2 ]; then return 1; fi
    fi
    _dq_r=$(_dnslib_doh_all "$_dq_h" "$_dq_a")
    if [ -n "$_dq_r" ]; then echo "$_dq_r"; return 0; fi
    return 1
}








command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
_dnslib_wan() { wan_iface; }




















CURL_CA_CAP="${CURL_CA_CAP:-/tmp/.enodia-curl-cafile}"
CURL_CA_CANDIDATES="${CURL_CA_CANDIDATES:-/etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem /usr/share/ca-certificates/ca-certificates.crt}"
curl_ca_opt() {   # $1 = URL пробы; $2… = доп-аргументы curl (напр. --resolve); без URL — только известный ответ
    if [ -f "$CURL_CA_CAP" ]; then
        [ -s "$CURL_CA_CAP" ] && printf -- '--cacert %s' "$(cat "$CURL_CA_CAP" 2>/dev/null)"
        return 0
    fi
    [ -n "$1" ] || return 0
    _ccu="$1"; shift
    _cc60=0






    for _cca in $CURL_CA_CANDIDATES; do
        [ -s "$_cca" ] || continue
        _ccc=$(curl -s -o /dev/null -w '%{http_code}' --cacert "$_cca" --connect-timeout 5 --max-time 10 "$@" "$_ccu" 2>/dev/null)
        _ccr=$?
        case "$_ccc" in



            ''|000) if [ "$_ccr" = 60 ]; then _cc60=1; else break; fi ;;
            *) printf '%s' "$_cca" > "$CURL_CA_CAP" 2>/dev/null
               printf -- '--cacert %s' "$_cca"; return 0 ;;
        esac
    done
    [ "$_cc60" = 1 ] && : > "$CURL_CA_CAP" 2>/dev/null   # это ОТВЕТ «бандлы не помогают» — помним до ребута
    return 0
}











_dnslib_doh_all() {
    _dda_ans=0
    for _dq in 'https://1.1.1.1/dns-query' 'https://8.8.8.8/resolve'; do




        _dda_b=$(curl -s --connect-timeout 3 --max-time 8 $2 "$_dq?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null || true)











        case "$_dda_b" in
            *'"Status"'*) ;;
            *) _dda_ca=$(curl_ca_opt "$_dq?name=$1&type=A")
               if [ -n "$_dda_ca" ]; then
                   _dda_b=$(curl -s $_dda_ca --connect-timeout 3 --max-time 8 $2 "$_dq?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null || true)
               fi
               case "$_dda_b" in
                   *'"Status"'*) ;;
                   *) _dda_b=$(curl -sk --connect-timeout 3 --max-time 8 $2 "$_dq?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null || true) ;;
               esac ;;
        esac
        case "$_dda_b" in *'"Status"'*) _dda_ans=1 ;; esac
        _di=$(printf '%s' "$_dda_b" | grep -o '"data":"[0-9.]*"' | cut -d'"' -f4)
        case "$_di" in *.*.*.*) echo "$_di"; return 0 ;; esac
    done
    if [ "$_dda_ans" = 1 ]; then return 2; fi
    return 1
}


is_ipv4() { echo "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; }






















ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
SEED_CACHE="${SEED_CACHE:-$ENODIA_STATE/.dns-seed-cache}"
if [ ! -f "$SEED_CACHE" ] && [ -f "${ENODIA_DIR:-/data/usr/app/enodia}/.dns-seed-cache" ] && [ -d "$ENODIA_STATE" ]; then   # migrate: см. mv ниже
    mv "${ENODIA_DIR:-/data/usr/app/enodia}/.dns-seed-cache" "$SEED_CACHE" 2>/dev/null || true   # migrate: код → состояние, один раз
fi
SEED_TRIES=${SEED_TRIES:-6}                  # ожиданий сети, когда прошлого адреса НЕТ (прежнее поведение)
SEED_TRIES_CACHED=${SEED_TRIES_CACHED:-2}    # ...и когда ЕСТЬ: дальше поднимаемся на нём



seed_cache_get() {
    [ -f "$SEED_CACHE" ] || return 1
    awk -v h="$1" '$1==h{print $2; exit}' "$SEED_CACHE" 2>/dev/null
}


seed_cache_put() {
    _scp_h="$1"; _scp_i="$2"
    [ -n "$_scp_h" ] && [ -n "$_scp_i" ] || return 0
    _scp_t="$SEED_CACHE.tmp"
    if [ -f "$SEED_CACHE" ]; then
        awk -v h="$_scp_h" '$1!=h' "$SEED_CACHE" > "$_scp_t" 2>/dev/null
    else
        : > "$_scp_t" 2>/dev/null
    fi
    printf '%s\t%s\t%s\n' "$_scp_h" "$_scp_i" "$(date +%s)" >> "$_scp_t" 2>/dev/null   # clock-raw: отметка для дампа, возраст по ней не считаем
    mv -f "$_scp_t" "$SEED_CACHE" 2>/dev/null
    return 0
}





















_seed_live() { case "$1" in /etc/dnsmasq.d/*) echo "/tmp/dnsmasq.d/${1##*/}" ;; esac; }















SEED_HOSTS="${SEED_HOSTS:-/etc/hosts}"
_seed_tag() { echo "# awg-seed ${1##*/}"; }




seed_hosts_put() {
    _shp_h="$1"; _shp_i="$2"
    { [ -n "$_shp_h" ] && [ -n "$(printf '%s' "$_shp_i" | tr -d ' ')" ]; } || return 0
    _shp_t=$(_seed_tag "$3")
    _shp_w=$(for _shp_a in $_shp_i; do printf '%s\t%s\t%s\n' "$_shp_a" "$_shp_h" "$_shp_t"; done)
    [ -f "$SEED_HOSTS" ] || : > "$SEED_HOSTS" 2>/dev/null

    [ "$(grep -F "$_shp_t" "$SEED_HOSTS" 2>/dev/null)" = "$_shp_w" ] && return 0
    _shp_p="$SEED_HOSTS.enodiatmp"
    grep -vF "$_shp_t" "$SEED_HOSTS" > "$_shp_p" 2>/dev/null      # busybox: код 1 при пустом выводе — не судим по нему
    printf '%s\n' "$_shp_w" >> "$_shp_p" 2>/dev/null
    [ -s "$_shp_p" ] && mv -f "$_shp_p" "$SEED_HOSTS" 2>/dev/null
    rm -f "$_shp_p" 2>/dev/null
    return 0
}


seed_hosts_clear() {
    _shc_t=$(_seed_tag "$1")
    grep -qF "$_shc_t" "$SEED_HOSTS" 2>/dev/null || return 1
    _shc_p="$SEED_HOSTS.enodiatmp"
    grep -vF "$_shc_t" "$SEED_HOSTS" > "$_shc_p" 2>/dev/null




    if [ -f "$_shc_p" ]; then mv -f "$_shc_p" "$SEED_HOSTS" 2>/dev/null; fi
    rm -f "$_shc_p" 2>/dev/null
    return 0
}






DNS_RELOAD_MARK=${DNS_RELOAD_MARK:-/tmp/enodia-dns-reload}
seed_host_clear() {
    _sc_f="$1"; [ -n "$_sc_f" ] || return 1
    _sc_l=$(_seed_live "$_sc_f"); _sc_hit=1
    [ -f "$_sc_f" ] && _sc_hit=0
    [ -n "$_sc_l" ] && [ -f "$_sc_l" ] && _sc_hit=0
    rm -f "$_sc_f" 2>/dev/null
    [ -n "$_sc_l" ] && rm -f "$_sc_l" 2>/dev/null
    if seed_hosts_clear "$_sc_f"; then _sc_hit=0; fi    # третья копия (форма `if` — она безразлична к позиции под set -e)
    if [ "$_sc_hit" = 0 ]; then : > "$DNS_RELOAD_MARK" 2>/dev/null; fi
    return $_sc_hit
}

seed_host_dns() {   # $1 = host ; $2 = seed-файл
    _sh_host="$1"; _sh_file="$2"
    [ -n "$_sh_host" ] && [ -n "$_sh_file" ] || return 1
    if is_ipv4 "$_sh_host"; then
        seed_host_clear "$_sh_file"; return 0          # server уже IP — сеять нечего, чистим прошлый сид (обе копии)
    fi



    _sh_ip=""; _sh_n=0; _sh_from_cache=0
    _sh_cached=$(seed_cache_get "$_sh_host")
    while [ "$_sh_n" -lt "$SEED_TRIES" ]; do
        _sh_ip=$(resolve_ipv4 "$_sh_host"); [ -n "$_sh_ip" ] && break
        _sh_n=$((_sh_n+1))
        if [ -n "$_sh_cached" ] && [ "$_sh_n" -ge "$SEED_TRIES_CACHED" ]; then
            _sh_ip="$_sh_cached"; _sh_from_cache=1
            _dnslib_log "резолв '$_sh_host' не удался ($_sh_n) → поднимаюсь на ПРОШЛОМ рабочем адресе $_sh_ip (кэш)"
            break
        fi
        _dnslib_log "резолв server-host '$_sh_host' попытка $_sh_n не удалась — повтор через 2с…"; sleep 2
    done
    [ -n "$_sh_ip" ] || { _dnslib_log "НЕ зарезолвил server-host '$_sh_host' за $SEED_TRIES попыток → несущая не встанет (честно)"; return 1; }
    is_ipv4 "$_sh_ip" || { _dnslib_log "резолв вернул не-IP '$_sh_ip' — не сею"; return 1; }


    if [ "$_sh_from_cache" = 0 ] && [ "$_sh_ip" != "$_sh_cached" ]; then seed_cache_put "$_sh_host" "$_sh_ip"; fi


    seed_hosts_put "$_sh_host" "$_sh_ip" "$_sh_file"










    _sh_want="address=/$_sh_host/$_sh_ip"
    _sh_live=$(_seed_live "$_sh_file")
    if [ "$(cat "$_sh_file" 2>/dev/null)" = "$_sh_want" ] \
       && { [ -z "$_sh_live" ] || [ "$(cat "$_sh_live" 2>/dev/null)" = "$_sh_want" ]; } \
       && timeout -t "${RESOLVE_NS_TIMEOUT:-2}" nslookup "$_sh_host" 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{print $NF}' | grep -qx "$_sh_ip"; then
        _dnslib_log "локальный DNS: $_sh_host → $_sh_ip (сид уже стоит — dnsmasq не трогаю)"
        return 0
    fi
    mkdir -p /etc/dnsmasq.d
    printf '%s\n' "$_sh_want" > "$_sh_file"
    if [ -n "$_sh_live" ]; then mkdir -p /tmp/dnsmasq.d 2>/dev/null; printf '%s\n' "$_sh_want" > "$_sh_live"; fi
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
    _sh_k=0                                            # дождаться, что dnsmasq реально отдаёт сид (до старта демона)
    while [ "$_sh_k" -lt 6 ]; do
        timeout -t "${RESOLVE_NS_TIMEOUT:-2}" nslookup "$_sh_host" 127.0.0.1 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{print $NF}' | grep -qx "$_sh_ip" && break
        _sh_k=$((_sh_k+1)); sleep 1
    done
    _dnslib_log "локальный DNS: $_sh_host → $_sh_ip (демон резолвит имя сам; конфиг по имени не трогаем)"
    return 0
}



_dnslib_log() { if command -v log >/dev/null 2>&1; then log "$@"; else echo "[dns-lib] $*"; fi; }
