#!/bin/sh



































IPT_WAIT_SEC=${IPT_WAIT_SEC:-5}      # сколько ждём лок; 5 с — как в ipt_check_t сторожа
IPT_WAIT_CACHE=/tmp/.enodia-ipt-wait # вердикт пробы (RAM: гибнет с ребутом — как и версия утилиты)
IP6T_WAIT_CACHE=/tmp/.enodia-ip6t-wait





case "$IPT_WAIT_SEC" in [1-9]|[1-9][0-9]) ;; *) IPT_WAIT_SEC=5 ;; esac



: "${IPT_BIN:=}"
: "${IP6T_BIN:=}"



if [ -n "$IPT_BIN" ]  && [ ! -x "$IPT_BIN" ];  then IPT_BIN=;  fi
if [ -n "$IP6T_BIN" ] && [ ! -x "$IP6T_BIN" ]; then IP6T_BIN=; fi
for _iptdir in /usr/sbin /sbin /usr/bin /bin; do
	if [ -z "$IPT_BIN" ]  && [ -x "$_iptdir/iptables" ];  then IPT_BIN="$_iptdir/iptables";   fi
	if [ -z "$IP6T_BIN" ] && [ -x "$_iptdir/ip6tables" ]; then IP6T_BIN="$_iptdir/ip6tables"; fi
done








_ipt_wait_probe() {                  # $1 — бинарь, $2 — файл кэша
	_iptw=
	if [ -r "$2" ]; then read -r _iptw < "$2" 2>/dev/null || _iptw=; fi


	case "$_iptw" in
		no|[1-9]|[1-9][0-9]) printf '%s' "$_iptw"; return 0 ;;
	esac
	if "$1" -w "$IPT_WAIT_SEC" -t filter -S INPUT >/dev/null 2>&1; then
		echo "$IPT_WAIT_SEC" > "$2" 2>/dev/null || true
		printf '%s' "$IPT_WAIT_SEC"
		return 0
	fi
	if "$1" -t filter -S INPUT >/dev/null 2>&1; then
		echo no > "$2" 2>/dev/null || true
	fi
	printf 'no'
	return 0
}


: "${IPT_WOPT:=}"
: "${IPT_WREADY:=}"
: "${IP6T_WOPT:=}"
: "${IP6T_WREADY:=}"

if [ -n "$IPT_BIN" ]; then
iptables() {
	if [ -z "$IPT_WREADY" ]; then
		IPT_WREADY=1
		_iptv=$(_ipt_wait_probe "$IPT_BIN" "$IPT_WAIT_CACHE")
		case "$_iptv" in [1-9]*) IPT_WOPT="-w $_iptv" ;; *) IPT_WOPT= ;; esac
	fi
	if [ -z "$IPT_WOPT" ]; then "$IPT_BIN" "$@"; return $?; fi

	"$IPT_BIN" $IPT_WOPT "$@"
	_iptrc=$?



	if [ "$_iptrc" = 2 ]; then "$IPT_BIN" "$@"; _iptrc=$?; fi
	return "$_iptrc"
}
fi

if [ -n "$IP6T_BIN" ]; then
ip6tables() {
	if [ -z "$IP6T_WREADY" ]; then
		IP6T_WREADY=1
		_iptv=$(_ipt_wait_probe "$IP6T_BIN" "$IP6T_WAIT_CACHE")
		case "$_iptv" in [1-9]*) IP6T_WOPT="-w $_iptv" ;; *) IP6T_WOPT= ;; esac
	fi
	if [ -z "$IP6T_WOPT" ]; then "$IP6T_BIN" "$@"; return $?; fi

	"$IP6T_BIN" $IP6T_WOPT "$@"
	_iptrc=$?
	if [ "$_iptrc" = 2 ]; then "$IP6T_BIN" "$@"; _iptrc=$?; fi
	return "$_iptrc"
}
fi










ipt_top() {
	_itc=$1; shift
	iptables -C "$_itc" "$@" 2>/dev/null && return 0
	_itp=$(iptables -S "$_itc" 2>/dev/null | awk '/^-A /{n++} /^-A [A-Z]+ -j ENODIA_(GEO)?BLK$/{p=n} END{print p+1}')
	case "$_itp" in ''|*[!0-9]*) _itp=1 ;; esac
	iptables -I "$_itc" "$_itp" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"
}





ipt_jump_state() {
	if ! iptables -nL "$2" >/dev/null 2>&1; then
		iptables -S "$1" >/dev/null 2>&1 && return 1
		return 2
	fi
	iptables -C "$1" -j "$2" 2>/dev/null; _ijs=$?
	case "$_ijs" in 0|1) return "$_ijs" ;; *) return 2 ;; esac
}








FW3_GEN_FILE=/tmp/enodia-fw3.gen
fw3_gen() { cat "$FW3_GEN_FILE" 2>/dev/null; }
fw3_gen_new() { { cat /proc/sys/kernel/random/uuid 2>/dev/null || echo "$$-$RANDOM-$RANDOM"; } > "$FW3_GEN_FILE" 2>/dev/null; }




ipt_wait_mode() {
	if [ -z "$IPT_BIN" ]; then echo no; return 0; fi



	( _ipt_wait_probe "$IPT_BIN" "$IPT_WAIT_CACHE" )
	echo
}
