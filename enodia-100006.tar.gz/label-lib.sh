#!/bin/sh















LBL_TAB=$(printf '\t')
LBL_NL='
'




lbl_lock_take() {
    _lbli=0
    while ! mkdir "$1" 2>/dev/null; do
        _lbli=$((_lbli+1)); [ "$_lbli" -gt 5 ] && return 1
        _lblp=$(cat "$1/pid" 2>/dev/null | tr -d ' \r\n')
        if [ -n "$_lblp" ]; then
            pid_runs "$_lblp" "$2" || { rm -rf "$1" 2>/dev/null; continue; }
        elif [ "$_lbli" -ge 3 ]; then
            rm -rf "$1" 2>/dev/null; continue
        fi
        sleep 1
    done
    echo $$ > "$1/pid" 2>/dev/null
    return 0
}
lbl_lock_drop() { rm -rf "$1" 2>/dev/null; }



lbl_san() { printf '%s' "$1" | tr '\t\r\n' '   ' | tr -d '\000-\037"\\' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[[:space:]][[:space:]]*/ /g'; }




lbl_list() {
    [ -f "$1" ] || return 0
    tr -d '\000-\010\013-\037"\\' < "$1" 2>/dev/null | awk -F"$LBL_TAB" -v kre="$2" -v low="${3:-}" '
    {
        m = $1; if (low != "") m = tolower(m); gsub(/ /, "", m)
        if (m !~ kre) next
        if (m in seen) next
        n = $2; for (i = 3; i <= NF; i++) n = n " " $i
        gsub(/  +/, " ", n); sub(/^ /, "", n); sub(/ $/, "", n)
        if (n == "") next
        seen[m] = 1; print m "\t" n
    }'
}



lbl_write() {
    _lblw=$(lbl_list "$1" "$4" "$5" | awk -F"$LBL_TAB" -v m="$2" '$1!=m')
    [ -n "$3" ] && _lblw="${_lblw:+$_lblw$LBL_NL}$2$LBL_TAB$3"
    lbl_commit "$1" "$_lblw"
}


lbl_merge() {
    _lblw=$( { lbl_list "$2" "$3" "$4"; lbl_list "$1" "$3" "$4"; } | awk -F"$LBL_TAB" '!($1 in s) { s[$1] = 1; print }')
    lbl_commit "$1" "$_lblw"
}


lbl_commit() {
    if [ -z "$2" ]; then rm -f "$1"; return $?; fi
    _lblt="$1.$$"
    if printf '%s\n' "$2" > "$_lblt" 2>/dev/null && [ "$(cat "$_lblt" 2>/dev/null)" = "$2" ]; then
        mv "$_lblt" "$1" && return 0
    fi
    rm -f "$_lblt"; return 1
}
