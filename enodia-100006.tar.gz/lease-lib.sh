#!/bin/sh











































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
LEASE_FILE="${LEASE_FILE:-/tmp/dhcp.leases}"




LEASE_OWNER_FILE="${LEASE_OWNER_FILE:-$ENODIA_STATE/.ip-owner}"
if [ ! -f "$LEASE_OWNER_FILE" ] && [ -f "$ENODIA_DIR/.ip-owner" ] && [ -d "$ENODIA_STATE" ]; then   # migrate: см. mv ниже
    mv "$ENODIA_DIR/.ip-owner" "$LEASE_OWNER_FILE" 2>/dev/null || true   # migrate: код → состояние, один раз
fi
LEASE_OWNER_MAX=300          # кольцо: строка ~50 Б, потолок держит файл в пределах 15 КБ на 20-МБ флеше


if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v clock_sane >/dev/null 2>&1 || clock_sane() { _csn=${1:-$(date +%s 2>/dev/null)}; case "$_csn" in ''|*[!0-9]*) return 1 ;; esac; [ "$_csn" -gt 1700000000 ] 2>/dev/null && [ "$_csn" -lt 4102444800 ] 2>/dev/null; }



mac_norm() { printf '%s' "$1" | tr 'A-Z' 'a-z' | tr -d ' \t\r\n'; }
mac_ok()   { printf '%s' "$1" | grep -qE '^[0-9a-f]{2}(:[0-9a-f]{2}){5}$'; }
_lmac_norm() { mac_norm "$1"; }


lease_mac_of()  { [ -n "$1" ] || return 1; awk -v w="$1" '$3==w{print $2; exit}' "$LEASE_FILE" 2>/dev/null; }
lease_exp_of()  { [ -n "$1" ] || return 1; awk -v w="$1" '$3==w{print $1; exit}' "$LEASE_FILE" 2>/dev/null; }

lease_host_of() {
    [ -n "$1" ] || return 1
    _lh=$(awk -v w="$1" '$3==w{print $4; exit}' "$LEASE_FILE" 2>/dev/null)
    [ "$_lh" = "*" ] && _lh=""
    printf '%s' "$_lh"
}



lease_ip_of_mac() {
    [ -n "$1" ] || return 1
    _lm=$(_lmac_norm "$1")
    awk -v m="$_lm" '$2==m && $1+0>b {b=$1+0; ip=$3} END{if(ip!="") print ip}' "$LEASE_FILE" 2>/dev/null
}



neigh_mac_of() {
    [ -n "$1" ] || return 1
    ip neigh show 2>/dev/null | awk -v w="$1" '$1==w && /lladdr/ && $NF!="FAILED" && $NF!="INCOMPLETE"{print $5; exit}'
}












neigh_pairs() {
    ip neigh show 2>/dev/null | awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && $4=="lladdr" && $3 ~ /^br-/ && $3!="br-docker" && $NF!="FAILED" && $NF!="INCOMPLETE"{print $1"\t"tolower($5)}'
}


ip_owner_now() {
    _lo=$(lease_mac_of "$1")
    [ -n "$_lo" ] || _lo=$(neigh_mac_of "$1")
    [ -n "$_lo" ] || return 1
    _lmac_norm "$_lo"
}




mac_is_random() {
    case "$(_lmac_norm "$1")" in
        ?[2367abef]:*) return 0 ;;
    esac
    return 1
}











ip_is_local() {
    [ -n "$1" ] || return 1




    _ldev=$(ip route get "$1" 2>/dev/null | sed -n '1s/.* dev \([^ ]*\).*/\1/p')   # not-wan: спрашиваем МОСТ клиента, а не WAN — владелец (ip-lib.sh) тут ни при чём
    case "$_ldev" in br-*|awgs0|lo) return 0 ;; esac





    _lsub=$(cat "$ENODIA_STATE/server/subnet" 2>/dev/null)
    [ -n "$_lsub" ] || _lsub=10.77.0
    case "$1" in "$_lsub".*) return 0 ;; esac
    return 1
}



owner_get() {
    [ -n "$1" ] || return 1
    [ -f "$LEASE_OWNER_FILE" ] || return 1
    awk -F'\t' -v w="$1" '$1==w{print $2"\t"$3"\t"$4; exit}' "$LEASE_OWNER_FILE" 2>/dev/null
}




owner_note() {
    [ -n "$1" ] || return 1
    _lom=$(ip_owner_now "$1") || return 1
    _loh=$(lease_host_of "$1")
    _lot=$(date +%s 2>/dev/null); clock_sane "$_lot" || _lot=0   # порог — у clock-lib.sh (C82)
    _lof=$(dirname "$LEASE_OWNER_FILE")
    [ -d "$_lof" ] || return 1
    _lotmp="$LEASE_OWNER_FILE.tmp.$$"
    { [ -f "$LEASE_OWNER_FILE" ] && awk -F'\t' -v w="$1" '$1!=w' "$LEASE_OWNER_FILE" 2>/dev/null | tail -n "$LEASE_OWNER_MAX"
      printf '%s\t%s\t%s\t%s\n' "$1" "$_lom" "$_loh" "$_lot"
    } > "$_lotmp" 2>/dev/null || { rm -f "$_lotmp" 2>/dev/null; return 1; }
    mv "$_lotmp" "$LEASE_OWNER_FILE" 2>/dev/null || { rm -f "$_lotmp" 2>/dev/null; return 1; }
    return 0
}

owner_forget() {
    [ -n "$1" ] || return 1
    [ -f "$LEASE_OWNER_FILE" ] || return 0
    _lotmp="$LEASE_OWNER_FILE.tmp.$$"
    awk -F'\t' -v w="$1" '$1!=w' "$LEASE_OWNER_FILE" 2>/dev/null > "$_lotmp" || { rm -f "$_lotmp" 2>/dev/null; return 1; }
    mv "$_lotmp" "$LEASE_OWNER_FILE" 2>/dev/null || { rm -f "$_lotmp" 2>/dev/null; return 1; }
    return 0
}
