#!/bin/sh
















































DNSMASQ_DIR="/etc/dnsmasq.d"
CUSTOM_FILE="$DNSMASQ_DIR/enodia-custom.conf"
MAIN_FILE="$DNSMASQ_DIR/enodia-domains.conf"
IPSET_NAME="enodia_list"
BYPASS_SET="enodia_bypass"







if [ -z "$ENODIA_DIR" ]; then
    ENODIA_DIR=$(cd "$(dirname "$0")" 2>/dev/null && pwd); [ -d "$ENODIA_DIR" ] || ENODIA_DIR=/data/usr/app/enodia   # flash-lit: последний фолбэк, когда и $0 не дал каталога
fi
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }





if [ -f "$ENODIA_DIR/set-lib.sh" ]; then . "$ENODIA_DIR/set-lib.sh"; fi
if ! command -v set_sync >/dev/null 2>&1; then
	set_sync() { ipset flush "$1" 2>/dev/null; }
fi





if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
if ! command -v dom_ok >/dev/null 2>&1; then
	dom_ok() { [ -n "$1" ] && [ "${#1}" -le 253 ] || return 1
	           printf '%s' "$1" | grep -qE '^[A-Za-z0-9_-]{1,63}(\.[A-Za-z0-9_-]{1,63})*$'; }
fi
PERSIST_FILE="$ENODIA_STATE/.enodia-custom.conf"
persist_save() { cp "$CUSTOM_FILE" "$PERSIST_FILE" 2>/dev/null; }

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

mkdir -p "$DNSMASQ_DIR"
[ ! -f "$CUSTOM_FILE" ] && {
    echo "# Пользовательские домены, идущие через AWG-туннель." > "$CUSTOM_FILE"
    echo "# Управляется через domain.sh. Можно редактировать руками." >> "$CUSTOM_FILE"
    echo "" >> "$CUSTOM_FILE"
}

reload_dnsmasq() {











    sh "$ENODIA_DIR/dns-merge.sh" reload 2>/dev/null \
        || /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
    [ "$1" = flush ] && ipset flush "$IPSET_NAME" 2>/dev/null
}












ensure_sets() {
    ipset list -n 2>/dev/null | grep -qx "$IPSET_NAME" || \
        ipset create "$IPSET_NAME" hash:net family inet hashsize 1024 maxelem 1000000 2>/dev/null


    ipset list -n 2>/dev/null | grep -qx "$BYPASS_SET" || \
        ipset create "$BYPASS_SET" hash:net hashsize 1024 maxelem 65536 2>/dev/null
}


dom_list() {
    [ -f "$CUSTOM_FILE" ] || return 0
    if [ -n "$1" ]; then sed -n "s|^ipset=/\([^/]*\)/$1\$|\1|p" "$CUSTOM_FILE" 2>/dev/null
    else sed -n 's|^ipset=/\([^/]*\)/.*|\1|p' "$CUSTOM_FILE" 2>/dev/null; fi
}


















dns_up() {
    _du=0
    while [ "$_du" -lt 10 ]; do
        nslookup localhost >/dev/null 2>&1 && return 0
        _du=$((_du + 1)); sleep 1
    done
    return 1
}






if ! command -v ns_ips >/dev/null 2>&1; then
    ns_ips() {
        nslookup "$1" 2>/dev/null | awk '/^Name:/{f=1}
            f{for(i=1;i<=NF;i++) if ($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) print $i}'
    }
fi



set_full() {
    ipset list -t "$1" 2>/dev/null | awk '
        /^Number of entries:/{n=$NF}
        /maxelem/{for(i=1;i<=NF;i++) if ($i=="maxelem") m=$(i+1)}
        END{if (m!="" && n!="" && n+0 >= m+0) exit 0; exit 1}'
}












warm_one() {
    _wo_s="$1"; _wo_d="$2"; _wo_t=0
    while :; do
        _wo_any=0
        for _wo_ip in $(ns_ips "$_wo_d"); do
            _wo_any=1
            ipset test "$_wo_s" "$_wo_ip" >/dev/null 2>&1 && return 0
        done
        [ "$_wo_any" = 1 ] || return 2          # A-записи нет — класть в набор нечего, это штатно
        _wo_t=$((_wo_t + 1))
        [ "$_wo_t" -ge "${WARM_TRIES:-2}" ] && return 1
        sleep 1
    done
}


warm() {
    _w_s="$1"; _w_miss=0
    for _w_d in $(dom_list "$_w_s"); do
        warm_one "$_w_s" "$_w_d"
        case $? in 1) _w_miss=$((_w_miss + 1)) ;; esac
    done
    [ "$_w_miss" = 0 ] && return 0
    printf "${YELLOW}[ ! ] %s: доменов с резолвом, но без адреса в наборе — %s.${NC}\n" "$_w_s" "$_w_miss"
    if set_full "$_w_s"; then
        printf "${RED}      Набор %s ПЕРЕПОЛНЕН — dnsmasq больше не добавляет в него адреса.${NC}\n" "$_w_s"
    else
        printf "${YELLOW}      Обычная причина: домен заявлен ещё где-то (группа/гео/пул), а dnsmasq${NC}\n"
        printf "${YELLOW}      кладёт адрес РОВНО В ОДИН набор на домен.${NC}\n"
    fi
    return 1
}
















WARM_SETS_CAP=${WARM_SETS_CAP:-40}




if [ -f "$ENODIA_DIR/lists-lib.sh" ]; then . "$ENODIA_DIR/lists-lib.sh"; fi
command -v ipset_count >/dev/null 2>&1 || ipset_count() {
    _ic=$(ipset list "$1" 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)
    case "$_ic" in ''|*[!0-9]*) _ic=$(ipset list "$1" 2>/dev/null | grep -cE '^[0-9]') ;; esac
    case "$_ic" in ''|*[!0-9]*) _ic=0 ;; esac
    printf '%s' "$_ic"
}



warm_have_work() {



    for _wh_dir in /etc/dnsmasq.d /tmp/dnsmasq.d; do
        for _wh_f in "$_wh_dir"/enodia-custom.conf "$_wh_dir"/[0-9][0-9]-*.conf; do
            [ -f "$_wh_f" ] || continue
            grep -q '^ipset=' "$_wh_f" 2>/dev/null && return 0
        done
    done
    return 1
}

warm_rule_sets() {
    _ws_confs=""
    for _ws_dir in /etc/dnsmasq.d /tmp/dnsmasq.d; do
        for _ws_f in "$_ws_dir"/[0-9][0-9]-*.conf; do
            [ -f "$_ws_f" ] && _ws_confs="$_ws_confs $_ws_f"
        done
    done
    [ -n "$_ws_confs" ] || return 0

    for _ws_s in $(sed -n 's|^ipset=/.*/\([^/]*\)$|\1|p' $_ws_confs 2>/dev/null | tr ',' '\n' | sort -u); do
        case "$_ws_s" in ''|"$IPSET_NAME"|"$BYPASS_SET") continue ;; esac
        ipset list -n 2>/dev/null | grep -qx "$_ws_s" || continue     # набора нет — не наше дело
        [ "$(ipset_count "$_ws_s")" = 0 ] || continue                 # живой набор прогрева не просит


        _ws_doms=$(sed -n 's|^ipset=/||p' $_ws_confs 2>/dev/null | while IFS= read -r _ws_l; do
                case ",${_ws_l##*/}," in *",$_ws_s,"*) echo "${_ws_l%%/*}" ;; esac
            done | sort -u | head -n "$WARM_SETS_CAP")
        [ -n "$_ws_doms" ] || continue
        _ws_n=0
        for _ws_d in $_ws_doms; do warm_one "$_ws_s" "$_ws_d"; _ws_n=$((_ws_n + 1)); done
        printf "[domain] %s: набор был пуст, прогрето доменов %s (лимит %s)\n" "$_ws_s" "$_ws_n" "$WARM_SETS_CAP"
    done
    return 0
}





rebuild_bypass_set() {
    ensure_sets




    _rb_c="/tmp/.enodia-dom-bypass-cidr.$$"; _rb_d="/tmp/.enodia-dom-bypass-dom.$$"
    : > "$_rb_c"; dom_list "$BYPASS_SET" > "$_rb_d" 2>/dev/null
    set_sync "$BYPASS_SET" "$_rb_c" "$_rb_d"
    rm -f "$_rb_c" "$_rb_d" 2>/dev/null

    sh "$ENODIA_DIR/apply-bypass.sh" set-dst-ensure "$BYPASS_SET" >/dev/null 2>&1 || true




    [ "$1" = nowarm ] || warm "$BYPASS_SET"
}



drop_rule() { sed -i "/^ipset=\/$1\/.*/d; /^address=\/$1\/.*/d" "$CUSTOM_FILE" 2>/dev/null; }


set_rule() {
    _dom="$1"; _set="$2"
    if grep -q "^ipset=/$_dom/$_set\$" "$CUSTOM_FILE" 2>/dev/null; then
        printf "${YELLOW}Домен %s уже %s.${NC}\n" "$_dom" "$([ "$_set" = "$IPSET_NAME" ] && echo 'в VPN' || echo 'мимо VPN')"
        exit 0
    fi
    drop_rule "$_dom"                       # смена направления = замена строки, а не вторая строка
    ensure_sets
    echo "ipset=/$_dom/$_set" >> "$CUSTOM_FILE"
    persist_save
    reload_dnsmasq


    dns_up || printf "${YELLOW}[ ! ] dnsmasq не ответил за 10 с — правило записано, адреса подъедут позже.${NC}\n"
    rebuild_bypass_set                      # сет «мимо» всегда = точный слепок правил (см. шапку)
    warm_one "$_set" "$_dom"; _sr_rc=$?
    case "$_sr_rc" in
        1) printf "${RED}[ ! ] Адрес %s НЕ попал в набор %s — правило записано, но пока не действует.${NC}\n" "$_dom" "$_set"
           if set_full "$_set"; then
               printf "${RED}      Набор переполнен: dnsmasq больше не добавляет в него адреса.${NC}\n"
           else
               printf "${YELLOW}      Проверьте, не заявлен ли домен ещё где-то (группа/гео/пул):${NC}\n"
               printf "${YELLOW}      dnsmasq кладёт адрес РОВНО В ОДИН набор на домен.${NC}\n"
           fi ;;
        2) printf "${YELLOW}[ i ] У %s нет A-записи — маршрутизировать по IPv4 пока нечего.${NC}\n" "$_dom" ;;
    esac

    ct_flush
    return "$_sr_rc"
}

case "$1" in
    add)
        domain="$2"
        if [ -z "$domain" ]; then
            printf "${RED}Укажите домен:${NC} domain.sh add chatgpt.com\n"
            exit 1
        fi

        domain=$(echo "$domain" | sed -E 's|^https?://||; s|^www\.||; s|/.*$||')
        dom_ok "$domain" || { printf "${RED}[ ! ]${NC} Недопустимый домен: %s\n" "$domain"; exit 1; }

        if grep -q "/$domain/" "$MAIN_FILE" 2>/dev/null; then
            printf "${BLUE}Кстати, %s уже есть в основном re-filter списке.${NC}\n" "$domain"
            printf "${BLUE}Но всё равно добавлю в ваш пользовательский — на всякий.${NC}\n"
        fi






        if set_rule "$domain" "$IPSET_NAME"; then
            printf "${GREEN}[ + ]${NC} %s теперь идёт В VPN.\n" "$domain"
        else
            printf "${YELLOW}[ + ]${NC} Правило для %s сохранено, но пока НЕ действует — причина выше.\n" "$domain"
        fi
        ;;




    bypass|out)
        domain="$2"
        if [ -z "$domain" ]; then
            printf "${RED}Укажите домен:${NC} domain.sh bypass mi.com\n"
            exit 1
        fi
        domain=$(echo "$domain" | sed -E 's|^https?://||; s|^www\.||; s|/.*$||')
        dom_ok "$domain" || { printf "${RED}[ ! ]${NC} Недопустимый домен: %s\n" "$domain"; exit 1; }
        if set_rule "$domain" "$BYPASS_SET"; then
            printf "${GREEN}[ → ]${NC} %s теперь идёт МИМО VPN (напрямую).\n" "$domain"
        else
            printf "${YELLOW}[ → ]${NC} Правило для %s сохранено, но пока НЕ действует — причина выше.\n" "$domain"
        fi
        ;;










    add-many)
        _n=0; _added="/tmp/.enodia-dom-many.$$"; : > "$_added"
        ensure_sets
        while read -r _l || [ -n "$_l" ]; do
            _d=$(printf '%s' "$_l" | tr -d ' \t\r' | sed -E 's|^https?://||; s|^\*\.||; s|^www\.||; s|/.*$||')
            [ -n "$_d" ] || continue


            dom_ok "$_d" || continue
            echo "$_d" | grep -qE '\.[A-Za-z]{2,}$' || continue
            grep -q "^ipset=/$_d/$IPSET_NAME\$" "$CUSTOM_FILE" 2>/dev/null && continue
            drop_rule "$_d"                     # смена направления = замена строки, а не вторая
            echo "ipset=/$_d/$IPSET_NAME" >> "$CUSTOM_FILE"
            echo "$_d" >> "$_added"
            _n=$((_n + 1))
        done
        if [ "$_n" -gt 0 ]; then
            persist_save
            reload_dnsmasq
            dns_up || echo "[domain] dnsmasq не ответил за 10 с — адреса подъедут позже" >&2
            rebuild_bypass_set                  # сет «мимо» = точный слепок правил (см. шапку)



            _miss=0
            while read -r _wd || [ -n "$_wd" ]; do
                warm_one "$IPSET_NAME" "$_wd"
                case $? in 1) _miss=$((_miss + 1)) ;; esac
            done < "$_added"
            [ "$_miss" = 0 ] || echo "[domain] адрес не попал в набор у доменов: $_miss" >&2
            ct_flush
        fi
        rm -f "$_added" 2>/dev/null
        echo "$_n"
        ;;





    block)
        domain="$2"
        if [ -z "$domain" ]; then
            printf "${RED}Укажите домен:${NC} domain.sh block ads.example.com\n"
            exit 1
        fi
        domain=$(echo "$domain" | sed -E 's|^https?://||; s|^www\.||; s|/.*$||')
        dom_ok "$domain" || { printf "${RED}[ ! ]${NC} Недопустимый домен: %s\n" "$domain"; exit 1; }
        drop_rule "$domain"                     # смена состояния = замена строк, не добавка
        printf 'address=/%s/0.0.0.0\naddress=/%s/::\n' "$domain" "$domain" >> "$CUSTOM_FILE"
        persist_save
        reload_dnsmasq                          # address= по SIGHUP не перечитывается → полный рестарт
        rebuild_bypass_set                      # если домен был «мимо» — убрать его IP из enodia_bypass
        ct_flush            # NSS/ECM-offload: живые соединения иначе не переключатся
        printf "${GREEN}[ x ]${NC} %s ЗАБЛОКИРОВАН (не открывается на всех устройствах).\n" "$domain"
        ;;

    remove|rm|del)
        domain="$2"
        if [ -z "$domain" ]; then
            printf "${RED}Укажите домен:${NC} domain.sh remove instagram.com\n"
            exit 1
        fi
        domain=$(echo "$domain" | sed -E 's|^https?://||; s|^www\.||; s|/.*$||')



        if grep -qE "^(ipset|address)=/$domain/" "$CUSTOM_FILE" 2>/dev/null; then

            was=$(sed -n "s|^ipset=/$domain/\(.*\)$|\1|p" "$CUSTOM_FILE" 2>/dev/null | head -1)
            drop_rule "$domain"
            persist_save




            if [ "$was" = "$IPSET_NAME" ]; then reload_dnsmasq flush; warm "$IPSET_NAME"; else reload_dnsmasq; fi
            rebuild_bypass_set          # ушёл из «мимо» → его IP обязаны уйти из enodia_bypass
            ct_flush
            printf "${GREEN}[ - ]${NC} правило для %s снято — домен снова «как все».\n" "$domain"
            if grep -q "/$domain/" "$MAIN_FILE" 2>/dev/null; then
                printf "${BLUE}Он есть в основном re-filter → продолжит идти через VPN оттуда.${NC}\n"
            fi
        else
            printf "${YELLOW}%s не было в пользовательском списке.${NC}\n" "$domain"
            if grep -q "/$domain/" "$MAIN_FILE" 2>/dev/null; then
                printf "${YELLOW}Но он есть в основном re-filter — он туда автоматом${NC}\n"
                printf "${YELLOW}возвращается при обновлении. Чтобы увести его мимо VPN,${NC}\n"
                printf "${YELLOW}используйте: domain.sh bypass %s${NC}\n" "$domain"
            fi
        fi
        ;;







    restore)
        if [ -s "$PERSIST_FILE" ]; then















            _rs_t="/tmp/.enodia-dom-restore.$$"; : > "$_rs_t"; _rs_bad=0; _rs_mig=0
            while IFS= read -r _rl || [ -n "$_rl" ]; do
                case "$_rl" in
                    ipset=/*|address=/*)
                        _rd=$(printf '%s' "$_rl" | sed -E 's|^[a-z]+=/([^/]*)/.*|\1|')
                        if ! dom_ok "$_rd"; then
                            _rs_bad=$((_rs_bad + 1))
                            printf "[domain] выкинул правило, с которым dnsmasq не стартует: %s\n" "$_rd" >&2
                            continue
                        fi ;;
                esac

                case "$_rl" in
                    ipset=/*/awg_list)   _rl="${_rl%/awg_list}/$IPSET_NAME";  _rs_mig=$((_rs_mig + 1)) ;;
                    ipset=/*/awg_bypass) _rl="${_rl%/awg_bypass}/$BYPASS_SET"; _rs_mig=$((_rs_mig + 1)) ;;
                esac
                printf '%s\n' "$_rl" >> "$_rs_t"
            done < "$PERSIST_FILE"







            _rs_want=$(( $(grep -c '' "$PERSIST_FILE" 2>/dev/null) - _rs_bad ))
            _rs_got=$(grep -c '' "$_rs_t" 2>/dev/null)
            if [ "${_rs_got:-0}" = "$_rs_want" ]; then
                cp "$_rs_t" "$CUSTOM_FILE" 2>/dev/null

                if [ "$_rs_bad" != 0 ] || [ "$_rs_mig" != 0 ]; then cp "$_rs_t" "$PERSIST_FILE" 2>/dev/null; fi
                [ "$_rs_mig" = 0 ] || printf "[domain] имена наборов до ребрендинга заменены на текущие: %s\n" "$_rs_mig" >&2
            else
                printf "[domain] фильтр не сошёлся по строкам (%s вместо %s) — кладу персист как есть\n" \
                    "${_rs_got:-0}" "$_rs_want" >&2
                cp "$PERSIST_FILE" "$CUSTOM_FILE" 2>/dev/null
            fi
            rm -f "$_rs_t" 2>/dev/null
            printf "[domain] правила восстановлены из персиста: %s\n" "$(grep -c '^ipset=\|^address=' "$CUSTOM_FILE" 2>/dev/null)"
        else
            printf "[domain] персиста нет или он пуст — живой файл не трогаем\n"
        fi
        ;;




    apply)
        ensure_sets







        rebuild_bypass_set nowarm
        sh "$ENODIA_DIR/apply-bypass.sh" set-dst-ensure "$BYPASS_SET" >/dev/null 2>&1 || true
        n_vpn=$(dom_list "$IPSET_NAME" | grep -c .); n_out=$(dom_list "$BYPASS_SET" | grep -c .)
        printf "[domain] правила доменов: в VPN %s, мимо VPN %s\n" "${n_vpn:-0}" "${n_out:-0}"
        ;;

    list|ls)
        printf "${BLUE}Ваши домены (через AWG):${NC}\n"
        if [ -s "$CUSTOM_FILE" ]; then
            grep "^ipset=" "$CUSTOM_FILE" | sed -E 's|ipset=/([^/]+)/.*|  \1|'
            grep -E "^address=/[^/]+/0\.0\.0\.0$" "$CUSTOM_FILE" | sed -E 's|address=/([^/]+)/.*|  \1 (заблокирован)|'
        else
            printf "  ${YELLOW}(пусто, используется только основной re-filter)${NC}\n"
        fi
        echo ""






        if [ -f "$MAIN_FILE" ]; then
            main_count=$(grep -c "^ipset=" "$MAIN_FILE" 2>/dev/null)
            printf "${BLUE}Основной re-filter:${NC} %s правил\n" "${main_count:-0}"
            printf "  (обновляется ежедневно в 5:00, файл $MAIN_FILE)\n"
        fi
        ipset_cnt=$(ipset list "$IPSET_NAME" 2>/dev/null | grep -c '^[0-9]')
        printf "${BLUE}Сейчас в ipset (резолвлено IP):${NC} %d записей\n" "${ipset_cnt:-0}"
        ;;

    search|find|grep)
        needle="$2"
        if [ -z "$needle" ]; then
            printf "${RED}Укажите что искать:${NC} domain.sh search openai\n"
            exit 1
        fi
        printf "${BLUE}Поиск '%s' в всех списках:${NC}\n" "$needle"
        echo ""





        echo "В вашем списке (enodia-custom.conf):"
        res=$(grep -i "$needle" "$CUSTOM_FILE" 2>/dev/null)
        if [ -n "$res" ]; then printf '%s\n' "$res" | sed 's/^/  /'; else echo "  (нет)"; fi
        echo ""
        echo "В основном re-filter (enodia-domains.conf):"
        res=$(grep -i "$needle" "$MAIN_FILE" 2>/dev/null | head -20)
        if [ -n "$res" ]; then printf '%s\n' "$res" | sed 's/^/  /'; else echo "  (нет)"; fi
        echo ""

        echo "Текущие IP в ipset:"
        ipset list "$IPSET_NAME" 2>/dev/null | grep -E '^[0-9]' | head -10 | sed 's/^/  /'
        ;;





    warm)





        if ! warm_have_work; then
            printf "[domain] доменных правил нет — греть нечего\n"
            exit 0
        fi


        dns_up || printf "[domain] dnsmasq не ответил за 10 с — прогрев может не лечь\n"
        warm "$IPSET_NAME"; warm "$BYPASS_SET"


        warm_rule_sets
        printf "[domain] прогрев доменных правил выполнен\n"
        ;;

    reload)
        reload_dnsmasq flush
        dns_up || printf "${YELLOW}[ ! ] dnsmasq не ответил за 10 с — прогрев может не лечь.${NC}\n"



        warm "$IPSET_NAME"; warm "$BYPASS_SET"
        printf "${GREEN}[ OK ]${NC} dnsmasq перечитан, ipset сброшен и прогрет.\n"
        printf "IP доменов из основного re-filter подъедут при следующих DNS-запросах с клиентов.\n"
        ;;

    *)
        cat <<EOF
Управление списком доменов, идущих через AWG-туннель:

  domain.sh add <домен>       — добавить домен в туннель
  domain.sh add-many          — пачка доменов в туннель из stdin (по домену на строку)
  domain.sh remove <домен>    — убрать домен из пользовательского списка
  domain.sh list              — показать все ваши добавления + статистику
  domain.sh search <строка>   — найти строку во всех списках
  domain.sh reload            — перезагрузить dnsmasq после ручной правки

Примеры:
  domain.sh add chatgpt.com
  domain.sh add my-personal-site.net
  domain.sh remove instagram.com
  domain.sh search youtube
EOF
        ;;
esac
